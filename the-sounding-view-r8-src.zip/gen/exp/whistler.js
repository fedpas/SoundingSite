// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// whistler — one charge in a magnetic field (the gyration, R and L), the branches of a magnetized plasma, and the whistler's falling pitch.
(function () { 'use strict';
  window.SDV_EXP = window.SDV_EXP || {};
  window.SDV_EXP.whistler = { mount: function (root, data, S, kit) {
    var BR = data.branches, MK = data.markers, LIGHT_SLOPE = data.light_slope, ALFVEN_SLOPE = data.alfven_slope, MASS_RATIO = data.mass_ratio, WPE = data.wpe, FCE = data.fce;
    var el = kit.el, ink = kit.ink, mut = kit.muted, acc = kit.accent;
    function T(id, o) { var s = S(id); if (o) for (var q in o) s = s.split('{' + q + '}').join(o[q]); return s; }
    var reduced = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches, paused = reduced;
    var P = { sp: 'e', hand: 'R', om: 0.8, cur: 200, D: 60000, nose: false, oct: false, muted: false };

    // ---- data: break where k falls (a new branch piece starts) ----
    function segs(a) { var s = [], b = 0; for (var i = 1; i < a.length; i++) { if (a[i][1] < a[i - 1][1]) { s.push([b, i - 1]); b = i; } } s.push([b, a.length - 1]); return s; }
    var SEG = {}; for (var n in BR) SEG[n] = segs(BR[n]);
    var R = BR.R, Rseg = SEG.R[0];
    function segOf(name, i) { for (var j = 0; j < SEG[name].length; j++) { var s = SEG[name][j]; if (i >= s[0] && i <= s[1]) return s; } }
    function vgAt(name, i) { var a = BR[name], s = segOf(name, i), i0 = Math.max(s[0], i - 1), i1 = Math.min(s[1], i + 1); return (a[i1][0] - a[i0][0]) / (a[i1][1] - a[i0][1]) / WPE; }
    function a2(name, i) { var p = BR[name][i]; return p[0] / p[1] / WPE; }
    var VG = []; for (var i0 = Rseg[0]; i0 <= Rseg[1]; i0++) VG.push(vgAt('R', i0));
    function vgOmega(w) { if (w < R[Rseg[0]][0] || w > R[Rseg[1]][0]) return null; var lo = Rseg[0], hi = Rseg[1]; while (hi - lo > 1) { var m = (lo + hi) >> 1; if (R[m][0] <= w) lo = m; else hi = m; } var t = (w - R[lo][0]) / (R[hi][0] - R[lo][0]); return VG[lo - Rseg[0]] * (1 - t) + VG[hi - Rseg[0]] * t; }
    var nose = 0.05, vgMax = 0; for (var w0 = 0.05; w0 <= 0.5; w0 += 0.0005) { var v0 = vgOmega(w0); if (v0 > vgMax) { vgMax = v0; nose = w0; } }
    var f3 = function (x) { return x >= 100 || x === 0 ? x.toFixed(0) : x >= 1 ? x.toPrecision(3) : x >= 0.01 ? x.toFixed(3) : x.toExponential(2); };

    // ---- layout ----
    root.classList.add('half');
    var left = el('div'), right = el('div'); right.style.cssText = 'display:flex;flex-direction:column;gap:14px;min-width:0'; left.style.minWidth = '0'; root.appendChild(left); root.appendChild(right);
    var pg = kit.panel_(left, 'exp.whistler.panel.gyr', S), pb = kit.panel_(right, 'exp.whistler.panel.br', S), pw = kit.panel_(right, 'exp.whistler.panel.wh', S);
    function cvas(parent, hWide, hNarrow) { var c = el('canvas', { class: 'exp-canvas' }); parent.appendChild(c); c.hw = hWide; c.hn = hNarrow; return c; }
    function fit(c) { var d = Math.min(window.devicePixelRatio || 1, 2), narrow = c.parentNode.clientWidth < 520; c.style.height = (narrow ? c.hn : c.hw) + 'px'; var w = c.clientWidth, h = c.clientHeight; if (c.width !== Math.round(w * d) || c.height !== Math.round(h * d)) { c.width = Math.round(w * d); c.height = Math.round(h * d); } var g = c.getContext('2d'); g.setTransform(d, 0, 0, d, 0, 0); g.clearRect(0, 0, w, h); g.fillStyle = kit.panel(); g.fillRect(0, 0, w, h); return [g, w, h]; }
    function setLabel(b, id) { b.textContent = S(id); b.setAttribute('data-s', id); }
    function setText(p, id, o) { p.textContent = o ? T(id, o) : S(id); p.setAttribute('data-s', id); }

    // panel 1
    var cg = cvas(pg, 420, 340); cg.setAttribute('aria-label', S('exp.whistler.aria.g'));
    var c1 = kit.controls(pg);
    c1.appendChild(el('span', { class: 'exp-lab', 'data-s': 'exp.whistler.charge', text: S('exp.whistler.charge') }));
    kit.seg(c1, { ids: ['exp.common.electron', 'exp.common.ion'], values: ['e', 'i'], value: 'e', S: S, onchange: function (v) { P.sp = v; resetSim(); updateOmLabel(); gSoundText(); if (gyrOn) startGyr(); } });
    c1.appendChild(el('span', { class: 'exp-lab', 'data-s': 'exp.whistler.turns', text: S('exp.whistler.turns') }));
    kit.seg(c1, { ids: ['exp.whistler.hand.R', 'exp.whistler.hand.L'], values: ['R', 'L'], value: 'R', S: S, onchange: function (v) { P.hand = v; resetSim(); } });
    var c1b = kit.controls(pg);
    var omS = kit.slider(c1b, { id: 'exp.whistler.om.e', S: S, min: 0.1, max: 3, step: 0.01, value: 0.8, fmt: function (v) { return v.toFixed(2); }, onchange: function (v) { P.om = v; } });
    function updateOmLabel() { var id = P.sp === 'i' ? 'exp.whistler.om.i' : 'exp.whistler.om.e', l = omS.el.querySelector('.exp-lab'); l.textContent = S(id); l.setAttribute('data-s', id); }
    var gRead = kit.readout(pg), gSlow = kit.readout(pg);
    kit.line(pg, 'exp.whistler.gcap1', S, 'exp-note'); kit.line(pg, 'exp.whistler.gcap2', S, 'exp-note');
    var c1c = kit.controls(pg);
    var gyrB = kit.button(c1c, 'exp.whistler.gyr', S, function () { if (!kit.audio()) return; if (gyrOn) stopGyr(); else startGyr(); }, 'acc');
    kit.check(c1c, 'exp.whistler.oct', S, false, function (v) { P.oct = v; gSoundText(); });
    var muteB = kit.button(c1c, 'exp.common.mute', S, function () { P.muted = !P.muted; muteB.setAttribute('aria-pressed', String(P.muted)); setLabel(muteB, P.muted ? 'exp.whistler.muted' : 'exp.common.mute'); if (out) out.gain.value = P.muted ? 0 : 0.8; });
    var gSound = kit.line(pg, 'exp.whistler.gsound.e', S, 'exp-note');
    var pauseB = kit.button(c1c, 'exp.common.pause', S, function () { paused = !paused; pauseB.setAttribute('aria-pressed', String(paused)); }); pauseB.setAttribute('aria-pressed', String(paused));

    // panel 2
    var cb = cvas(pb, 360, 320); cb.style.cursor = 'crosshair'; cb.style.touchAction = 'none'; cb.setAttribute('aria-label', S('exp.whistler.aria.b'));
    var curS = kit.slider(pb, { id: 'exp.whistler.cursor', S: S, min: 0, max: R.length - 1, step: 1, value: 200, fmt: function (v) { return String(Math.round(v)); }, onchange: function (v) { P.cur = Math.round(v); } });
    kit.line(pb, 'exp.whistler.hover', S, 'exp-note');
    var bRead = kit.readout(pb), bCap = el('p', { class: 'exp-line' }); pb.appendChild(bCap);
    // panel 3
    var cw = cvas(pw, 230, 400); cw.setAttribute('aria-label', S('exp.whistler.aria.w'));
    var c3 = kit.controls(pw);
    kit.slider(c3, { id: 'exp.whistler.path', S: S, min: 15000, max: 120000, step: 500, value: 60000, fmt: function (v) { return Math.round(v).toLocaleString('en-US') + ' c/ωce'; }, onchange: function (v) { P.D = v; } });
    kit.check(c3, 'exp.whistler.nose', S, false, function (v) { P.nose = v; });
    var whB = kit.button(c3, 'exp.whistler.whistler', S, function () { if (!kit.audio()) return; playWhistler(); });
    var wRead = kit.readout(pw);
    kit.line(pw, 'exp.whistler.wcap1', S); kit.line(pw, 'exp.whistler.wcap2', S, 'exp-note');
    var nasa = el('p', { class: 'exp-line exp-note' }); nasa.appendChild(el('span', { 'data-s': 'exp.whistler.nasa', text: S('exp.whistler.nasa') + ' ' })); nasa.appendChild(el('a', { href: data.nasa_url, text: data.nasa_url })); nasa.setAttribute('data-nasa', '1'); pw.appendChild(nasa);
    var sh = el('div', { class: 'exp-panel span' }); root.appendChild(sh);
    sh.appendChild(el('h3', { 'data-s': 'exp.common.see', text: S('exp.common.see') })); kit.line(sh, 'exp.whistler.see', S);
    sh.appendChild(el('h3', { 'data-s': 'exp.common.hear', text: S('exp.common.hear') })); kit.line(sh, 'exp.whistler.hear', S);

    // ================= panel 1: the gyration =================
    var E0 = 0.06, TAU_RATE = 2 * Math.PI * 0.4, st, tau, trail, resetFlash = 0;
    function resetSim() { st = [0, 0, 0, 0]; tau = 0; trail = []; }
    function deriv(t, y) { var ph = P.om * t, h = P.hand === 'R' ? 1 : -1, Ex = E0 * Math.cos(ph), Ey = E0 * h * Math.sin(ph), s = P.sp === 'e' ? -1 : 1; return [y[2], y[3], s * (Ex + y[3]), s * (Ey - y[2])]; }
    function rk4(t, y, h) { var k1 = deriv(t, y), a = y.map(function (v, i) { return v + h / 2 * k1[i]; }), k2 = deriv(t + h / 2, a), b = y.map(function (v, i) { return v + h / 2 * k2[i]; }), k3 = deriv(t + h / 2, b), c = y.map(function (v, i) { return v + h * k3[i]; }), k4 = deriv(t + h, c); return y.map(function (v, i) { return v + h / 6 * (k1[i] + 2 * k2[i] + 2 * k3[i] + k4[i]); }); }
    function stepSim(dt) { var rem = dt * TAU_RATE; while (rem > 1e-9) { var h = Math.min(0.02, rem); st = rk4(tau, st, h); tau += h; rem -= h; }
      if (Math.hypot(st[0], st[1]) > 2.3) { st[0] = st[1] = st[2] = st[3] = 0; trail = []; resetFlash = 1; }
      trail.push([st[0], st[1]]); if (trail.length > 260) trail.shift(); }
    function drawGyration() {
      var a = fit(cg), g = a[0], w = a[1], h = a[2], i, j;
      var cx = w / 2, cy = h / 2 - 8, sc = Math.min(w, h - 50) / 2 / 2.55;
      g.strokeStyle = mut(); g.fillStyle = mut(); g.lineWidth = 1; g.globalAlpha = 0.6;
      for (i = -2; i <= 2; i++) for (j = -2; j <= 2; j++) { var x = cx + i * sc * 1.05 + sc * 0.5, y = cy - j * sc * 1.05 - sc * 0.5; if (x < 8 || x > w - 8 || y < 8 || y > cy * 2 - 8 + 16) continue; g.beginPath(); g.arc(x, y, 5, 0, 7); g.stroke(); g.beginPath(); g.arc(x, y, 1.5, 0, 7); g.fill(); }
      g.globalAlpha = 1; g.fillStyle = mut(); g.font = '11px system-ui'; g.textAlign = 'left'; g.fillText(S('exp.whistler.cv.g.b'), 8, h - 8);
      g.strokeStyle = mut(); g.globalAlpha = 0.5; g.setLineDash([3, 4]); g.beginPath(); g.arc(cx, cy, 2.3 * sc, 0, 7); g.stroke(); g.setLineDash([]); g.globalAlpha = 1;
      var col = P.sp === 'e' ? kit.blue : kit.warm(); g.lineWidth = 1.6;
      for (i = 1; i < trail.length; i++) { g.strokeStyle = col; g.globalAlpha = i / trail.length * 0.8; g.beginPath(); g.moveTo(cx + trail[i - 1][0] * sc, cy - trail[i - 1][1] * sc); g.lineTo(cx + trail[i][0] * sc, cy - trail[i][1] * sc); g.stroke(); } g.globalAlpha = 1;
      var ph = P.om * tau, hh = P.hand === 'R' ? 1 : -1, ex = Math.cos(ph), ey = hh * Math.sin(ph), L = 46;
      kit.arrow(g, cx, cy, cx + ex * L, cy - ey * L, kit.red, 2.5); g.fillStyle = kit.red; g.fillText('E', cx + ex * (L + 9) - 3, cy - ey * (L + 9) + 4);
      var px = cx + st[0] * sc, py = cy - st[1] * sc, q = P.sp === 'e' ? '−' : '+';
      g.fillStyle = col; g.beginPath(); g.arc(px, py, 8, 0, 7); g.fill(); g.fillStyle = '#fff'; g.font = 'bold 12px system-ui'; g.textAlign = 'center'; g.fillText(q, px, py + 4); g.textAlign = 'left';
      kit.arrow(g, px, py, px + st[2] * sc * 0.9, py - st[3] * sc * 0.9, ink(), 1.2);
      var ke = 0.5 * (st[2] * st[2] + st[3] * st[3]), bx = 12, by = h - 34, bw = w - 24;
      g.fillStyle = mut(); g.globalAlpha = 0.2; g.fillRect(bx, by, bw, 8); g.globalAlpha = 1; g.fillStyle = acc(); g.fillRect(bx, by, bw * Math.min(1, ke / 1.0), 8);
      g.fillStyle = mut(); g.font = '11px system-ui'; g.fillText(S('exp.whistler.cv.g.energy'), bx, by - 4);
      if (resetFlash > 0) { resetFlash -= 0.02; g.globalAlpha = Math.min(1, resetFlash); g.fillStyle = mut(); g.fillText(S('exp.whistler.cv.g.reset'), bx, 16); g.globalAlpha = 1; }
    }
    function gyrText() {
      var ion = P.sp === 'i', ci = 1 / MASS_RATIO, omce = ion ? P.om * ci : P.om;
      var co = (P.sp === 'e' && P.hand === 'R') || (P.sp === 'i' && P.hand === 'L'), res = co && Math.abs(P.om - 1) < 0.04;
      var slow = (ion ? FCE / MASS_RATIO : (P.oct ? FCE / 8 : FCE)) / 0.4;
      var t = T('exp.whistler.gread', { w: omce >= 0.01 ? omce.toFixed(3) : omce.toExponential(2), turn: S(P.hand === 'R' ? 'exp.whistler.turn.e' : 'exp.whistler.turn.i'), state: S(res ? 'exp.whistler.st.res' : co ? 'exp.whistler.st.beat' : 'exp.whistler.st.opp') });
      if (gRead.textContent !== t) gRead.textContent = t;
      var t2 = T('exp.common.slowed', { n: slow >= 100 ? slow.toFixed(0) : slow.toFixed(1) }); if (gSlow.textContent !== t2) gSlow.textContent = t2;
    }
    function gSoundText() { var id = P.sp === 'i' ? 'exp.whistler.gsound.i' : P.oct ? 'exp.whistler.gsound.e.oct' : 'exp.whistler.gsound.e'; setText(gSound, id, { hz: (FCE / MASS_RATIO).toFixed(2) }); }

    // ================= panel 2: the branches =================
    var XR = [3e-4, 20], YR = [1e-5, 12], bGeo = {};
    function lx(k, G) { return G.l + (Math.log(k) - Math.log(XR[0])) / (Math.log(XR[1]) - Math.log(XR[0])) * (G.r - G.l); }
    function ly(w, G) { return G.b - (Math.log(w) - Math.log(YR[0])) / (Math.log(YR[1]) - Math.log(YR[0])) * (G.b - G.t); }
    var STY = { R: { w: 2.6, d: [] }, L: { w: 1.6, d: [] }, X: { w: 1.5, d: [6, 3] }, O: { w: 1.5, d: [1.5, 3] } };
    function line(g, G, fn, col) { g.strokeStyle = col; g.beginPath(); var m = false; for (var e = -3.52; e <= 1.3; e += 0.05) { var k = Math.pow(10, e), x = lx(k, G), y = ly(fn(k), G); if (m) g.lineTo(x, y); else { g.moveTo(x, y); m = true; } } g.stroke(); }
    function lab(g, G, t, p, col, dx, dy) { g.fillStyle = col; g.fillText(t, Math.min(lx(p[1], G) + dx, G.r - 12), ly(p[0], G) + dy); }
    function drawBranches() {
      var a = fit(cb), g = a[0], w = a[1], h = a[2], G = bGeo = { l: 44, r: w - 64, t: 12, b: h - 34 }, e, n;
      var cols = { R: kit.blue, L: ink(), X: mut(), O: mut() };
      g.font = '11px system-ui'; g.lineWidth = 1;
      for (e = -5; e <= 1; e++) { var y = ly(Math.pow(10, e), G); g.strokeStyle = mut(); g.globalAlpha = 0.2; g.beginPath(); g.moveTo(G.l, y); g.lineTo(G.r, y); g.stroke(); g.globalAlpha = 1; g.fillStyle = mut(); g.textAlign = 'right'; g.fillText('1e' + e, G.l - 4, y + 3); }
      for (e = -3; e <= 1; e++) { var x = lx(Math.pow(10, e), G); g.strokeStyle = mut(); g.globalAlpha = 0.2; g.beginPath(); g.moveTo(x, G.t); g.lineTo(x, G.b); g.stroke(); g.globalAlpha = 1; g.fillStyle = mut(); g.textAlign = 'center'; g.fillText('1e' + e, x, G.b + 13); }
      g.strokeStyle = mut(); g.strokeRect(G.l, G.t, G.r - G.l, G.b - G.t);
      g.fillStyle = ink(); g.textAlign = 'center'; g.fillText(S('exp.whistler.cv.b.k'), (G.l + G.r) / 2, h - 4);
      g.save(); g.translate(11, (G.t + G.b) / 2); g.rotate(-Math.PI / 2); g.fillText(S('exp.whistler.cv.b.w'), 0, 0); g.restore();
      g.save(); g.beginPath(); g.rect(G.l, G.t, G.r - G.l, G.b - G.t); g.clip();
      g.lineWidth = 1; g.setLineDash([2, 3]); line(g, G, function (k) { return LIGHT_SLOPE * k; }, kit.warm()); line(g, G, function (k) { return ALFVEN_SLOPE * k; }, kit.violet); g.setLineDash([]);
      ['O', 'X', 'L', 'R'].forEach(function (nm) { var s = STY[nm]; g.strokeStyle = cols[nm]; g.lineWidth = s.w; g.setLineDash(s.d);
        SEG[nm].forEach(function (sg) { g.beginPath(); for (var i = sg[0]; i <= sg[1]; i++) { var x = lx(BR[nm][i][1], G), y = ly(BR[nm][i][0], G); if (i === sg[0]) g.moveTo(x, y); else g.lineTo(x, y); } g.stroke(); }); });
      g.setLineDash([]);
      if (P.sp === 'e') { var yd = ly(P.om, G); g.strokeStyle = kit.red; g.globalAlpha = 0.55; g.lineWidth = 1; g.setLineDash([5, 3]); g.beginPath(); g.moveTo(G.l, yd); g.lineTo(G.r, yd); g.stroke(); g.setLineDash([]); g.globalAlpha = 1; }
      var p = R[P.cur], cxp = lx(p[1], G), cyp = ly(p[0], G);
      g.fillStyle = kit.panel(); g.strokeStyle = kit.blue; g.lineWidth = 2.2; g.beginPath(); g.arc(cxp, cyp, 5.5, 0, 7); g.fill(); g.stroke(); g.restore();
      g.textAlign = 'left'; g.font = 'bold 11px system-ui';
      lab(g, G, 'R', R[Rseg[1]], kit.blue, 6, -2); lab(g, G, 'L', BR.L[SEG.L[0][1]], ink(), 6, -4); lab(g, G, 'X', BR.X[BR.X.length - 1], mut(), -10, 12); lab(g, G, 'O', BR.O[BR.O.length - 1], mut(), -10, -6);
      g.font = '10px system-ui'; g.fillStyle = kit.warm(); g.fillText(S('exp.whistler.cv.b.light'), lx(0.0035, G) - 6, ly(LIGHT_SLOPE * 0.0035, G) - 6);
      g.fillStyle = kit.violet; g.fillText(S('exp.whistler.cv.b.alf'), lx(0.0008, G) + 8, ly(ALFVEN_SLOPE * 0.0008, G) + 14);
      var names = [['ωci', MK.omega_ci], ['ωLH', MK.omega_LH], ['ωce', MK.omega_ce], ['ωL', MK.omega_L], ['ωUH', MK.omega_UH], ['ωR', MK.omega_R]];
      var last = 1e9, pos = names.map(function (n) { return { n: n[0], v: n[1], y: ly(n[1], G) }; }).sort(function (a, b) { return b.y - a.y; });
      pos.forEach(function (m) { m.ly = Math.min(m.y, last - 11); last = m.ly; });
      g.font = '11px system-ui'; g.textAlign = 'left';
      pos.forEach(function (m) { g.strokeStyle = ink(); g.lineWidth = 1.2; g.beginPath(); g.moveTo(G.r, m.y); g.lineTo(G.r + 5, m.y); g.lineTo(G.r + 9, m.ly); g.stroke(); g.fillStyle = ink(); g.fillText(m.n, G.r + 11, m.ly + 4); });
      var i = P.cur, sg = segOf('R', i), vg = vgAt('R', i), vph = a2('R', i);
      var t = T('exp.whistler.bread', { k: f3(p[1]), w: f3(p[0]), vph: f3(vph), vg: f3(vg), part: S(sg === SEG.R[0] ? 'exp.whistler.part.w' : 'exp.whistler.part.u') });
      if (bRead.textContent !== t) bRead.textContent = t;
    }
    (function () { var rmax = R[Rseg[1]], lmax = BR.L[SEG.L[0][1]];
      bCap.textContent = T('exp.whistler.bcap', { rw: rmax[0].toFixed(4), rk: rmax[1].toFixed(2), cim: MK.omega_ci.toExponential(3), lw: lmax[0].toExponential(3), lk: lmax[1].toFixed(3), wR: MK.omega_R.toFixed(3), alf: ALFVEN_SLOPE.toFixed(5), wpe: MK.omega_pe_prime.toFixed(4) }); bCap.setAttribute('data-s', 'exp.whistler.bcap'); })();
    function nearest(mx, my) { var best = -1, bd = 900; for (var i = 0; i < R.length; i++) { var dx = lx(R[i][1], bGeo) - mx, dy = ly(R[i][0], bGeo) - my, d = dx * dx + dy * dy; if (d < bd) { bd = d; best = i; } } return best; }
    function hover(e) { var r = cb.getBoundingClientRect(), i = nearest(e.clientX - r.left, e.clientY - r.top); if (i >= 0) { P.cur = i; curS.set(i); } }
    cb.addEventListener('pointermove', hover); cb.addEventListener('pointerdown', hover);

    // ================= panel 3: the whistler =================
    var NC = 60, wPlay = null;
    function band() { var fmax = P.nose ? nose : 0.5, fs = []; for (var i = 0; i < NC; i++) fs.push(0.05 * Math.pow(fmax / 0.05, i / (NC - 1))); return fs; }
    function delays() { var fs = band(), tt = fs.map(function (f) { return P.D / vgOmega(f) / (2 * Math.PI * FCE); }), t0 = Math.min.apply(null, tt); return { fs: fs, tt: tt, t0: t0, span: Math.max.apply(null, tt) - t0 }; }
    function drawWhistler() {
      var a = fit(cw), g = a[0], w = a[1], h = a[2], d = delays(), wide = w > 600, pad = 44, i;
      var A = wide ? { l: pad, r: w / 2 - 14, t: 14, b: h - 34 } : { l: pad, r: w - 14, t: 12, b: h / 2 - 30 };
      var B = wide ? { l: w / 2 + pad, r: w - 12, t: 14, b: h - 34 } : { l: pad, r: w - 14, t: h / 2 + 12, b: h - 30 };
      g.font = '11px system-ui'; g.lineWidth = 1; g.strokeStyle = mut(); g.strokeRect(A.l, A.t, A.r - A.l, A.b - A.t);
      var fmax = P.nose ? nose : 0.5;
      var ts = d.tt, tlo = Math.min.apply(null, ts), thi = Math.max.apply(null, ts), pr = (thi - tlo) || 1, ta = tlo - 0.1 * pr, tb = thi + 0.1 * pr;
      var ax = function (f) { return A.l + (Math.log(f) - Math.log(0.05)) / (Math.log(0.5) - Math.log(0.05)) * (A.r - A.l); }, ay = function (t) { return A.b - (t - ta) / (tb - ta) * (A.b - A.t); };
      g.fillStyle = ink(); g.textAlign = 'center'; g.fillText(S('exp.whistler.cv.w.f'), (A.l + A.r) / 2, A.b + 26);
      [0.05, 0.1, 0.2, 0.5].forEach(function (f) { g.fillStyle = mut(); g.fillText(f, ax(f), A.b + 12); g.strokeStyle = mut(); g.globalAlpha = 0.2; g.beginPath(); g.moveTo(ax(f), A.t); g.lineTo(ax(f), A.b); g.stroke(); g.globalAlpha = 1; });
      g.strokeStyle = kit.blue; g.lineWidth = 2.4; g.beginPath(); d.fs.forEach(function (f, i) { var x = ax(f), y = ay(d.tt[i]); if (i) g.lineTo(x, y); else g.moveTo(x, y); }); g.stroke();
      if (!P.nose && nose < 0.5) { var x = ax(nose); g.strokeStyle = kit.red; g.setLineDash([3, 3]); g.lineWidth = 1; g.beginPath(); g.moveTo(x, A.t); g.lineTo(x, A.b); g.stroke(); g.setLineDash([]); g.fillStyle = kit.red; g.textAlign = 'left'; g.fillText(T('exp.whistler.cv.w.nose', { n: nose.toFixed(2) }), x + 4, A.t + 11); }
      g.fillStyle = ink(); g.textAlign = 'left'; g.fillText(S('exp.whistler.cv.w.t'), A.l + 4, A.t + (nose < 0.5 && !P.nose ? 24 : 11));
      g.save(); g.translate(11, (A.t + A.b) / 2); g.rotate(-Math.PI / 2); g.textAlign = 'center'; g.fillStyle = ink(); g.fillText(S('exp.whistler.cv.w.ts'), 0, 0); g.restore();
      g.textAlign = 'right'; g.fillStyle = mut(); g.fillText(tlo.toFixed(2), A.l - 3, ay(tlo) + 3); g.fillText(thi.toFixed(2), A.l - 3, ay(thi) + 3);
      var Tt = d.span + 0.6, bx = function (t) { return B.l + (t - d.t0 + 0.1) / Tt * (B.r - B.l); }, fy = function (f) { return B.b - (Math.log(f) - Math.log(400)) / (Math.log(4000) - Math.log(400)) * (B.b - B.t); };
      g.strokeStyle = mut(); g.strokeRect(B.l, B.t, B.r - B.l, B.b - B.t);
      g.fillStyle = mut(); g.textAlign = 'right'; [400, 1000, 2000, 4000].forEach(function (f) { g.fillText(f, B.l - 3, fy(f) + 3); g.strokeStyle = mut(); g.globalAlpha = 0.2; g.beginPath(); g.moveTo(B.l, fy(f)); g.lineTo(B.r, fy(f)); g.stroke(); g.globalAlpha = 1; });
      g.textAlign = 'center'; g.fillStyle = ink(); g.fillText(S('exp.whistler.cv.w.time'), (B.l + B.r) / 2, B.b + 26);
      g.save(); g.translate(B.l - 33, (B.t + B.b) / 2); g.rotate(-Math.PI / 2); g.fillText(S('exp.whistler.cv.w.hz'), 0, 0); g.restore();
      for (i = 0; i < NC; i++) { var f = d.fs[i] * FCE, x1 = bx(d.tt[i]), x2 = bx(d.tt[i] + 0.2), y = fy(f); var gr = g.createLinearGradient(x1, 0, x2, 0); gr.addColorStop(0, kit.blue); gr.addColorStop(1, 'rgba(43,95,158,0)'); g.strokeStyle = gr; g.lineWidth = 3; g.beginPath(); g.moveTo(x1, y); g.lineTo(x2, y); g.stroke(); }
      for (var t = 0; t <= Tt - 0.3; t += (Tt > 3 ? 1 : 0.5)) { g.fillStyle = mut(); g.textAlign = 'center'; g.fillText(t.toFixed(1), bx(t + d.t0), B.b + 12); }
      if (wPlay) { var el_ = (performance.now() - wPlay.t0) / 1000 - wPlay.lead, xx = bx(d.t0 + el_); if (xx <= B.r + 1 && xx >= B.l) { g.strokeStyle = kit.red; g.lineWidth = 1.5; g.beginPath(); g.moveTo(xx, B.t); g.lineTo(xx, B.b); g.stroke(); } else if (xx > B.r + 30) wPlay = null; }
      var vmin = Math.min.apply(null, d.fs.map(vgOmega));
      var tx = T('exp.whistler.wread', { D: P.D.toLocaleString('en-US'), span: d.span.toFixed(2), lo: tlo.toFixed(2), hi: thi.toFixed(2), f0: String(0.05 * FCE), f1: String(Math.round(fmax * FCE)), v0: vmin.toFixed(3), v1: vgMax.toFixed(3), nose: nose.toFixed(3), nhz: String(Math.round(nose * FCE)) });
      if (wRead.textContent !== tx) wRead.textContent = tx;
    }

    // ================= sound =================
    var out = null, gyr = null, gyrOn = false, clickAcc = [0, 0];
    function ensure() { var a = kit.audio(); if (!a) return null; if (!out) { out = a.ctx.createGain(); out.gain.value = P.muted ? 0 : 0.8; out.connect(a.master); } return a; }
    function startGyr() { var a = ensure(); if (!a) return; stopGyr(); var ctx = a.ctx; gyr = {};
      if (P.sp !== 'i') { gyr.o1 = ctx.createOscillator(); gyr.g1 = ctx.createGain(); gyr.o2 = ctx.createOscillator(); gyr.g2 = ctx.createGain(); gyr.g1.gain.value = 0; gyr.g2.gain.value = 0; gyr.o1.connect(gyr.g1); gyr.g1.connect(out); gyr.o2.connect(gyr.g2); gyr.g2.connect(out); gyr.o1.start(); gyr.o2.start(); }
      gyrOn = true; gyrB.setAttribute('aria-pressed', 'true'); setLabel(gyrB, 'exp.whistler.gyr.on'); }
    function stopGyr() { if (gyr) { ['o1', 'o2'].forEach(function (k) { if (gyr[k]) { try { gyr[k].stop(); } catch (e) { } } }); gyr = null; } gyrOn = false; gyrB.setAttribute('aria-pressed', 'false'); setLabel(gyrB, 'exp.whistler.gyr'); }
    function click(freq, amp) { var a = kit.audio(); if (!a || !out) return; var t = a.ctx.currentTime, o = a.ctx.createOscillator(), g = a.ctx.createGain(); o.frequency.value = freq; g.gain.setValueAtTime(Math.min(0.3, amp), t); g.gain.exponentialRampToValueAtTime(0.0005, t + 0.03); o.connect(g); g.connect(out); o.start(t); o.stop(t + 0.04); }
    function gyrAudio(dt) { if (!gyrOn || !gyr) return; var a = kit.audio(); if (!a) return; var v = Math.hypot(st[2], st[3]), amp = Math.min(1, v / 1.2);
      if (P.sp === 'e') { var fc = P.oct ? FCE / 8 : FCE, fd = P.om * fc, t = a.ctx.currentTime;
        gyr.o1.frequency.setTargetAtTime(fc, t, 0.02); gyr.o2.frequency.setTargetAtTime(Math.min(fd, 20000), t, 0.02);
        gyr.g1.gain.setTargetAtTime(0.03 + 0.22 * amp, t, 0.05); gyr.g2.gain.setTargetAtTime(fd <= 16000 ? 0.04 : 0, t, 0.05); }
      else { var fi = FCE / MASS_RATIO; clickAcc[0] += fi * dt; clickAcc[1] += fi * P.om * dt; if (clickAcc[0] >= 1) { clickAcc[0] -= 1; click(650, 0.15 + 0.15 * amp); } if (clickAcc[1] >= 1) { clickAcc[1] -= 1; click(1300, 0.09); } } }
    function playWhistler() { var a = ensure(); if (!a) return; var d = delays(), t0 = a.ctx.currentTime + 0.08;
      for (var i = 0; i < NC; i++) { var f = d.fs[i] * FCE, t = t0 + (d.tt[i] - d.t0), o = a.ctx.createOscillator(), g = a.ctx.createGain();
        o.frequency.value = f; g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.045, t + 0.006); g.gain.setTargetAtTime(0, t + 0.006, 0.2 / 4); o.connect(g); g.connect(out); o.start(t); o.stop(t + 0.35); }
      wPlay = { t0: performance.now(), lead: 0.08 }; }

    resetSim(); gSoundText();
    kit.loop(function (t, dt) { if (!paused) stepSim(dt); gyrAudio(dt); drawGyration(); drawBranches(); drawWhistler(); gyrText(); });
  } };
})();
