// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// violinbody.js — The violin in motion: the photograph scored, the post converged, Schelleng's diagram computed, the wolf in
// time, the violin-shaped plate, the box (MUS-231 … MUS-237). Draws the data's arrays; plays the data's waveforms and envelopes.
(function () {
  'use strict';
  window.SDV_EXP = window.SDV_EXP || {};
  window.SDV_EXP['violinbody'] = { mount: function (root, data, S, kit) {
    var P = 'exp.violinbody.', el = kit.el, TAU = Math.PI * 2;
    var reduce = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    var PH = data.photo, PO = data.post, BR = data.bridge, SC = data.schelleng_sim, WO = data.wolf_sim, VP = data.vplate, BX = data.box, HZ = data.violin_plate_hz_per_lambda2;
    var st = { t: 0, paused: reduce, cand: 0, lam: 3, bi: 7, fi: 9, wf: 'helmholtz', body: 'string', plate: 'back_maple_3mm', pm: 0, cfg: 'bar+post' };
    // ------------------------------------------------------------ helpers (after the violin module's)
    function grid(parent, min) { var d = el('div'); d.style.cssText = 'display:grid;grid-template-columns:repeat(auto-fit,minmax(' + (min || 250) + 'px,1fr));gap:12px;align-items:start'; parent.appendChild(d); return d; }
    function cv(parent, a, m) { var d = el('div'); parent.appendChild(d); return kit.canvas(d, a, m); }
    function txt(c, s, x, y, color, align, size) { c.fillStyle = color || kit.muted(); c.textAlign = align || 'left'; c.font = (size || 11) + 'px system-ui, sans-serif'; c.fillText(s, x, y); }
    function fill(s, o) { for (var k in o) s = s.split('{' + k + '}').join(o[k]); return s; }
    function R(id, o) { return fill(S(P + id), o || {}); }
    function line(parent, id) { return kit.line(parent, P + id, S); }
    function show(e, on) { (e.el || e).style.display = on ? '' : 'none'; }
    function n(v, d) { return v == null ? '—' : kit.num(v, d); }
    function sig(v, d) { return Number(v).toPrecision(d); }
    function key(o, re) { if (!o || typeof o !== 'object') return null; for (var k in o) if (re.test(k)) return k; return null; }   // a key that may or may not be in the data
    function pair(a, d) { return Array.isArray(a) ? n(a[0], d) + '–' + n(a[1], d) : n(a, d); }
    function dots(c, pts, X, Y, color, r) { c.fillStyle = color; pts.forEach(function (p) { c.beginPath(); c.arc(X(p[0]), Y(p[1]), r || 3, 0, TAU); c.fill(); }); }
    function vline(c, x, t, b, color, dash) { c.strokeStyle = color; c.lineWidth = 1; c.setLineDash(dash || []); c.beginPath(); c.moveTo(x, t); c.lineTo(x, b); c.stroke(); c.setLineDash([]); }
    function table(parent, heads, rows) {
      var t = el('table'); t.style.cssText = 'border-collapse:collapse;font-size:12.5px;font-variant-numeric:tabular-nums;margin:8px 0 0;width:100%';
      var tr = el('tr'); heads.forEach(function (h) { var th = el('th', { 'data-s': P + h, text: S(P + h) }); th.style.cssText = 'text-align:left;padding:3px 6px;border-bottom:1px solid var(--rule);color:var(--ink-2);font-weight:500'; tr.appendChild(th); }); t.appendChild(tr);
      var trs = rows.map(function (r) { var row = el('tr'); r.forEach(function (x) { var td = el('td'); if (x && x.sid) { td.setAttribute('data-s', x.sid); td.textContent = S(x.sid); } else td.textContent = x; td.style.cssText = 'padding:3px 6px;border-bottom:1px solid var(--rule-2)'; row.appendChild(td); }); t.appendChild(row); return row; });
      var wrap = el('div'); wrap.style.overflowX = 'auto'; wrap.appendChild(t); parent.appendChild(wrap); return trs;
    }
    // ------------------------------------------------------------ one sound for the whole experiment
    var SND = null, noAudio = null;
    function setBtn(b, on, idOff) { var id = on ? 'exp.common.mute' : idOff; b.textContent = S(id); b.setAttribute('data-s', id); }
    function stopSnd() { if (SND) { try { SND.stop(); } catch (e) { } if (SND.btn) setBtn(SND.btn, false, SND.idOff); SND = null; } }
    function noA() { if (!noAudio) noAudio = kit.line(root, 'exp.common.noaudio', S); }
    function toggle(kind, btn, idOff, start) {
      if (SND && SND.kind === kind) { stopSnd(); return; }
      stopSnd(); var a = kit.audio(); if (!a) { noA(); return; }
      var s = start(a); SND = { kind: kind, btn: btn, idOff: idOff, stop: s.stop, upd: s.upd, t0: s.t0 }; setBtn(btn, true, idOff);
    }
    function upd(kind) { if (SND && SND.kind === kind && SND.upd) SND.upd(); }
    function strike(parts, gain) { stopSnd(); var a = kit.audio(); if (!a) { noA(); return; } kit.strike(parts, gain); }
    // three peaking filters at the body's bands, as the violin module has them (280, 455, 545 Hz, Q 15, +12 dB: a setting)
    function bodyChain(ctx, input) { var node = input; [280, 455, 545].forEach(function (f) { var q = ctx.createBiquadFilter(); q.type = 'peaking'; q.frequency.value = f; q.Q.value = 15; q.gain.value = 12; node.connect(q); node = q; }); return node; }

    // ================================================================ (i) the photograph scored (MUS-231)
    var p1 = kit.panel_(root, P + 'panel.photo', S), g1 = grid(p1, 260);
    var cPh = cv(g1, 1, 380), side1 = el('div'); g1.appendChild(side1);
    var CAND = PH.candidates.map(function (c, i) { return { c: c, i: i }; }).sort(function (a, b) { var x = a.c.score_sand_to_nodal, y = b.c.score_sand_to_nodal; return (x == null ? 1e9 : x) - (y == null ? 1e9 : y); });
    function candKey(name) { var m = /^(held|free) SS (\d)/.exec(name); if (m) return m[1] + m[2]; if (/W1/.test(name)) return 'w1'; if (/twist/.test(name)) return 'twist'; return 'other'; }
    var k1 = kit.controls(p1);
    kit.button(k1, 'exp.common.strike', S, function () { var hs = PO.interlacing.held; strike(hs.map(function (l, i) { return { f: l * HZ, a: i === 2 ? 1 : 0.45, decay: 1.2 }; }), 0.2); });
    var segC = kit.seg(kit.controls(p1), { S: S, ids: CAND.map(function (x) { return P + 'cand.' + candKey(x.c.name); }), values: CAND.map(function (x, i) { return i; }), value: 0, onchange: function (v) { st.cand = v; drawPhoto(); markRow(); } });
    var rowsC = table(side1, ['th.cand', 'th.l2', 'th.a', 'th.b'], CAND.map(function (x) { return [{ sid: P + 'cand.' + candKey(x.c.name) }, n(x.c.lambda2, 4), n(x.c.score_sand_to_nodal, 4), n(x.c.score_nodal_to_sand, 4)]; }));
    line(side1, 'tab.note');
    function markRow() { rowsC.forEach(function (r, i) { r.style.fontWeight = i === 0 ? '700' : '400'; r.style.color = i === 0 ? kit.accent() : ''; r.style.background = i === st.cand ? 'var(--accent-tint)' : ''; }); }
    var rPh1 = kit.readout(p1), rPh2 = kit.readout(p1);
    ['cap.photo1', 'cap.photo2', 'cap.photo3', 'hear.photo'].forEach(function (k) { line(p1, k); });
    function readPhoto() {
      rPh1.textContent = R('ph.rd1', { n: String(PH.sand_count), s: String(PH.sand_uv.length), m1: n(PH.midline_crossings[0], 2), m2: n(PH.midline_crossings[1], 2), r: String(PH.ring_count) });
      rPh2.textContent = R('ph.rd2', { d: n(PH.diagonal_fraction, 5), a: n(PH.axis_fraction, 4), h: PO.interlacing.held.map(function (l) { return n(l * HZ, 1); }).join(', '), k: n(HZ, 4) });
    }
    function drawPhoto() {
      var c = cPh.ctx, w = cPh.w, h = cPh.h, sd = Math.min(w, h) - 40, ox = (w - sd) / 2 + 8, oy = 8; c.clearRect(0, 0, w, h);
      var X = function (u) { return ox + (u + 1) / 2 * sd; }, Y = function (v) { return oy + (1 - v) / 2 * sd; }, G = PH.grid, cand = CAND[st.cand].c;
      c.fillStyle = 'rgba(43,95,158,0.28)';
      cand.nodal_cells.forEach(function (ab) { var a = ab[0], b = ab[1]; c.fillRect(X(G[a]), Y(G[b + 1]), X(G[a + 1]) - X(G[a]) + 0.5, Y(G[b]) - Y(G[b + 1]) + 0.5); });
      c.fillStyle = kit.warm(); PH.sand_uv.forEach(function (p) { c.fillRect(X(p[0]) - 1, Y(p[1]) - 1, 2.2, 2.2); });
      c.strokeStyle = kit.ink(); c.lineWidth = 1.2; c.strokeRect(X(-1), Y(1), sd, sd);
      c.fillStyle = kit.ink(); c.beginPath(); c.arc(X(0), Y(0), 3, 0, TAU); c.fill();
      txt(c, 'u', X(1), Y(-1) + 14, kit.muted(), 'right', 10); txt(c, 'v', X(-1) - 4, Y(1) + 8, kit.muted(), 'right', 10);
      if (!cand.nodal_cells.length) txt(c, S(P + 'cv.nocell'), X(0), Y(0.9), kit.ink(), 'center', 12);
      txt(c, S(P + 'cv.sand'), X(-1), h - 6, kit.warm(), 'left', 10); txt(c, S(P + 'cv.cells'), X(1), h - 6, kit.blue, 'right', 10);
    }

    // ================================================================ (ii) the post converged (MUS-232)
    var p2 = kit.panel_(root, P + 'panel.post', S), cQ = cv(p2, window.innerWidth < 600 ? 0.8 : 0.45, 300), cI = cv(p2, window.innerWidth < 600 ? 0.3 : 0.16, 90);
    var L2 = PO.lambda2, byN = function (o) { return Object.keys(o).sort(function (a, b) { return +a - +b; }); }, NS = byN(PO.Q_products), NG = byN(PO.Q_singular);
    kit.slider(kit.controls(p2), { S: S, id: P + 'lam', min: 0, max: L2.length - 1, step: 1, value: st.lam, fmt: function (v) { return kit.num(L2[Math.round(v)], 1); }, onchange: function (v) { st.lam = Math.round(v); readPost(); drawPost(); } });
    var rQ1 = kit.readout(p2), rQ2 = kit.readout(p2), rQ3 = kit.readout(p2);
    ['cap.post1', 'cap.post2', 'cap.post3', 'hear.post'].forEach(function (k) { line(p2, k); });
    var Q0 = 1e-4; function ash(q) { return Math.asinh(q / Q0); }   // a signed log scale for the drawing: asinh(Q / 10⁻⁴)
    function readPost() {
      var i = st.lam, d = PO.digits[i];
      rQ1.textContent = R('post.rd1', { l: n(L2[i], 1), p: NS.map(function (k) { return 'N = ' + k + ': ' + sig(PO.Q_products[k][i], 6); }).join(' · ') });
      rQ2.textContent = R('post.rd2', { s: NG.map(function (k) { return 'N = ' + k + ': ' + sig(PO.Q_singular[k][i], 6); }).join(' · '), q: sig(PO.Q_singular[NG[NG.length - 1]][i], d), d: String(d) });
      var I = PO.interlacing; rQ3.textContent = R('post.rd3', { c: I['class'], f: I.free.join(', '), h: I.held.join(', '), b: S(P + (I.brackets_hold ? 'post.hold' : 'post.nohold')) });
    }
    function drawPost() {
      var c = cQ.ctx, w = cQ.w, h = cQ.h, box = { l: 62, r: w - 12, t: 12, b: h - 34 }; c.clearRect(0, 0, w, h);
      var all = []; NS.forEach(function (k) { all = all.concat(PO.Q_products[k]); }); NG.forEach(function (k) { all = all.concat(PO.Q_singular[k]); });
      var ym = ash(Math.max.apply(null, all.map(Math.abs))) * 1.08;
      var ax = kit.axes(c, box, { xmin: 0, xmax: 70, ymin: -ym, ymax: ym, xticks: [0, 10, 20, 30, 40, 50, 60, 70], xlabel: S(P + 'cv.lam2') });
      [-1e-2, -1e-3, 0, 1e-3, 1e-2, 1e-1].forEach(function (q) { var y = ax.y(ash(q)); if (y < box.t || y > box.b) return; c.strokeStyle = 'rgba(0,0,0,0.06)'; c.beginPath(); c.moveTo(box.l, y); c.lineTo(box.r, y); c.stroke(); txt(c, q === 0 ? '0' : (q < 0 ? '−' : '') + '10^' + Math.round(Math.log10(Math.abs(q))), box.l - 5, y + 4, kit.muted(), 'right', 10); });
      txt(c, S(P + 'cv.q'), box.l + 4, box.t + 10, kit.muted(), 'left', 10);
      var cols = ['#9aa19d', '#4a6b8a', kit.violet, '#1f8a6e', kit.ink()];
      NS.forEach(function (k, j) { var pp = L2.map(function (l, i) { return [l, ash(PO.Q_products[k][i])]; }); kit.curve(c, pp, ax.x, ax.y, kit.warm(), 1 + 0.4 * j, [2, 3]); dots(c, pp, ax.x, ax.y, kit.warm(), 2); });
      NG.forEach(function (k, j) { var ps = L2.map(function (l, i) { return [l, ash(PO.Q_singular[k][i])]; }), cl = cols[(cols.length - NG.length + j + cols.length) % cols.length]; kit.curve(c, ps, ax.x, ax.y, cl, 1 + 0.3 * j); dots(c, ps, ax.x, ax.y, cl, 2.5); txt(c, 'N = ' + k, box.r - 4, box.t + 12 + 13 * j, cl, 'right', 10); });
      txt(c, S(P + 'cv.prod') + ' (N = ' + NS.join(', ') + ')', box.r - 4, box.t + 12 + 13 * NG.length, kit.warm(), 'right', 10); txt(c, S(P + 'cv.sing'), box.r - 4, box.t + 25 + 13 * NG.length, kit.ink(), 'right', 10);
      vline(c, ax.x(L2[st.lam]), box.t, box.b, kit.accent(), [3, 3]);
      // the interlacing: free values as ticks, held values as dots inside their brackets
      var I = PO.interlacing, ci = cI.ctx, wi = cI.w, hi = cI.h, x0 = 20, x1 = wi - 20, top = Math.max.apply(null, I.free) * 1.04, XI = function (v) { return x0 + v / top * (x1 - x0); }, yl = hi * 0.55; ci.clearRect(0, 0, wi, hi);
      ci.strokeStyle = kit.muted(); ci.lineWidth = 1; ci.beginPath(); ci.moveTo(x0, yl); ci.lineTo(x1, yl); ci.stroke();
      I.held.forEach(function (v, k) { if (k + 1 >= I.free.length) return; ci.strokeStyle = kit.accent(); ci.globalAlpha = 0.35; ci.lineWidth = 6; ci.beginPath(); ci.moveTo(XI(I.free[k]), yl - 9 - (k % 2) * 4); ci.lineTo(XI(I.free[k + 1]), yl - 9 - (k % 2) * 4); ci.stroke(); ci.globalAlpha = 1; });
      I.free.forEach(function (v) { ci.strokeStyle = kit.ink(); ci.lineWidth = 2; ci.beginPath(); ci.moveTo(XI(v), yl - 8); ci.lineTo(XI(v), yl + 8); ci.stroke(); txt(ci, String(v), XI(v), yl + 21, kit.ink(), 'center', 10); });
      I.held.forEach(function (v) { ci.fillStyle = kit.red; ci.beginPath(); ci.arc(XI(v), yl, 4.5, 0, TAU); ci.fill(); txt(ci, String(v), XI(v), yl - 16, kit.red, 'center', 10); });
      txt(ci, S(P + 'cv.free'), x0, 11, kit.ink(), 'left', 10); txt(ci, S(P + 'cv.held'), x1, 11, kit.red, 'right', 10);
    }

    // ================================================================ (iii) Schelleng's diagram computed (MUS-234)
    var p3 = kit.panel_(root, P + 'panel.schelleng', S), g3 = grid(p3);
    var cR = cv(g3, 0.85, 340), cWf = cv(g3, 0.85, 340), ST_ = SC.settings, BE = SC.beta, FF = SC.F, k3 = kit.controls(p3);
    var playB = kit.button(k3, 'exp.common.play', S, function () { toggle('bow', playB, 'exp.common.play', startBow); });
    var WFS = SC.waveforms, segW = kit.seg(k3, { S: S, ids: WFS.map(function (x) { return P + 'wf.' + x.regime; }), values: WFS.map(function (x) { return x.regime; }), value: st.wf, onchange: function (v) { st.wf = v; readBow(); drawWave(); upd('bow'); } });
    kit.seg(k3, { S: S, ids: [P + 'body.string', P + 'body.body'], values: ['string', 'body'], value: st.body, onchange: function (v) { st.body = v; upd('bow'); } });
    var k3b = kit.controls(p3);
    kit.slider(k3b, { S: S, id: P + 'beta', min: 0, max: BE.length - 1, step: 1, value: st.bi, fmt: function (v) { return '1/' + kit.num(1 / BE[Math.round(v)], 1); }, onchange: function (v) { st.bi = Math.round(v); readBow(); drawRegime(); } });
    kit.slider(k3b, { S: S, id: P + 'force', min: 0, max: FF.length - 1, step: 1, value: st.fi, fmt: function (v) { return kit.num(FF[Math.round(v)], 3) + ' N'; }, onchange: function (v) { st.fi = Math.round(v); readBow(); drawRegime(); } });
    var rB1 = kit.readout(p3), rB2 = kit.readout(p3), rB3 = kit.readout(p3), rB4 = kit.readout(p3);
    ['cap.bow1', 'cap.bow2', 'cap.bow3', 'hear.bow'].forEach(function (k) { line(p3, k); });
    var DMU = ST_.mus - ST_.mud, F0 = ST_.fs / ST_.P;
    function fmax(b) { return 2 * ST_.Z0 * ST_.vb / (DMU * b); }                                   // MUS-224's F_max at the settings
    function fmin(b) { return ST_.Z0 * ST_.Z0 * ST_.vb / (2 * ST_.R * DMU * b * b); }             // MUS-224's F_min at the settings
    function fitF(f, b) { return Math.exp(f.intercept + f.slope * Math.log(b)); }                   // the fitted boundaries, ln F = intercept + slope ln β
    var RCOL = [kit.blue, '#e0a476', '#d9d9d6'], RKEY = ['reg.h', 'reg.m', 'reg.o'];
    function curWave() { return WFS.filter(function (x) { return x.regime === st.wf; })[0]; }
    function readBow() {
      var r = SC.regime[st.fi][st.bi];
      rB1.textContent = R('bow.rd1', { b: '1/' + n(1 / BE[st.bi], 1), f: n(FF[st.fi], 3), r: S(P + RKEY[r]), lo: n(SC.fit.lower.slope, 2), up: n(SC.fit.upper.slope, 2) });
      var s = SC['sim_at_0.1'], fo = SC['formula_at_0.1'];
      var bm = s.bracket_min, bx = s.bracket_max, kr1 = key(s, /ratio.*min|min.*ratio/), kr2 = key(s, /ratio.*max|max.*ratio/), kl = key(s, /lossless|^g1|g_?1/);
      var r1 = kr1 ? s[kr1] : [bm[0] / fo.Fmin, bm[1] / fo.Fmin], r2 = kr2 ? s[kr2] : [bx[0] / fo.Fmax, bx[1] / fo.Fmax];   // the ratios: the data's if given, else the brackets over the formula
      rB2.textContent = R('bow.rd2', { a1: n(bm[0], 3), a2: n(bm[1], 3), b1: n(bx[0], 3), b2: n(bx[1], 3), c: n(fo.Fmin, 4), d: n(fo.Fmax, 3), x: pair(r1, kr1 ? 0 : 1), y: pair(r2, 2) }) + (kl != null && s[kl] != null ? ' · ' + R('bow.lossless', { f: n(Array.isArray(s[kl]) ? s[kl][0] : s[kl], 3) }) : '');
      rB3.textContent = R('bow.rd3', { s: n(SC.slip_fraction, 4), b: '0.1', p: String(ST_.P), fs: String(ST_.fs), f: n(F0, 2), F: n(curWave().F, 3) });
      rB4.textContent = R('bow.rd4', { z: String(ST_.Z0), R: String(ST_.R), mu: ST_.mus + ' / ' + ST_.mud, v: String(ST_.vb), g: String(ST_.g), n: String(ST_.periods) });
    }
    function edges(a) { var e = [a[0] / Math.sqrt(a[1] / a[0])]; for (var i = 1; i < a.length; i++) e.push(Math.sqrt(a[i - 1] * a[i])); e.push(a[a.length - 1] * Math.sqrt(a[a.length - 1] / a[a.length - 2])); return e; }
    var EB = edges(BE), EF = edges(FF);
    function drawRegime() {
      var c = cR.ctx, w = cR.w, h = cR.h, box = { l: 52, r: w - 10, t: 10, b: h - 36 }; c.clearRect(0, 0, w, h);
      var ax = kit.axes(c, box, { xmin: EB[0], xmax: EB[EB.length - 1], xlog: true, ymin: 0.003, ymax: EF[EF.length - 1], ylog: true, xticks: [0.04, 0.06, 0.1, 0.2], yticks: [0.01, 0.1, 1], xlabel: S(P + 'cv.beta'), ylabel: S(P + 'cv.force') });
      SC.regime.forEach(function (row, i) { row.forEach(function (r, j) { c.fillStyle = RCOL[r]; c.fillRect(ax.x(EB[j]), ax.y(EF[i + 1]), ax.x(EB[j + 1]) - ax.x(EB[j]) + 0.5, ax.y(EF[i]) - ax.y(EF[i + 1]) + 0.5); }); });
      c.save(); c.beginPath(); c.rect(box.l, box.t, box.r - box.l, box.b - box.t); c.clip();
      var bs = []; for (var i = 0; i <= 60; i++) bs.push(EB[0] * Math.pow(EB[EB.length - 1] / EB[0], i / 60));
      kit.curve(c, bs.map(function (b) { return [b, fmax(b)]; }), ax.x, ax.y, kit.ink(), 2); kit.curve(c, bs.map(function (b) { return [b, fmin(b)]; }), ax.x, ax.y, kit.ink(), 2, [7, 4]);
      kit.curve(c, bs.map(function (b) { return [b, fitF(SC.fit.lower, b)]; }), ax.x, ax.y, kit.red, 1.6, [3, 3]); kit.curve(c, bs.map(function (b) { return [b, fitF(SC.fit.upper, b)]; }), ax.x, ax.y, kit.red, 1.6, [3, 3]);
      var px = ax.x(BE[st.bi]), py = ax.y(FF[st.fi]); c.strokeStyle = kit.accent(); c.lineWidth = 2.5; c.strokeRect(ax.x(EB[st.bi]), ax.y(EF[st.fi + 1]), ax.x(EB[st.bi + 1]) - ax.x(EB[st.bi]), ax.y(EF[st.fi]) - ax.y(EF[st.fi + 1]));
      c.fillStyle = kit.accent(); c.beginPath(); c.arc(px, py, 3, 0, TAU); c.fill(); c.restore();
      txt(c, S(P + 'cv.fmax'), ax.x(0.045), ax.y(fmax(0.045)) - 5, kit.ink(), 'left', 10); txt(c, S(P + 'cv.fmin'), ax.x(0.045), ax.y(fmin(0.045)) + 13, kit.ink(), 'left', 10);
      txt(c, S(P + 'cv.fit'), box.r - 4, box.b - 6, kit.red, 'right', 10);
      [0, 1, 2].forEach(function (k) { var yy = box.b - 50 + 14 * k; c.fillStyle = RCOL[k]; c.fillRect(box.l + 6, yy, 10, 10); c.strokeStyle = kit.muted(); c.strokeRect(box.l + 6, yy, 10, 10); txt(c, S(P + RKEY[k]), box.l + 20, yy + 9, kit.ink(), 'left', 10); });
    }
    function drawWave() {
      var c = cWf.ctx, w = cWf.w, h = cWf.h, W = curWave(), T = W.t_ms[W.t_ms.length - 1]; c.clearRect(0, 0, w, h);
      var b1 = { l: 46, r: w - 10, t: 14, b: h * 0.55 }, b2 = { l: 46, r: w - 10, t: h * 0.66, b: h - 32 };
      var fr = Math.max.apply(null, W.F_bridge.map(Math.abs)) * 1.1, a1 = kit.axes(c, b1, { xmin: 0, xmax: T, ymin: -fr, ymax: fr, yticks: [] });
      kit.curve(c, W.t_ms.map(function (t, i) { return [t, W.F_bridge[i]]; }), a1.x, a1.y, kit.red, 1.4);
      var vmin = Math.min.apply(null, W.v_bow), vmax = Math.max.apply(null, W.v_bow), pad = 0.1 * (vmax - vmin || 1), a2 = kit.axes(c, b2, { xmin: 0, xmax: T, ymin: vmin - pad, ymax: vmax + pad, xticks: [0, 5, 10], xlabel: S(P + 'cv.ms') });
      kit.curve(c, W.t_ms.map(function (t, i) { return [t, W.v_bow[i]]; }), a2.x, a2.y, kit.blue, 1.4);
      c.strokeStyle = kit.muted(); c.setLineDash([2, 3]); c.beginPath(); c.moveTo(b2.l, a2.y(ST_.vb)); c.lineTo(b2.r, a2.y(ST_.vb)); c.stroke(); c.setLineDash([]);
      txt(c, S(P + 'cv.fbr'), b1.l + 4, b1.t - 3, kit.red, 'left', 10); txt(c, S(P + 'cv.vbow'), b2.l + 4, b2.t - 3, kit.blue, 'left', 10); txt(c, S(P + 'cv.vb'), b2.r - 4, a2.y(ST_.vb) - 3, kit.muted(), 'right', 10);
    }
    // the bridge force played: the four-period curve resampled to the context's rate by linear interpolation, four periods in 4/f0
    function waveBuffer(ctx, W) {
      var src = W.F_bridge, m = src.length, mean = src.reduce(function (s, x) { return s + x; }, 0) / m, pk = 0;
      var N = Math.round(4 * ctx.sampleRate / F0), buf = ctx.createBuffer(1, N, ctx.sampleRate), d = buf.getChannelData(0), i;
      for (i = 0; i < N; i++) { var x = i / N * m, k = Math.floor(x), f = x - k, a = src[k % m], b = src[(k + 1) % m]; d[i] = a + (b - a) * f - mean; pk = Math.max(pk, Math.abs(d[i])); }
      for (i = 0; i < N; i++) d[i] *= 0.25 / (pk || 1);
      return buf;
    }
    function startBow(a) {
      var ctx = a.ctx, out = ctx.createGain(), dry = ctx.createGain(), wet = ctx.createGain(), mix = ctx.createGain(), src = null;
      mix.connect(dry); dry.connect(out); bodyChain(ctx, mix).connect(wet); wet.connect(out); out.connect(a.master); out.gain.value = 0;
      function u() {
        var t = ctx.currentTime; if (src) { try { src.stop(t + 0.03); } catch (e) { } }
        src = ctx.createBufferSource(); src.buffer = waveBuffer(ctx, curWave()); src.loop = true; src.connect(mix); src.start(t + 0.02);
        dry.gain.setTargetAtTime(st.body === 'body' ? 0 : 1, t, 0.02); wet.gain.setTargetAtTime(st.body === 'body' ? 0.4 : 0, t, 0.02); out.gain.setTargetAtTime(1, t, 0.02);
      }
      u();
      return { upd: u, stop: function () { var t = ctx.currentTime; out.gain.setTargetAtTime(0, t, 0.02); try { src.stop(t + 0.15); } catch (e) { } } };
    }

    // ================================================================ (iv) the wolf in time (MUS-235)
    var p4 = kit.panel_(root, P + 'panel.wolf', S), cE = cv(p4, window.innerWidth < 600 ? 0.95 : 0.42, 360), k4 = kit.controls(p4);
    var WB = {};
    [['on', 'wolf.on'], ['detuned', 'wolf.det'], ['free', 'wolf.free']].forEach(function (q) { var b = kit.button(k4, P + q[1], S, function () { toggle('wolf.' + q[0], b, P + q[1], function (a) { return startWolf(a, q[0]); }); }); WB[q[0]] = b; });
    var rW1 = kit.readout(p4), rW3 = kit.readout(p4), rW2 = kit.readout(p4);
    var trs = table(p4, ['th.case', 'th.depth', 'th.one', 'th.mean'],
      WO.Q_sweep.map(function (q) { return ['Q = ' + q.Q, n(q.depth, 4), String(q.one_slip_periods), n(q.mean_slips, 2)]; }).concat(
      WO.F_variants.map(function (v) { return [v.factor + ' F · ' + S(P + (v.tuning === 'on' ? 'tune.on' : 'tune.det')), n(v.depth, 4), String(v.one_slip_periods), n(v.mean_slips, 2)]; })));
    ['cap.wolf1', 'cap.wolf2', 'cap.wolf3', 'hear.wolf'].forEach(function (k) { line(p4, k); });
    var EN = WO.envelope, TW = EN.on.t, DT = TW[1] - TW[0], TEND = TW[TW.length - 1] + DT, AMAX = Math.max(Math.max.apply(null, EN.on.A), Math.max.apply(null, EN.detuned.A));
    function readWolf() {
      var s = WO.settings;
      rW1.textContent = R('wolf.rd1', { L: String(s.L), fb: String(s.fb), ms: String(s.ms * 1000), M: String(s.M), Q: String(s.Q), vb: String(s.vb), b: s.beta, F: n(WO.F, 2), lo: n(WO.limits[0], 2), hi: n(WO.limits[1], 2) });
      var ka = key(WO, /^autocorr_9/), kb = key(WO, /^autocorr_4/), ks = key(WO, /^share_/), num = function (k) { return k ? (k.match(/\d+/g) || []).join('–') : ''; };
      rW3.textContent = R('wolf.rd3', { t1: num(ka), a1: ka ? n(WO[ka], 3) : '—', t2: num(kb), a2: kb ? n(WO[kb], 3) : '—', b: num(ks), s: ks ? n(WO[ks], 4) : '—', l: n(WO.largest_line_Hz, 1), w: n(WO.mus229_ms, 1) });
      rW2.textContent = R('wolf.rd2', { w: n(WO.mus229_ms, 1), fr: n(WO.free_beat_ms, 1), d1: n(WO.depth_on, 4), d2: n(WO.depth_detuned, 4), r: WO.regimes_on });
    }
    function drawWolf() {
      var c = cE.ctx, w = cE.w, h = cE.h; c.clearRect(0, 0, w, h);
      var b1 = { l: 46, r: w - 10, t: 12, b: h * 0.56 }, b2 = { l: 46, r: w - 10, t: h * 0.64, b: h - 52 };
      var mn = Math.min(Math.min.apply(null, EN.on.A), Math.min.apply(null, EN.detuned.A)), a1 = kit.axes(c, b1, { xmin: 0, xmax: TEND, ymin: mn * 0.95, ymax: AMAX * 1.03, yticks: [Math.round(mn), Math.round(AMAX)] });
      kit.curve(c, TW.map(function (t, i) { return [t, EN.detuned.A[i]]; }), a1.x, a1.y, kit.blue, 1.2); kit.curve(c, TW.map(function (t, i) { return [t, EN.on.A[i]]; }), a1.x, a1.y, kit.red, 1.2);
      txt(c, S(P + 'cv.on'), b1.r - 4, b1.b - 18, kit.red, 'right', 10); txt(c, S(P + 'cv.det'), b1.r - 4, b1.b - 6, kit.blue, 'right', 10); txt(c, S(P + 'cv.env'), b1.l + 4, b1.t + 10, kit.muted(), 'left', 10);
      for (var k = 1; WO.mus229_ms * k < TEND; k++) vline(c, a1.x(WO.mus229_ms * k), b1.t, b1.t + 6, kit.ink());
      var fe = WO.free_envelope, fmx = Math.max.apply(null, fe), fmn = Math.max(1e-12, Math.min.apply(null, fe));
      var a2 = kit.axes(c, b2, { xmin: 0, xmax: TEND, ymin: fmn, ymax: fmx * 1.5, ylog: true, xticks: [0, 500, 1000, 1500], xlabel: S(P + 'cv.ms') });
      kit.curve(c, fe.map(function (v, i) { return [TW[i] != null ? TW[i] : i * DT, Math.max(v, fmn)]; }), a2.x, a2.y, kit.muted(), 1.2);
      txt(c, S(P + 'cv.freeenv'), b2.r - 4, b2.t + 10, kit.muted(), 'right', 10);
      // the regimes on the note, period by period: S none, H one slip, M two or more
      var ys = h - 22, tp = 0, col = { S: kit.muted(), H: kit.blue, M: '#e0a476' };
      WO.regimes_on.split(' ').forEach(function (tok) { var L = tok[0], m = +tok.slice(1); c.fillStyle = col[L] || kit.muted(); c.fillRect(a2.x(tp * DT), ys, Math.max(1, a2.x((tp + m) * DT) - a2.x(tp * DT)), 8); tp += m; });
      txt(c, S(P + 'cv.regimes'), b2.l, ys - 3, kit.ink(), 'left', 10);
      if (SND && SND.kind.indexOf('wolf.') === 0 && SND.t0 != null && kit.ready()) { var el_ = (kit.audio().ctx.currentTime - SND.t0) * 1000; if (el_ >= 0 && el_ <= TEND) { vline(c, a1.x(el_), b1.t, b1.b, kit.accent()); vline(c, a2.x(el_), b2.t, b2.b, kit.accent()); } }
    }
    // the model's envelope applied to a 175 Hz sawtooth, period by period over 2 s (linear interpolation between the values)
    function startWolf(a, which) {
      var ctx = a.ctx, osc = ctx.createOscillator(), lp = ctx.createBiquadFilter(), g = ctx.createGain(), t0 = ctx.currentTime + 0.05;
      osc.type = 'sawtooth'; osc.frequency.value = WO.settings.fb; lp.type = 'lowpass'; lp.frequency.value = 4000; osc.connect(lp); lp.connect(g); g.connect(a.master);
      var A = which === 'free' ? WO.free_envelope : EN[which].A, mx = which === 'free' ? Math.max.apply(null, A) : AMAX;
      var curve = new Float32Array(A.length); for (var i = 0; i < A.length; i++) curve[i] = 0.25 * A[i] / mx;
      g.gain.setValueAtTime(0, ctx.currentTime); g.gain.linearRampToValueAtTime(curve[0], t0); g.gain.setValueCurveAtTime(curve, t0, TEND / 1000);
      g.gain.setValueAtTime(curve[curve.length - 1], t0 + TEND / 1000 + 0.001); g.gain.linearRampToValueAtTime(0, t0 + TEND / 1000 + 0.05);
      osc.start(); osc.stop(t0 + TEND / 1000 + 0.1);
      var me = { t0: t0, stop: function () { try { var t = ctx.currentTime; g.gain.cancelScheduledValues(t); g.gain.setValueAtTime(g.gain.value, t); g.gain.linearRampToValueAtTime(0, t + 0.03); osc.stop(t + 0.05); } catch (e) { } } };
      osc.onended = function () { if (SND && SND.stop === me.stop) { setBtn(SND.btn, false, SND.idOff); SND = null; } };
      return me;
    }

    // ================================================================ (v) the violin-shaped plate (MUS-236)
    var p5 = kit.panel_(root, P + 'panel.plate', S), cPl = cv(p5, 0.66, 420), k5 = kit.controls(p5);
    kit.button(k5, 'exp.common.strike', S, function () { var f = VP.plates[st.plate].f; strike(f.map(function (x, i) { return { f: x, a: 1 / (i + 1), decay: 1.0 }; }), 0.15); });
    kit.button(k5, P + 'gough.play', S, function () { strike(goughOf().map(function (x, i) { return { f: x, a: 1 / (i + 1), decay: 1.0 }; }), 0.15); });
    var pauseB = kit.button(k5, 'exp.common.pause', S, function () { st.paused = !st.paused; pauseB.setAttribute('aria-pressed', String(st.paused)); }); pauseB.setAttribute('aria-pressed', String(st.paused));
    var k5b = kit.controls(p5);
    kit.seg(k5b, { S: S, ids: [P + 'pl.back', P + 'pl.top'], values: ['back_maple_3mm', 'top_spruce_2.5mm'], value: st.plate, onchange: function (v) { st.plate = v; setPl(); } });
    kit.seg(k5b, { S: S, ids: [1, 2, 3, 4, 5].map(function (i) { return P + 'pm.' + i; }), values: [0, 1, 2, 3, 4], value: 0, onchange: function (v) { st.pm = v; setPl(); } });
    var rP1 = kit.readout(p5), rP2 = kit.readout(p5), rP5 = kit.readout(p5), rP3 = kit.readout(p5), rP4 = kit.readout(p5), rPs = kit.readout(p5);
    ['cap.plate1', 'cap.plate2', 'cap.plate3', 'cap.spline', 'hear.plate'].forEach(function (k) { line(p5, k); });
    var OUTL = VP.outline_mm, LEN = OUTL[OUTL.length - 1][0], BHW = 0, GR = null;
    OUTL.forEach(function (p) { BHW = Math.max(BHW, p[1]); });
    function goughOf() { return st.plate === 'top_spruce_2.5mm' ? VP.gough.top : VP.gough.back; }
    function hashNo(name) { var m = /^#(\d+)/.exec(name || ''); return m ? +m[1] : null; }
    function nameOf(name) { var k = hashNo(name); return k ? S(P + 'name.' + k) : name; }
    // the outline: a Catmull–Rom curve through the control points (a drawing), mirrored about the long axis
    function spline() { var pts = [], Q = OUTL; for (var i = 0; i < Q.length - 1; i++) { var p0 = Q[Math.max(0, i - 1)], p1 = Q[i], p2 = Q[i + 1], p3 = Q[Math.min(Q.length - 1, i + 2)]; for (var s = 0; s < 10; s++) { var t = s / 10, t2 = t * t, t3 = t2 * t; pts.push([0, 1].map(function (k) { return 0.5 * (2 * p1[k] + (-p0[k] + p2[k]) * t + (2 * p0[k] - 5 * p1[k] + 4 * p2[k] - p3[k]) * t2 + (-p0[k] + 3 * p1[k] - 3 * p2[k] + p3[k]) * t3); })); } } pts.push(Q[Q.length - 1]); return pts; }
    var SPL = spline();
    function bodyPath(c, X, Y) { c.beginPath(); SPL.forEach(function (p, i) { if (i) c.lineTo(X(p[0]), Y(p[1])); else c.moveTo(X(p[0]), Y(p[1])); }); for (var i = SPL.length - 1; i >= 0; i--) c.lineTo(X(SPL[i][0]), Y(-SPL[i][1])); c.closePath(); }
    function frame(w, h, padB) { var sc = Math.min((w - 24) / LEN, (h - (padB || 30)) / (2 * BHW + 8)), ox = (w - LEN * sc) / 2, oy = 6 + (h - (padB || 30) - 2 * BHW * sc) / 2; return { X: function (x) { return ox + x * sc; }, Y: function (y) { return oy + (BHW - y) * sc; }, sc: sc }; }
    function setPl() {
      var pl = VP.plates[st.plate], m = pl.modes[st.pm]; GR = m.grid;
      var k = hashNo(m.name), gi = [1, 2, 5].indexOf(k), go = goughOf();
      rP1.textContent = R('pl.rd1', { f: n(m.f, 1), nm: nameOf(m.name), g: gi >= 0 ? R('pl.gough', { g: String(go[gi]), r: n(go[gi] / m.f, 2) }) : S(P + 'pl.nogough') });
      var kA = key(VP, /^at_\d+_\d+/), mat = st.plate === 'back_maple_3mm' ? 'maple' : 'spruce', hi = kA && VP[kA][mat];
      rP5.textContent = hi ? R('pl.rd5', { f: pl.f.map(function (x) { return n(x, 1); }).join(', '), n: kA.replace(/^at_/, '').replace('_', ', '), g: hi.map(function (x) { return n(x, 1); }).join(', ') }) : ''; show(rP5, !!hi);
      rP2.textContent = R('pl.rd2', { f: pl.f.map(function (x) { return n(x, 0); }).join(', '), g: go.join(', '), h: n(VP.materials[st.plate === 'back_maple_3mm' ? 'maple' : 'spruce'].h * 1000, 1), a: n(VP.area_cm2, 1) });
      var iso = VP.plates.back_isotropic; rP3.textContent = R('pl.rd3', { a: iso.f.slice(0, 2).map(function (x, i) { var h = hashNo(iso.names[i]); return (h ? '#' + h : '') + ' ' + n(x, 0) + ' Hz'; }).join(' · '), b: VP.plates.back_maple_3mm.f.slice(0, 2).map(function (x, i) { var h = hashNo(VP.plates.back_maple_3mm.names[i]); return (h ? '#' + h : '') + ' ' + n(x, 0) + ' Hz'; }).join(' · ') });
      rP4.textContent = R('pl.rd4', { a: VP.square_control.values.slice(0, 7).map(function (x) { return n(x, 4); }).join(', '), b: VP.square_control.packV.join(', '), nu: String(VP.square_control.nu) });
      rPs.textContent = S('exp.common.slowed.pic').replace('{n}', kit.num(Math.round(m.f / 0.5), 0));
    }
    function drawPlate() {
      var c = cPl.ctx, w = cPl.w, h = cPl.h, F = frame(w, h, 34), ny = GR.length - 1, nx = GR[0].length - 1, amp = Math.cos(TAU * 0.5 * st.t), i, j; c.clearRect(0, 0, w, h);
      var gx = function (i) { return LEN * i / nx; }, gy = function (j) { return -BHW + 2 * BHW * j / ny; };
      c.save(); bodyPath(c, F.X, F.Y); c.clip();
      for (j = 0; j < ny; j++) for (i = 0; i < nx; i++) { var q = [GR[j][i], GR[j][i + 1], GR[j + 1][i], GR[j + 1][i + 1]].filter(function (v) { return v != null; }); if (!q.length) continue; var m = q.reduce(function (s, v) { return s + v; }, 0) / q.length; c.fillStyle = kit.cmap(amp * m); c.fillRect(F.X(gx(i)), F.Y(gy(j + 1)), F.X(gx(i + 1)) - F.X(gx(i)) + 0.7, F.Y(gy(j)) - F.Y(gy(j + 1)) + 0.7); }
      // the nodal lines by marching squares on the grid (cells with a corner outside are skipped)
      c.strokeStyle = kit.ink(); c.lineWidth = 1.5; c.beginPath(); var C4 = [[0, 0], [1, 0], [1, 1], [0, 1]];
      for (j = 0; j < ny; j++) for (i = 0; i < nx; i++) {
        var v = [GR[j][i], GR[j][i + 1], GR[j + 1][i + 1], GR[j + 1][i]]; if (v.some(function (x) { return x == null; })) continue; var pts = [];
        for (var e = 0; e < 4; e++) { var a0 = v[e], b0 = v[(e + 1) % 4]; if ((a0 < 0) !== (b0 < 0)) { var f = a0 / (a0 - b0), p0 = C4[e], p1 = C4[(e + 1) % 4]; pts.push([F.X(gx(i + p0[0] + f * (p1[0] - p0[0]))), F.Y(gy(j + p0[1] + f * (p1[1] - p0[1])))]); } }
        for (e = 0; e + 1 < pts.length; e += 2) { c.moveTo(pts[e][0], pts[e][1]); c.lineTo(pts[e + 1][0], pts[e + 1][1]); }
      }
      c.stroke(); c.restore();
      c.strokeStyle = kit.ink(); c.lineWidth = 1.3; bodyPath(c, F.X, F.Y); c.stroke();
      c.fillStyle = kit.accent(); OUTL.forEach(function (p) { [1, -1].forEach(function (s) { c.beginPath(); c.arc(F.X(p[0]), F.Y(s * p[1]), 2.5, 0, TAU); c.fill(); }); });
      txt(c, S(P + 'cv.ctrl'), F.X(0), h - 8, kit.accent(), 'left', 10); txt(c, S(P + 'cv.grain'), F.X(LEN), h - 8, kit.muted(), 'right', 10);
    }

    // ================================================================ (vi) the box (MUS-237)
    var p6 = kit.panel_(root, P + 'panel.box', S), g6 = grid(p6), cBx = cv(g6, 0.66, 300), cMo = cv(g6, 0.66, 300), k6 = kit.controls(p6);
    var CF = ['none', 'bar', 'post', 'bar+post'];
    var playX = kit.button(k6, 'exp.common.play', S, function () { stopSnd(); ringBox(); });
    kit.seg(k6, { S: S, ids: [P + 'cfg.none', P + 'cfg.bar', P + 'cfg.post', P + 'cfg.both'], values: CF, value: st.cfg, onchange: function (v) { st.cfg = v; readBox(); drawBox(); drawMono(); } });
    var rX1 = kit.readout(p6), rX2 = kit.readout(p6), rX4 = kit.readout(p6), rX3 = kit.readout(p6), rBr = kit.readout(p6);
    ['cap.box1', 'cap.box2', 'cap.box3', 'cap.bridge', 'hear.box'].forEach(function (k) { line(p6, k); });
    var LABK = { 'plug': 'lab.plug', 'breathing': 'lab.breath', 'plates opposed': 'lab.opp', 'no volume': 'lab.novol' };
    function cfgGain(k) { var all = 0, mine = 0; CF.forEach(function (q) { var m = Math.max.apply(null, BX.configs[q].drive.Q.map(Math.abs)); all = Math.max(all, m); if (q === k) mine = m; }); return mine / (all || 1); }
    function readBox() {
      var C = BX.configs[st.cfg], low = 100 * (1 - C.A0 / BX.A0_rigid);
      rX1.textContent = R('box.rd1', { v: n(BX.V_cm3, 1), h: String(BX.rib_mm), c: n(BX.C_total_m, 5), px: String(BX.post_mm[0]), py: String(BX.post_mm[1]), fx: String(BX.feet_mm[0][0]), fy: String(Math.abs(BX.feet_mm[0][1])), by: String(BX.bar.y_mm), b0: String(BX.bar.x_mm[0]), b1: String(BX.bar.x_mm[1]), ei: n(BX.bar.EI, 3) });
      var kL = key(C, /lower/) || null, kLB = key(BX, /lower/); if (kL) low = C[kL]; else if (kLB && BX[kLB] && BX[kLB][st.cfg] != null) low = BX[kLB][st.cfg]; if (Math.abs(low) < 1 && (kL || kLB)) low *= 100;
      var kV = key(BX, /vacuo/), vac = kV ? BX[kV] : null;
      rX4.textContent = vac == null ? '' : R('box.vac', { l: typeof vac === 'object' ? Object.keys(vac).filter(function (k) { return typeof vac[k] === 'number'; }).map(function (k) { var nm = /top/.test(k) && /bar/.test(k) ? 'vac.topbar' : /top/.test(k) ? 'vac.top' : /back/.test(k) ? 'vac.back' : null; return (nm ? S(P + nm) : k) + ' ' + n(vac[k], 1) + ' Hz'; }).join(' · ') : n(vac, 1) + ' Hz' }); show(rX4, vac != null);
      rX2.textContent = R('box.rd2', { a: n(C.A0, 1), r: n(BX.A0_rigid, 1), p: n(low, 1), m: n(BX.B1.minus, 1), q: n(BX.B1.plus, 1) });
      var Q = C.drive.Q.map(Math.abs); rX3.textContent = R('box.rd3', { lo: kit.sci(Math.min.apply(null, Q), 2), hi: kit.sci(Math.max.apply(null, Q), 2), g: kit.sci(cfgGain(st.cfg), 1) });
      rBr.textContent = R('br.rd', { y1: String(BR.Y_band[0]), y2: String(BR.Y_band[1]), F: n(BR.F_partials[0], 4), f1: String(BR.f_list[0]), f2: String(BR.f_list[1]), v1: n(BR.v_um_s.trough / 1000, 2), v2: n(BR.v_um_s.peak / 1000, 1), x1: n(BR.x_um.trough, 3), x2: n(BR.x_um.peak, 2), r1: n(BR.ratio_to_report_mm[0], 0), r2: n(BR.ratio_to_report_mm[1], 0) });
    }
    function drawBox() {
      var c = cBx.ctx, w = cBx.w, h = cBx.h, F = frame(w, h, 30), has = function (k) { return st.cfg.indexOf(k) >= 0; }; c.clearRect(0, 0, w, h);
      c.fillStyle = kit.panel(); bodyPath(c, F.X, F.Y); c.fill(); c.strokeStyle = kit.ink(); c.lineWidth = 1.5; c.stroke();
      c.setLineDash([4, 4]); c.strokeStyle = kit.violet; c.lineWidth = 1; c.beginPath(); c.moveTo(F.X(0), F.Y(0)); c.lineTo(F.X(LEN), F.Y(0)); c.stroke(); c.setLineDash([]);
      txt(c, S(P + 'cv.mirror'), F.X(4), F.Y(0) - 4, kit.violet, 'left', 10);
      // the f-holes: a drawing
      [1, -1].forEach(function (s) { c.strokeStyle = kit.ink(); c.lineWidth = 2; c.beginPath(); c.moveTo(F.X(212), F.Y(s * 50)); c.bezierCurveTo(F.X(230), F.Y(s * 30), F.X(245), F.Y(s * 62), F.X(266), F.Y(s * 40)); c.stroke(); [[212, 50], [266, 40]].forEach(function (q) { c.fillStyle = kit.ink(); c.beginPath(); c.arc(F.X(q[0]), F.Y(s * q[1]), 2.6, 0, TAU); c.fill(); }); });
      if (has('bar')) { c.strokeStyle = kit.warm(); c.lineWidth = 4; c.beginPath(); c.moveTo(F.X(BX.bar.x_mm[0]), F.Y(BX.bar.y_mm)); c.lineTo(F.X(BX.bar.x_mm[1]), F.Y(BX.bar.y_mm)); c.stroke(); txt(c, S(P + 'cv.bar'), F.X(BX.bar.x_mm[0]), F.Y(BX.bar.y_mm) + 14, kit.warm(), 'left', 10); }
      var ph = Math.sin(TAU * 0.5 * st.t);
      BX.feet_mm.forEach(function (p) { var s = p[1] > 0 ? 1 : -1; c.fillStyle = kit.ink(); c.fillRect(F.X(p[0]) - 4, F.Y(p[1]) - 4, 8, 8); kit.arrow(c, F.X(p[0]) - 8, F.Y(p[1]), F.X(p[0]) - 8 - 16 * ph * s, F.Y(p[1]), s * ph > 0 ? kit.red : kit.blue, 2); });
      txt(c, S(P + 'cv.feet'), F.X(BX.feet_mm[0][0]) - 6, F.Y(BHW) + 2, kit.ink(), 'center', 10);
      if (has('post')) { var pp = BX.post_mm; c.strokeStyle = kit.accent(); c.lineWidth = 2.5; c.beginPath(); c.arc(F.X(pp[0]), F.Y(pp[1]), 6, 0, TAU); c.stroke(); txt(c, S(P + 'cv.post'), F.X(pp[0]) + 9, F.Y(pp[1]) - 6, kit.accent(), 'left', 10); }
      txt(c, S(P + 'cv.top'), 6, h - 6, kit.muted(), 'left', 10);
    }
    function drawMono() {
      var c = cMo.ctx, w = cMo.w, h = cMo.h, box = { l: 64, r: w - 10, t: 26, b: h - 34 }, Y0 = 1e-10, C = BX.configs[st.cfg]; c.clearRect(0, 0, w, h);
      var ax = kit.axes(c, box, { xmin: 100, xmax: 1000, ymin: Y0, ymax: 1e-5, ylog: true, xticks: [100, 300, 500, 700, 900], yticks: [], xlabel: S(P + 'cv.hz'), ylabel: S(P + 'cv.mono') });
      [-10, -8, -6].forEach(function (e) { var y = ax.y(Math.pow(10, e)); c.strokeStyle = kit.muted(); c.beginPath(); c.moveTo(box.l - 4, y); c.lineTo(box.l, y); c.stroke(); txt(c, '10^' + e, box.l - 6, y + 4, kit.muted(), 'right', 10); });
      var col = { none: kit.muted(), bar: kit.warm(), post: '#1f8a6e', 'bar+post': kit.blue };
      CF.forEach(function (k) { var D = BX.configs[k].drive, me = k === st.cfg; kit.curve(c, D.f.map(function (f, i) { return [f, Math.max(Y0 * 1.05, Math.abs(D.Q[i]))]; }), ax.x, ax.y, col[k], me ? 2.6 : 1, k === 'none' ? [4, 3] : []); });
      txt(c, S(P + 'cv.zero'), box.l + 4, box.b - 5, kit.muted(), 'left', 10);
      C.modes.forEach(function (m) { if (m.f > 1000) return; var x = ax.x(m.f), hh = 4 + 10 * Math.min(1, Math.abs(m.monopole) / 2); c.strokeStyle = kit.ink(); c.lineWidth = 1.5; c.beginPath(); c.moveTo(x, box.t); c.lineTo(x, box.t + hh); c.stroke(); var lb = LABK[m.label]; txt(c, lb ? S(P + lb + '.s') : '?', x, box.t - 3, kit.ink(), 'center', 9); });
      vline(c, ax.x(C.A0), box.t, box.b, kit.accent(), [3, 3]); txt(c, 'A0', ax.x(C.A0) + 3, box.b - 18, kit.accent(), 'left', 10);
      if (BX.A0_rigid <= 1000) { vline(c, ax.x(BX.A0_rigid), box.t, box.b, kit.muted(), [1, 3]); txt(c, S(P + 'cv.rigid'), ax.x(BX.A0_rigid) + 3, box.b - 30, kit.muted(), 'left', 10); }
      [['minus', 'B1−'], ['plus', 'B1+']].forEach(function (q, i) { var x = ax.x(BX.B1[q[0]]); vline(c, x, box.t, box.b, kit.violet, [2, 2]); txt(c, q[1], x + 3, box.t + 26 + 12 * i, kit.violet, 'left', 10); });
      txt(c, S(P + 'cv.legend'), box.r - 4, box.b - 6, kit.ink(), 'right', 9);
    }
    // the box rung: its modes below 1 kHz as decaying partials, amplitude ∝ |monopole| × the configuration's largest driven monopole over all four
    function ringBox() {
      var a = kit.audio(); if (!a) { noA(); return; }
      var C = BX.configs[st.cfg], g = cfgGain(st.cfg), mm = 0; C.modes.forEach(function (m) { mm = Math.max(mm, Math.abs(m.monopole)); });
      kit.strike(C.modes.filter(function (m) { return m.f < 1000; }).map(function (m) { return { f: m.f, a: g * Math.abs(m.monopole) / (mm || 1), decay: 0.7 }; }), 0.09);
    }

    // ================================================================ see · hear · data
    var pe = kit.panel_(root, null, S); [['exp.common.see', 'see'], ['exp.common.hear', 'hear']].forEach(function (q) { var p = el('p', { class: 'exp-line' }); p.appendChild(el('strong', { 'data-s': q[0], text: S(q[0]) })); p.appendChild(document.createTextNode(' ')); p.appendChild(el('span', { 'data-s': P + q[1], text: S(P + q[1]) })); pe.appendChild(p); });
    var pd = el('p', { class: 'exp-source' }); pd.appendChild(el('strong', { 'data-s': 'exp.common.data', text: S('exp.common.data') })); pd.appendChild(document.createTextNode(' ')); pd.appendChild(el('span', { 'data-s': P + 'data', text: S(P + 'data') })); pe.appendChild(pd);

    // ================================================================ start
    readPhoto(); markRow(); readPost(); readBow(); readWolf(); setPl(); readBox();
    var still = [drawPhoto, drawPost, drawRegime, drawWave, drawMono], dirty = true; window.addEventListener('resize', function () { dirty = true; });
    kit.loop(function (t, dt) { if (!st.paused) st.t += dt; if (dirty) { dirty = false; still.forEach(function (f) { f(); }); } drawWolf(); drawPlate(); drawBox(); });
  } };
})();
