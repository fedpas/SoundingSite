<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors -->
# The Sounding View — release 2

*2 November 2026. Built from the tables of the Cascade Atlas, release 4.4.9, with round 36 merged (its checks ran on 1 November 2026), and from the pack of round 37, *The bridges drilled* (a study of 2 November 2026 against 4.4.9; stored, not merged: its rows are proposed). In English and in Italian.*

Release 2 adds a page of its own for the drill, three instruments, the pack's nine scripts, twelve figures and nine clips on the pages that hold such things, the paper's dictionary, and an Italian side told by a narrator. A reader of release 1 finds the same site with more in it: the same chips, the same four registers, the same stamps.

## What the release adds

- **The page *The bridges drilled*** (`bridges.html`): the study's stamp and standing (a study's page: its rows are proposed, not merged); the question and the method in the study's words (§1 and the opening of part 2); the table of the eleven bridges from `BRIDGES_DRILLED.md` (bridge · before · after · what decided it, every cell traced); eight parts, one per item in the study's order — the clock, the labels of twelve, the duality and the bell, the walk, the rows as an instrument, the ring with its hypotheses removed, the rigid body on the Atlas's motors, sound and light on the kernel and the paper — each with the study's sections telling it (formulas set with KaTeX from the study's TeX), its proposed rows as row blocks, its figures, its clips and its instrument; the paper's dictionary with its ten candidates; the opinion (§9) and what part 2 changes (§16); the way to the references.
- **A proposed row block** has the four registers of an Atlas row and reads the item's `ROWS.md` instead of the tables: Story the study's units for the row (else its research text, and the block says so); Research the research text proposed; Atlas the claim in mathematics and in physics, the kind, the status the Atlas's rule would give with the word *proposed*, the stage and ptype, what it rests on (the ids linked where the row is on the site), the proposed home, the evidence with the script's statement for the group (the docstring's Statements section), the lines its log prints, the run's last line and seconds, and what the controls break; Standard the standard reference (its links live) and the bridge the item's `BRIDGE.md` grades for the row, before and proposed. The chip is the status's chip of release 1 with the outline *proposed* beside it.
- **The other pages**: the home's ninth card (the study's sentence, 36 proposed rows by status); Checks with the nine scripts after the two (311 ok lines in 44 groups, the 45 controls with their FAIL counts, the seconds of each run, the logs as text and as files under `checks/round37/` with the pack's README and `run_all.sh`); Pictures with the twelve figures after the thirteen (their rows linked to the proposed row blocks); Sounds with the nine clips 13 … 21 after the twelve and three instruments after the six; Dictionary with a second part, the paper's dictionary (Tables 3 and 4 of Burns, Daniel, Alexander and Dressel carried into three columns, the counts, and the candidates on the page of the drill); Sources with the drill's references (arXiv numbers and DOIs live) and the paper; About with the method's extension and the pack named.
- **Three instruments** (`sounds.js`, tested in `test_sounds.mjs`): **7. the Tonnetz as the CRT grid** — the twelve pitch classes on the 3 × 4 torus (a, b) ↦ 4a + 3b of `crt_tonnetz.json`, a cell sounding its pitch class or the triad on it, the fifth's diagonal, the two cycles ℤ₄ and ℤ₃, the mirror x ↦ 7x computed on the grid as (a, b) ↦ (a, −b) and compared with the file, with the arrows drawn; **8. the two rings and the bell** — the ring solved for the partials 1 … 6 (three stiffnesses negative, `harmonic_ring.json`) against the nearest-neighbour ring (the page's 2 sin(πk/12) compared with the file), the positive rings 7 … 12 and {4, 6, 7, 8, 9, 10} of `sets.json`, ring A and ring B of `clips_rings.json`, the 12-cube and 3-cube bells of `bell_levels.json`, each plucked at one mass with the character expansion's amplitudes, the partials drawn as a strip; **9. the all-interval rows** — the 3856 rows of `all_interval_rows.json` by number or preset (Berg's Lyric Suite row, the least and the greatest, Slonimsky's Grandmother chord), voiced by the rule of `audio/INDEX.md`, with retrograde, inversion and R = T₆, the classes under T, I and R and under Fripertinger's G₃, the first hexachord, the melody drawn.
- **The Italian side** (`out/it/`): every page again, `lang="it"`, with the switch EN · IT in the header. It is not a translation: a narrator — a professional of music, mathematics and physics, written by two narrators under one contract and read by an independent reviewer — tells the site in Italian: 122 narrations (`content/it/racconto.json`: the home, the eight sections, the 27 + 36 rows, the pages, the nine instruments, the 21 clips, the page of the drill with its table, its eight items, its opinion and the paper's dictionary, the pack's scripts and figures), and the chrome in the narrator's words (`content/it/strings_it.json`, 405 strings, one per id of the English table). The Atlas's records — the research texts, the Atlas register, the standard references, the study's prose, the logs, the captions, the clip indexes — stay in the Atlas's English on the Italian pages, with one Italian line saying so above each register of records; so under the Italian label *Stato* the record's word reads *computed* while the chip beside it reads *calcolato*: the rule, kept on purpose. The register switch reads *Racconto · Ricerca · Atlas · Standard*: Racconto shows the narrator's telling of the row, the three others the records as the English page shows them. The checker verifies the Italian pages as it verifies the English ones, and the narrations against their table, each rendered exactly once at its target, every `tells` id on the site, no banned word of the contract. The record of the Italian side is in the source: `it/VOICE_IT.md` (the contract: the targets, the voice, the glossary, the banned words), `it/draft/NOTE_IT-1.md` and `it/draft/NOTE_IT-2.md` (the two narrators' notes: what was read, the terminology beyond the glossary, what was unclear and how it was told), and `it/REVIEW_IT.md` (the reviewer's pass: 24 edits applied in place, and the observations).

## The counts (`content/version.json`)

| | |
|---|---|
| pages | 16 in English (8 sections, the page of the drill, Sounds, Dictionary, Checks, Pictures, Sources, About, the home) and 16 in Italian |
| row blocks | 27 of the Atlas in 8 chains, and 36 proposed rows in 8 items, each in 4 registers |
| traced blocks | 3,913 on the English pages, 7,659 with the Italian ones, every one verified; 0 errors, 0 warnings |
| figures | 25 (13 + 12), with their captions and data |
| clips | 21 (12 + 9) |
| instruments | 9 |
| log lines | 89 + 311 ok lines of the eleven logs; 12 + 45 controls |
| formulas | 162 set with KaTeX on the English pages (16 displays with `\htmlData`) |
| strings | 405 in `content/strings.json` (220 of release 1 and 185 of release 2), and 405 in Italian |
| narrations | 122, one per target, each rendered once |
| screenshots | 128 (32 pages × 1280 and 390 px × light and dark), 0 console problems |

## The method, extended

- **A study's own files.** A study whose rows are not merged can still be read: the site reads the pack as the study's own files — its study (units and sentences, as *Music on the labels*), its items' `ROWS.md` (a reader of their format), `BRIDGE.md` and `BRIDGES_DRILLED.md`, the scripts' statements and logs, the figure and clip indexes, the dictionary — through trace sources `pack.*` that `lib/pack.mjs` resolves for the generator and for the checker alike, and marks every such row *proposed*.
- **The Italian narrator.** The Italian pages add a third traced element, `data-r`, a narration of `racconto.json`; the checker resolves it as it resolves `data-b` and `data-s`.
- **From the disk**, as before: the Italian pages share the stylesheet, the scripts, the figures, the clips and KaTeX with the English ones by relative paths; nothing is fetched.

## The synthesizer's test

`gen/test_sounds.mjs`: 37 assertions, 37 pass — the 20 of release 1 and 17 of release 2: the CRT grid's fifth diagonal recovered pitch class by pitch class from its FFT peaks, the mirror computed from the cells and compared with the file, the image of the diatonic set (seven consecutive fifths onto seven consecutive semitones) and the sets the mirror keeps, the fifth and the semitone on the torus; the solved ring's and the nearest-neighbour ring's partials within 0.1 %, the pluck's amplitudes 2/12 and 1/12 with the decays compensated, the 12-cube bell's twelve partials 220√j with the loudest at j = 6, the 3-cube bell's 1 : √2 : √3 with 3/8, 3/8, 1/8, the positive ring 7 … 12, ring A's ten audible partials; Berg's row voiced as `berg_row.json` prints it and recovered interval by interval, round(12 log₂(f_{j+1}/f_j)) mod 12, from the rendered melody, R = T₆ measured as √2 note by note, the rule on all 3856 rows (every melody ends a tritone above its first note and spans 11 to 21 semitones; exactly 176 rows have R = T₆), the least and the greatest rows as each other's inversion, the Grandmother chord's wedge.

## Two small things a reader may notice

- The chrome says "clip 7" where the clip labels print "Clip 07" (the files are numbered with two digits); the English and the Italian pages share the habit, which release 1 set.
- Under *Stato* on the Italian pages the status prints the record's English word beside the Italian chip, as said above: records stay English.

## The one link to the Atlas

Unchanged: About's "The Atlas — one rule: the page Music", to `https://toy-model-v0.vercel.app/#/music`, once per language (the Italian About carries the same link). To move it, change `ATLAS_URL` in `gen/build.mjs` and the address the checker accepts, and rebuild.

## How to host

Unzip and serve the folder with any static server, or open `index.html` (or `it/index.html`) from the disk. `.ogg` as `audio/ogg`, `.py`, `.log`, `.md` and `.sh` as `text/plain`. The two text fonts come from Google Fonts; without the network the system fonts are used.

## Licence and credits

- The Cascade Atlas, its tables, figures, scripts and clips, the pack of round 37, and this site with its generator, are under the PolyForm Noncommercial License 1.0.0. Required Notice: Copyright (c) 2026 the Cascade Atlas authors.
- The studies *Music on the labels* and *The bridges drilled* cite their sources by name; the Sources page lists them with their links. The paper the drill reads, Burns, Daniel, Alexander and Dressel, *Spacetime geometry of acoustics and electromagnetism* (arXiv:2305.11448 v2, DOI 10.1007/s40509-024-00317-8), is named there with its links.
- KaTeX (MIT licence) sets the formulas at build time; its stylesheet and fonts ship with the site. IBM Plex Sans and Newsreader are under the SIL Open Font License.

---

# The Sounding View — release 1

*2 November 2026. Built from the tables of the Cascade Atlas, release 4.4.9, with round 36 merged (its checks ran on 1 November 2026).*

The Sounding View is a standalone static website about music, read with the Atlas. It is the Atlas's reading of the study *Music on the labels* (round 36): a musical theory in nine parts, each statement sorted by what establishes it — computed on the labels, a textbook result recomputed, an input with its source, a reading of ours with its reason, or open. It is built the way its sister site, *The Shifted View*, is built, and it adds a Sounds page that plays the Atlas's own numbers.

Every sentence on the site comes from one of four places: a record of the Atlas, an inventory, a study's own files, or the site's own string table. The generator checks each one against its source.

## What the site reads

- **The Atlas 4.4.9** (`content/`): the rows MUS-001 … MUS-012, INP-124 … INP-130 and the Atlas's own rows the page `music` tells (SPR-M01, SPR-M16, ATY-040, LAB-046, LAB-047, LAB-016b, LNS-137); their research texts and, where they exist, their learner texts (`texts.json`); the page `music` with its eight sections, eight chains, nine leads (MUS-701, MUS-741 … MUS-748) and its own row MUS-013 (`content/chains/music/`); the status of every row (`derived/status.json`); the lens `mus` with its 34 entries (`lenses.json`) and its 124 readings (`lens_readings.json`); the records of the two scripts (`checks.json`) and their runs (`check_runs.json`); the page titles (`pages.json`).
- **Round 36's own files**: the study `docs/round36/music_on_the_labels.html` (its prose for the Story register, its abstract, its references), the thirteen figures with `figs/FIGURES_INDEX.md`, the literature's `lit/SOURCES.md`; `checks/selfcheck/round36/`: the two scripts, their logs and their faults logs, the figure data `figdata/*.json`, and the twelve clips with `audio/INDEX.md` (here as Ogg Vorbis).

## The pages (15)

- **Home** (`index.html`): the question in one paragraph, composed sentence by sentence from the study's abstract and the lead MUS-701; the study's map as the site's picture; the eight sections as cards, each with its lead and the count of its rows by status; the way to the Sounds page.
- **Eight section pages**, one per chain of the page `music`: `tone.html`, `consonance.html`, `clock.html`, `scales.html`, `groups.html`, `shapes.html`, `fourier.html`, `question.html`. Each has its titles (learner, physics, mathematics), its lead, the chain's rows in the Atlas's order with the chain's links between them, the section's figures (by FIGURES_INDEX.md's row column) and clips, and the instrument of the Sounds page that plays its numbers.
  - **A row** is a block with its id, its status chip and its claim, in **four registers** (the switch at the top: Story · Research · Atlas · Standard):
    - *Story*: the study's own prose for the row, traced to the study's section (21 rows); else the Atlas's learner text (5 rows); else the research text (ATY-040). The block says which.
    - *Research*: the row's research text.
    - *Atlas*: the row's claim in mathematics and in physics, its kind, status and badge, cells, what it rests on, the reason for its status, its release; its checks with the check's statement, the lines the log prints for its group (round 36), and the last run.
    - *Standard*: the standard reference (its links live), and the entries of the lens Music for the row.
  - **The chips** are the Atlas's: computed plain, standard grey-blue (MUS-003, LAB-016b: standard, recomputed), an input grey and dashed (INP-124 … INP-130), our reading amber and dashed (MUS-013), open violet and dotted.
- **Dictionary**: the lens Music, its 34 entries as a table (Atlas term · music term · grade · evidence · rows), the grades' legend with their counts (exact 16, exact with an input 1, partial 7, analogy 2, none 8), and the 124 readings of the Atlas's rows through the lens, grouped by the page where each row is at home.
- **Checks**: `music_sound.py` and `music_symmetry.py`, what each computes, its method, second route and controls; its 14 groups with every line of the logs (89 ok lines); the last lines; the twelve controls with their FAIL counts; the run records; the logs as text and as files (`checks/`); and the Atlas's other checks of the rows the pages tell.
- **Pictures**: the thirteen figures with their captions, their data files and their rows.
- **Sounds**: the twelve clips with what is heard and what they are built from, and six instruments (below).
- **Sources**: the study's references with their links, and every source of `SOURCES.md` with the link its literature reader fetched and what came back.
- **About**: the method, the four registers, the chips, what the site reads, what is not here, the one Atlas link, the licence and the credits.

## The Sounds page

A synthesizer in one plain JavaScript file (`sounds.js`, no library), reading its numbers from `sounds-data.js` (the figure data of the checks, copied by the generator). Sine oscillators summed as partials, 20 ms raised-cosine fades, a master gain at −6 dBFS, the AudioContext made on the first click. Beneath each instrument the page says where its numbers come from.

1. **The clock**: twelve toggles on a dial, 12-TET or just (the 5-limit ratios of `cents_table.json` for the seven diatonic degrees), chord or arpeggio; the cardinality, the interval vector, |f̂(k)| computed in the page, and the exact |f̂(k)|² = a + b√3 of `dft.json` for its twelve named sets, which are the presets.
2. **The Tonnetz walk**: the 24 triads at their centroids (`plr_dual.json`), with the P, L and R edges; click to hear a triad, P, L, R to move; the hexatonic and octatonic cycles, the LR cycle and Beethoven's nineteen chords as presets; the word and, in just intonation with the common tones held, the drift in cents — the hexatonic cycle comes back 128/125 sharp, and the first chord sounds again after it.
3. **Euclidean rhythms**: k and n up to 16, the necklace, Bjorklund's algorithm in the page, the clips' click sounds; the page says when its string matches E(k, n) of ms·EVEN (`even.json`); presets tresillo, cinquillo, the bossa-nova necklace, the bell E(7, 12), E(9, 16).
4. **The chain and the ring**: the modes of the chain of N = 1 … 8 masses (exact ω² from `chain_modes.json` for N ≤ 5), the twelve modes of the ring C₁₂, and the partials of the string, the stiff string, the free bar and the membrane (`partials.json`).
5. **The dissonance glissando**: clip 5's recipe, with the curve of `dissonance_curve.json` drawn and a marker on it; harmonic or bar partials.
6. **The commas**: the just and tempered fifths, the Pythagorean comma as two beating tones, and the major chord just and tempered, with the beat shown.

**The synthesizer's test** (`gen/test_sounds.mjs`, in the source): Chromium renders the page's engine into an OfflineAudioContext and measures the sound by FFT, as the Atlas's group mu·AUDIO measures its clips: 20 assertions, 20 pass — the major chord's 18 partials in 12-TET and in just intonation, the onsets of E(7, 12), E(3, 8) and E(5, 16) (each within 1 % of a pulse), the chain's five modes at 220.00, 425.01, 601.05, 736.13, 821.05 Hz, the ring's modes, the comma's beat at 3.0015 Hz, the hexatonic drift of 128/125, the glissando at the dissonance curve's minima, Bjorklund against even.json and against {⌊in/k⌋} for all 136 pairs, |f̂(k)| against dft.json.

## The method

- **Traced blocks.** Each block of text carries `data-b` (a record of the Atlas, a row of an inventory, sentences of the study) or `data-s` (a string of the site's table); the generator's trace says where each `data-b` comes from, and the checker resolves it again, compares the text, and compares what the page shows. Outside the traced elements no page holds a run of three words.
- **The study as a source.** The study is read into its units (paragraphs, list items, captions, displays) and their sentences; a Story block is a declared list of units or sentence ranges, recomputed by the checker. Its formulas are set at build time with KaTeX from the TeX the study carries; each display names its source through `\htmlData`.
- **From the disk.** The site opens from `file://`: nothing is fetched, the Sounds page's numbers are a script, the clips are `<audio>` elements, KaTeX's stylesheet and fonts ship with the site.

## The counts (`content/version.json`)

| | |
|---|---|
| pages | 15 (8 sections) |
| row blocks | 27 in 8 chains, each in 4 registers |
| traced blocks | about 1,700, every one verified; 0 errors |
| figures | 13, with their captions and data |
| clips | 12 |
| lens entries | 34; readings 124 |
| log lines | 89 ok lines of the two logs, 12 controls |
| formulas | 19 set with KaTeX (10 displays with `\htmlData`) |

## What is not here

- **The learner texts** of the music rows and of the nine leads: the storyteller has not written them. The Story register tells those rows in the study's own words and says so.
- The study's tables (Table 0, 4.1, 5.1, 5.2), its appendix, and its opinion in the first person (§8, "My opinion, plainly"): they stay in the study.
- A site-wide search.

## The one link to the Atlas

The site is standalone. Its only link into the Atlas is on About (`about.html`, `data-atlas-link`): "The Atlas — one rule: the page Music", to `https://toy-model-v0.vercel.app/#/music`. To move it, change `ATLAS_URL` in `gen/build.mjs` and the address the checker accepts (one line in `gen/check.mjs`), and rebuild.

## How to host

Unzip and serve the folder with any static server, or open `index.html` from the disk. `.ogg` as `audio/ogg`, `.py` and `.log` as `text/plain`. The two text fonts (IBM Plex Sans, Newsreader) come from Google Fonts; without the network the system fonts are used.

## Licence and credits

- The Cascade Atlas, its tables, figures, scripts and clips, and this site with its generator, are under the PolyForm Noncommercial License 1.0.0. Required Notice: Copyright (c) 2026 the Cascade Atlas authors.
- The study *Music on the labels* cites its sources by name; the Sources page lists them with their links.
- KaTeX (MIT licence) sets the formulas at build time; its stylesheet and fonts ship with the site. IBM Plex Sans and Newsreader are under the SIL Open Font License.
