// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// landau — the fading sound: a plasma wave that dies without friction, heard as a bell that fades at the wave's own rate.
(function () { 'use strict';
  window.SDV_EXP = window.SDV_EXP || {};
  window.SDV_EXP.landau = { mount: function (root, data, S, kit) {
    var LANDAU = { rows: data.landau }, KIN = data.kinetic, CERT = data.cert, NEXT = data.next, F0 = data.f0, SIMRATE = data.simrate;
    var SLOW = Math.round(2 * Math.PI * F0 / SIMRATE);
    var el = kit.el, ink = kit.ink, mut = kit.muted, acc = kit.accent;
    function T(id, o) { var s = S(id); if (o) for (var q in o) s = s.split('{' + q + '}').join(o[q]); return s; }
    var fmt = function (x) { return x === 0 ? '0' : (Math.abs(x) < 1e-3 || Math.abs(x) >= 1e4) ? x.toExponential(2) : x.toPrecision(3); };
    var preset = 'maxwell', k = 0.40, soundOn = false, curTone = null, rootSel = '3/10', simT = 0, dots = null, cur = null;
    var reduced = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches, paused = reduced;

    function point(p, kk) {
      var i6 = Math.round((kk - 0.06) / 0.01), i1 = Math.round((kk - 0.10) / 0.01);
      if (p === 'maxwell') { var r = LANDAU.rows[i6]; return { w: r.omega_r, g: r.gamma, src: 'landau' }; }
      if (p === 'lorentz') { if (i1 >= 0 && i1 <= 50) { var t = KIN.lorentz[i1]; return { w: t[1], g: t[2], src: 'kinetic' }; } return { w: 1, g: kk, src: 'rule' }; }
      var arr = KIN[p]; if (i1 < 0 || i1 > 50) return null; var t2 = arr[i1]; return { w: t2[1], g: t2[2], src: 'kinetic' };
    }
    var bg = function (kk) { return LANDAU.rows[Math.round((kk - 0.06) / 0.01)].bohm_gross; };
    function rawf(p, v) { if (p === 'maxwell') return Math.exp(-v * v / 2); if (p === 'lorentz') return 1 / (1 + v * v); var K = p === 'kappa2' ? 2 : 6; return Math.pow(1 + v * v / (2 * K - 3), -K); }
    var NORM = {}; ['maxwell', 'lorentz', 'kappa2', 'kappa6'].forEach(function (p) { var s = 0; for (var v = -1500; v <= 1500; v += 0.02) s += rawf(p, v) * 0.02; NORM[p] = s; });
    var fdist = function (p, v) { return rawf(p, v) / NORM[p]; };
    function rng(seed) { var s = seed >>> 0; return function () { s = (s + 0x6D2B79F5) >>> 0; var t = s; t = Math.imul(t ^ t >>> 15, t | 1); t ^= t + Math.imul(t ^ t >>> 7, t | 61); return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
    function sampleV(p, r) {
      var n = function () { return Math.sqrt(-2 * Math.log(r() + 1e-12)) * Math.cos(2 * Math.PI * r()); };
      if (p === 'maxwell') return n(); if (p === 'lorentz') return Math.tan(Math.PI * (r() - 0.5));
      var K = p === 'kappa2' ? 2 : 6, nu = 2 * K - 1, c = 0; for (var i = 0; i < nu; i++) { var z = n(); c += z * z; }
      return n() / Math.sqrt(c / nu) * Math.sqrt((2 * K - 3) / (2 * K - 1));
    }
    var AMP0 = function () { return 0.16 * k; };
    function restart() { simT = 0; cur = point(preset, k); var r = rng(12345), N = 1500; dots = new Float32Array(N * 2); for (var i = 0; i < N; i++) { dots[2 * i] = r() * 2 * Math.PI; dots[2 * i + 1] = sampleV(preset, r); } }
    function step(dt) {
      if (!cur) return; var w = cur.w, nsub = Math.max(1, Math.ceil(dt / 0.02)), h = dt / nsub, N = dots.length / 2;
      for (var s = 0; s < nsub; s++) { var E = AMP0() * Math.exp(-cur.g * simT);
        for (var i = 0; i < N; i++) { var ph = dots[2 * i], v = dots[2 * i + 1]; v += -E * Math.sin(ph - w * simT) * h; ph += k * v * h; ph %= 2 * Math.PI; if (ph < 0) ph += 2 * Math.PI; dots[2 * i] = ph; dots[2 * i + 1] = v; }
        simT += h; }
    }

    // ---------------------------------------------------------------- layout
    root.classList.add('wide-left');
    var ctl = kit.controls(root); ctl.style.gridColumn = '1 / -1';
    var playB = kit.button(ctl, 'exp.common.play', S, function () {
      if (!kit.audio()) { return; } soundOn = !soundOn; setLabel(playB, soundOn ? 'exp.common.mute' : 'exp.common.play'); playB.setAttribute('aria-pressed', String(soundOn));
      if (!soundOn) stopTone(); else strikeNow();
    }, 'acc');
    function setLabel(b, id) { b.textContent = S(id); b.setAttribute('data-s', id); }
    kit.button(ctl, 'exp.common.strike', S, function () { strikeNow(); });
    kit.button(ctl, 'exp.landau.fluid', S, function () { restart(); readout(); tone(F0 * bg(k), 0); });
    var kS = kit.slider(ctl, { id: 'exp.landau.k', S: S, min: 0.06, max: 0.80, step: 0.01, value: 0.40, fmt: function (v) { return v.toFixed(2); }, onchange: function (v) { k = Math.round(v * 100) / 100; restart(); readout(); } });
    kS.el.querySelector('input').addEventListener('change', function () { if (cur) tone(F0 * cur.w, cur.g * 2 * Math.PI * F0); });
    var sel = el('select', { 'aria-label': S('exp.landau.dist') });
    [['maxwell', 'exp.landau.d.maxwell'], ['lorentz', 'exp.landau.d.lorentz'], ['kappa2', 'exp.landau.d.kappa2'], ['kappa6', 'exp.landau.d.kappa6']].forEach(function (o) { sel.appendChild(el('option', { value: o[0], 'data-s': o[1], text: S(o[1]) })); });
    sel.addEventListener('change', function () { preset = sel.value; strikeNow(); });
    var dl = el('label', { class: 'exp-slider' }); dl.appendChild(el('span', { class: 'exp-lab', 'data-s': 'exp.landau.dist', text: S('exp.landau.dist') })); dl.appendChild(sel); ctl.appendChild(dl);
    var pauseB = kit.button(ctl, 'exp.common.pause', S, function () { paused = !paused; pauseB.setAttribute('aria-pressed', String(paused)); }); pauseB.setAttribute('aria-pressed', String(paused));
    var read = kit.readout(root); read.style.gridColumn = '1 / -1';

    var left = el('div'), right = el('div'); right.style.cssText = 'display:flex;flex-direction:column;gap:14px;min-width:0'; root.appendChild(left); root.appendChild(right);
    var p1 = kit.panel_(left, 'exp.landau.panel.surfer', S), p2 = kit.panel_(right, 'exp.landau.panel.disp', S), p3 = kit.panel_(right, 'exp.landau.panel.root', S);
    function cvas(parent, hWide, hNarrow) { var c = el('canvas', { class: 'exp-canvas' }); parent.appendChild(c); c.hw = hWide; c.hn = hNarrow; return c; }
    var cv1 = cvas(p1, 560, 460), cv2 = cvas(p2, 400, 380), cv3 = cvas(p3, 250, 250);
    var cap1 = el('p', { class: 'exp-line' }); p1.appendChild(cap1); var cap2 = el('p', { class: 'exp-line' }); p2.appendChild(cap2); var cap3 = el('p', { class: 'exp-line' }); p3.appendChild(cap3);
    var rb = el('span'); rb.style.cssText = 'display:inline-flex;gap:6px;margin-left:10px'; p3.firstChild.appendChild(rb);
    var b03 = el('button', { type: 'button', class: 'btn exp-btn', text: '0.3', 'aria-pressed': 'true' }), b05 = el('button', { type: 'button', class: 'btn exp-btn', text: '0.5', 'aria-pressed': 'false' });
    [b03, b05].forEach(function (b) { b.style.padding = '2px 10px'; rb.appendChild(b); });
    b03.addEventListener('click', function () { rootSel = '3/10'; b03.setAttribute('aria-pressed', 'true'); b05.setAttribute('aria-pressed', 'false'); });
    b05.addEventListener('click', function () { rootSel = '1/2'; b05.setAttribute('aria-pressed', 'true'); b03.setAttribute('aria-pressed', 'false'); });
    var sh = el('div', { class: 'exp-panel span' }); root.appendChild(sh);
    sh.appendChild(el('h3', { 'data-s': 'exp.common.see', text: S('exp.common.see') })); kit.line(sh, 'exp.landau.see', S);
    sh.appendChild(el('h3', { 'data-s': 'exp.common.hear', text: S('exp.common.hear') })); kit.line(sh, 'exp.landau.hear', S);

    function setup(cv) {
      var d = window.devicePixelRatio || 1, narrow = cv.parentNode.clientWidth < 560; cv.style.height = (narrow ? cv.hn : cv.hw) + 'px';
      var w = cv.clientWidth, h = cv.clientHeight; if (cv.width !== Math.round(w * d) || cv.height !== Math.round(h * d)) { cv.width = Math.round(w * d); cv.height = Math.round(h * d); }
      var c = cv.getContext('2d'); c.setTransform(d, 0, 0, d, 0, 0); c.clearRect(0, 0, w, h); c.fillStyle = kit.panel(); c.fillRect(0, 0, w, h); c.font = '12px system-ui,sans-serif'; return { c: c, w: w, h: h };
    }
    function grid(c) { c.strokeStyle = kit.muted(); c.globalAlpha = 0.25; }

    function drawSurfer() {
      var g = setup(cv1), c = g.c, w = g.w, h = g.h, narrow = w < 520, A, i;
      var x0 = 40, fw = narrow ? 64 : 104, x1 = w - fw - 12, pw = x1 - x0, yp0 = 14, yp1 = narrow ? 64 : 74, y0 = yp1 + 34, y1 = h - (narrow ? 44 : 30), ph = y1 - y0;
      c.fillStyle = ink();
      if (!cur) { c.fillStyle = mut(); c.fillText(S('exp.landau.cv.nodata'), x0, h / 2); cap1.textContent = ''; return; }
      var vph = cur.w / k, vmin = -5.5, vmax = Math.max(6, vph + 3.5);
      var X = function (p) { return x0 + p / (2 * Math.PI) * pw; }, V = function (v) { return y1 - (v - vmin) / (vmax - vmin) * ph; };
      A = Math.exp(-cur.g * simT);
      for (i = 0; i < pw; i++) { var p = i / pw * 2 * Math.PI; c.fillStyle = kit.cmap(A * Math.sin(p - cur.w * simT)); c.fillRect(x0 + i, yp0, 1.5, yp1 - yp0); }
      c.strokeStyle = ink(); c.lineWidth = 1.4; c.beginPath();
      for (i = 0; i <= pw; i += 2) { var p2_ = i / pw * 2 * Math.PI, y = (yp0 + yp1) / 2 - A * Math.sin(p2_ - cur.w * simT) * (yp1 - yp0) * 0.45; if (i) c.lineTo(x0 + i, y); else c.moveTo(x0 + i, y); }
      c.stroke(); c.strokeStyle = mut(); c.lineWidth = 1; c.strokeRect(x0, yp0, pw, yp1 - yp0);
      c.fillStyle = ink(); c.fillText(T(narrow ? 'exp.landau.cv.pot.n' : 'exp.landau.cv.pot', { a: fmt(A) }), x0, yp1 + 14);
      c.strokeStyle = mut(); c.strokeRect(x0, y0, pw, ph);
      var hw = 2 * Math.sqrt(AMP0() * A / k);
      c.globalAlpha = 0.14; c.fillStyle = acc(); c.fillRect(x0, V(vph + hw), pw, V(vph - hw) - V(vph + hw)); c.globalAlpha = 1;
      c.strokeStyle = acc(); c.setLineDash([5, 4]); c.beginPath(); c.moveTo(x0, V(vph)); c.lineTo(x1, V(vph)); c.stroke(); c.setLineDash([]);
      c.fillStyle = acc(); c.fillText(T(narrow ? 'exp.landau.cv.vph.n' : 'exp.landau.cv.vph', { v: vph.toFixed(2) }), x0 + 6, Math.max(y0 + 12, V(vph) - 5));
      var N = dots.length / 2, E = AMP0() * A;
      for (i = 0; i < N; i++) { var ph_ = dots[2 * i], v = dots[2 * i + 1]; if (v < vmin || v > vmax) continue; var a = -E * Math.sin(ph_ - cur.w * simT); c.fillStyle = v * a >= 0 ? kit.red : kit.blue; c.globalAlpha = 0.75; c.fillRect(X(ph_) - 1, V(v) - 1, 2.2, 2.2); }
      c.globalAlpha = 1; c.fillStyle = ink(); c.fillText(S(narrow ? 'exp.landau.cv.dots.n' : 'exp.landau.cv.dots'), x0, y1 + 16);
      c.fillText(T('exp.landau.cv.xlab', { n: (2 * Math.PI / k).toFixed(1) }), narrow ? x0 : x0 + pw - 210, narrow ? y1 + 30 : y1 + 16);
      for (var v2 = Math.ceil(vmin / 5) * 5; v2 <= vmax; v2 += 5) { c.fillStyle = mut(); c.fillText(v2, x0 - 24, V(v2) + 4); c.strokeStyle = mut(); c.globalAlpha = 0.2; c.beginPath(); c.moveTo(x0, V(v2)); c.lineTo(x1, V(v2)); c.stroke(); c.globalAlpha = 1; }
      var fx0 = w - fw - 6, fmax = 0.42; c.strokeStyle = mut(); c.strokeRect(fx0, y0, fw, ph);
      c.strokeStyle = ink(); c.lineWidth = 1.5; c.beginPath();
      for (var j = 0; j <= ph; j += 2) { var vv = vmax - (j / ph) * (vmax - vmin), xx = fx0 + fdist(preset, vv) / fmax * fw; if (j) c.lineTo(xx, y0 + j); else c.moveTo(xx, y0 + j); } c.stroke(); c.lineWidth = 1;
      c.strokeStyle = acc(); c.setLineDash([5, 4]); c.beginPath(); c.moveTo(fx0, V(vph)); c.lineTo(fx0 + fw, V(vph)); c.stroke(); c.setLineDash([]);
      var hh = 1e-3, sl = (fdist(preset, vph + hh) - fdist(preset, vph - hh)) / (2 * hh), fx = fx0 + fdist(preset, vph) / fmax * fw, sg = sl < 0 ? -1 : 1;
      c.strokeStyle = acc(); c.lineWidth = 3; c.beginPath(); c.moveTo(fx, V(vph)); c.lineTo(fx + sg * 14, V(vph) - 14); c.stroke(); c.lineWidth = 1;
      c.fillStyle = ink(); c.fillText('f(v)', fx0 + 4, y0 - 4); c.fillStyle = acc(); c.fillText('∂f/∂v = ' + fmt(sl), fx0 + 2, Math.min(y1 - 6, V(vph) + 16));
      var txt = S(sl < 0 ? 'exp.landau.cap1.neg' : 'exp.landau.cap1.pos') + ' ' + S('exp.landau.cap1.kin') + ' ' + T('exp.common.slowed', { n: SLOW });
      if (cap1.getAttribute('data-t') !== txt) { cap1.setAttribute('data-t', txt); cap1.textContent = txt; }
    }
    function drawDisp() {
      var g = setup(cv2), c = g.c, w = g.w, h = g.h, L = 48, R = w - 10, narrow = w < 420;
      var kx = function (v) { return L + (v - 0.06) / (0.8 - 0.06) * (R - L); }, rows = LANDAU.rows;
      function axes(y0, y1, title, ticks, Y) { c.strokeStyle = mut(); c.strokeRect(L, y0, R - L, y1 - y0); c.fillStyle = ink(); c.fillText(title, L + 4, y0 + 13);
        ticks.forEach(function (t) { var y = Y(t[0]); c.strokeStyle = mut(); c.globalAlpha = 0.2; c.beginPath(); c.moveTo(L, y); c.lineTo(R, y); c.stroke(); c.globalAlpha = 1; c.fillStyle = mut(); c.fillText(t[1], 4, y + 4); });
        [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8].forEach(function (x) { c.fillStyle = mut(); c.fillText(x.toFixed(1), kx(x) - 9, y1 + 13); }); }
      function line(arr, X, Y, col, dash, lw) { c.strokeStyle = col; c.setLineDash(dash || []); c.lineWidth = lw || 1.6; c.beginPath(); arr.forEach(function (p, i) { if (i) c.lineTo(X(p), Y(p)); else c.moveTo(X(p), Y(p)); }); c.stroke(); c.setLineDash([]); c.lineWidth = 1; }
      var a0 = 10, a1 = h * 0.42, wy = function (v) { return a1 - (v - 0.95) / (1.85 - 0.95) * (a1 - a0); };
      axes(a0, a1, S(narrow ? 'exp.landau.cv.w.n' : 'exp.landau.cv.w'), [[1, '1.0'], [1.25, '1.25'], [1.5, '1.5'], [1.75, '1.75']], wy);
      line(rows, function (p) { return kx(p.k_lambda); }, function (p) { return wy(p.omega_r); }, ink());
      line(rows, function (p) { return kx(p.k_lambda); }, function (p) { return wy(p.bohm_gross); }, mut(), [5, 4]);
      if (preset !== 'maxwell') line(KIN[preset], function (p) { return kx(p[0]); }, function (p) { return wy(p[1]); }, acc(), null, 2);
      var b0 = h * 0.42 + 34, b1 = h - 22, lo = -60, hi = 0.5, gy = function (v) { return b1 - (Math.log(v) / Math.LN10 - lo) / (hi - lo) * (b1 - b0); };
      axes(b0, b1, S(narrow ? 'exp.landau.cv.g.n' : 'exp.landau.cv.g'), [[1e-50, '1e-50'], [1e-40, '1e-40'], [1e-30, '1e-30'], [1e-20, '1e-20'], [1e-10, '1e-10'], [1, '1']], gy);
      line(rows, function (p) { return kx(p.k_lambda); }, function (p) { return gy(p.gamma); }, ink());
      line(rows, function (p) { return kx(p.k_lambda); }, function (p) { return gy(p.gamma_weak); }, mut(), [5, 4]);
      if (preset !== 'maxwell') { line(KIN[preset], function (p) { return kx(p[0]); }, function (p) { return gy(p[2]); }, acc(), null, 2); c.fillStyle = acc(); c.fillText(T('exp.landau.cv.preset', { d: S('exp.landau.d.' + preset) }), L + 4, b1 - 6); }
      c.fillStyle = mut(); c.fillText('kλ_D', R - 28, h - 3);
      c.strokeStyle = acc(); c.lineWidth = 1.5; c.beginPath(); c.moveTo(kx(k), a0); c.lineTo(kx(k), a1); c.moveTo(kx(k), b0); c.lineTo(kx(k), b1); c.stroke(); c.lineWidth = 1;
      if (cur) { c.fillStyle = acc(); c.beginPath(); c.arc(kx(k), wy(cur.w), 4, 0, 7); c.fill(); c.beginPath(); c.arc(kx(k), gy(cur.g), 4, 0, 7); c.fill(); }
      var id = preset === 'maxwell' ? 'exp.landau.cap2.maxwell' : preset === 'lorentz' ? 'exp.landau.cap2.lorentz' : 'exp.landau.cap2.kappa';
      if (cap2.getAttribute('data-s') !== id) { cap2.setAttribute('data-s', id); cap2.textContent = S(id); }
    }
    function drawRoot() {
      var g = setup(cv3), c = g.c, w = g.w, h = g.h, L = 44, R = w - 10, Tp = 8, B = h - 26, xr = [1.0, 2.3], yr = [-1.8, 0.1];
      var X = function (v) { return L + (v - xr[0]) / (xr[1] - xr[0]) * (R - L); }, Y = function (v) { return B - (v - yr[0]) / (yr[1] - yr[0]) * (B - Tp); };
      c.strokeStyle = mut(); c.strokeRect(L, Tp, R - L, B - Tp); c.fillStyle = mut();
      [1, 1.5, 2].forEach(function (x) { c.fillText(x.toFixed(1), X(x) - 8, B + 13); c.globalAlpha = 0.2; c.beginPath(); c.moveTo(X(x), Tp); c.lineTo(X(x), B); c.stroke(); c.globalAlpha = 1; });
      [0, -0.5, -1, -1.5].forEach(function (y) { c.fillText(y.toFixed(1), 6, Y(y) + 4); c.globalAlpha = 0.2; c.beginPath(); c.moveTo(L, Y(y)); c.lineTo(R, Y(y)); c.stroke(); c.globalAlpha = 1; });
      c.fillText('Re ω/ωₚ', R - 60, B + 22); c.fillText('Im ω', L + 4, Tp + 12);
      var z = CERT[rootSel], nx = NEXT[rootSel];
      nx.forEach(function (p) { c.strokeStyle = kit.blue; c.lineWidth = 1.8; c.beginPath(); c.arc(X(p[0]), Y(p[1]), 6, 0, 7); c.stroke(); });
      c.lineWidth = 1; c.fillStyle = acc(); c.fillRect(X(z[0]) - 4, Y(z[1]) - 4, 8, 8); c.fillText(S('exp.landau.cv.root'), X(z[0]) + 8, Y(z[1]) + 14);
      var ratio = Math.abs(nx[0][1]) / Math.abs(z[1]);
      var txt = T('exp.landau.cap3', { k: rootSel === '3/10' ? '0.3' : '0.5', re: z[0].toFixed(5), im: z[1].toFixed(5), next: nx.map(function (p) { return p[0].toFixed(3) + ' ' + p[1].toFixed(3) + ' i'; }).join(', '), m: rootSel === '3/10' ? '49' : '7.4', r: ratio.toFixed(1) });
      if (cap3.getAttribute('data-t') !== txt) { cap3.setAttribute('data-t', txt); cap3.textContent = txt; }
    }
    function readout() {
      if (!cur) { read.textContent = T('exp.landau.read.none', { k: k.toFixed(2) }); return; }
      var per = cur.w / (2 * Math.PI * cur.g), sec = 1 / (cur.g * 2 * Math.PI * F0), f = F0 * cur.w;
      var t = T('exp.landau.read', { k: k.toFixed(2), w: cur.w.toFixed(4), g: fmt(cur.g), f: f.toFixed(1), per: fmt(per), sec: fmt(sec) });
      if (sec > 60) t += ' ' + S('exp.landau.read.silent');
      if (cur.src === 'rule') t += ' ' + S('exp.landau.read.rule');
      if (preset === 'lorentz') t += ' ' + S('exp.landau.read.lor');
      read.textContent = t;
    }
    function stopTone() { if (curTone) { try { var a = kit.audio(); curTone.g.gain.cancelScheduledValues(a.ctx.currentTime); curTone.g.gain.setTargetAtTime(0, a.ctx.currentTime, 0.01); curTone.o.stop(a.ctx.currentTime + 0.08); } catch (e) { } curTone = null; } }
    // a bell: a sine at F0 × ω/ωp with the envelope e^(−γ_a t), γ_a = γ × 2π F0 (the same ratio γ/ω as the plasma's); attack 0.6 ms so that a fast fade is not smeared
    function tone(freq, gam) {
      if (!soundOn) return; var a = kit.audio(); if (!a) return; stopTone();
      var t0 = a.ctx.currentTime + 0.02, o = a.ctx.createOscillator(), g = a.ctx.createGain();
      o.type = 'sine'; o.frequency.value = freq; o.connect(g); g.connect(a.master);
      g.gain.setValueAtTime(0, t0); g.gain.linearRampToValueAtTime(0.3, t0 + 0.0006);
      var dur = 4; if (gam > 0) { g.gain.setTargetAtTime(0, t0 + 0.0006, 1 / gam); dur = Math.min(4, 14 / gam); } else { g.gain.setValueAtTime(0.3, t0 + 3.6); g.gain.linearRampToValueAtTime(0, t0 + 4); }
      o.start(t0); o.stop(t0 + dur + 0.05); curTone = { o: o, g: g };
    }
    function strikeNow() { restart(); readout(); if (cur) tone(F0 * cur.w, cur.g * 2 * Math.PI * F0); }

    restart(); readout();
    kit.loop(function (t, dt) { if (!paused) step(dt * SIMRATE); drawSurfer(); drawDisp(); drawRoot(); });
  } };
})();
