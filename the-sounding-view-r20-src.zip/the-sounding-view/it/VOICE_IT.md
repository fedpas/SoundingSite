# The Sounding View — the Italian narrator (release 2)

The owner's words: *"The site should have Italian too. Not just english to italian, but 'un agente professionista della musica, della matematica e della fisica che racconta il nostro sito.'"*

So the Italian side of the site is **not a translation**. It is a narrator — a professional of music, of mathematics and of physics — who tells the site in Italian: what each page shows, what each row establishes and how, what each clip lets you hear, what each instrument plays. The Atlas's own records (the research texts, the Atlas register, the standard references, the logs, the figure captions, the clip indexes) stay in the Atlas's English on the Italian pages too: they are records, and the narrator tells them, quotes their numbers, and never rewrites them. The site's own chrome (navigation, labels, legends, the Sounds page's controls) is in Italian, written by the same narrator (`strings_it.json`, same ids as `strings.json`, each a free rewording in the narrator's voice that does the string's job).

## The two tables the Italian pages are built from

Both live in `site/gen/content/it/`. The generator reads nothing else for the Italian pages; the checker verifies every Italian sentence on the site against them.

### `strings_it.json`

```json
{ "about": "…", "voice": "…", "strings": [ { "id": "brand", "text": "The Sounding View", "why": "…" }, … ] }
```

One entry per id of `gen/content/strings.json` (220 in release 1; the release-2 strings are added by the builder with their ids and must be filled too — the builder lists them in `content/it/MANIFEST.json` under `strings_new`). `text` is the narrator's Italian for the job that string does (a label stays a label; a legend gloss stays one sentence; a `why` says in English what the string is for, as in `strings.json`). Names are not translated: *The Sounding View*, *The Shifted View*, *the Cascade Atlas* → "l'Atlante" in prose but the proper names stay; *Story · Research · Atlas · Standard* become **Racconto · Ricerca · Atlas · Standard**.

### `racconto.json`

```json
{ "about": "…", "voice": "…",
  "items": [
    { "id": "r:row:MUS-003", "target": "row:MUS-003", "tells": ["MUS-003", "clip:04"], "text": "…", "why": "the narrator's telling of MUS-003" },
    …
  ] }
```

- `target` names what the narration stands on (the ids below); `id` is `r:` + target. One item per target, no target twice.
- `tells` lists what the narration draws on: row ids (`MUS-003`), study sections (`study:§3.2` for *Music on the labels*, `drill:§12` for *The bridges drilled*), clips (`clip:04`), figures (`fig:fig_rows`), lens entries, scripts (`check:music_rows.py`). The checker verifies that each exists.
- `text` is Italian, in the narrator's voice (below); plain text with the Atlas's inline notation as the records print it (ω², ℤ₁₂, √3, 12-TET, C(12, j)/4096, Cl(1,3)); no HTML, no markdown, no formulas in TeX. Where you must quote a row's number, quote it **as the record prints it** (decimal point, the record's units and digits), so the reader finds the same figure in the English record beside.
- `why`: one English line, as in `strings.json`.

## The targets

Release 1 (the narrator IT-1 writes these):

| target | what it is | length |
|---|---|---|
| `page:home` | the home: the question of the site, in the narrator's words, after the study's abstract and MUS-701 | 120–180 words |
| `section:tone`, `section:consonance`, `section:clock`, `section:scales`, `section:groups`, `section:shapes`, `section:fourier`, `section:question` | each of the eight sections of the page `music`: what the section is about, what its rows establish together, what to listen to | 100–160 words |
| `row:<id>` for the 27 row blocks: MUS-001 … MUS-013, INP-124 … INP-130, SPR-M01, SPR-M16, ATY-040, LAB-046, LAB-047, LAB-016b, LNS-137 | the row told: what it claims, what establishes it (computed on the labels / recomputed from a book / an input with its source / a reading of ours / open), the numbers that matter, where it sits in the music | 60–140 words |
| `page:dictionary` | the lens Music: what a grade means, how to read the table and the readings | 100–160 |
| `page:checks` | what a check script is, what the two scripts compute, what a control is, how to read a log | 100–160 |
| `page:pictures` | the thirteen figures as a set | 60–120 |
| `page:sounds` | the Sounds page: the clips and the instruments, how the synthesizer is built and tested | 100–160 |
| `instrument:chain`, `instrument:gliss`, `instrument:clock`, `instrument:rhythm`, `instrument:tonnetz`, `instrument:commas` | each instrument: what it plays, what to try, where its numbers come from | 60–120 |
| `clip:01` … `clip:12` (ids as the files: `clip:01`, `clip:08a`, `clip:08b`, `clip:08c`, `clip:09` …) | what you hear, in two to four sentences, after `audio/INDEX.md`'s "what is heard" | 40–90 |
| `page:sources`, `page:about` | the sources page; the method of the site (the four registers, the chips, the one link to the Atlas, the licence) told by the narrator | 80–140 each |

Release 2, the page *The bridges drilled* (the narrator IT-2 writes these):

| target | what it is | length |
|---|---|---|
| `page:bridges` | the page: the round's question (the ten bridges of round 36 drilled; music leading on ℤ₈ against ℤ₁₂; the Atlas's computation extended to twelve; the four questions left open and tried; the paper), what is proposed and not merged | 150–220 |
| `bridges:item:clock`, `bridges:item:labels`, `bridges:item:duality`, `bridges:item:walk`, `bridges:item:rows`, `bridges:item:rings`, `bridges:item:body`, `bridges:item:acoustics` | each of the eight items of the drill: which bridges it drills, what was computed, what grade came out, what to listen to | 120–180 |
| `row:MUS-014` … `row:MUS-049` | each proposed row (36), told as above; say that it is proposed, not merged, where it helps | 60–140 |
| `instrument:crt`, `instrument:rings`, `instrument:rows` | the three instruments of release 2: the Tonnetz as the CRT grid (the fifth's diagonal, the two cycles, the mirror x ↦ 7x); the two rings against the 12-cube bell; the all-interval rows played by the voicing rule | 80–140 |
| `clip:13` … `clip:21` | what you hear | 40–90 |
| `page:acoustics` | the paper's dictionary: Burns, Daniel, Alexander and Dressel's tables carried into three columns (the paper's acoustics, its electromagnetism, the Atlas's words), the grades, the ten candidates | 120–180 |
| `bridges:table` | the table of the eleven bridges, before and after the drill: how to read it | 60–100 |

The builder (the site agent) may add targets of release 2 it needs (a figure group, the references); it lists every target with the English material it stands on in `content/it/MANIFEST.json`, and the narrators fill what the manifest lists. If a narrator finds a target in the manifest that is not in the tables above, write it at the length of its kind.

## The voice

- **Who speaks.** One narrator, a professional of music, of mathematics and of physics, speaking in the first person singular to a reader addressed as *voi* (an audience), present tense. Warm, exact, unhurried; never promotional. The narrator knows the three fields and uses their proper Italian terms (the glossary below), explains a term the first time it is needed on a page, and never hides behind the English.
- **What the narrator does.** Tells what the record establishes and *how* — the three ways the site sorts statements: *calcolato sulle etichette* (a check ran and passed), *standard, ricalcolato* (a textbook result recomputed), *dato in ingresso* with its source, *nostra lettura* with its reason, *aperto*. Names the rows by their ids ("la riga MUS-003"), the clips by their numbers ("il clip 04"), the scripts by their names. Quotes the numbers that matter, as the record prints them. Says what to listen for.
- **What the narrator never does.** Never claims more than the record: an analogy stays an analogy, a reading of ours stays ours, a proposed row is proposed. Never invents a number, a name, a source. Never translates the English records sentence by sentence (the reader has them beside); tells them instead. Never uses the banned words of the Atlas's tables in any form, Italian or English: *ora, adesso, nuovo, nuova, recente, ultimo, aggiornato, precedente, prima (in the sense of earlier), corretto (in the sense of fixed), sostituito, superato, versione, release, round N* — the narration is written as if it were always true. (The chrome may say "release 2" where the English chrome says it: the stamp line; nowhere else.)
- **The register of the Italian.** Professional Italian prose, no anglicisms where an Italian word exists (*verifica* not *check* in prose — but the Atlas's register names *Atlas* and *Standard*, the ids, and the file names stay as they are; *clip* is fine, it is the Atlas's word). Numbers as the records print them (decimal point). Mathematical notation as the records print it (ℤ₁₂, ω², Cl(1,3), √3, C(12, j)). Accents correct (è, perché, più, così). No bullet lists in a narration: prose, one to three paragraphs (separate paragraphs with a blank line in the JSON text; the generator renders them as paragraphs).

## The glossary (use these; add to it in your NOTE if you needed more)

| English (the Atlas's word) | Italian |
|---|---|
| the Atlas; the ONE RULE | l'Atlante; la regola unica (ONE RULE as a name stays) |
| label (the Atlas's bit labels) | etichetta |
| the rule; the cell | la regola; la cella |
| row; chain; lead (of a section); page; section | riga; catena; apertura (la guida di sezione); pagina; sezione |
| status: computed · standard, recomputed · input · ours · open | stato: calcolato · standard, ricalcolato · dato in ingresso · nostra lettura · aperto |
| chip (the status chip) | il bollino di stato |
| check (script); check tag; control (a check kept as a negative); fault | script di verifica; sigla della verifica; controllo; guasto (il `--fault`) |
| register: Story · Research · Atlas · Standard | registro: Racconto · Ricerca · Atlas · Standard |
| research text; learner text | testo di ricerca; testo per chi impara |
| claim; depends on; evidence; standard reference | enunciato; poggia su; evidenza; riferimento standard |
| the lens Music; grade: exact · partial · analogy · none; reading | la lente Musica; grado: esatto · parziale · analogia · nessuno; lettura |
| bridge (between the Atlas and music) | ponte |
| proposed, not merged | proposta, non ancora integrata nelle tavole (avoid "nuova") — say "proposta" |
| pitch; pitch class; interval; interval class; interval vector | altezza; classe di altezza; intervallo; classe intervallare; vettore intervallare |
| pitch-class set; set class; normal form; prime form | insieme di classi di altezza; classe di insiemi; forma normale; forma prima |
| tone row; all-interval row; retrograde; inversion; hexachord | serie (dodecafonica); serie panintervallare; retrogrado; inversione; esacordo |
| Tonnetz; triad; P, L, R (parallel, leading-tone exchange, relative) | Tonnetz; triade; P, L, R (parallela, scambio di sensibile, relativa) |
| hexatonic / octatonic cycle | ciclo esatonale / ottatonico |
| the clock (of twelve); the cycle of fifths; semitone; tritone; fifth; major/minor third | l'orologio (delle dodici classi); il circolo delle quinte; semitono; tritono; quinta; terza maggiore/minore |
| equal temperament, 12-TET; just intonation; cents; comma (Pythagorean, syntonic); beats | temperamento equabile, 12-TET; intonazione naturale; cent; comma (pitagorico, sintonico); battimenti |
| consonance, dissonance; dissonance curve; roughness | consonanza, dissonanza; curva di dissonanza; asprezza |
| partial; harmonic; fundamental; overtone; inharmonic | parziale; armonico; fondamentale; armonico superiore; inarmonico |
| string, stiff string, bar, membrane, bell | corda, corda rigida, barra, membrana, campana |
| chain of masses and springs; ring; mode; normal mode; stiffness; mass | catena di masse e molle; anello; modo; modo normale; rigidezza; massa |
| plucked; struck; decay | pizzicato; percosso; decadimento |
| Euclidean rhythm; necklace; Bjorklund's algorithm | ritmo euclideo; collana; algoritmo di Bjorklund |
| scale; diatonic; chromatic; generator (of a scale); well-formed scale; Sturmian word; Christoffel word | scala; diatonica; cromatica; generatore; scala ben formata; parola sturmiana; parola di Christoffel |
| continued fraction; cut; walk; 2-automatic sequence; substitution | frazione continua; taglio; cammino; successione 2-automatica; sostituzione |
| Fourier transform; DFT; character; Gauss sum | trasformata di Fourier; DFT; carattere; somma di Gauss |
| group; dihedral group D₁₂; cyclic group; orbit; Burnside's lemma; centralizer; conjugation; torsor; affine group | gruppo; gruppo diedrale D₁₂; gruppo ciclico; orbita; lemma di Burnside; centralizzante; coniugio; torsore; gruppo affine |
| Chinese remainder theorem (CRT) | teorema cinese del resto |
| Clifford algebra Cl(p,q); signature; grade; multivector; bivector; rotor; motor; versor; the mirror Cl(p,q) → Cl(q,p) | algebra di Clifford Cl(p,q); segnatura; grado; multivettore; bivettore; rotore; motore; versore; lo specchio Cl(p,q) → Cl(q,p) |
| rigid body; body frame; space frame; angular velocity; Euler's equations | corpo rigido; sistema solidale; sistema fisso; velocità angolare; equazioni di Eulero |
| spacetime; Maxwell's equations; electromagnetism; acoustics; wave; pressure; velocity potential; energy–momentum tensor | spaziotempo; equazioni di Maxwell; elettromagnetismo; acustica; onda; pressione; potenziale di velocità; tensore energia-impulso |
| figure; clip; instrument; the synthesizer; oscillator; fade | figura; clip; strumento; il sintetizzatore; oscillatore; dissolvenza |
| source; reference; the study *Music on the labels*; the study *The bridges drilled*; the pack | fonte; riferimento; lo studio *Music on the labels*; lo studio *The bridges drilled* (titles stay in English, say "lo studio"); il pacchetto |
| home; dictionary; checks; pictures; sounds; sources; about (the pages) | inizio; dizionario; verifiche; figure; suoni; fonti; il sito (the About page: "Il metodo") |

## What the narrators deliver

- `site/it/draft/strings_it.json` and `site/it/draft/racconto_r1.json` (IT-1); `site/it/draft/racconto_bridges.json` (IT-2) — valid JSON (check with `python3 -c 'import json;json.load(open(...))'`), the ids exactly as above, every text in the lengths above (count words), no banned word (grep the list), no HTML.
- `site/it/draft/NOTE_IT-1.md` / `NOTE_IT-2.md`: what was read, the choices of terminology beyond the glossary, what was unclear in the sources and how it was told, and a word count.
- Every narration must be *checkable*: each number, name and claim in it must be found in the record it `tells`. The reviewer reads them side by side.

## Second pass (the owner's reading of the Italian site)

The owner opened the Italian site and said: *"why english is still there? … An italian human reader has to read SPR-M01, then english and then what do you understand? Is that a narrative way?"* and, on the bookkeeping lines (the study's byline, "proposed, not merged", "stored as a pack for a later release"): *"that was for you to reason … What does a reader of music / math / physics care about these information?"*

Two consequences for the narrators.

### A. The Italian reading flow is yours alone: the table `titoli.json`

On an Italian page every title, claim, caption and label a reader meets is the narrator's. The builder is rebuilding the pages so that the English records leave the flow (they stay in the Ricerca · Atlas · Standard registers and in collapsed disclosures). What is missing are the short pieces: a table `titoli.json` with the same shape as `racconto.json` (`{"about", "voice", "items": [{"id": "t:<target>", "target": "<target>", "text": "…", "why": "…"}]}`), one item per target of `gen/content/it/MANIFEST_TITOLI.json` (the builder writes it within its first fifteen minutes; until it is there, the list below is the contract, and the manifest only adds the English material each target stands on):

| target | what you write | length |
|---|---|---|
| `section:<slug>` | the section's title: the page's h1 and the home card's title | ≤ 8 words, no final period |
| `section:<slug>:sub` | one line under it, the physics and the mathematics of the section in one breath | ≤ 14 words |
| `chain:<slug>` | the heading of the section's list of rows | ≤ 8 words |
| `card:section:<slug>` | the home card's text: what the section is about and what it establishes | 40–70 words |
| `page:bridges`, `page:bridges:sub`, `page:bridges:head`, `card:page:bridges` | the bridges page: its title ("I ponti" or your better word — no "sondati/trivellati" jargon), its subtitle, one line saying what the page is (a study of eleven bridges between the Atlas and music, read on the labels — no byline, no date, no owner), the home card's text (40–70) | as the kinds above |
| `row:<id>` | the row's claim in one Italian line: what the row says, as the title of its block — the reader meets this line first, then the chip, then your narration | ≤ 14 words, no final period |
| `fig:<name>` | the figure's caption: what it shows and what to look at | 15–45 words |
| `clip:<nn>` | the clip's title line | ≤ 10 words |
| `item:<item>` | the title of each of the eight chapters of the bridges page | ≤ 10 words |
| `bridge:<n>`, `bridge:<n>:why` | the bridge's name (what it joins) and what decided its grade | ≤ 8 words; ≤ 25 words |
| `lens:<n>` | the music term of the lens entry n, in Italian (the entry's `term` field, told in a few words) | ≤ 10 words |
| `paper:<row>` | the Italian for the Atlas column of the paper's dictionary row | ≤ 10 words |
| `check:<script>` | one line: what the script computes | ≤ 16 words |

Deliveries: `it/draft/titoli_r1.json` (IT-1: the eight sections, chains and cards; the 27 Atlas rows; the 13 figures of *Music on the labels*; the clips 01 … 10; the 34 lens entries; the scripts music_sound and music_symmetry) and `it/draft/titoli_bridges.json` (IT-2: the bridges page's four, the 36 rows MUS-014 … 049, the 12 figures of the bridges, the clips 13 … 21, the eight items, the eleven bridges, the 17 paper rows, the nine scripts). Same rules as the narrations: the voice, the glossary, the banned words, no HTML, the ids exact, fidelity to the record (a row's one-line claim says what the row's claim says — read its homePhys and research text — not more).

### B. No bookkeeping in the narrations

A reader of music, mathematics and physics does not care that a row is "proposta, non integrata nelle tavole", that the study "è conservato come pacchetto", that it was "scritta per il proprietario dell'Atlante", nor about "la release 4.4.9", "round 36", "il pacchetto". Those were the work's words. Go through your half of `gen/content/it/racconto.json` and `strings_it.json` (the merged, reviewed tables — edit them in place with a script, by target/id, leaving every other field as it is) and remove every such sentence or clause: a proposed row is simply told (what it says, what establishes it — "calcolato", "standard, ricalcolato", "nostra lettura" — and what to hear); the bridges page is "lo studio dei ponti" or "questa pagina", never a pack or a note for the owner; the stamps and intros say nothing of releases and rounds. Keep the word counts inside the ranges after the cut (add a sentence of substance where a cut leaves a narration short). The builder's `MANIFEST_TITOLI.json` lists under `strings_changed` the English strings it reworded for the same reason: re-word their Italian too. Record every edit (target/id, old → new) in `it/draft/NOTE_IT-<n>_pass2.md`.
