# -*- coding: utf-8 -*-
# IT-2 · pass 2 · the narrator's check of titoli_bridges.json and pass2_edits_bridges.json against
# gen/content/it/MANIFEST_TITOLI.json (the titoli targets and lengths) and MANIFEST.json (the narrations' lengths):
# the banned words of it/VOICE_IT.md as gen/lib/italian.mjs matches them, the process words of BRIEF_R2b.md §0,
# the lengths, no final period on the one-line kinds, no markup, the ids exact, the placeholders kept.
# Run from anywhere: python3 -I it/draft/check_IT-2_pass2.py
import json, re, os, sys
DRAFT = os.path.dirname(os.path.abspath(__file__))
SITE = os.path.dirname(os.path.dirname(DRAFT))
MT = json.load(open(os.path.join(SITE, 'gen', 'content', 'it', 'MANIFEST_TITOLI.json'), encoding='utf-8'))
M1 = json.load(open(os.path.join(SITE, 'gen', 'content', 'it', 'MANIFEST.json'), encoding='utf-8'))
TIT = json.load(open(os.path.join(DRAFT, 'titoli_bridges.json'), encoding='utf-8'))
ED = json.load(open(os.path.join(DRAFT, 'pass2_edits_bridges.json'), encoding='utf-8'))
EN = {s['id']: s for s in json.load(open(os.path.join(SITE, 'gen', 'content', 'strings.json'), encoding='utf-8'))['strings']}

BANNED = ['adesso', 'nuovo', 'nuova', 'nuovi', 'nuove', 'recente', 'recenti', 'ultimo', 'ultima', 'ultimi', 'ultime',
          'aggiornato', 'aggiornata', 'aggiornati', 'aggiornate', 'precedente', 'precedenti', 'corretto', 'corretta',
          'corretti', 'corrette', 'sostituito', 'sostituita', 'sostituiti', 'sostituite', 'superato', 'superata',
          'superati', 'superate', 'versione', 'versioni', 'release']
# the process words of BRIEF_R2b.md §0 / MANIFEST_TITOLI.json rules.banned (every form)
PROCESS = ['pacchetto', 'pacchetti', 'integrato', 'integrata', 'integrati', 'integrate', 'proposto', 'proposta', 'proposti', 'proposte',
           'proprietario', 'sondato', 'sondata', 'sondati', 'sondate', 'sonda', 'sondare', 'trivellato', 'trivellati', 'trivellata',
           'trivellate', 'perforato', 'perforati', 'perforata', 'perforate', 'drill', 'drilled']
NL = r"(?<![^\W\d_])"; NLQ = r"(?<![^\W\d_])(?<!['’])"; NF = r"(?![^\W\d_])"
def hits(text, words):
    h = []
    for w in words:
        h += [m.group(1) for m in re.finditer(NLQ + "(" + w + ")" + NF, text, flags=re.I)]
    return h
def banned_hits(text):
    h = hits(text, BANNED)
    h += [m.group(1) for m in re.finditer(NLQ + r"(ora)" + NF, text, flags=re.I)]
    h += [m.group(1) for m in re.finditer(NL + r"(round\s*\d+)", text, flags=re.I)]
    h += [m.group(1) for m in re.finditer(NLQ + r"(prima)(?=\s+(?:di|che|del|della|dei|delle|dello|degli|d')\b|\s*[,.;:!?]|\s*$)", text, flags=re.I)]
    h += [m.group(1) for m in re.finditer(r"\b(?:come|di|da)\s+(prima)" + NF, text, flags=re.I)]
    h += [m.group(0) for m in re.finditer(r"nota di ricerca|4\.4\.9", text, flags=re.I)]
    return h
def process_hits(text):
    return hits(text, PROCESS)
def ntok(text): return len(text.split())
def maxlen(spec):
    m = re.search(r'≤\s*(\d+)', spec); return int(m.group(1)) if m else None
def rangelen(spec):
    m = re.search(r'(\d+)\s*[–-]\s*(\d+)', spec); return (int(m.group(1)), int(m.group(2))) if m else None

errors = []
targets = {t['target']: t for t in MT['targets']}
MINE = (['page:bridges', 'page:bridges:sub', 'page:bridges:head', 'card:page:bridges'] + ['row:MUS-%03d' % n for n in range(14, 50)]
        + ['fig:' + f for f in 'two_clocks crt_tonnetz fig_johnson_tonnetz fig_bell_levels fig_288 fig_harmonic_ring two_cuts fig_rows fig_chain fig_sets fig_motors fig_grades'.split()]
        + ['clip:%d' % n for n in range(13, 22)] + ['item:' + i for i in 'clock labels duality walk rows rings body acoustics'.split()]
        + sum([['bridge:%d' % n, 'bridge:%d:why' % n] for n in range(1, 12)], []) + ['paper:' + p for p in ['0', '1a', '1b'] + [str(i) for i in range(2, 16)]]
        + ['check:music_' + s for s in 'clock12 labels12 duality bell walk rows rings body acoustics'.split()])
ONE_LINE = ('page:bridges', 'page:bridges:sub', 'row:', 'clip:', 'item:', 'bridge:', 'paper:', 'check:')
seen = set()
for it in TIT['items']:
    t = it['target']
    if t not in targets: errors.append('titoli: unknown target ' + t); continue
    if t not in MINE: errors.append('titoli: not my target ' + t)
    if t in seen: errors.append('titoli: target twice ' + t)
    seen.add(t)
    if it['id'] != 't:' + t: errors.append('titoli: bad id ' + it['id'])
    if not it.get('why'): errors.append('titoli: no why ' + t)
    text = it['text']; spec = targets[t]['length']; n = ntok(text)
    mx = maxlen(spec); rg = rangelen(spec)
    if mx is not None and n > mx: errors.append('titoli length %s: %d > %s' % (t, n, spec))
    if rg is not None and not (rg[0] <= n <= rg[1]): errors.append('titoli length %s: %d, wants %s' % (t, n, spec))
    if t.startswith(ONE_LINE) and text.rstrip().endswith('.'): errors.append('titoli: final period on ' + t)
    h = banned_hits(text) + process_hits(text)
    if h: errors.append('titoli banned/process %s: %s' % (t, sorted(set(h))))
    if re.search(r'<[a-z][^>]*>|\*\*|^#', text, flags=re.M): errors.append('titoli markup ' + t)
    if 'The bridges drilled' in text: errors.append('titoli names The bridges drilled: ' + t)
missing = [t for t in MINE if t not in seen]
if missing: errors.append('titoli missing: %s' % missing)

T1 = {t['target']: t for t in M1['targets']}
for e in ED['racconto']:
    t = e['target']; text = e['text']; n = ntok(text)
    rg = rangelen(T1[t]['length'])
    if not (rg[0] <= n <= rg[1]): errors.append('edit length %s: %d, wants %s' % (t, n, T1[t]['length']))
    h = banned_hits(text) + process_hits(text)
    if h: errors.append('edit banned/process %s: %s' % (t, sorted(set(h))))
    if re.search(r'<[a-z][^>]*>|\*\*|^#', text, flags=re.M): errors.append('edit markup ' + t)
    if 'The bridges drilled' in text: errors.append('edit names The bridges drilled: ' + t)
ABOUT = ('method.', 'about.')
for e in ED['strings']:
    i = e['id']
    if e.get('drop'):
        if i in EN: errors.append('dropped string still in strings.json: ' + i)
        continue
    text = e['text']
    if i not in EN: errors.append('edit string not in strings.json: ' + i); continue
    h = banned_hits(text)
    if h: errors.append('edit string banned %s: %s' % (i, sorted(set(h))))
    p = process_hits(text)
    if p and not i.startswith(ABOUT): errors.append('edit string process word %s: %s' % (i, sorted(set(p))))
    if p and i.startswith(ABOUT): print('note: process word allowed on Il metodo in %s: %s' % (i, sorted(set(p))))
    for ph in re.findall(r'\{[a-zA-Z]+\}', EN[i]['text']):
        if ph not in text: errors.append('placeholder %s lost in %s' % (ph, i))
    if 'The bridges drilled' in text and not (i.startswith(ABOUT) or i.startswith('src.')): errors.append('string names The bridges drilled outside Fonti/Il metodo: ' + i)
for err in errors: print('ERR', err)
print('titoli %d items, edits: %d narrations, %d strings (%d dropped), errors %d' % (
    len(TIT['items']), len(ED['racconto']), len([e for e in ED['strings'] if not e.get('drop')]), len([e for e in ED['strings'] if e.get('drop')]), len(errors)))
sys.exit(1 if errors else 0)
