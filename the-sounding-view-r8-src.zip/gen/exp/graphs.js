// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// graphs — one construction on three graphs: chain, ring, cube (MUS-002, SPR-M16, MUS-025, MUS-030, MUS-005).
// The cube's walsh, edges, omega2 and the flat projection are those of ATLAS/engines/springEngine.js (with bitrule's popcount), copied as plain functions.
(function () {
  'use strict';
  window.SDV_EXP = window.SDV_EXP || {};
  var RM = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  function cents(r) { return 1200 * Math.log(r) / Math.LN2; }
  function rep(s, o) { for (var k in o) s = s.replace('{' + k + '}', o[k]); return s; }
  function cv(kit, parent, aspect, maxH) { var d = kit.el('div', { style: 'width:100%;min-width:0' }); parent.appendChild(d); return kit.canvas(d, aspect, maxH); }
  function txt(ctx, s, x, y, al, col, px) { ctx.fillStyle = col; ctx.font = (px || 11) + 'px system-ui, sans-serif'; ctx.textAlign = al || 'left'; ctx.fillText(s, x, y); }
  // one Play/Mute per panel (only one sounds at a time) and one Pause for the picture
  function transport(kit, S) {
    var st = { paused: RM }, cur = null, hasAudio = !!(window.AudioContext || window.webkitAudioContext), warned = false;
    st.pause = function (controls) {
      var p = kit.button(controls, 'exp.common.pause', S, function () { st.paused = !st.paused; show(); if (st.onpause) st.onpause(); });
      function show() { p.setAttribute('aria-pressed', String(st.paused)); p.style.background = st.paused ? 'var(--accent-tint)' : ''; }
      show(); return p;
    };
    st.player = function (controls, o) {
      var me = { on: false };
      var b = kit.button(controls, 'exp.common.play', S, function () {
        if (me.on) { me.stop(); return; }
        if (!hasAudio || !kit.audio()) { b.disabled = true; if (!warned) { warned = true; kit.line(controls.parentNode, 'exp.common.noaudio', S); } return; }
        if (cur && cur !== me) cur.stop();
        me.on = true; cur = me; label(); o.start();
      });
      function label() { var id = me.on ? 'exp.common.mute' : 'exp.common.play'; b.setAttribute('data-s', id); b.textContent = S(id); b.setAttribute('aria-pressed', String(me.on)); }
      me.stop = function () { if (!me.on) return; me.on = false; if (cur === me) cur = null; label(); o.stop(); };
      return me;
    };
    return st;
  }
  // the foot of every experiment: what you see, what you hear, the data line
  function foot(kit, S, root, slug) {
    var p = kit.panel_(root, 'exp.common.see', S, 'span');
    kit.line(p, 'exp.' + slug + '.see', S);
    p.appendChild(kit.el('h3', { 'data-s': 'exp.common.hear', text: S('exp.common.hear') }));
    kit.line(p, 'exp.' + slug + '.hear', S);
    p.appendChild(kit.el('p', { class: 'exp-source' }, [kit.el('b', { 'data-s': 'exp.common.data', text: S('exp.common.data') }), ' · ', kit.el('span', { 'data-s': 'exp.' + slug + '.data', text: S('exp.' + slug + '.data') })]));
  }
  var TAU = Math.PI * 2, F1 = 220, FPIC = 0.5;
  function pc(x) { var c = 0; while (x) { c += x & 1; x >>= 1; } return c; }
  function walsh(s, x) { return pc(x & s) & 1 ? -1 : 1; }
  function edgesOf(n) { var r = []; for (var x = 0; x < 1 << n; x++) for (var i = 0; i < n; i++) if (!(x >> i & 1)) r.push([x, x | 1 << i]); return r; }
  function binom(n, k) { var r = 1; for (var i = 1; i <= k; i++) r = r * (n - k + i) / i; return Math.round(r); }
  var PROJ = [[1, 0], [0, -1], [0.46, -0.36], [-0.42, -0.5], [0.15, 0.58]];
  function bin(n, x) { var s = x.toString(2); while (s.length < n) s = '0' + s; return s; }

  window.SDV_EXP.graphs = { mount: function (root, data, S, kit) {
    root.classList.add('half');
    var T = transport(kit, S), accent = kit.accent(), ink = kit.ink(), mut = kit.muted();
    var g = { kind: 'chain', N: 12, n: 3, m: 1, s: 1 }, tau = 0, tp = 0, node = { chain: 3, ring: 0, cube: 0 }, hit = [], voice = null, pmode = 'here', drawn = {};

    // ---- the Atlas's spectra (chain N = 5 and ring from the data; chain N = 12 by the formula, cube by omega2 = 2|s|)
    function chainOm(N, k) { return N === 5 ? Math.sqrt(data.chain5_omega2[k - 1]) : 2 * Math.sin(Math.PI * k / (2 * (N + 1))); }
    function ringOm(k) { return Math.sqrt(data.ring12_omega2[((k % 12) + 12) % 12]); }
    function cubeOm(s) { return Math.sqrt(2 * pc(s)); }
    function ref() { return g.kind === 'chain' ? chainOm(g.N, 1) : g.kind === 'ring' ? ringOm(1) : Math.sqrt(2); }
    function om() { return g.kind === 'chain' ? chainOm(g.N, g.m) : g.kind === 'ring' ? ringOm(g.m) : cubeOm(g.s); }
    function hz() { return F1 * om() / ref(); }
    function levels() { // [{w (ratio to the first), mult, id, weight (of the pluck at node)}]
      var L = [], k, j;
      if (g.kind === 'chain') for (k = 1; k <= g.N; k++) L.push({ w: chainOm(g.N, k) / ref(), mult: 1, id: k, wt: 2 / (g.N + 1) * Math.pow(Math.sin(Math.PI * k * (node.chain + 1) / (g.N + 1)), 2) });
      else if (g.kind === 'ring') for (k = 1; k <= 6; k++) L.push({ w: ringOm(k) / ref(), mult: k === 6 ? 1 : 2, id: k, wt: k === 6 ? 1 / 12 : 2 / 12 });
      else for (j = 1; j <= g.n; j++) L.push({ w: Math.sqrt(j), mult: binom(g.n, j), id: j, wt: binom(g.n, j) / (1 << g.n) });
      L.forEach(function (l) { l.c = cents(l.w); });
      return L;
    }
    function curLevel() { return g.kind === 'ring' ? Math.min(g.m, 12 - g.m) : g.kind === 'chain' ? g.m : pc(g.s); }
    function nodes() { return g.kind === 'chain' ? g.N : g.kind === 'ring' ? 12 : 1 << g.n; }
    // the mode and the pluck as displacements of the nodes
    function modeVals(ph) {
      var v = [], i, c = Math.cos(ph);
      for (i = 0; i < nodes(); i++) v.push(c * (g.kind === 'chain' ? Math.sin(Math.PI * g.m * (i + 1) / (g.N + 1)) : g.kind === 'ring' ? Math.cos(TAU * g.m * i / 12) : walsh(g.s, i)));
      return v;
    }
    function pluckVals(t) { // t: picture turns of the lowest mode
      var v = [], N = nodes(), j0 = node[g.kind], i, k, a;
      for (i = 0; i < N; i++) {
        a = 0;
        if (g.kind === 'chain') for (k = 1; k <= g.N; k++) a += 2 / (g.N + 1) * Math.sin(Math.PI * k * (j0 + 1) / (g.N + 1)) * Math.sin(Math.PI * k * (i + 1) / (g.N + 1)) * Math.cos(Math.PI * 2 * t * chainOm(g.N, k) / ref());
        else if (g.kind === 'ring') { for (k = 0; k < 12; k++) a += Math.cos(TAU * k * (i - j0) / 12) * Math.cos(TAU * t * ringOm(k) / ref()); a /= 12; }
        else { for (k = 0; k < N; k++) a += walsh(k, j0) * walsh(k, i) * Math.cos(TAU * t * cubeOm(k) / ref()); a /= N; }
        v.push(a);
      }
      return v;
    }

    // ---- drawing the graph with displacements
    function geom(w, h) {
      var P = [], i, N = nodes(), cx = w / 2, cy = h / 2, R;
      if (g.kind === 'chain') { for (i = 0; i < N; i++) P.push({ x: 14 + (w - 28) * (i + 1) / (N + 1), y: cy, dx: 0, dy: -1 }); }
      else if (g.kind === 'ring') { R = Math.min(w, h) * 0.32; for (i = 0; i < N; i++) { var a = TAU * i / 12 - Math.PI / 2; P.push({ x: cx + R * Math.cos(a), y: cy + R * Math.sin(a), dx: Math.cos(a), dy: Math.sin(a) }); } }
      else {
        var q = [], x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9;
        for (i = 0; i < N; i++) { var px = 0, py = 0; for (var b = 0; b < g.n; b++) if (i >> b & 1) { px += PROJ[b][0]; py += PROJ[b][1]; } q.push([px, py]); x0 = Math.min(x0, px); x1 = Math.max(x1, px); y0 = Math.min(y0, py); y1 = Math.max(y1, py); }
        var k = Math.min((w - 60) / Math.max(0.5, x1 - x0), (h - 50) / Math.max(0.5, y1 - y0));
        q.forEach(function (p) { P.push({ x: cx + (p[0] - (x0 + x1) / 2) * k, y: cy + (p[1] - (y0 + y1) / 2) * k, dx: 0, dy: 0 }); });
      }
      return P;
    }
    function drawGraph(c, vals, key) {
      var ctx = c.ctx, w = c.w, h = c.h, P = geom(w, h), N = P.length, A = g.kind === 'chain' ? h * 0.3 : g.kind === 'ring' ? Math.min(w, h) * 0.12 : 0, i;
      ctx.clearRect(0, 0, w, h);
      var Q = P.map(function (p, i) { return { x: p.x + p.dx * A * vals[i] * (g.kind === 'ring' ? 1 : 0) + 0, y: p.y + (g.kind === 'chain' ? -A * vals[i] : p.dy * A * vals[i]) }; });
      if (g.kind === 'ring') Q = P.map(function (p, i) { return { x: p.x + p.dx * A * vals[i], y: p.y + p.dy * A * vals[i] }; });
      ctx.strokeStyle = mut; ctx.lineWidth = 1.2; ctx.beginPath();
      if (g.kind === 'chain') { ctx.moveTo(14, h / 2); Q.forEach(function (p) { ctx.lineTo(p.x, p.y); }); ctx.lineTo(w - 14, h / 2); ctx.stroke(); [14, w - 14].forEach(function (x) { ctx.lineWidth = 2.5; ctx.strokeStyle = ink; ctx.beginPath(); ctx.moveTo(x, h / 2 - 12); ctx.lineTo(x, h / 2 + 12); ctx.stroke(); }); }
      else if (g.kind === 'ring') { Q.forEach(function (p, i) { if (i) ctx.lineTo(p.x, p.y); else ctx.moveTo(p.x, p.y); }); ctx.closePath(); ctx.stroke(); }
      else { edgesOf(g.n).forEach(function (e) { ctx.moveTo(Q[e[0]].x, Q[e[0]].y); ctx.lineTo(Q[e[1]].x, Q[e[1]].y); }); ctx.stroke(); }
      for (i = 0; i < N; i++) {
        var r = g.kind === 'cube' ? 3 + 8 * Math.min(1, Math.abs(vals[i])) : 5, v = vals[i];
        ctx.beginPath(); ctx.arc(Q[i].x, Q[i].y, r, 0, TAU);
        if (g.kind === 'cube') { if (v >= 0) { ctx.fillStyle = kit.red; ctx.fill(); } else { ctx.fillStyle = kit.panel(); ctx.fill(); ctx.strokeStyle = kit.blue; ctx.lineWidth = 2; ctx.stroke(); } }
        else { ctx.fillStyle = ink; ctx.fill(); }
        if (key === 'p' && i === node[g.kind]) { ctx.strokeStyle = accent; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(Q[i].x, Q[i].y, r + 4, 0, TAU); ctx.stroke(); }
      }
      if (g.kind === 'cube') for (i = 0; i < N; i++) if (N <= 8) txt(ctx, bin(g.n, i), P[i].x, P[i].y - 14, 'center', mut, 9);
      drawn[key] = P;
    }
    function bars(c, items, hmax, selc) { // items {c cents, h, sel}; the harmonic ruler behind
      var ctx = c.ctx, w = c.w, h = c.h, l = 12, r = 10, t = 10, b = 26, maxC = 1;
      ctx.clearRect(0, 0, w, h);
      items.forEach(function (it) { maxC = Math.max(maxC, it.c); }); maxC = Math.max(maxC * 1.06, 1300);
      var X = function (cc) { return l + cc / maxC * (w - l - r); };
      ctx.lineWidth = 1; ctx.strokeStyle = mut;
      for (var n = 1; n <= 12; n++) { var cc = cents(n); if (cc > maxC) break; ctx.globalAlpha = 0.5; ctx.setLineDash([3, 3]); ctx.beginPath(); ctx.moveTo(X(cc), t); ctx.lineTo(X(cc), h - b); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1; txt(ctx, String(n), X(cc), h - b + 12, 'center', mut, 10); }
      ctx.beginPath(); ctx.moveTo(l, h - b); ctx.lineTo(w - r, h - b); ctx.stroke();
      items.forEach(function (it) { var bh = Math.max(2, it.h / hmax * (h - b - t)); ctx.fillStyle = it.sel ? accent : kit.blue; ctx.fillRect(X(it.c) - 3.5, h - b - bh, 7, bh); });
      txt(ctx, S('exp.common.cents'), w - r, h - 4, 'right', mut, 10);
    }

    // ---- panel a
    var pa = kit.panel_(root, 'exp.graphs.panel.a', S);
    var cA = cv(kit, pa, 0.7, 340), ctlA = kit.controls(pa), clockWrap = kit.el('div'), cClock = cv(kit, clockWrap, 0.34);
    kit.seg(ctlA, { ids: ['exp.graphs.g.chain', 'exp.graphs.g.ring', 'exp.graphs.g.cube'], values: ['chain', 'ring', 'cube'], value: 'chain', S: S, onchange: function (v) { g.kind = v; g.m = 1; g.s = 1; ms.set(1); setRange(); sync(); } });
    var segN = kit.seg(ctlA, { ids: ['exp.graphs.n.5', 'exp.graphs.n.12'], values: [5, 12], value: 12, S: S, onchange: function (v) { g.N = v; g.m = Math.min(g.m, v); node.chain = Math.min(node.chain, v - 1); setRange(); sync(); } });
    var segC = kit.seg(ctlA, { ids: ['exp.graphs.c.2', 'exp.graphs.c.3', 'exp.graphs.c.4'], values: [2, 3, 4], value: 3, S: S, onchange: function (v) { g.n = v; g.s = 1; ms.set(1); node.cube = 0; setRange(); sync(); } });
    var rangeEl, ms = kit.slider(ctlA, { id: 'exp.common.mode', S: S, min: 1, max: 12, step: 1, value: 1, fmt: function (v) { return g.kind === 'cube' ? bin(g.n, v) : String(v); }, onchange: function (v) { if (g.kind === 'cube') g.s = v; else g.m = v; sync(); } });
    rangeEl = ms.el.querySelector('input');
    function setRange() { rangeEl.max = g.kind === 'chain' ? g.N : g.kind === 'ring' ? 11 : (1 << g.n) - 1; ms.set(g.kind === 'cube' ? g.s : g.m); }
    var playA = T.player(ctlA, { start: function () { voice = kit.voice({ f: hz(), gain: 0.15 }); }, stop: function () { if (voice) voice.stop(); voice = null; } });
    T.pause(ctlA);
    pa.appendChild(clockWrap);
    var rdA = kit.readout(pa), rdA2 = kit.readout(pa);
    kit.line(pa, 'exp.graphs.line.clock', S, 'clockline');

    // ---- panel b
    var pb = kit.panel_(root, 'exp.graphs.panel.b', S);
    var cB = cv(kit, pb, 0.62, 300), rdB = kit.readout(pb);
    var lnForm = kit.line(pb, 'exp.graphs.line.formula', S);
    kit.line(pb, 'exp.graphs.line.harmonic', S);

    // ---- panel c
    var pc_ = kit.panel_(root, 'exp.graphs.panel.c', S, 'span');
    var cP = cv(kit, pc_, 0.5, 300), cW = cv(kit, pc_, 0.26, 130), ctlC = kit.controls(pc_);
    kit.seg(ctlC, { ids: ['exp.graphs.p.here', 'exp.graphs.p.cube12'], values: ['here', 'cube12'], value: 'here', S: S, onchange: function (v) { pmode = v; draw(); } });
    kit.button(ctlC, 'exp.common.pluck', S, function () { strike(); });
    var rdC = kit.readout(pc_), rdC2 = kit.readout(pc_);
    kit.line(pc_, 'exp.graphs.line.pluck', S);
    foot(kit, S, root, 'graphs');

    function strike() {
      tp = 0;
      if (!kit.audio()) { if (!strike.w) { strike.w = 1; kit.line(pc_, 'exp.common.noaudio', S); } return; }
      var parts;
      if (pmode === 'cube12') parts = data.clip14.freqs_hz.map(function (f, i) { return { f: f, a: data.clip14.amps[i], decay: 1.8 }; });
      else if (g.kind === 'cube' && g.n === 3) parts = data.clip13.freqs_hz.map(function (f, i) { return { f: f, a: data.clip13.amps[i], decay: data.clip13.tau1_s }; });
      else parts = levels().map(function (l) { return { f: F1 * l.w, a: l.wt * l.mult, decay: 1.8 }; });
      var tot = 0; parts.forEach(function (p) { tot += p.a; });
      parts.forEach(function (p) { p.a = p.a / tot; });
      kit.strike(parts, 0.3);
    }
    function sync() {
      var on = g.kind;
      segN.el.style.display = on === 'chain' ? '' : 'none'; segC.el.style.display = on === 'cube' ? '' : 'none';
      clockWrap.style.display = on === 'ring' ? '' : 'none'; pa.querySelector('.clockline').style.display = on === 'ring' ? '' : 'none';
      lnForm.style.display = on === 'chain' && g.N === 12 || on === 'ring' || on === 'cube' && g.n > 4 ? '' : 'none';
      lnForm.setAttribute('data-s', on === 'cube' ? 'exp.graphs.line.formula.cube' : on === 'ring' ? 'exp.graphs.line.formula.ring' : 'exp.graphs.line.formula'); lnForm.textContent = S(lnForm.getAttribute('data-s'));
      if (voice) voice.set(hz(), null);
      draw();
    }
    function draw() {
      var ph = Math.PI * 2 * FPIC * (om() / ref()) * tau;
      drawGraph(cA, modeVals(ph), 'a');
      if (g.kind === 'ring') { // the clock: the mode k as the character zeta^(jk)
        var c = cClock.ctx, w = cClock.w, h = cClock.h, R = Math.min(w, h) * 0.34, cx = w / 2, cy = h / 2, j; c.clearRect(0, 0, w, h);
        c.strokeStyle = mut; c.lineWidth = 1; c.beginPath(); c.arc(cx, cy, R, 0, TAU); c.stroke();
        for (j = 0; j < 12; j++) {
          var a = TAU * j / 12 - Math.PI / 2, hx = cx + R * Math.cos(a), hy = cy + R * Math.sin(a), th = TAU * g.m * j / 12 - Math.PI / 2 + Math.PI / 2 * 0, L = R * 0.3;
          c.beginPath(); c.moveTo(cx, cy); c.lineTo(hx, hy); c.globalAlpha = 0.25; c.stroke(); c.globalAlpha = 1;
          kit.arrow(c, hx, hy, hx + L * Math.cos(th), hy + L * Math.sin(th), j === 0 ? accent : kit.blue, 1.5);
          txt(c, String(j === 0 ? 12 : j), cx + (R + 14) * Math.cos(a), cy + (R + 14) * Math.sin(a) + 3, 'center', mut, 10);
        }
      }
      var L = levels(), cl = curLevel();
      bars(cB, L.map(function (l) { return { c: l.c, h: l.mult, sel: l.id === cl }; }), Math.max.apply(null, L.map(function (l) { return l.mult; })));
      // the pluck
      if (pmode === 'cube12') {
        var c2 = cP.ctx, w2 = cP.w, h2 = cP.h, i, W = 0.03, s0 = tp / (F1 / FPIC), cv12 = data.cube12; c2.clearRect(0, 0, w2, h2);
        c2.strokeStyle = mut; c2.lineWidth = 0.6; c2.beginPath(); c2.moveTo(6, h2 / 2); c2.lineTo(w2 - 6, h2 / 2); c2.stroke();
        c2.strokeStyle = ink; c2.lineWidth = 1.4; c2.beginPath();
        for (i = 0; i <= 300; i++) { var s = s0 - W + W * i / 300, v = 0; cv12.forEach(function (r) { v += r.weight_float * Math.cos(TAU * F1 * Math.sqrt(r.j) * s); }); var X = 6 + (w2 - 12) * i / 300, Y = h2 / 2 - v * (h2 / 2 - 8); if (i) c2.lineTo(X, Y); else c2.moveTo(X, Y); }
        c2.stroke(); txt(c2, S('exp.graphs.p.trace'), 8, 14, 'left', mut, 10);
        var items = cv12.filter(function (r) { return r.j > 0; }).map(function (r) { return { c: parseFloat(r.cents_0_1), h: r.weight_float, sel: r.j === 6 }; });
        bars(cW, items, 0.25);
        rdC.textContent = 'ω²/ω₁² = j · weights C(12, j)/4096 · j = 1…12: ' + data.cube12.filter(function (r) { return r.j > 0; }).map(function (r) { return r.weight; }).join(', ');
        rdC2.textContent = 'loudest: √6 = ' + kit.num(parseFloat(data.cube12[6].cents_0_1), 1) + ' ' + S('exp.common.cents') + ' (' + data.cube12[6].weight + ') · ' + S('exp.common.slowed').replace('{n}', kit.num(F1 / FPIC, 0));
      } else {
        drawGraph(cP, pluckVals(tp * FPIC), 'p');
        bars(cW, L.map(function (l) { return { c: l.c, h: l.wt * l.mult, sel: false }; }), Math.max.apply(null, L.map(function (l) { return l.wt * l.mult; })));
        if (g.kind === 'cube' && g.n === 3) {
          var cb = data.cube3;
          rdC.textContent = '1 : √2 : √3 = ' + cb.cents_above_first.map(function (x) { return kit.num(x, 3); }).join(', ') + ' ' + S('exp.common.cents') + ' · ' + cb.weights.slice(1).join(', ');
        } else rdC.textContent = L.map(function (l) { return kit.num(l.c, 0); }).join(' · ') + ' ' + S('exp.common.cents');
        rdC2.textContent = S('exp.common.slowed').replace('{n}', kit.num(F1 / FPIC, 0));
      }
      var Lc = L.map(function (l) { return kit.num(l.c, 0); });
      rdA.textContent = (g.kind === 'cube' ? 's = ' + bin(g.n, g.s) + ' · ω² = 2·' + pc(g.s) + ' = ' + (2 * pc(g.s)) : S('exp.common.mode') + ' ' + g.m + ' · ω = ' + kit.num(om(), 4)) + ' → ' + kit.num(hz(), 1) + ' ' + S('exp.common.hz');
      rdA2.textContent = S('exp.common.slowed').replace('{n}', kit.num(F1 / FPIC, 0));
      rdB.textContent = Lc.join(' · ') + ' ' + S('exp.common.cents') + (g.kind === 'ring' ? ' (×2 ×2 ×2 ×2 ×2 ×1)' : g.kind === 'cube' ? ' (' + L.map(function (l) { return '×' + l.mult; }).join(' ') + ')' : '');
    }
    function pick(key, ev, c) {
      var rc = c.el.getBoundingClientRect(), x = ev.clientX - rc.left, y = ev.clientY - rc.top, P = drawn[key] || [], best = -1, bd = 1e9;
      P.forEach(function (p, i) { var d = Math.hypot(p.x - x, p.y - y); if (d < bd) { bd = d; best = i; } });
      if (best >= 0 && bd < 40) { node[g.kind] = best; draw(); }
    }
    cP.el.addEventListener('click', function (e) { if (pmode === 'here') pick('p', e, cP); });
    cA.el.addEventListener('click', function (e) { pick('a', e, cA); });
    T.onpause = draw; window.addEventListener('resize', draw);
    setRange(); sync();
    kit.loop(function (t, dt) { if (!T.paused) { tau += dt; tp += dt; } draw(); });
  } };
})();
