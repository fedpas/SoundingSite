// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// noimage.js — The pressure has no image (MUS-049, 056, 057, 058, 079)
(function () {
  'use strict';
  window.SDV_EXP = window.SDV_EXP || {};
  window.SDV_EXP['noimage'] = { mount: function (root, data, S, kit) {
    var P = 'exp.noimage.', el = kit.el, TAU = Math.PI * 2, FP = 330, PIC_HZ = 0.5, SLOW = Math.round(FP / PIC_HZ);
    var reduce = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    var st = { t: 0, paused: reduce, on: false }, voices = null;
    function cv(parent, a, m) { var d = el('div', { class: 'exp-cvwrap' }); parent.appendChild(d); return kit.canvas(d, a, m); }
    function txt(ctx, s, x, y, color, align, size) { ctx.fillStyle = color || kit.muted(); ctx.textAlign = align || 'left'; ctx.font = (size || 11) + 'px system-ui, sans-serif'; ctx.fillText(s, x, y); }
    function short(n) { return n.split(' =')[0]; }
    function fit(ctx, s, wmax) { while (s.length > 2 && ctx.measureText(s).width > wmax) s = s.slice(0, -2) + '…'; return s; }

    // ---------------------------------------------------------------- (a) the dictionary
    var pa = kit.panel_(root, P + 'panel.dict', S, 'span');
    var dc = cv(pa, 0.9, 330);
    var ctl0 = kit.controls(pa);
    var pb = null;
    var rdMasks = kit.readout(pa);
    rdMasks.textContent = data.labels.map(function (l) { return 'g' + l.grade + ': ' + l.names.map(function (n, i) { return n + ' (' + l.masks[i] + ')'; }).join(' '); }).join('   ·   ');
    kit.line(pa, P + 'hodge', S);
    var rule = kit.line(pa, P + 'dict.nopress', S); rule.style.color = kit.red; rule.style.fontWeight = '600';
    var rows = el('div', { class: 'exp-sources' });
    [['mass', 'charge'], ['force', 'current'], ['vort', 'mag']].forEach(function (p) {
      var r = el('p', { class: 'exp-line' });
      r.appendChild(el('span', { 'data-s': P + 'src.' + p[0], text: S(P + 'src.' + p[0]) })); r.appendChild(document.createTextNode('  →  '));
      r.appendChild(el('span', { 'data-s': P + 'src.' + p[1], text: S(P + 'src.' + p[1]) })); rows.appendChild(r);
    });
    var hd = el('p', { class: 'exp-line' }); hd.appendChild(el('code', { text: 'MUS-056' })); hd.appendChild(document.createTextNode(' ')); hd.appendChild(kit.chip('computed')); pa.appendChild(hd); pa.appendChild(rows);

    function drawDict() {
      var ctx = dc.ctx, w = dc.w, h = dc.h, top = 26, rh = (h - top - 6) / 5, c1 = w * 0.36, c2 = w * 0.64, gut = 0;
      ctx.clearRect(0, 0, w, h);
      txt(ctx, S(P + 'col.ac'), c1 / 2, 15, kit.blue, 'center', 12); txt(ctx, S(P + 'col.hodge'), (c1 + c2) / 2, 15, kit.muted(), 'center', 12); txt(ctx, S(P + 'col.em'), (c2 + w) / 2, 15, kit.red, 'center', 12);
      var g, kinds = ['measurable', 'potential', 'source'], pBox = null;
      ctx.font = '11px system-ui, sans-serif';
      for (g = 0; g < 5; g++) {
        var y = top + g * rh;
        ctx.strokeStyle = kit.muted(); ctx.globalAlpha = 0.25; ctx.beginPath(); ctx.moveTo(4, y); ctx.lineTo(w - 4, y); ctx.stroke(); ctx.globalAlpha = 1;
        txt(ctx, String(g), (c1 + c2) / 2 + 14, y + rh / 2 + 4, kit.ink(), 'center', 12);
        [['acoustics', 6, c1 - 12], ['electromagnetism', c2 + 6, w - 6]].forEach(function (side) {
          var items = []; kinds.forEach(function (k) { (data.fields[side[0]][k] || []).forEach(function (f) { if (f.grade === g) items.push([k, short(f.name)]); }); });
          var ih = Math.min(22, (rh - 6) / Math.max(items.length, 1));
          items.forEach(function (it, i) {
            var yy = y + 3 + i * (ih + 1), x0 = side[1], x1 = side[2], col = side[0] === 'acoustics' ? kit.blue : kit.red;
            ctx.lineWidth = 1.2; ctx.strokeStyle = col; ctx.setLineDash(it[0] === 'potential' ? [4, 3] : []);
            if (it[0] === 'source') { ctx.fillStyle = col; ctx.globalAlpha = 0.14; ctx.fillRect(x0, yy, x1 - x0, ih); ctx.globalAlpha = 1; }
            ctx.strokeRect(x0, yy, x1 - x0, ih); ctx.setLineDash([]);
            ctx.font = '11px system-ui, sans-serif'; txt(ctx, fit(ctx, it[1], x1 - x0 - 8), (x0 + x1) / 2, yy + ih / 2 + 4, kit.ink(), 'center', 11);
            if (side[0] === 'acoustics' && g === 1 && it[1] === 'p') pBox = { x: x1, y: yy + ih / 2, yy: yy, ih: ih, x0: x0 };
          });
        });
      }
      // the Hodge complement: grade g with grade 4 − g
      [[0, 4, 0], [1, 3, 1]].forEach(function (p) {
        var x = c2 - 14 - p[2] * 12, ya = top + p[0] * rh + rh / 2, yb = top + p[1] * rh + rh / 2;
        kit.arrow(ctx, x, (ya + yb) / 2, x, ya + 4, kit.muted(), 1.2); kit.arrow(ctx, x, (ya + yb) / 2, x, yb - 4, kit.muted(), 1.2);
      });
      var y2 = top + 2.5 * rh; ctx.strokeStyle = kit.muted(); ctx.beginPath(); ctx.arc(c2 - 14 - 24, y2 - 8, 7, 0.4, TAU - 0.4); ctx.stroke();
      if (pBox) {
        ctx.strokeStyle = kit.red; ctx.lineWidth = 2.2; ctx.strokeRect(pBox.x0 - 2, pBox.yy - 2, pBox.x - pBox.x0 + 4, pBox.ih + 4);
        ctx.setLineDash([5, 4]); ctx.beginPath(); ctx.moveTo(pBox.x + 3, pBox.y); ctx.lineTo(c2 - 30, pBox.y); ctx.stroke(); ctx.setLineDash([]);
        var cx = (pBox.x + c2 - 30) / 2; ctx.beginPath(); ctx.moveTo(cx - 5, pBox.y - 5); ctx.lineTo(cx + 5, pBox.y + 5); ctx.moveTo(cx + 5, pBox.y - 5); ctx.lineTo(cx - 5, pBox.y + 5); ctx.stroke();
        txt(ctx, S(P + 'p.short'), cx, pBox.y - 8, kit.red, 'center', 10);
      }
      // legend
      txt(ctx, S(P + 'kind.measurable') + ' ▭   ' + S(P + 'kind.potential') + ' ┄   ' + S(P + 'kind.source') + ' ▮', w / 2, h - 2, kit.muted(), 'center', 10);
    }

    // ---------------------------------------------------------------- (b) the longitudinal electric wave
    var pw = kit.panel_(root, P + 'panel.wave', S);
    var wc = cv(pw, 0.7, 300);
    var rdW = kit.readout(pw); rdW.textContent = S('exp.common.slowed').replace('{n}', String(SLOW));
    var ctlW = kit.controls(pw);
    kit.line(pw, P + 'wave.em', S); kit.line(pw, P + 'wave.ac', S);
    var pauseB = kit.button(ctlW, 'exp.common.pause', S, function () { st.paused = !st.paused; pauseB.setAttribute('aria-pressed', String(st.paused)); }); pauseB.setAttribute('aria-pressed', String(st.paused));
    function drawWave() {
      var ctx = wc.ctx, w = wc.w, h = wc.h, n = 18, x0 = 16, x1 = w - 16, i, th = function (u) { return TAU * (2 * u - PIC_HZ * st.t); };
      ctx.clearRect(0, 0, w, h);
      var rowsY = [h * 0.14, h * 0.27, h * 0.40], aY = [h * 0.64, h * 0.77], sc = Math.min(18, (x1 - x0) / n * 0.9);
      txt(ctx, S(P + 'lab.E'), 4, rowsY[0] - 12, kit.muted(), 'left', 10); txt(ctx, S(P + 'lab.rho'), 4, rowsY[1] - 10, kit.muted(), 'left', 10); txt(ctx, S(P + 'lab.J'), 4, rowsY[2] - 12, kit.muted(), 'left', 10);
      txt(ctx, S(P + 'lab.v'), 4, aY[0] - 12, kit.muted(), 'left', 10); txt(ctx, S(P + 'lab.rho'), 4, aY[1] - 10, kit.muted(), 'left', 10);
      ctx.strokeStyle = kit.muted(); ctx.globalAlpha = 0.4; ctx.beginPath(); ctx.moveTo(4, h * 0.50); ctx.lineTo(w - 4, h * 0.50); ctx.stroke(); ctx.globalAlpha = 1;
      for (i = 0; i < n; i++) {
        var u = (i + 0.5) / n, x = x0 + u * (x1 - x0), E = -Math.sin(th(u)), rho = -Math.cos(th(u)), J = rho, col = function (v) { return v >= 0 ? kit.red : kit.blue; };
        kit.arrow(ctx, x - sc * 0.5 * E, rowsY[0], x + sc * 0.5 * E, rowsY[0], col(E), 1.6);
        ctx.fillStyle = col(rho); ctx.beginPath(); ctx.arc(x, rowsY[1], 1 + 5 * Math.abs(rho), 0, TAU); ctx.fill();
        kit.arrow(ctx, x - sc * 0.5 * J, rowsY[2], x + sc * 0.5 * J, rowsY[2], col(J), 1.6);
        kit.arrow(ctx, x - sc * 0.5 * E, aY[0], x + sc * 0.5 * E, aY[0], col(E), 1.6);
        ctx.fillStyle = col(rho); ctx.beginPath(); ctx.arc(x, aY[1], 1 + 5 * Math.abs(rho), 0, TAU); ctx.fill();
      }
      var py0 = h * 0.86, ph = h * 0.1;
      ctx.fillStyle = kit.cmap(0); ctx.fillRect(x0, py0, x1 - x0, ph); ctx.strokeStyle = kit.muted(); ctx.setLineDash([4, 3]); ctx.strokeRect(x0, py0, x1 - x0, ph); ctx.setLineDash([]);
      txt(ctx, S(P + 'lab.p') + ' — ' + S(P + 'wave.nop'), w / 2, py0 + ph / 2 + 4, kit.muted(), 'center', 11);
    }

    // ---------------------------------------------------------------- (c) the match holds at one wavenumber
    var pc = kit.panel_(root, P + 'panel.match', S);
    var mc = cv(pc, 0.8, 300), rdM = kit.readout(pc), ctlM = kit.controls(pc);
    kit.line(pc, P + 'match.line', S);
    var gr = el('div', { class: 'exp-grades' }); kit.grade(gr, 'none', 'exp.common.grade.none', S); gr.lastChild.appendChild(el('span', { 'data-s': P + 'grade.timeedge', text: ' ' + S(P + 'grade.timeedge') })); pc.appendChild(gr);
    var l79 = kit.line(pc, P + 'match.timeedge', S); l79.appendChild(document.createTextNode(' ')); l79.appendChild(el('code', { text: 'MUS-079' })); l79.appendChild(document.createTextNode(' ')); l79.appendChild(kit.chip('computed'));
    var kcur = 1;
    function drawMatch() {
      var ctx = mc.ctx, w = mc.w, h = mc.h, box = { l: 40, t: 12, r: w - 12, b: h - 34 };
      ctx.clearRect(0, 0, w, h);
      var ax = kit.axes(ctx, box, { xmin: 0, xmax: 2.4, ymin: 0, ymax: 2.4, xticks: [0, 1, 2], yticks: [0, 1, 2], xlabel: S(P + 'ax.k'), ylabel: S(P + 'ax.w') });
      kit.curve(ctx, [[0, 0], [2.4, 2.4]], ax.x, ax.y, kit.blue, 2); kit.curve(ctx, [[0, 1], [2.4, 1]], ax.x, ax.y, kit.red, 2);
      txt(ctx, S(P + 'curve.sound'), ax.x(1.45), ax.y(1.75), kit.blue, 'left', 11); txt(ctx, S(P + 'curve.plasma'), ax.x(1.5), ax.y(0.9), kit.red, 'left', 11);
      ctx.strokeStyle = kit.accent(); ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(ax.x(1), ax.y(1), 8, 0, TAU); ctx.stroke(); txt(ctx, S(P + 'cross'), ax.x(1) + 12, ax.y(1) + 18, kit.accent(), 'left', 11);
      var g = (st.t % 6) / 6; kcur = 0.2 + 1.8 * g; ctx.fillStyle = kit.ink(); ctx.beginPath(); ctx.arc(ax.x(kcur), ax.y(kcur), 4.5, 0, TAU); ctx.fill();
      rdM.textContent = kit.num(FP * kcur, 0) + ' Hz  ·  ' + kit.num(FP, 0) + ' Hz';
      if (voices) voices.b.set(FP * kcur);
    }

    // ---------------------------------------------------------------- hear
    var ph = kit.panel_(root, P + 'panel.hear', S, 'span'), ctlH = kit.controls(ph);
    var playB = kit.button(ctlH, 'exp.common.play', S, function () {
      st.on = !st.on; playB.textContent = S(st.on ? 'exp.common.mute' : 'exp.common.play'); playB.setAttribute('data-s', st.on ? 'exp.common.mute' : 'exp.common.play');
      if (st.on) { if (!kit.audio()) { rd.textContent = S('exp.common.noaudio'); return; } voices = { a: kit.voice({ f: FP, gain: 0.12 }), b: kit.voice({ f: FP * 0.2, gain: 0.12 }) }; }
      else if (voices) { voices.a.stop(); voices.b.stop(); voices = null; }
    });
    var rd = kit.readout(ph); kit.line(ph, P + 'hear.line', S);
    drawDict(); drawWave(); drawMatch();
    kit.loop(function (t, dt) { if (!st.paused) st.t += dt; drawDict(); drawWave(); drawMatch(); });
  } };
})();
