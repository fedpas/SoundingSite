// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// shoot.cjs — renders every page of ../out (and of ../out/it, the Italian pages, as it_<page>) from the disk (file://)
// with Chromium at 1280 and 390 px, light and dark, into ../record/shots/, and reports what a reader would meet: console
// errors and page errors, a page wider than its viewport (horizontal scroll), images or clips that do not load.
// Usage: node gen/shoot.cjs [--pages a,b] [--full] [--reg atlas]
const path = require('path');
const fs = require('fs');
const { chromium } = (() => { try { return require('playwright'); } catch { return require('/opt/npm-tools/node_modules/playwright'); } })();
const SITE = path.dirname(__dirname);
const OUT = path.join(SITE, 'out');
const SHOTS = path.join(SITE, 'record', 'shots');
const args = process.argv.slice(2);
const only = args.includes('--pages') ? args[args.indexOf('--pages') + 1].split(',') : null;
const FULL = args.includes('--full');
const REG = args.includes('--reg') ? args[args.indexOf('--reg') + 1] : null; // shoot a register other than Story
const MAXH = 5200;
(async () => {
  fs.mkdirSync(SHOTS, { recursive: true });
  const pages = fs.readdirSync(OUT).filter((f) => f.endsWith('.html')).map((f) => f.replace(/\.html$/, ''));
  const ITD = path.join(OUT, 'it');
  if (fs.existsSync(ITD)) for (const f of fs.readdirSync(ITD).filter((f) => f.endsWith('.html'))) pages.push('it/' + f.replace(/\.html$/, ''));
  const chosen = pages.filter((p) => !only || only.includes(p) || only.includes(p.replace('/', '_')));
  const shotName = (p) => p.replace('/', '_');
  const browser = await chromium.launch({ executablePath: fs.existsSync('/opt/pw-browsers/chromium-1194/chrome-linux/chrome') ? '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' : undefined, args: ['--allow-file-access-from-files', '--autoplay-policy=no-user-gesture-required'] });
  const problems = [];
  let offlineFonts = 0, fontOnly = true;
  const report = [];
  for (const scheme of ['light', 'dark']) {
    for (const width of [1280, 390]) {
      const context = await browser.newContext({ viewport: { width, height: width === 390 ? 844 : 900 }, colorScheme: scheme, deviceScaleFactor: 1 });
      for (const p of chosen) {
        const page = await context.newPage();
        const errs = [];
        page.on('console', (m) => { if (m.type() !== 'error' && m.type() !== 'warning') return; const u = (m.location() || {}).url || ''; if (/fonts\.(googleapis|gstatic)\.com/.test(u) || (/ERR_TUNNEL_CONNECTION_FAILED|ERR_INTERNET_DISCONNECTED|ERR_NAME_NOT_RESOLVED/.test(m.text()) && fontOnly)) { offlineFonts++; return; } errs.push(`${m.type()}: ${m.text()} ${u}`); });
        page.on('pageerror', (e) => errs.push('pageerror: ' + e.message));
        page.on('requestfailed', (r) => { const u = r.url(); if (!/fonts\.(googleapis|gstatic)\.com/.test(u)) errs.push('requestfailed: ' + u); });
        await page.goto('file://' + path.join(OUT, p + '.html'), { waitUntil: 'load' });
        // the figures load lazily for readers; a shot of the whole page needs them all
        await page.evaluate(async () => { const imgs = [...document.images]; imgs.forEach((i) => { i.loading = 'eager'; }); await Promise.all(imgs.map((i) => (i.complete ? null : new Promise((r) => { i.onload = i.onerror = r; setTimeout(r, 3000); })))); });
        if (REG) await page.evaluate((r) => { const b = document.querySelector(`[data-switch="reg"] button[data-reg="${r}"]`); if (b) b.click(); }, REG);
        await page.waitForTimeout(150);
        const m = await page.evaluate(() => {
          const de = document.documentElement;
          const wide = [];
          if (de.scrollWidth > window.innerWidth + 1) {
            for (const el of document.querySelectorAll('body *')) { const r = el.getBoundingClientRect(); if (r.right > window.innerWidth + 1 && r.width > 0 && !el.closest('.tbl, .plate, .sd, .tz, .logpre, .strip-in, .dftbox')) { wide.push(el.tagName.toLowerCase() + (el.className && typeof el.className === 'string' ? '.' + el.className.split(' ')[0] : '') + ' ' + Math.round(r.right)); if (wide.length > 4) break; } }
          }
          const brokenImg = [...document.images].filter((i) => i.complete && i.naturalWidth === 0).map((i) => i.getAttribute('src'));
          return { scrollWidth: de.scrollWidth, height: de.scrollHeight, wide, brokenImg };
        });
        const file = path.join(SHOTS, `${shotName(p)}.${width}.${scheme}${REG ? '.' + REG : ''}.png`);
        if (FULL && m.height > MAXH) { // a long page: its first MAXH px, through a tall viewport
          await page.setViewportSize({ width, height: MAXH });
          await page.waitForTimeout(100);
          await page.screenshot({ path: file, timeout: 60000 });
          await page.setViewportSize({ width, height: width === 390 ? 844 : 900 });
        } else await page.screenshot({ path: file, timeout: 60000, fullPage: FULL });
        const pr = [];
        if (m.scrollWidth > width + 1) pr.push(`horizontal scroll: ${m.scrollWidth} px (${m.wide.join(', ')})`);
        if (m.brokenImg.length) pr.push('broken images: ' + m.brokenImg.join(', '));
        for (const e of errs) pr.push(e);
        report.push({ page: p, width, scheme, height: m.height, problems: pr });
        for (const x of pr) problems.push(`${p} ${width} ${scheme}: ${x}`);
        await page.close();
      }
      await context.close();
    }
  }
  await browser.close();
  fs.writeFileSync(path.join(SITE, 'record', 'shots_report.json'), JSON.stringify(report, null, 1));
  for (const x of problems) console.log('PROBLEM ' + x);
  console.log(`shoot: ${offlineFonts} console lines of the two web fonts failing without a network (the system fonts stand in); ${report.length} shots of ${chosen.length} pages in ${SHOTS}; ${problems.length} problems`);
  process.exit(problems.length ? 1 : 0);
})();
