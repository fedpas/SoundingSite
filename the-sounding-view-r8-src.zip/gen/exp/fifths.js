// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// fifths — the fifth, its continued fraction, even scales (MUS-009, 010, 033, 034, 035)
(function () {
  'use strict';
  window.SDV_EXP = window.SDV_EXP || {};
  window.SDV_EXP['fifths'] = {
    mount: function (root, data, S, kit) {
      var TAU = Math.PI * 2, el = kit.el, NS = 'exp.fifths.', snd = false, live = [], timers = [], names = data.names;
      var n = 12, scl = 'diatonic', cut = 4, A = data.alpha;
      function hz(pc) { return 261.6256 * Math.pow(2, pc / 12); }
      function cell(p) { var c = el('div', { style: 'min-width:0;overflow:hidden' }); p.appendChild(c); return c; }
      function silence() { live.forEach(function (t) { t.stop(); }); live = []; timers.forEach(clearTimeout); timers = []; }
      function seq(freqs, dt, dur) { if (!snd) return; silence(); freqs.forEach(function (f, i) { live.push(kit.tone({ f: f, gain: 0.18, dur: dur || 0.3, at: 0.02 + i * dt })); }); }
      function playBtn(parent) {
        var b = kit.button(parent, 'exp.common.play', S, function () {
          snd = !snd; b.textContent = S(snd ? 'exp.common.mute' : 'exp.common.play'); b.setAttribute('data-s', snd ? 'exp.common.mute' : 'exp.common.play');
          if (snd) { if (!kit.audio()) kit.line(root, 'exp.common.noaudio', S); seqFifths(); } else silence();
        }); return b;
      }
      function seqFifths() { var f = []; for (var k = 1; k <= n; k++) f.push(261.6256 * Math.pow(2, (k * A) % 1)); seq(f, 0.18, 0.25); }
      function pos(x, cx, cy, R) { var a = TAU * x - Math.PI / 2; return [cx + R * Math.cos(a), cy + R * Math.sin(a)]; }

      root.classList.add('half');
      // ---------------------------------------------- (a) stacking fifths
      var pa = kit.panel_(root, NS + 'panel.a', S, 'span'), wa = el('div', { style: 'display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:10px' }); pa.appendChild(wa);
      var d1 = kit.canvas(cell(wa), 1, 340), d2 = kit.canvas(cell(wa), 1, 340), ca = kit.controls(pa);
      playBtn(ca);
      kit.slider(ca, { id: NS + 'n', S: S, min: 1, max: 60, step: 1, value: 12, fmt: function (v) { return String(v); }, onchange: function (v) { n = v; seqFifths(); } });
      kit.button(ca, NS + 'again', S, function () { seqFifths(); });
      var ra = kit.readout(pa), rcf = kit.readout(pa), rcm = kit.readout(pa);
      kit.line(pa, NS + 'a.note', S);
      rcf.textContent = '[' + data.cf[0] + '; ' + data.cf.slice(1).join(', ') + ', …]   ' + data.conv.slice(0, 9).map(function (c) { return c.p + '/' + c.q; }).join('  ');
      rcm.textContent = Object.keys(data.commas).map(function (k) { return data.commas[k].ratio + ' = ' + kit.num(data.commas[k].cents, 2) + ' ' + S('exp.common.cents'); }).join('   ');
      function drawA() {
        var s = d1.size(), c = d1.ctx, W = s.w, H = s.h, cx = W / 2, cy = H / 2, R = Math.min(W, H) * 0.36, k, p;
        c.clearRect(0, 0, W, H); c.strokeStyle = kit.muted(); c.lineWidth = 1; c.globalAlpha = 0.5; c.beginPath(); c.arc(cx, cy, R, 0, TAU); c.stroke(); c.globalAlpha = 1;
        for (k = 0; k < 12; k++) { p = pos(k / 12, cx, cy, R); c.fillStyle = kit.muted(); c.beginPath(); c.arc(p[0], p[1], 2, 0, TAU); c.fill(); var q = pos(k / 12, cx, cy, R + 16); c.font = '11px system-ui, sans-serif'; c.textAlign = 'center'; c.fillText(names[k], q[0], q[1] + 4); }
        c.strokeStyle = kit.accent(); c.lineWidth = 1; c.globalAlpha = 0.5; c.beginPath();
        for (k = 0; k <= n; k++) { p = pos((k * A) % 1, cx, cy, R * (0.55 + 0.45 * k / 60)); if (k) c.lineTo(p[0], p[1]); else c.moveTo(p[0], p[1]); } c.stroke(); c.globalAlpha = 1;
        for (k = 0; k <= n; k++) { p = pos((k * A) % 1, cx, cy, R * (0.55 + 0.45 * k / 60)); c.fillStyle = k === n ? kit.warm() : kit.accent(); c.beginPath(); c.arc(p[0], p[1], k === n ? 5.5 : 3, 0, TAU); c.fill(); }
        // the error plot
        var s2 = d2.size(), c2 = d2.ctx, W2 = s2.w, H2 = s2.h, box = { l: 42, t: 14, r: W2 - 10, b: H2 - 34 }; c2.clearRect(0, 0, W2, H2);
        var ax = kit.axes(c2, box, { xmin: 0, xmax: 61, ymin: 0.03, ymax: 600, ylog: true, xticks: [1, 12, 24, 36, 48, 60], yticks: [0.1, 1, 10, 100], xlabel: 'n', ylabel: S('exp.common.cents') });
        var best = 1e9, stair = [];
        data.err.forEach(function (e) { var v = Math.max(0.03, Math.abs(e.cents)); best = Math.min(best, v); stair.push([e.n, best]); stair.push([e.n + 1, best]); });
        kit.curve(c2, stair, ax.x, ax.y, kit.accent(), 1.6);
        data.err.forEach(function (e) { var rec = data.records_steps.indexOf(e.n) >= 0; c2.fillStyle = rec ? kit.warm() : kit.muted(); c2.beginPath(); c2.arc(ax.x(e.n), ax.y(Math.max(0.03, Math.abs(e.cents))), rec ? 4.5 : 2.2, 0, TAU); c2.fill(); });
        c2.strokeStyle = kit.ink(); c2.lineWidth = 1; c2.beginPath(); c2.moveTo(ax.x(n), box.t); c2.lineTo(ax.x(n), box.b); c2.stroke();
        var e = data.err[n - 1]; ra.textContent = 'n = ' + n + '   ' + e.m + '/' + e.n + '   ' + kit.num(e.cents, 3) + ' ' + S('exp.common.cents') + '   ' + data.records_steps.join(', ');
      }

      // ---------------------------------------------- (b) maximal evenness
      var pb = kit.panel_(root, NS + 'panel.b', S), wb = el('div', { style: 'display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px' }); pb.appendChild(wb);
      var d3 = kit.canvas(cell(wb), 1, 260), d4 = kit.canvas(cell(wb), 1, 260), cb = kit.controls(pb);
      kit.seg(cb, { ids: [NS + 'diatonic', NS + 'pentatonic'], values: ['diatonic', 'pentatonic'], value: scl, S: S, onchange: function (v) { scl = v; play12(); } });
      function play12() { var s = scl === 'diatonic' ? data.diatonic : data.pentatonic; seq(s.concat([12]).map(hz), 0.3, 0.35); }
      kit.button(cb, NS + 'scale', S, play12);
      var rb = kit.readout(pb); kit.line(pb, NS + 'b.note', S);
      rb.textContent = data.well_formed.N.join(', ');
      function drawB() {
        var s = d3.size(), c = d3.ctx, W = s.w, H = s.h, cx = W / 2, cy = H / 2, R = Math.min(W, H) * 0.34, set = scl === 'diatonic' ? data.diatonic : data.pentatonic, k, p;
        c.clearRect(0, 0, W, H); c.strokeStyle = kit.muted(); c.globalAlpha = 0.5; c.beginPath(); c.arc(cx, cy, R, 0, TAU); c.stroke(); c.globalAlpha = 1;
        c.strokeStyle = kit.accent(); c.lineWidth = 1.4; c.beginPath(); set.forEach(function (x, i) { p = pos(x / 12, cx, cy, R); if (i) c.lineTo(p[0], p[1]); else c.moveTo(p[0], p[1]); }); c.closePath(); c.stroke();
        for (k = 0; k < 12; k++) { var on = set.indexOf(k) >= 0; p = pos(k / 12, cx, cy, R); c.fillStyle = on ? kit.accent() : kit.panel(); c.strokeStyle = on ? kit.accent() : kit.muted(); c.beginPath(); c.arc(p[0], p[1], on ? 6 : 4, 0, TAU); c.fill(); c.stroke(); }
        // the Christoffel path on its 7 × 5 grid
        var s4 = d4.size(), c4 = d4.ctx, W4 = s4.w, H4 = s4.h, g = Math.min((W4 - 30) / 7, (H4 - 30) / 5), x0 = (W4 - 7 * g) / 2, y0 = H4 - (H4 - 5 * g) / 2; c4.clearRect(0, 0, W4, H4);
        c4.strokeStyle = kit.muted(); c4.lineWidth = 0.6; c4.globalAlpha = 0.5;
        for (k = 0; k <= 7; k++) { c4.beginPath(); c4.moveTo(x0 + k * g, y0); c4.lineTo(x0 + k * g, y0 - 5 * g); c4.stroke(); } for (k = 0; k <= 5; k++) { c4.beginPath(); c4.moveTo(x0, y0 - k * g); c4.lineTo(x0 + 7 * g, y0 - k * g); c4.stroke(); }
        c4.globalAlpha = 1; c4.beginPath(); c4.moveTo(x0, y0); c4.lineTo(x0 + 7 * g, y0 - 5 * g); c4.setLineDash([4, 3]); c4.stroke(); c4.setLineDash([]);
        kit.curve(c4, data.path.map(function (q) { return [q[1], q[0]]; }), function (v) { return x0 + v * g; }, function (v) { return y0 - v * g; }, kit.accent(), 2.4);
      }

      // ---------------------------------------------- (c) two numerations
      var pc = kit.panel_(root, NS + 'panel.c', S), wc = el('div', { style: 'display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px' }); pc.appendChild(wc);
      var d5 = kit.canvas(cell(wc), 1, 260), d6 = kit.canvas(cell(wc), 1, 260), cc = kit.controls(pc);
      kit.slider(cc, { id: NS + 'cut', S: S, min: 0, max: 9, step: 1, value: cut, fmt: function (v) { return String(v); }, onchange: function (v) { cut = v; } });
      var rc = kit.readout(pc), g1 = el('p', { class: 'exp-line' }); pc.appendChild(g1);
      kit.grade(g1, 'analogy', 'exp.common.grade.analogy', S); g1.appendChild(document.createTextNode(' ')); g1.appendChild(el('span', { 'data-s': NS + 'c.analogy', text: S(NS + 'c.analogy') }));
      var minx = 1e9, maxx = -1e9, miny = 1e9, maxy = -1e9; data.walk.forEach(function (q) { minx = Math.min(minx, q[0]); maxx = Math.max(maxx, q[0]); miny = Math.min(miny, q[1]); maxy = Math.max(maxy, q[1]); });
      function drawC() {
        var s = d5.size(), c = d5.ctx, W = s.w, H = s.h, sc = Math.min((W - 20) / (maxx - minx), (H - 20) / (maxy - miny)), ox = (W - sc * (maxx - minx)) / 2 - sc * minx, oy = (H + sc * (maxy - miny)) / 2 + sc * miny;
        function X(v) { return ox + sc * v; } function Y(v) { return oy - sc * v; }
        c.clearRect(0, 0, W, H); c.strokeStyle = kit.muted(); c.lineWidth = 0.8; c.beginPath(); data.walk.forEach(function (q, i) { if (i) c.lineTo(X(q[0]), Y(q[1])); else c.moveTo(X(q[0]), Y(q[1])); }); c.stroke();
        data.cuts.forEach(function (q, i) { var p = data.walk[Math.pow(2, i)]; c.fillStyle = i === cut ? kit.warm() : kit.accent(); c.beginPath(); c.arc(X(p[0]), Y(p[1]), i === cut ? 5.5 : 3, 0, TAU); c.fill(); });
        var s6 = d6.size(), c6 = d6.ctx, W6 = s6.w, H6 = s6.h, box = { l: 42, t: 12, r: W6 - 8, b: H6 - 32 }; c6.clearRect(0, 0, W6, H6);
        var ax = kit.axes(c6, box, { xmin: 1, xmax: 700, xlog: true, ymin: -300, ymax: 300, xticks: [1, 10, 100, 700], yticks: [-200, 0, 200], xlabel: 'N', ylabel: S('exp.common.cents') });
        c6.fillStyle = kit.muted(); c6.globalAlpha = 0.6; data.scale_N.forEach(function (N, i) { c6.fillRect(ax.x(N) - 1, ax.y(kit.clamp(data.scale_err[i], -300, 300)) - 1, 2, 2); }); c6.globalAlpha = 1;
        data.scale_conv.forEach(function (q, i) { var N = q[1]; if (N < 1 || N > 700) return; var e = data.scale_err[Math.floor((N - 1) / 2)]; c6.fillStyle = i === cut ? kit.warm() : kit.accent(); c6.beginPath(); c6.arc(ax.x(N), ax.y(kit.clamp(e, -300, 300)), i === cut ? 5.5 : 3.2, 0, TAU); c6.fill(); });
        var cu = data.cuts[cut], cq = data.scale_conv[cut], w = data.step_words[String(cq[1])];
        rc.textContent = '2^' + cut + ' = ' + Math.pow(2, cut) + '   S = (' + cu.S[0] + ', ' + cu.S[1] + ')   |S|² = ' + cu.abs2 + '   ·   ' + cq[0] + '/' + cq[1] + '   ' + (w ? w.word : S('exp.common.outside'));
      }

      var pz = kit.panel_(root, 'exp.common.see', S); kit.line(pz, NS + 'see', S);
      var ph = kit.panel_(root, 'exp.common.hear', S); kit.line(ph, NS + 'hear', S);
      var pdt = el('p', { class: 'exp-line' }); pdt.appendChild(el('strong', { 'data-s': 'exp.common.data', text: S('exp.common.data') })); pdt.appendChild(document.createTextNode(' ')); pdt.appendChild(el('span', { 'data-s': NS + 'data', text: S(NS + 'data') }));
      root.appendChild(el('div', { class: 'exp-panel span' }, [pdt]));
      kit.loop(function () { drawA(); drawB(); drawC(); });
    }
  };
})();
