# NOTE IT-3B (narrator B)

Written: it/draft/r3_B.json, 33 narrations (26 assigned + 7 page rewrites), 59 titles (55 + 4), 73 strings. Checker: 0 errors; warnings left: INP-139 narration 101 words, three long captions/card (spin figures, card:section:spin).

Italian titles. Parts: Il suono / Dodici / (III: "Il suono accanto alla luce", my plain wording in nav.light and bridgech:light; A's title for part III was not available, align on merge) / La domanda. Chapter: "Lo spin del suono". Bridge chapters: Due dodici, Dodici bit, Due dualità, Che cosa può suonare un anello, Il suono accanto alla luce. Line P: "un fluido carico in forma acustica ↔ le equazioni di Maxwell". Reference menu: "Riferimenti"; nav.about stays "Il metodo".

Checked and kept (release-2 Italian stands, no banned word, nothing moved): row:MUS-016, MUS-037, MUS-046, MUS-004, LNS-137, SPR-M01, section:tone (stops at MUS-044), page:about. None rewritten.

Choices: "spin", "gauge", "getti" (jets), "momento torcente"/"coppia", "assorbitore", "elicità"; about.provenance says the rows "restano fuori dalle tavole dell'Atlante" (no "non ancora nelle tavole"). page:dictionary examples for partial/analogy (ratio and cents; Euler's Tonnetz) are taken from lens 42 and 41. page:pictures lists figures by part from the English dump headings; fig groups assumed (dissonance, tet in Sound).

Doubts: MUS-066 narration states the spin ratio "non è stato misurato" (from the row's research: orbital measured to a few percent, spin not). Lens 35, 36, 43, 44 terms exceed 8 words, like their English.
