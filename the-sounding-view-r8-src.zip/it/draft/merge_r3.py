# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# merge_r3.py — merges the narrators' drafts of release 3 (it/draft/r3_A.json, r3_B.json) into the three Italian tables
# (gen/content/it/racconto.json, titoli.json, strings_it.json): each draft entry replaces the table's entry with the same
# id (the stub, or the release-2 text for a rewrite), drops "stub" and "previousIt", and keeps the table's order.
# Usage: python3 -I it/draft/merge_r3.py it/draft/r3_A.json it/draft/r3_B.json
import json, os, sys
DRAFT = os.path.dirname(os.path.abspath(__file__))
IT = os.path.join(os.path.dirname(os.path.dirname(DRAFT)), 'gen', 'content', 'it')
def J(p): return json.load(open(p, encoding='utf-8'))
def W(p, o):
    with open(p, 'w', encoding='utf-8') as f: f.write(json.dumps(o, ensure_ascii=False, indent=1) + '\n')
R, T, S = (J(os.path.join(IT, f)) for f in ('racconto.json', 'titoli.json', 'strings_it.json'))
byR = {i['id']: i for i in R['items']}; byT = {i['id']: i for i in T['items']}; byS = {i['id']: i for i in S['strings']}
n = {'racconto': 0, 'titoli': 0, 'strings': 0, 'appended': 0}
for f in sys.argv[1:]:
    D = J(f)
    for it in D.get('racconto', []):
        cur = byR.get(it['id'])
        if cur is None: R['items'].append(dict(it)); n['appended'] += 1; continue
        cur['text'] = it['text']; cur['tells'] = it.get('tells') or cur.get('tells', [])
        cur['why'] = it.get('why') or cur.get('why'); cur.pop('stub', None); n['racconto'] += 1
    for it in D.get('titoli', []):
        cur = byT.get(it['id'])
        if cur is None: T['items'].append(dict(it)); n['appended'] += 1; continue
        cur['text'] = it['text']; cur['why'] = it.get('why') or cur.get('why'); cur.pop('stub', None); n['titoli'] += 1
    for it in D.get('strings', []):
        cur = byS.get(it['id'])
        if cur is None: raise SystemExit('strings_it.json has no entry ' + it['id'])
        cur['text'] = it['text']; cur.pop('stub', None); cur.pop('previousIt', None)
        if it.get('why'): cur['why'] = it['why']
        elif str(cur.get('why', '')).startswith('stub'): cur['why'] = 'the narrator\'s Italian for the string ' + it['id']
        n['strings'] += 1
for name, o, key in (('racconto.json', R, 'items'), ('titoli.json', T, 'items'), ('strings_it.json', S, 'strings')):
    W(os.path.join(IT, name), o)
    left = [i['id'] for i in o[key] if i.get('stub')]
    print(f'{name}: {len(left)} stubs left' + (': ' + ', '.join(left[:20]) if left else ''))
print('merged', n)
