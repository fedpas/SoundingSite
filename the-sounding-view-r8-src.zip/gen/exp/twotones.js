// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// twotones — beats, roughness and what listeners report (MUS-004, ATY-040, INP-124 … INP-128).
(function () {
  'use strict';
  window.SDV_EXP = window.SDV_EXP || {};
  var RM = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  function cents(r) { return 1200 * Math.log(r) / Math.LN2; }
  function rep(s, o) { for (var k in o) s = s.replace('{' + k + '}', o[k]); return s; }
  function cv(kit, parent, aspect, maxH) { var d = kit.el('div', { style: 'width:100%;min-width:0' }); parent.appendChild(d); return kit.canvas(d, aspect, maxH); }
  function txt(ctx, s, x, y, al, col, px) { ctx.fillStyle = col; ctx.font = (px || 11) + 'px system-ui, sans-serif'; ctx.textAlign = al || 'left'; ctx.fillText(s, x, y); }
  // one Play/Mute per panel (only one sounds at a time) and one Pause for the picture
  function transport(kit, S) {
    var st = { paused: RM }, cur = null, hasAudio = !!(window.AudioContext || window.webkitAudioContext), warned = false;
    st.pause = function (controls) {
      var p = kit.button(controls, 'exp.common.pause', S, function () { st.paused = !st.paused; show(); if (st.onpause) st.onpause(); });
      function show() { p.setAttribute('aria-pressed', String(st.paused)); p.style.background = st.paused ? 'var(--accent-tint)' : ''; }
      show(); return p;
    };
    st.player = function (controls, o) {
      var me = { on: false };
      var b = kit.button(controls, 'exp.common.play', S, function () {
        if (me.on) { me.stop(); return; }
        if (!hasAudio || !kit.audio()) { b.disabled = true; if (!warned) { warned = true; kit.line(controls.parentNode, 'exp.common.noaudio', S); } return; }
        if (cur && cur !== me) cur.stop();
        me.on = true; cur = me; label(); o.start();
      });
      function label() { var id = me.on ? 'exp.common.mute' : 'exp.common.play'; b.setAttribute('data-s', id); b.textContent = S(id); b.setAttribute('aria-pressed', String(me.on)); }
      me.stop = function () { if (!me.on) return; me.on = false; if (cur === me) cur = null; label(); o.stop(); };
      return me;
    };
    return st;
  }
  // the foot of every experiment: what you see, what you hear, the data line
  function foot(kit, S, root, slug) {
    var p = kit.panel_(root, 'exp.common.see', S, 'span');
    kit.line(p, 'exp.' + slug + '.see', S);
    p.appendChild(kit.el('h3', { 'data-s': 'exp.common.hear', text: S('exp.common.hear') }));
    kit.line(p, 'exp.' + slug + '.hear', S);
    p.appendChild(kit.el('p', { class: 'exp-source' }, [kit.el('b', { 'data-s': 'exp.common.data', text: S('exp.common.data') }), ' · ', kit.el('span', { 'data-s': 'exp.' + slug + '.data', text: S('exp.' + slug + '.data') })]));
  }

  // bars on a ruler of cents with the harmonic series behind them; items {c, h, sel}
  function rulerBars(kit, S, c, items, hmax, maxC0) {
    var ctx = c.ctx, w = c.w, h = c.h, l = 12, r = 10, t = 10, b = 26, maxC = 1, mut = kit.muted();
    ctx.clearRect(0, 0, w, h);
    items.forEach(function (it) { maxC = Math.max(maxC, it.c); }); maxC = Math.max(maxC * 1.06, maxC0 || 1300);
    var X = function (cc) { return l + cc / maxC * (w - l - r); };
    ctx.lineWidth = 1; ctx.strokeStyle = mut;
    for (var n = 1; n <= 24; n++) { var cc = cents(n); if (cc > maxC) break; ctx.globalAlpha = 0.5; ctx.setLineDash([3, 3]); ctx.beginPath(); ctx.moveTo(X(cc), t); ctx.lineTo(X(cc), h - b); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1; if (n < 10 || n % 2 === 0) txt(ctx, String(n), X(cc), h - b + 12, 'center', mut, 10); }
    ctx.beginPath(); ctx.moveTo(l, h - b); ctx.lineTo(w - r, h - b); ctx.stroke();
    items.forEach(function (it) { var bh = Math.max(2, it.h / hmax * (h - b - t)); ctx.fillStyle = it.col || (it.sel ? kit.accent() : kit.blue); ctx.fillRect(X(it.c) - 3.5, h - b - bh, 7, bh); });
    txt(ctx, S('exp.common.cents'), w - r, h - 4, 'right', mut, 10);
  }
  var TAU = Math.PI * 2;
  var JUST = [['6/5', 6 / 5], ['5/4', 5 / 4], ['4/3', 4 / 3], ['3/2', 3 / 2], ['5/3', 5 / 3], ['2', 2]];
  function table(kit, parent, heads, rows, S) { // heads: string ids; rows: arrays of text
    var wrap = kit.el('div', { style: 'overflow-x:auto;max-width:100%' }), t = kit.el('table', { style: 'border-collapse:collapse;font-size:13px;width:100%;font-variant-numeric:tabular-nums' }), tr = kit.el('tr'), trs = [];
    heads.forEach(function (id) { tr.appendChild(kit.el('th', { 'data-s': id, text: id ? S(id) : '', style: 'text-align:left;padding:4px 8px;border-bottom:1.5px solid var(--rule);font-weight:600;white-space:nowrap' })); });
    t.appendChild(kit.el('thead', null, [tr]));
    var tb = kit.el('tbody');
    rows.forEach(function (r) { var row = kit.el('tr'); r.forEach(function (c) { row.appendChild(kit.el('td', { text: c, style: 'padding:3px 8px;border-bottom:1px solid var(--rule-2);white-space:nowrap' })); }); tb.appendChild(row); trs.push(row); });
    t.appendChild(tb); wrap.appendChild(t); parent.appendChild(wrap); return { rows: trs, el: wrap };
  }
  window.SDV_EXP.twotones = { mount: function (root, data, S, kit) {
    root.classList.add('half');
    var T = transport(kit, S), accent = kit.accent(), ink = kit.ink(), mut = kit.muted(), F1 = data.f1_hz, r = 1.5, curveKey = 1, vs = null, glide = null, noA = false, C = data.consonance;

    // ---- panel a: two tones
    var pa = kit.panel_(root, 'exp.twotones.panel.a', S), cA = cv(kit, pa, 0.5, 260), ctlA = kit.controls(pa);
    var sl = kit.slider(ctlA, { id: 'exp.twotones.ratio', S: S, min: 1, max: 2, step: 0.001, value: 1.5, fmt: function (v) { return kit.num(v, 3); }, onchange: function (v) { glide = null; setR(v); } });
    function startV() { stopV(); vs = [kit.voice({ f: F1, gain: 0.12 }), kit.voice({ f: F1 * r, gain: 0.12 })]; }
    function stopV() { if (vs) vs.forEach(function (v) { v.stop(); }); vs = null; }
    var playA = T.player(ctlA, { start: startV, stop: stopV });
    kit.button(ctlA, 'exp.twotones.glide', S, function () {
      if (!kit.audio()) { if (!noA) { noA = true; kit.line(pa, 'exp.common.noaudio', S); } return; }
      var own = !playA.on; if (own) startV(); glide = { t0: null, dur: data.glide_times_s['2'], own: own };
    });
    var rdA = kit.readout(pa), rdA2 = kit.readout(pa);
    kit.line(pa, 'exp.twotones.line.beats', S);
    // ---- panel b: roughness
    var pb = kit.panel_(root, 'exp.twotones.panel.b', S), cB = cv(kit, pb, 0.62, 300), ctlB = kit.controls(pb);
    kit.seg(ctlB, { ids: ['exp.twotones.b.harm', 'exp.twotones.b.bar'], values: [1, 2], value: 1, S: S, onchange: function (v) { curveKey = v; draw(); } });
    var rdB = kit.readout(pb);
    var lnB = kit.line(pb, 'exp.twotones.line.minima', S);
    var chipRow = kit.el('p', { class: 'exp-line' }); chipRow.appendChild(kit.chip('input')); chipRow.appendChild(document.createTextNode(' ')); chipRow.appendChild(kit.el('span', { 'data-s': 'exp.twotones.line.fit', text: S('exp.twotones.line.fit') })); pb.appendChild(chipRow);

    // ---- panel c: listeners
    var pcc = kit.panel_(root, 'exp.twotones.panel.c', S, 'span'), cons = [];
    var heads = ['exp.twotones.t.dyad', 'exp.twotones.t.rank', 'exp.twotones.t.sj', 'exp.twotones.t.st', 'exp.twotones.t.harm', 'exp.twotones.t.gradus'];
    var rows = C.dyads.map(function (d, i) { return [d + ' ' + C.just[i], String(C.empirical_rank[i]), kit.num(C.sethares_just[i], 3), kit.num(C.sethares_tet[i], 3), String(C.harmonicity_just[i]), String(C.gradus[i])]; });
    var sp = C.spearman, sk = Object.keys(sp);
    rows.push(['ρ', '—', kit.num(sp[sk[0]], 3), kit.num(sp[sk[1]], 3), kit.num(sp[sk[2]], 3), kit.num(sp[sk[4]], 3)]);
    var tb = table(kit, pcc, heads, rows, S);
    tb.rows.forEach(function (row, i) { if (i < C.dyads.length) { row.style.cursor = 'pointer'; row.addEventListener('click', function () { var q = eval_(C.just[i]); glide = null; sl.set(q); setR(q); }); } else row.style.fontWeight = '600'; });
    function eval_(s) { var p = s.split('/'); return p.length === 2 ? +p[0] / +p[1] : +p[0]; }
    var rdC = kit.readout(pcc);
    rdC.textContent = 'ρ = ' + sk.map(function (k) { return kit.num(sp[k], 3); }).join(' · ');
    kit.line(pcc, 'exp.twotones.line.rho', S);
    ['125', '126', '127'].forEach(function (n) { var card = kit.el('p', { class: 'exp-line' }, [kit.el('code', { text: 'INP-' + n }), ' ', kit.chip('input'), ' ']); card.appendChild(kit.el('span', { 'data-s': 'exp.twotones.inp.' + n, text: S('exp.twotones.inp.' + n) })); pcc.appendChild(card); });

    // ---- panel d: commas
    var pd = kit.panel_(root, 'exp.twotones.panel.d', S, 'span'), tt = data.tet;
    var rowsD = tt.rows.map(function (q) { return [q.degree, q.just, kit.num(q.just_cents, 2), kit.num(q.tet_cents, 0), kit.num(q.tet_minus_just, 2)]; });
    table(kit, pd, ['exp.twotones.d.degree', 'exp.twotones.d.just', 'exp.twotones.d.jc', 'exp.twotones.d.tc', 'exp.twotones.d.diff'], rowsD, S);
    var ctlD = kit.controls(pd);
    kit.button(ctlD, 'exp.twotones.d.chord', S, function () {
      if (!kit.audio()) { if (!noA) { noA = true; kit.line(pd, 'exp.common.noaudio', S); } return; }
      var C4 = tt.C4_hz; [[1, 5 / 4, 3 / 2, 0], [1, Math.pow(2, 4 / 12), Math.pow(2, 7 / 12), 1.8]].forEach(function (ch) { ch.slice(0, 3).forEach(function (q) { kit.tone({ f: C4 * q, gain: 0.1, dur: 1.6, at: ch[3] }); }); });
    });
    var rdD = kit.readout(pd), rdD2 = kit.readout(pd), rdD3 = kit.readout(pd);
    rdD.textContent = Object.keys(tt.commas).map(function (k) { return S('exp.twotones.d.comma.' + k) + ' ' + tt.commas[k] + ' = ' + kit.num(tt.commas_cents[k], 2) + ' ' + S('exp.common.cents'); }).join(' · ');
    rdD2.textContent = Object.keys(tt.chord_beats_hz_12tet).map(function (k) { return k + ' → ' + kit.num(tt.chord_beats_hz_12tet[k], 2) + ' ' + S('exp.common.hz'); }).join(' · ');
    rdD3.textContent = data.hexatonic.names.join(' → ').replace(/Ab/g, 'A♭') + ' · ' + data.hexatonic.drift + ' = ' + kit.num(tt.commas_cents.diesis, 2) + ' ' + S('exp.common.cents');
    kit.line(pd, 'exp.twotones.line.commas', S);
    foot(kit, S, root, 'twotones');

    function setR(v) { r = v; if (vs) vs[1].set(F1 * r, null); draw(); }
    function drawA() {
      var ctx = cA.ctx, w = cA.w, h = cA.h, f2 = F1 * r, df = f2 - F1, W = Math.max(0.02, Math.min(1.5, 3 / Math.max(df, 1e-6))), lowered = F1 * W > 40, fa = lowered ? 30 / W : F1, fb = fa + df, i, N = Math.round(w * 1.5), y0 = h / 2, yh = h / 2 - 12;
      ctx.clearRect(0, 0, w, h);
      ctx.strokeStyle = mut; ctx.lineWidth = 0.6; ctx.setLineDash([2, 3]); ctx.beginPath(); ctx.moveTo(4, y0); ctx.lineTo(w - 4, y0); ctx.stroke(); ctx.setLineDash([]);
      [1, -1].forEach(function (sg) { ctx.strokeStyle = accent; ctx.lineWidth = 1.3; ctx.setLineDash([4, 3]); ctx.beginPath(); for (i = 0; i <= N; i++) { var s = W * i / N, X = 4 + (w - 8) * i / N, Y = y0 - sg * Math.abs(Math.cos(Math.PI * df * s)) * yh; if (i) ctx.lineTo(X, Y); else ctx.moveTo(X, Y); } ctx.stroke(); ctx.setLineDash([]); });
      ctx.strokeStyle = ink; ctx.lineWidth = 1.1; ctx.beginPath();
      for (i = 0; i <= N; i++) { var s2 = W * i / N, v = (Math.cos(TAU * fa * s2) + Math.cos(TAU * fb * s2)) / 2, X2 = 4 + (w - 8) * i / N, Y2 = y0 - v * yh; if (i) ctx.lineTo(X2, Y2); else ctx.moveTo(X2, Y2); }
      ctx.stroke();
      txt(ctx, kit.num(W * 1000, W < 0.1 ? 1 : 0) + ' ms', w - 6, h - 5, 'right', mut, 10);
      var near = JUST.concat([['1', 1]]).map(function (q) { return [q[0], cents(r / q[1])]; }).sort(function (a, b) { return Math.abs(a[1]) - Math.abs(b[1]); })[0];
      rdA.textContent = 'f₁ = ' + kit.num(F1, 1) + ' · f₂ = ' + kit.num(f2, 1) + ' ' + S('exp.common.hz') + ' · ' + kit.num(r, 3) + ' = ' + kit.num(cents(r), 1) + ' ' + S('exp.common.cents') + (Math.abs(near[1]) < 8 ? ' (≈ ' + near[0] + ', ' + kit.num(near[1], 1) + ')' : '') + ' · |f₂ − f₁| = ' + kit.num(df, 1) + ' ' + S('exp.common.hz');
      rdA2.textContent = lowered ? S('exp.twotones.line.lowered').replace('{n}', kit.num(fa, 0)).replace('{m}', kit.num(F1, 1)) : '';
      rdA2.style.display = lowered ? '' : 'none';
    }
    function drawB() {
      var ctx = cB.ctx, w = cB.w, h = cB.h, cu = data.curve, mx = 0, i; ctx.clearRect(0, 0, w, h);
      cu.forEach(function (p) { mx = Math.max(mx, p[curveKey]); });
      var box = { l: 30, t: 12, r: w - 10, b: h - 34 }, ax = kit.axes(ctx, box, { xmin: 1, xmax: 2.3, ymin: 0, ymax: mx * 1.05, ylabel: S('exp.twotones.b.rough') });
      ctx.strokeStyle = mut; ctx.globalAlpha = 0.5; ctx.setLineDash([3, 3]);
      JUST.concat([['1', 1]]).forEach(function (q) { ctx.beginPath(); ctx.moveTo(ax.x(q[1]), box.t); ctx.lineTo(ax.x(q[1]), box.b); ctx.stroke(); });
      ctx.setLineDash([]); ctx.globalAlpha = 1;
      JUST.concat([['1', 1]]).forEach(function (q, i) { txt(ctx, q[0], ax.x(q[1]), box.b + 14 + (i % 2) * 11, 'center', mut, 10); });
      kit.curve(ctx, cu.map(function (p) { return [p[0], p[curveKey]]; }), ax.x, ax.y, curveKey === 1 ? kit.blue : kit.violet, 1.8);
      var D = kit.interp(cu.map(function (p) { return [p[0], p[curveKey]]; }), r);
      ctx.strokeStyle = accent; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(ax.x(r), box.t); ctx.lineTo(ax.x(r), box.b); ctx.stroke();
      if (D != null) { ctx.fillStyle = accent; ctx.beginPath(); ctx.arc(ax.x(r), ax.y(D), 4.5, 0, TAU); ctx.fill(); }
      else txt(ctx, S('exp.common.outside'), ax.x(r), box.t + 10, 'center', accent, 11);
      var mins = curveKey === 1 ? data.minima_harmonic.map(function (m) { return m.just; }).join(', ') : data.minima_bar.filter(function (m) { return m.kind === 'corner'; }).map(function (m) { return kit.num(m.r, 3); }).join(', ');
      rdB.textContent = 'D(' + kit.num(r, 3) + ') = ' + (D == null ? S('exp.common.outside') : kit.num(D, 4)) + ' · ' + (curveKey === 1 ? '' : 'r: ') + mins;
    }
    function draw() { drawA(); drawB(); }
    T.onpause = draw; window.addEventListener('resize', draw);
    kit.loop(function (t) {
      if (glide) {
        if (glide.t0 == null) glide.t0 = t; var u = (t - glide.t0) / glide.dur;
        if (u >= 1) { u = 1; if (glide.own) stopV(); glide = null; }
        var q = Math.pow(2, u); sl.set(q); setR(q);
      }
    });
    draw();
  } };
})();
