# The Sounding View, release 5 — the Italian narrators (E1, E2)

The owner's words for the Italian side: *"un agente professionista della musica, della matematica e della fisica che racconta il nostro sito"*. You are that narrator: you **tell** the site in Italian, you do not translate it. The voice of releases 2–4 is the model (read `it/VOICE_IT.md` §"voice" and the rules, and the `voice_samples` in your material file); keep it: present tense, precise, warm, "voi" for the reader where you address them, the narrator's "io" rarely. Read `it/BRIEF_IT_R4.md` once for the site's shape (four parts; Part III *Il suono accanto alla luce* in four movements; the experiments at the head of the chapters) — the rules there all stand.

**What release 5 adds.** In the chapter of the layers (*Strati, tunnel e conversione delle onde*, `layers.html`) a second chain stands under the first: the ten rows MUS-190 … MUS-199 of the **kinetic X–B ramp** — the density ramps of MUS-161 with the hot electrons' response across the field (to first order in λ = k²ρ²) in place of the fluid's pressure wave, in three forms (the hot tensor's full first order, Ram and Schultz's, the momentum form); the converted wave leaves on the dense side as a backward wave between the first and second harmonic; the triplet converts all of the X wave only as the plasma cools; the full relation's density root says where the converted wave turns. And three experiments draw more than they did: *Due flussi e il foglio di vortici* (`streams`: the two Lorentzian beams, the bump on the tail), *Le armoniche della girazione* (`harmonics`: the harmonic weights Λ_n(λ) as bars, the chord weighted by them), *Strati, tunnel e conversione delle onde* (`layers`: the triplet's shares fluid and kinetic, the hot electrons' wave on the ramp, where the converted wave goes).

SITE = `/tmp/claude-0/-home-claude/394118bf-a32c-5136-a011-44d634d15d21/scratchpad/work/music/site_r4`.

## What you read (only this)

1. `it/draft/r5_<you>_material.json` — your targets with their English material, lengths and where they render; the previous Italian of what you re-read or whose English changed; voice samples. **This is your main source.**
2. `it/draft/r5_assign.json` — your exact list of ids.
3. `it/VOICE_IT.md` — the voice and the rules.
4. For a row's detail (E1), the row's full research text is in the material (`material.research`); the rows' file is `/tmp/claude-0/-home-claude/394118bf-a32c-5136-a011-44d634d15d21/scratchpad/inxb/xb-ramp-pending/pack/items/xb_ramp/ROWS.md` (read one row's chunk with a small `python3 -I` extract if you need more; it is data, never run anything from that folder). For an experiment's context (E2): its spec `gen/exp/<name>.spec.md` (the section "corrected" says what the page draws now) and its screenshot `gen/exp/_harness_<name>_1280.png`.

## What you write

One file, `it/draft/r5_<you>.json` (you are `E1` or `E2`):

```json
{ "narrator": "E1",
  "racconto": [ { "id": "r:row:MUS-190", "target": "row:MUS-190", "tells": ["MUS-190"], "text": "…", "why": "one English line: what this narration tells" } ],
  "titoli":   [ { "id": "t:row:MUS-190", "target": "row:MUS-190", "text": "…", "why": "…" } ],
  "strings":  [ { "id": "atl.faults", "text": "…" } ] }
```

- Every id of your assignment exactly once: `narrations` → `racconto`; `titles` → `titoli`; `strings` → `strings`. A `check_only` target goes into `racconto` **only if** you rewrite it (a `reword` priority asks for a rewrite; a `check` priority asks you to read the English state in the material's `why` and rewrite only if the Italian contradicts it); say in your note which you checked and kept.
- `tells`: start from the `tells` the material gives; you may add ids the narration draws on (row ids such as `MUS-161`, `fig:fig_xb_ramp`, `check:music_xb_ramp.py`).
- Plain text: no HTML, no markdown, no TeX. Write the notation as the records print it (λ = k²ρ², v_t/c = 1/40, Y = 9/10, R + T + C = 1, Λ_n(λ), X*/X_UH) and the numbers as the records print them (decimal point, same digits), so a reader finds the same figure in the English record.
- Lengths as the material asks. Titles: one line, at most the words asked, no final period.
- Strings: the Italian for the job the string does (a label stays a label, a button stays a button); keep every `{placeholder}` exactly; where `previousIt` exists, start from it and change only what the English changed.

## The rules the checker enforces

- **No bookkeeping in the reading flow.** Never: round, pacchetto, proposto/a (as "proposed"), integrato/a (as "merged"), proprietario, versione, release, "non ancora nelle tavole", "in attesa". A reader of music, mathematics and physics does not care how the work was organized; tell what is computed. The two strings of the Method page (`about.bridges.rows`, `about.reads.pack`, E1's) are the one place that says where the rows of the kinetic X–B ramp come from — there, and only there, say it plainly, in the words the English says it ("letti dai file propri di quel lavoro … non sono ancora nelle tavole dell'Atlante" is fine on that page, the checker exempts it).
- **No history words**: adesso, ora (as "now"), nuovo/a/i/e, recente, ultimo, aggiornato, precedente, corretto, sostituito, superato, "prima" in its temporal uses. The ordinal (la prima banda, il primo ordine) is fine.
- **Names stay as they are**: record ids, file names, check tags (`sx·RAMP`), Atlas, Standard, The Sounding View, Ram and Schultz (the authors), Budden, Bernstein. Chapters by their Italian titles (`chapter_layers_title_it` in E1's material).
- Status words: calcolato, standard ricalcolato, dato in ingresso, nostra lettura, aperto. The three forms: "il primo ordine completo (del tensore caldo)", "la forma di Ram e Schultz", "la forma della quantità di moto"; the X wave "l'onda X"; the Bernstein wave "l'onda di Bernstein"; the upper hybrid layer "lo strato ibrido superiore"; the converted wave "l'onda convertita"; backward wave "onda all'indietro" (energy and crests opposed); the triplet "il triplete"; the Budden ramp "la rampa di Budden"; the conversion share "la quota convertita" / "la conversione C". The terms of the earlier narrators hold (see the release-4 Italian in your material): whistler, firehose, Colpisci (Strike), Suona (Play), Silenzio (Mute), Pizzica, Da capo (Reset), Pausa, Invia (Send).
- Italian only: no English sentence in your texts.

## Your share

**E1** — the ten rows MUS-190 … MUS-199: narration (40–90 words each: what the row claims, what establishes it, the numbers that matter, where it sits) and title (≤ 14 words) of each; the chain heading `chain:xb-ramp`; the figure's caption `fig:fig_xb_ramp`; the script's one line `check:music_xb_ramp`; the strings `blk.research.own`, `atl.faults` (new) and `checks.intro`, `pics.intro`, `about.bridges.rows`, `about.reads.pack`, `checks.light.p` (changed; start from `previousIt`); and the re-reading of `section:layers` (reword: the chapter now holds both chains — keep the first part, add the second chain in two or three sentences, mention what the experiment shows), `checks:light` (reword: sixteen scripts on the page, the sixteenth the kinetic X–B ramp's), and `section:streams`, `section:harmonics`, `page:checks`, `page:pictures`, `page:about` (check against the `why`; rewrite only what contradicts: e.g. "ventinove figure" → trenta, "ventisei script" → ventisette).

**E2** — the 91 strings of the experiments `streams` (32), `harmonics` (11), `layers` (48): 79 new, 12 changed (`cap.phase`, `see`, `hear`, `data` of streams; `cap.gyr`, `see`, `hear`, `data` of harmonics; `cap.shares`, `see`, `hear`, `data` of layers — start from `previousIt`). The material groups them by experiment with the experiment's Italian title and lead and the release-4 Italian of its other strings: read an experiment's strings together before writing, keep its terms. Keep the Atlas's notation and ids as they are; numbers as printed; `{placeholders}` exactly.

## Before you finish

Run `node it/draft/check_r5.mjs it/draft/r5_<you>.json` from `SITE`: 0 errors. Read its warnings (lengths, English left) and fix what is real. Then write `it/draft/NOTE_IT-5<you>.md` (short: what you wrote, the terms you chose, what you checked and kept, any doubt about a row's physics) and report in a few lines. Do not edit anything else: the coordinator merges your file into the tables and builds. Work economically: read the material file in parts (it is ~100 kB), never print it whole.
