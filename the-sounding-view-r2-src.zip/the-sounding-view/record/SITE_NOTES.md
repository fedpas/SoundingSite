<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors -->
# The Sounding View — site notes (release 2, 2 November 2026)

How the generator works, its readers and string tables, how to rebuild and check, and what is not done. Release 1's notes are kept below the rule at the end.

## Layout

```
site/
  gen/                    the generator (Node 22, KaTeX 0.16.47 and Playwright from NODE_PATH=/opt/npm-tools/node_modules)
    build.mjs             reads the Atlas, the pack and the tables below, writes out/ (and out/it/) and gen/build/trace.json
    check.mjs             verifies out/ against the sources (exit 0 when clean); the Italian pages too
    manifest_it.mjs       writes content/it/MANIFEST.json for the narrators (every target, strings_new, strings_changed)
    shoot.cjs             screenshots of every page, English and Italian (it_<page>), 1280 and 390 px, light and dark, from file://
    test_sounds.mjs       the synthesizer's test: Chromium renders sounds.js into an OfflineAudioContext and measures it (37 assertions)
    lib/sources.mjs       loads the Atlas's tables and round 36's files, attaches the pack; resolve(source) → text; applyPart
    lib/pack.mjs          the pack of round 37 as a source: the study, the ROWS.md reader, BRIDGE.md, BRIDGES_DRILLED.md, the
                          indexes, the scripts' docstrings, the logs, the figure data, DICTIONARY.md; resolvePack('pack.*')
    lib/italian.mjs       the narrator's tables (content/it/), SDV_IT, the banned-word matcher
    lib/study.mjs         reads a study's HTML into units and sentences (both studies)
    lib/tex.mjs, lib/scripts.mjs, lib/md.mjs   as in release 1 (md.mjs now holds the table reader mdTables)
    content/strings.json  the site's own strings (405: 220 of release 1, 185 of release 2): id, text, why; `optional` for the ones
                          shown only on some data or used as attributes
    content/story_map.json   the Story register of the Atlas's rows (release 1)
    content/bridges_map.json the Story maps of the page of the drill: the head, the question, the eight items' sections, clips and
                          instruments, each proposed row's units or sentence ranges, the opinion
    content/placements.json  the section order and slugs, the clips of each section, each section's instrument, the home's figure
    content/it/strings_it.json, racconto.json   the narrator's tables (see below); MANIFEST.json for the narrators
    figures/mark.svg      the site's mark
    assets/               site.css, site.js (the register switch), sounds.js (the synthesizer, 9 instruments), RELEASE_NOTES.md
    build/                trace.json (every traced block), build_log.json, check_log.json
  out/                    the site: 16 pages, it/ (16 Italian pages), site.css, site.js, sounds.js, sounds-data.js, katex/, figures/
                          (figures/round37/), audio/ (21 clips), checks/ (checks/round37/), content/version.json, RELEASE_NOTES.md, LICENSE
  record/                 these notes, shots/ (128 screenshots), shots_report.json, test_sounds.json, build_log.json, check_log.json
  NOTE_R2.md              the builder's note for the orchestrator (not shipped)
```

## How to rebuild

```
cd site
NODE_PATH=/opt/npm-tools/node_modules node gen/build.mjs REPO     # REPO: the Atlas's repository (default ../repo); SDV_PACK: the pack
                                                                  # (default ../../../r37/pack/round37_bridges_pack); about 1 s
NODE_PATH=/opt/npm-tools/node_modules node gen/check.mjs REPO     # 0 errors required; about 2 s
NODE_PATH=/opt/npm-tools/node_modules node gen/test_sounds.mjs    # 37 of 37 PASS required; about 20 s
NODE_PATH=/opt/npm-tools/node_modules node gen/shoot.cjs [--full] [--pages a,b,it_c] [--reg atlas]   # 0 problems; about 90 s
NODE_PATH=/opt/npm-tools/node_modules node gen/manifest_it.mjs    # rewrites content/it/MANIFEST.json after a string changes
```

`SDV_IT` chooses the Italian build: `full` (the default) refuses to finish, exit 1 naming the ids, when `strings_it.json` lacks a string or `racconto.json` lacks a narration for a target the pages render, or when a table holds a stub (`"stub": true`); `partial` renders a missing narration as a visible placeholder (`data-r-missing`) and the checker reports it, and the stubs, as warnings; `off` builds and checks the English site alone (and removes `out/it/`). `SDV_DATE` and `SDV_RELEASE` set the stamp; `SDV_OUT` builds elsewhere; `SDV_OGG` names the folder of round 36's Ogg clips (default `../audio_ogg`; the pack's own Ogg copies are read from its `audio/`). Every step reads the repository and the pack only.

## How the generator works

- **Trace.** `traced(ctx, base, source, {part, render})` resolves a source — `{table, key, field}` on the Atlas's tables (`rows`, `texts`, `status`, `checks`, `check_runs`, `log`, `logfile`, `lens`, `lens_readings`, `pages`, `page`, `chains`), on round 36's files (`study`, `study.heading`, `figures`, `clips`, `clips.outro`, `sources_md`), on the pack (`pack.study`, `pack.study.heading`, `pack.row`, `pack.item`, `pack.bridges`, `pack.bridge`, `pack.figures`, `pack.clips`, `pack.clips.rule`, `pack.clips.outro`, `pack.script`, `pack.log`, `pack.logfile`, `pack.seconds`, `pack.ogg`, `pack.dict`, `pack.dict.counts`, `pack.dict.slips`, `pack.dict.top`, `pack.dict.cand`, `pack.readme`), or a site string — applies the declared part (`first-sentence`, `md-plain`, `sentences:a-b`, `grade-word`), records the block in `build/trace.json` and gives the element its `data-b`. A site string is an element with `data-s`; a narration an element with `data-r`.
- **Renderings.** `text`, `script`, `md`, `mdlinks`, `links`, `study` as in release 1; `lines` (the lines of a ROWS.md field, nested bullets as lines, scripts drawn), `ids` (scripts drawn, the row ids linked where the row is on the site), `refs` (arXiv numbers and DOIs as links).
- **The pack as a source** (`lib/pack.mjs`). The study `docs/round37/the_bridges_drilled.html` is read by `lib/study.mjs` like the first study (170 units, 29 formulas; its figures and embedded clips are dropped, the site shows its own copies). `ROWS.md` is read by `parseRows`: chunks between horizontal rules, the head `**MUS-0NN** · kind · **status** · tags · controls`, the stage line, the bold fields (`homeMath`, `homePhys`, `depends`, `standardRef`, `home` or `proposed home`, `what the control(s) break(s)`, `chain note`, `reason`, `the web claims`), nested bullets and indented lines as further lines of the field, the blockquote as the research text. `BRIDGE.md` gives its first table (the last column the grade proposed) and, per numbered section (`## n.` or `**n. …**`), the row ids and the check tags its text names (a row touches the bridges whose sections name it or one of its tags). `BRIDGES_DRILLED.md`'s summary table, `FIGURES_INDEX.md` (the eight items' tables joined) and `audio/INDEX.md` (the three items' tables joined, the voicing-rule paragraph, the three "the clips illustrate" lines) are read with `mdTables`. The nine scripts' docstrings give the first paragraph, the Statements section (one statement per check tag, continued on indented lines), the legend lines and the Scope line; the logs, the faults logs, `.log.seconds` and `ogg.log` are read as lines. `DICTIONARY.md` gives its three tables (the dictionary, the counts, the printed slips), its prose before the table and the ten candidates with their bullets.
- **Rows.** `rowBlock` as in release 1 for the Atlas's rows. `proposedRowBlock` for the pack's: the chip of the status ROWS.md gives with the outline *proposed*; Story from `bridges_map.json` (else the research text, and the block says so); Research the research text; Atlas the fields of ROWS.md, each traced, the depends text verbatim with the ids linked, the evidence tags each with the docstring's statement, the ok lines of the log's group, the log's ALL OK line and the run's seconds, what the controls break; Standard the standard reference and the bridge grade of the item's BRIDGE.md (the sections naming the row or its tags; for an item with one bridge, that bridge). On the Italian pages the Story register holds the narration `r:row:<id>` and the three others carry the Italian line `it.records`.
- **The page of the drill.** The head (the study's byline sentence as its stamp, the standing string with the study's "Nothing is merged" sentence), the question (§1 and part 2's opening), the table of the eleven bridges, the eight items (heading string, the BRIDGE.md title, the sections' prose units, the rows, the figures whose first row the item proposes, the clips, the instrument), the paper's dictionary (also the second part of `dictionary.html`), the opinion and what part 2 changes, the pointer to the references on Sources.
- **Languages.** `buildPages()` runs once per language with `L` (the string table, the folder, the prefix `../` of the shared files, the narrations). The Italian pages are the same pages with the Italian chrome, the records in English, the narrations at their targets (`racc(target)`), the switch EN · IT and `lang="it"`.
- **Sounds.** `sounds-data.js` is written by the build from both rounds' `figdata/` (release 1's keys and `crt`, `rings`, `rows`); `sounds.js` exposes its engine as `window.SDV_ENGINE`; every word it writes into the page is read from the page (hidden spans `data-s`, the select's options, the containers' aria-labels), so the Italian page plays the same engine with Italian controls.

## What the checker verifies (`gen/check.mjs`)

Everything of release 1, on the English and the Italian pages (the English records keep their `data-b` on the Italian pages and are resolved again), and: the proposed rows' chips are the status their ROWS.md gives, with the marking *proposed* beside each, and no Atlas row is marked; the page of the drill shows every proposed row once, in the items' order, with its clips; the 12 figures of the pack on Pictures and on the page of the drill and shipped under `figures/round37/`; the 9 clips on Sounds and shipped; the nine instruments; the paper's dictionary's rows on both pages; the pack's scripts, logs, faults logs, README and run_all.sh under `checks/round37/`; 311 ok lines of the pack's logs and 45 controls on Checks (beside 89 and 12); the 11 bridges in the table; `version.json` naming the pack as proposed, not merged, with its study's date; one link to the Atlas per language. For the Italian pages: every `data-s` equals its string in `strings_it.json` (every id of `strings.json` present, with a text and a why); every `data-r` equals its item's text (paragraphs joined), stands at its target (the row block, section, page, instrument, clip or part it names) and every item of `racconto.json` is rendered exactly once; every `tells` id exists (a row on the site, a study section `study:§n` / `drill:§n`, a clip, a figure, a script or a check tag, a file of the pack, a figure data file, the lens); no run of three words outside the traced elements; `lang="it"`; the switch links resolve both ways; the Italian stamp names the Atlas; no banned word of `it/VOICE_IT.md` in either table (`lib/italian.mjs`, `bannedHits`: whole words, every form; *prima* in its temporal uses; *ora* not after an apostrophe; *release*, *versione* and *round N* allowed in the stamp alone); no stub and no placeholder in the final build (warnings under `SDV_IT=partial`). Last run: see `record/check_log.json`.

## The string tables

- `content/strings.json` — 405 strings, each with a `why`; the 185 of release 2 are the navigation and the switch (`nav.bridges`, `lang.*`, `it.records`), the home's ninth card, the page of the drill (`b.*`), the proposed row block (`chip.proposed`, `chip.legend.proposed`, `blk.*.p`, `atl.*`, `std.bridge*`), the Checks and Pictures additions (`checks.r37*`, `pics.r3*`), the paper's dictionary (`dict.paper*`), the Sources additions (`src.refs2*`, `src.paper`), the three instruments (`i7.*`, `i8.*`, `i9.*`, `inst.*`), the labels the synthesizer reads from the page (`i2.cents`, `i4.body.*`, `ui.hz`), the accessibility labels (`aria.*`, optional), and About's additions (`method.4`, `about.reads.pack*`, `about.italian*`). 14 strings of release 1 changed their text for the new counts; `content/it/MANIFEST.json` lists both.
- `content/it/strings_it.json` — 405 entries, one per id of `strings.json`, the narrator's Italian for the job the string does; `content/it/racconto.json` — 122 narrations (`r:` + target): the home, the eight sections, the 27 + 36 rows, the pages, the nine instruments, the 21 clips, the page of the drill, its table, its eight items, its opinion, the paper's dictionary, the nine scripts and the twelve figures of the pack. The tables are the two narrators' (IT-1 release 1's targets, IT-2 the drill's), merged by the orchestrator and read by an independent reviewer (24 edits applied in place); their record is `it/VOICE_IT.md` (the contract), `it/draft/NOTE_IT-1.md`, `it/draft/NOTE_IT-2.md` (the narrators' notes, with their drafts and their own checks beside them) and `it/REVIEW_IT.md`. The checker verifies both tables (last run: 0 errors, 0 warnings, 122 narrations rendered once each).
- `content/bridges_map.json` — the Story maps of the page of the drill (above).

## Screenshots and the console

`record/shots/`: every page, English and Italian (`it_` prefixed), at 1280 and 390 px, light and dark (128 shots). From the disk, no console error on any page and no horizontal scroll at 390 px; the only console lines are the two Google fonts failing for want of a network in this sandbox (reported apart; the system fonts stand in). Read on the Italian shots at 390 px: the header, whose language switch took a row of its own, now shares the register switch's row (the brand on the first row); the instruments' Italian labels wrap into their rows and the readouts under their labels; nothing overflows.

## What I could not do, or did otherwise

- **The ring sounding 4, 5, 6, 5, 4, 1** is not in the instrument: its stiffnesses are printed in the log and in `audio/INDEX.md`, not in the figure data, and the instruments show the figure data's numbers only.
- **Ring B's amplitudes** are not in the data (`clips_rings.json` has its partials only): the page plays them equal and says so beneath the instrument. **Ring A's eleventh partial** is nearly silent at the listening mass (as the clip says); the test asserts the ten audible ones.
- **The decays** of the rings of §13 (τ = 1.5 s × (f_low/f)^½) are the clips' listening choice, stated in `audio/INDEX.md`, not a number of the figure data; the bells' τ = 1.8 s × 220/f is `clips.json`'s.
- **The mirror's image of the diatonic set** is seven consecutive semitones, not a diatonic set a fifth-step apart: x ↦ 7x carries the line of fifths onto the line of semitones. The test asserts what the arithmetic gives.
- **The learner texts** of the proposed rows do not exist; their Story register tells them in the study's words or by their research text, and says which.
- **BRIDGE.md grades** stand in a proposed row's Standard register where the item's BRIDGE.md names the row in a numbered section, by its id or by one of its check tags, or where the item drills one bridge; MUS-025 alone (ml·CUBE, named only in an unnumbered section) shows the line "names no bridge for this row".
- **Web fonts** need the network, as before; KaTeX's fonts ship. **Not packaged**: no zip was made; `out/` is the site.

---

# Release 1 (2 November 2026), as it was

How the generator works, its string tables, how to rebuild and check, and what is not done.

## Layout

```
site/
  gen/                    the generator (Node 22, KaTeX 0.16.47 and Playwright from NODE_PATH=/opt/npm-tools/node_modules)
    build.mjs             reads the Atlas and the tables below, writes out/ and gen/build/trace.json
    check.mjs             verifies out/ against the sources (exit 0 when clean)
    shoot.cjs             screenshots of every page, 1280 and 390 px, light and dark, from file://, with the console checked
    test_sounds.mjs       the synthesizer's test: Chromium renders sounds.js into an OfflineAudioContext and measures it
    lib/sources.mjs       loads the Atlas's tables and round 36's files; resolve(source) → text; applyPart (declared parts)
    lib/study.mjs         reads the study's HTML into units (paragraphs, list items, captions, displays) and sentences
    lib/tex.mjs           the sister site's lib/tex.mjs, copied unchanged (its inline sub/superscript rules are used)
    lib/scripts.mjs       scriptsH / scriptsP: those rules plus one of this site's ((−1)^|x∧s| is one superscript)
    lib/md.mjs            the inline markdown of the round's indexes (code, bold, italics, links, \|)
    content/strings.json  the site's own strings (220): id, text, why; `optional` for the ones shown only on some data
    content/story_map.json  the Story register: for each row, the study's units or sentence ranges that tell it; the home's question
    content/placements.json the section order and slugs, the clips of each section, each section's instrument, the home's figure
    figures/mark.svg      the site's mark (the clock with the augmented triad)
    assets/               site.css, site.js (the register switch), sounds.js (the synthesizer), RELEASE_NOTES.md
    build/                trace.json (every traced block), build_log.json, check_log.json
  out/                    the site: 15 pages, site.css, site.js, sounds.js, sounds-data.js, katex/, figures/, audio/, checks/, content/version.json, RELEASE_NOTES.md, LICENSE
  record/                 these notes, shots/ (64+ screenshots), shots_report.json, test_sounds.json
```

## How the generator works (release 1)

- **Trace.** `traced(ctx, base, source, {part, render})` resolves a source — `{table, key, field}` on the Atlas's tables, on the round's files, or a site string — applies the declared part (`first-sentence`, `md-plain`, `sentences:a-b`, `grade-word`), records the block in `build/trace.json` and gives the element its `data-b`. A site string is an element with `data-s`.
- **Renderings.** `text` (escaped), `script` (the Atlas's inline sub- and superscripts drawn, the sister site's rules), `md` (the indexes' markdown, already plain, with scripts), `mdlinks` and `links` (URLs as links), `study` (the study's units: formulas set by KaTeX, its "corrected" chips and emphasis kept, scripts drawn).
- **The study.** `lib/study.mjs` cuts the study's body at its headings into units, replaces each KaTeX rendering by its TeX (the annotation the study carries), keeps i, b, code, links and the chips, and splits units into sentences (the sister site's rule). A displayed formula is rendered as `\htmlData{src=<unit>}{…}` with its `\tag` kept outside, so the page names the source of each display; `data-tex` keeps the plain TeX for the checker.
- **Rows.** `rowBlock` writes the head (id, chip from `derived/status.json`, badge, claim = homePhys or the research text's first sentence) and the four registers. Story: `story_map.json` (the study), else the learner text (`texts.json`, level learner, register full), else the research text. Atlas: homeMath, homePhys, kind (and the input's kind), status and badge, cells, depends (grouped by relation, linked when the row is on the site), the reason, since; each evidence with the check's statement (`checks.json` ids), the run record (date, ok, fail, last line; the latest record of the script) and, for round 36, the group's lines of the log. Standard: standardRef (URLs live) and the lens entries whose rows hold the row (else its readings).
- **Sections.** From `page.json` (titles, leads) and `chains.json` (the rows in order, the links with their notes); figures where FIGURES_INDEX.md's row column meets the chain (ranges expanded; the map is the home's); clips from `placements.json`.
- **Sounds.** `sounds-data.js` is written by the build from `figdata/` (cents_table, dissonance_curve, dft, plr_dual, even, chain_modes, partials); `sounds.js` exposes its engine as `window.SDV_ENGINE` so the test renders the same calls offline.

## What the checker verified in release 1

Every traced block equals its source (with its part) and the page shows exactly that text; every `data-b` is traced; every `data-s` shows its string and every string has an id, a text and a why; no run of three words stands outside the traced elements; each chip is its row's status in `derived/status.json`; each row block has its four registers and Story its source line; each section shows its chain's rows in order and its clips; every internal link and anchor resolves and every image, clip, script, stylesheet and KaTeX font ships; exactly one link to the Atlas (About, `data-atlas-link`, `#/music`); every formula renders with KaTeX and no page holds a KaTeX error; no script fetches; `version.json` names the Atlas 4.4.9, the release and the date, and every page carries the stamp; the 13 figures, 12 clips, 34 lens entries, 89 ok lines and the scripts and logs are all there. Last run of release 1: 0 errors, 0 warnings, about 1,700 traced blocks.

## What release 1 could not do, or did otherwise

- **No learner texts**: none exist for the MUS and INP rows or the leads; Story uses the study's prose (21 rows), the Atlas's learner texts (5 rows) or, for ATY-040, its research text, and each block says which.
- **Clips 7 and the sections**: the brief named the clips of five sections; shapes, fourier and question have none, and link instead to the Sounds page's instrument (the Tonnetz walk, the clock).
- **Clicks**: the rhythm's percussive sounds use a 2 ms raised-cosine attack and an exponential decay, not the 20 ms fades of the tones (clip 8's clicks are percussive too).
- **Drift of other walks**: the page computes the just drift of any walk; only the hexatonic one (128/125) is a number of the Atlas's tables, and the test asserts it.
- **Web fonts** need the network, as on the sister site; KaTeX's fonts ship.
- **Not packaged**: no zip and no publish lists were made; `out/` is the site.
