// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// _harness.mjs — writes a standalone test page for one experiment module, with the kit, the module, its data and its
// strings inlined (a file:// page cannot fetch JSON), so that a builder can open and screenshot the experiment before
// the generator mounts it. Usage: node gen/exp/_harness.mjs <slug>   → gen/exp/_harness_<slug>.html
import fs from 'node:fs';
import path from 'node:path';
import url from 'node:url';
const HERE = path.dirname(url.fileURLToPath(import.meta.url));
const slug = process.argv[2];
if (!slug) { console.error('usage: node gen/exp/_harness.mjs <slug>'); process.exit(2); }
const read = (f) => fs.readFileSync(path.join(HERE, f), 'utf8');
const kit = read('_kit.js'), mod = read(`${slug}.js`), css = read('_exp.css');
const data = fs.existsSync(path.join(HERE, `${slug}.data.json`)) ? read(`${slug}.data.json`) : '{}';
const strings = JSON.parse(read(`${slug}.strings.json`));
const common = JSON.parse(read('_common.strings.json'));
const S = {}; for (const s of common.strings.concat(strings.strings)) S[s.id] = s.text;
const legend = (strings.rows || []).map((id) => `<li><code>${id}</code></li>`).join('');
const html = `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>harness · ${slug}</title>
<style>
:root{--bg:#f7f6f2;--panel:#fff;--ink:#1d221f;--ink-2:#454d49;--muted:#6b7470;--rule:#dcdcd4;--rule-2:#ebebe4;--accent:#0e7368;--accent-tint:#e1efea;--warm:#b4552b;--c-std:#4a6b8a;--c-std-tint:#e4ecf3;--c-input:#6b7470;--c-ours:#b07a1a;--c-ours-tint:#f6ecd6;--c-open:#6b4fa0;--c-open-tint:#ece6f5;--sans:system-ui,sans-serif;--fs-xs:12px;--fs-s:13.5px;--fs-m:16px}
body{margin:0;background:var(--bg);color:var(--ink);font:400 16px/1.55 system-ui,sans-serif}
main{max-width:1180px;margin:0 auto;padding:16px}
.chip{display:inline-flex;align-items:center;gap:4px;font:500 12px/1 var(--sans);padding:4px 9px;border-radius:999px;border:1.5px solid var(--ink);color:var(--ink);background:var(--panel);white-space:nowrap}
.chip--standard-recomputed{border-color:var(--c-std);color:var(--c-std);background:var(--c-std-tint)}.chip--input{border-style:dashed;border-color:var(--c-input);color:var(--c-input)}.chip--ours{border-style:dashed;border-color:var(--c-ours);color:var(--c-ours);background:var(--c-ours-tint)}.chip--open{border-style:dotted;border-width:2px;border-color:var(--c-open);color:var(--c-open);background:var(--c-open-tint)}.chip--sm{padding:3px 7px}
.seg{display:inline-flex;border:1px solid var(--rule);border-radius:999px;padding:2px;background:var(--panel)}.seg button{font:500 13.5px/1 var(--sans);color:var(--ink-2);background:transparent;border:0;border-radius:999px;padding:7px 12px;cursor:pointer;min-height:32px}.seg button[aria-checked="true"]{background:var(--ink);color:var(--bg)}
.btn{font:500 13.5px/1 var(--sans);padding:8px 14px;border-radius:999px;border:1.5px solid var(--ink);background:var(--panel);color:var(--ink);cursor:pointer}
${css}
</style></head><body><main>
<section class="exp" data-exp="${slug}"><header class="exp-head"><h2 data-s="exp.${slug}.title">${S['exp.' + slug + '.title'] || slug}</h2><p class="exp-lead" data-s="exp.${slug}.lead">${S['exp.' + slug + '.lead'] || ''}</p></header>
<div class="exp-stage"></div>
<div class="exp-legend"><p class="k">What this picture establishes (the generator draws the rows here)</p><ul>${legend}</ul></div>
</section>
<script id="exp-data-${slug}" type="application/json">${data}</script>
<script>${kit}</script>
<script>${mod}</script>
<script>
var STRINGS = ${JSON.stringify(S)};
function S(id){ if(!(id in STRINGS)){ console.error('missing string '+id); return '['+id+']'; } return STRINGS[id]; }
document.addEventListener('DOMContentLoaded', function(){ window.SDV_EXP._kit.mountAll(S); });
</script>
</main></body></html>`;
fs.writeFileSync(path.join(HERE, `_harness_${slug}.html`), html);
console.log(`gen/exp/_harness_${slug}.html written (${Object.keys(S).length} strings)`);
