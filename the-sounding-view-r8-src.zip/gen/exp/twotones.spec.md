# Builder B1 — Ladder I: one tone, many bodies (five experiments)

Read `CONTRACT.md` and `_common.strings.json` first; then `_kit.js` (the helpers), and `field.js` if it exists. The Atlas rows' claims are in `/tmp/claude-0/-home-claude/394118bf-a32c-5136-a011-44d634d15d21/scratchpad/plan4/atlas_sound.json` (`rows[id].homePhys`, `.status`, `.text`). ATLAS = `/tmp/claude-0/-home-claude/394118bf-a32c-5136-a011-44d634d15d21/scratchpad/in4414/one-rule-src-4.4.14`; its figure data for these five: `checks/selfcheck/round36/figdata/{chain_modes, partials, dissonance_curve, consonance, cents_table}.json`, `checks/selfcheck/round37/figdata/{bell, bell_levels, harmonic_ring, rings, chain, cut_ring, sets, clips, clips_rings}.json`. Read them with `python3 -I`, inspect the shapes (the `source` fields name the check groups), and copy what each experiment needs into `<slug>.data.json`. The Atlas's engine `ATLAS/engines/springEngine.js` (plain ES module: `walsh, verts, edges, omega2, mode, pluck, levelShare, signedLevels`) may be copied into your module as plain functions, with its SPDX header line kept; it needs `ATLAS/engines/bitrule.js` (`popcount`, `sign`): copy what you use.

Pitch mapping for every experiment here: the first partial (or the lowest mode) sounds at 220 Hz unless the spec says otherwise; print the mapping in the `hear` line.



---

## 5. `twotones` — Beats, roughness and what listeners report (MUS-004, ATY-040, INP-124 … 128)

*Panels:* (a) **Two tones**: f₁ = 261.6 Hz fixed (the data's C4), f₂ from a slider over one octave (ratio 1 … 2, printed also in cents); the sum's envelope drawn; the beat rate printed. (b) **The roughness curve**: `dissonance_curve.json` (`r` and `D_harmonic`, `D_bar`, 1200 points; the model's constants): the curve against the ratio with a cursor at the slider's ratio; a switch harmonic partials / bar partials; the just intervals marked on the axis (3/2, 4/3, 5/4, 6/5, 5/3, 2); say "the minima sit at the simple ratios" and note the fitted shape is an input (INP-128, chip input). (c) **Three functions beside the listeners**: `consonance.json`: the 13 dyads as a table with four columns — the listeners' rank (INP-124, chip input), Sethares roughness (just and 12-TET), harmonicity, Euler's gradus — the Spearman correlations printed from `spearman`; the inputs INP-125 … 127 as three one-line cards with their chips (what is universal and what is not: read the claims from atlas_sound.json). (d) **Commas** (MUS-004, `cents_table.json`): the tempered scale's thirds against just, the four commas in cents, the chord beats in 12-TET (`chord_beats_hz_12tet`), the just hexatonic cycle's drift (`hexatonic`). *Hear:* the two tones; a glissando of f₂ over the octave with the roughness curve's cursor following; the chord just then tempered. *Legend rows:* ATY-040, MUS-004, INP-124, INP-125, INP-126, INP-127, INP-128. *Data:* the three files, trimmed (subsample the curve to 300 points, say so).

---

Deliver for each slug: `<slug>.js`, `<slug>.strings.json` (with `rows`), `<slug>.data.json`, `<slug>.spec.md` (this section plus "as built"), `_harness_<slug>.html` and the two screenshots, zero console errors. Then a short `B1_NOTE.md`: what each shows, what deviates, the slow-downs, open points. Work economically: one module ≈ 300–500 lines; reuse your own helpers across the five (copy them; no shared file but the kit).

### As built

Mapping: the lower tone is C4 = 261.6256 Hz (data), the upper 261.6·r, r from 1 to 2; the glissando takes 7.0 s (`glide_times_s['2']`), linear in cents. No slow-down on the sound; in panel (a) the plotted window is 3/Δf seconds (20 ms … 1.5 s); when the carrier would show more than 40 cycles it is drawn lower (printed), the beat at its true rate. Nothing animates but the glide, so no Pause is drawn.
Deviations: the curve is every 4th point of the 1200 (300 + last), and the roughness axis is in the model's own units (no numbers). The minima of the bar curve are listed as the 'corner' minima ratios. The fourth Spearman value (12-TET, 16 cents, 0.905) is printed in the line under the table although its column is not shown. Names of the commas and of the dyads are from the data. Click a row of the table to set the ratio (no sound by itself).
