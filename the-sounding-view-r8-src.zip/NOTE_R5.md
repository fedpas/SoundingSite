# NOTE_R5 — release 5 of The Sounding View, 5 November 2026

Everything is in `site_r4/` (the folder keeps its name). Atlas source: `scratchpad/in4414/one-rule-src-4.4.14`; the kinetic X–B ramp: `scratchpad/inxb/xb-ramp-pending/pack` (`SDV_PACK_XB`, an input of the build), both read as data.

## What was wrong, and what release 5 does

Release 4's pages for the Lorentzian beams, the harmonic weights and the warm triplet's shares said "no data here". That was the builders' report of their search of `figdata/*.json`, not the Atlas's state: `kinetic.json figure.beams` holds MUS-120's four growth curves and band edges, `bot` MUS-121's certified points and curve; MUS-177's weights are a certified formula whose float method the Atlas certifies (`sb·BESSEL`); MUS-161's triplet shares are in its text and the log line `sy·RAMP`. Builder B5 (`gen/exp/SPECS_B5_fix.md`, `B5_NOTE.md`) corrected the three modules.

The owner sent the pending pack of the kinetic X–B ramp; release 5 reads it as release 3 read the round-38 pack: `lib/pack.mjs loadXB` parses `items/xb_ramp/ROWS.md` (the round-37 reader, with the fields `homes` and `what the faults break`), takes the chain record from its json block, and places the ten rows in the tables in memory (`rows`, `texts`, `status`, `chains`, `checks`), each marked `xb: 'xb_ramp'`; the script joins `SCRIPTS38` (its log dir in `P.logDir`), the figure joins `P.figures` (study `light`). The trace records the rows under the Atlas's table names; `version.json` lists the pack's files apart (`xb`, with sha256). The row block guards `since` (the rows have none), adds the line *What the faults break* (`atl.faults`), and says in Research that the text is the row's own file's (`blk.research.own`). `structure.json`: the layers chapter has two chains.

## State

- `SDV_IT=full`: **0 errors, 0 warnings**; `test_sounds.mjs` 43 of 43; `shoot.cjs` 232 shots of 58 pages, 0 problems.
- 29 pages (+29 Italian); 197 row blocks, 27 scripts, 30 figures, 22 clips, 62 lens entries, 342 readings, 23 experiments; 19 850 traced blocks; 266 narrations, 921 titles, 1 341 Italian strings.
- The stamp is **Release 5** (the checker wants an integer release; the process-word rule bans "release N.N" in the flow).

## The Italian side

`gen/manifest_r5.mjs` (release 4 as the baseline, the deployed site under `SDV_R4`; the experiments' changed strings stubbed too) → `MANIFEST_R5.json`: 10 narrations, 13 titles, 2 new + 5 changed strings, 91 experiment strings, 4 review items. `it/draft/mk_r5.py` → `r5_assign.json`, `r5_E1_material.json`, `r5_E2_material.json`; `it/BRIEF_IT_R5.md`; narrators E1 (rows, titles, Method strings, the re-reading of the layers chapter and the counts) and E2 (the experiments' strings); `check_r5.mjs` (the Method strings exempt from the process-word rule, as the site's checker has it); `merge_r5.py`. Reconciled by hand: *tripletto* (the tables' term; the brief had said *triplete*), *intervalli certificati* for the enclosures, one physics slip in `exp.layers.hear` (at v_t/c = 1/160 almost nothing *comes back*).

## Open

- The |E_y| scale of `xb_ramp.json ramps`: explained (the fields are per unit amplitude of each form's normalized mode vector, not per unit E_y; B5_NOTE.md, and the note for the merge `XB_RAMP_FIGDATA_NOTE.md` in the delivery); the page scales each trace to its own largest and says why. The writer's fix is on the Atlas side.
- The Y = 2/5 ramps and the exact steps are drawn (second build of release 5).
