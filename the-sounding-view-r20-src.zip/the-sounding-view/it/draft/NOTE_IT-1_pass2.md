# NOTE_IT-1_pass2 — the narrator IT-1's second pass

Delivered in `site/it/draft/`:

- `titoli_r1.json` — 120 items, one per target of my share in `gen/content/it/MANIFEST_TITOLI.json`: the eight sections (`section:<slug>`, `section:<slug>:sub`, `chain:<slug>`, `card:section:<slug>`, 32 items), the one-line claims of the 27 Atlas rows (`row:<id>`), the captions of the thirteen figures of *Music on the labels* (`fig:<name>`), the title lines of the clips 01 … 10 (`clip:<nn>`, 12 items), the Italian music term of the 34 entries of the lens Musica (`lens:1` … `lens:34`), and `check:music_sound`, `check:music_symmetry`. Shape `{about, voice, items: [{id: "t:"+target, target, text, why}]}`.
- `pass2_edits_r1.json` — `{"racconto": [{target, text}], "strings": [{id, text}]}`: the 5 narrations and the 8 strings of my half of the merged tables that change (full new texts; everything else untouched). I did **not** edit `gen/content/it/racconto.json` or `strings_it.json`, as you asked.
- `pass2_strings_new_r1.json` — **optional**, not in my assignment: the Italian for the 58 strings the manifest lists under `strings_new` (the disclosure labels "…, in inglese", the grade words, the preset names of the instruments, the two provenance sentences of Il metodo, the bridges page's subtitle, lead and card). You did not assign them to me; I wrote them in case they are assigned to nobody. Discard the file if IT-2 has them.
- `check_IT-1_pass2.py` — the standalone check (lengths against the manifests, no banned word, no process word, no final period on titles, claims and labels). Run from `it/draft/`: `python3 -I check_IT-1_pass2.py ../../gen/content/it/MANIFEST_TITOLI.json ../../gen/content/it/MANIFEST.json titoli_r1.json pass2_edits_r1.json`.

All three JSON files load (`python3 -c 'import json; json.load(open(...))'`, exit 0).

## The manifest's keys and lengths (they differ slightly from VOICE_IT.md's table)

I followed `MANIFEST_TITOLI.json`, as you asked: `section:<slug>:sub` is "one line, ≤ 16 words" there (≤ 14 in VOICE_IT.md), `chain:<slug>` "≤ 10 words" (≤ 8 in VOICE_IT.md); the other kinds agree (section title ≤ 8, card 40–70, row ≤ 14 with no final period, fig 15–45, clip ≤ 10, lens ≤ 10, check ≤ 16). The target ids are exactly the ones you listed; the manifest has no extra target of my kinds. I kept every section title and chain heading inside the stricter VOICE_IT.md limit anyway except `chain:fourier` (10 words) and `chain:tone` (9), which use the manifest's room.

## What I wrote (titoli_r1.json)

- **Sections.** The title is the learner title told in Italian, not translated ("Un tono, una corda, un cubo che suona"; "Perché alcune note suonano bene insieme"; "Dodici note su un orologio"; "Perché dodici note, e perché sette"; "Due modi di muoversi fra gli accordi"; "Una ciambella di accordi, un nastro di coppie"; "Quanto è uniforme un accordo"; "Dove sta la magia, per quanto si sappia"). The sub-line carries the physics and the mathematics titles in one breath; the chain heading is the chain's learner title; the card (40–70 words) is the lead's substance in two or three sentences, with no row ids, so that the home reads as prose.
- **Rows.** One line per row, the claim as the row's `homePhys` states it (and `homeMath` where the physics line is thin: SPR-M01, SPR-M16, LAB-016b), ≤ 14 words, no final period, no id and no English. For the inputs the line says what the datum says (INP-124 "Come gli occidentali ordinano gli intervalli di due note: la mediana di sette studi"); for MUS-013 "Dove sta la magia: una lettura nostra, con la sua ragione" (the record's "Our reading, with its reason"). Numbers quoted as the records print them (224, 23, 352, 700 cent contro 701.955, 2κ, 16 per 16).
- **Figures.** Each caption says what the figure shows and what to look at, from `FIGURES_INDEX.md`'s caption as the manifest carries it, with the record's numbers (the cents of tet.svg, the ratios of dissonance.svg, the n-TET within ±2 cents of fifths.svg, f and χ of mobius.svg). Where the English caption is long I kept the first and the decisive numbers and dropped the rest (the English caption stays in the disclosure).
- **Clips.** Title lines after INDEX.md's "what is heard" (clip 03 "Quinta naturale, quinta temperata, comma pitagorico: i battimenti").
- **Lens.** The 34 music terms in a few words, in the manifest's order (the order of `lenses.json`'s `mus` dictionary); the "none" entries begin with "nessuno:" as the records begin with "none:", and say why in the record's words (lens 3 "nessuno: nessuna operazione musicale moltiplica due accordi").
- **Checks.** One line each: the part of the study and the rows (MUS-001 … MUS-004; MUS-005 … MUS-012) and what is computed, from the scripts' "what it computes".

Terminology beyond the first NOTE: *scheda a scomparsa* for a collapsed disclosure (`<details>`); *filo della lettura* for the reading flow; *la pagina dei ponti* / *i ponti* for the bridges page (its title "I ponti" is IT-2's `t:page:bridges`); *refusi* for the paper's "printed slips" (optional file); *invariato* for a bridge's "unchanged" grade (optional file); *toni interi* for the whole-tone set, *C maggiore* / *C minore* for the sets of dft.json (English note names, as the records and my narrations use them).

## The bookkeeping cuts (pass2_edits_r1.json)

What I searched for on my half of the merged tables (by script, after the reviewers' changes, which I kept): round N, pacchetto, integrato / non integrato, proposto/a/e/i, release, versione/edizione (outside the stamp), proprietario, nota di ricerca, 4.4.9, every word for drill (trivellati, sondati, perforati), "The bridges drilled" outside Fonti and Il metodo, and the first pass's banned list. Found and changed:

- `page:home`: the reviewers' "i ponti sondati" → "i ponti" (a drill word).
- `page:sounds`: "e le righe che illustrano sono proposte" cut (the manifest's `racconto_to_reword`).
- `page:about`: "una riga proposta porta anche il contorno che lo dice" cut, and "con le schede dell'Atlante in inglese accanto" → the records stand in the three record registers, out of the reading flow (the manifest's remark).
- `page:dictionary`: the table's columns re-described as the Italian table has them (the Italian term, the grade, the evidence, the rows; the Atlas term and the English term in each row's disclosure) (the manifest's remark); the first paragraph trimmed by a few words to stay ≤ 160.
- `row:INP-130`: "alla proposta di Koelsch, Vuust e Friston" → "all'ipotesi di Koelsch, Vuust e Friston" — not bookkeeping (it is the authors' proposal), but the checker's process-word test would read "proposta"; "ipotesi" says the same (the record: "proposed as a speculation").
- `release.stamp` → "Edizione {release} · {dateWords}" (the merged table already has this text; included so the edits file is complete).
- `home.play.p`, `checks.intro`, `pics.intro`, `src.intro`: reworded for the manifest's `strings_changed` ("from the bridges", "the eleven scripts behind the rows", "the twelve of the bridges", "the paper read whole for the bridges"); *The bridges drilled* no longer named on Verifiche and Figure.
- `method.2`: "del pacchetto" → "dello studio dei ponti".
- `about.reads.p`: "con lo studio Music on the labels integrato" → "che comprendono lo studio Music on the labels" (the provenance stays, in the narrator's words, on Il metodo).
- `about.notthere.p`: "le trentasei righe proposte" → "le trentasei righe dei ponti".

Of the manifest's 29 `strings_changed`, five are in my 220 (release.stamp, home.play.p, checks.intro, pics.intro, src.intro) and are in the edits file; the other 24 (home.more.bridges, b.*, blk.from.research.p, blk.research.p, atl.proposed, atl.home.proposed, std.bridge.proposed, checks.r37*, pics.r37*, dict.paper*, i8.p, i9.p, method.4, about.italian.p) are the first pass's `strings_new`, IT-2's ids. Of the 18 `strings_it_to_reword`, two are mine (release.stamp, checks.intro), both in the edits file. Of the 46 `racconto_to_reword`, one is mine (r:page:sounds), in the edits file, plus the two remarks (page:about, page:dictionary) and the home.

Every edited narration stays inside its range of `MANIFEST.json` (page:home 178/120–180, page:sounds 152/100–160, page:about 139/80–140, page:dictionary 149/100–160, row:INP-130 136/60–140); the placeholders of the edited strings match the manifest's English (`{release}`, `{dateWords}`, `{atlas}`).

## Checks run

`check_IT-1_pass2.py` on the three files: 120 titoli items, every one a target of the manifest, none twice, every length inside the manifest's limit, no final period on the 93 titles, claims, headings, clip lines, lens terms and check lines; the 5 + 8 edits inside their ranges; **0 banned words and 0 process words** in titoli_r1.json, pass2_edits_r1.json and (outside the two provenance sentences of Il metodo, where the brief allows them) pass2_strings_new_r1.json; the three JSON files load. A residual scan of my whole half after the edits (60 narrations, 220 strings) finds no process word left and *The bridges drilled* named only in `page:sources`, `about.credit.study` (Fonti, Il metodo).

## Every edit, old → new

### racconto `page:home` (179 → 178 words)

**old**

> La musica è vincolata da leggi severe quanto quelle della fisica, eppure, quando la si ascolta, accade qualcosa che le leggi non sembrano contenere. Questo sito affronta quella domanda con il metodo dell'Atlante: ogni enunciato viene ordinato secondo ciò che lo stabilisce. La struttura è calcolata sulle etichette, in interi, frazioni e nell'anello ℤ[ζ₁₂]: la serie armonica di una corda, il circolo delle dodici classi di altezza, i due gruppi diedrali che muovono gli accordi, il toro delle triadi, il nastro degli accordi di due note, le scale massimamente uniformi che sono anche ritmi, la frazione continua dietro il temperamento a dodici note, la trasformata di Fourier di un accordo. La risposta di chi ascolta è misurata, non dedotta: entra come dato in ingresso con la sua fonte, e due di quei dati dicono che una parte di essa è culturale. Fra le due sta una lettura nostra, con la sua ragione, e due domande restano aperte.
>
> Vi accompagno di pagina in pagina: otto sezioni, i ponti sondati, un dizionario, le verifiche, le figure, i suoni e le fonti.

**new**

> La musica è vincolata da leggi severe quanto quelle della fisica, eppure, quando la si ascolta, accade qualcosa che le leggi non sembrano contenere. Questo sito affronta quella domanda con il metodo dell'Atlante: ogni enunciato viene ordinato secondo ciò che lo stabilisce. La struttura è calcolata sulle etichette, in interi, frazioni e nell'anello ℤ[ζ₁₂]: la serie armonica di una corda, il circolo delle dodici classi di altezza, i due gruppi diedrali che muovono gli accordi, il toro delle triadi, il nastro degli accordi di due note, le scale massimamente uniformi che sono anche ritmi, la frazione continua dietro il temperamento a dodici note, la trasformata di Fourier di un accordo. La risposta di chi ascolta è misurata, non dedotta: entra come dato in ingresso con la sua fonte, e due di quei dati dicono che una parte di essa è culturale. Fra le due sta una lettura nostra, con la sua ragione, e due domande restano aperte.
>
> Vi accompagno di pagina in pagina: otto sezioni, i ponti, un dizionario, le verifiche, le figure, i suoni e le fonti.

### racconto `page:sounds` (159 → 152 words)

**old**

> Questa pagina ha i ventun clip scritti dalle verifiche e nove strumenti che suonano i numeri dell'Atlante. I clip sono delle verifiche: dodici li scrive music_sound.py dai propri numeri e li misura a ritroso con il gruppo mu·AUDIO; i nove dello studio dei ponti li scrivono e li misurano i suoi script, e le righe che illustrano sono proposte. Si va dal clip 01, i modi della catena, al clip 21, due anelli su 110 Hz. I timbri e i tempi sono scelte fatte per l'ascolto, non stimoli di un esperimento.
>
> Il sintetizzatore è un solo file di JavaScript senza librerie: oscillatori sinusoidali sommati come parziali, dissolvenze a coseno rialzato di 20 ms, un livello generale di −6 dBFS, e il suono parte al vostro primo clic. Sotto ogni strumento una riga dice da dove vengono i suoi numeri. Un test in Chromium esegue fuori linea il motore della pagina e lo misura per FFT: 37 asserzioni, tutte riuscite.

**new**

> Questa pagina ha i ventun clip scritti dalle verifiche e nove strumenti che suonano i numeri dell'Atlante. I clip sono delle verifiche: dodici li scrive music_sound.py dai propri numeri e li misura a ritroso con il gruppo mu·AUDIO; i nove dello studio dei ponti li scrivono e li misurano i suoi script. Si va dal clip 01, i modi della catena, al clip 21, due anelli su 110 Hz. I timbri e i tempi sono scelte fatte per l'ascolto, non stimoli di un esperimento.
>
> Il sintetizzatore è un solo file di JavaScript senza librerie: oscillatori sinusoidali sommati come parziali, dissolvenze a coseno rialzato di 20 ms, un livello generale di −6 dBFS, e il suono parte al vostro primo clic. Sotto ogni strumento una riga dice da dove vengono i suoi numeri. Un test in Chromium esegue fuori linea il motore della pagina e lo misura per FFT: 37 asserzioni, tutte riuscite.

### racconto `page:about` (139 → 139 words)

**old**

> Ogni frase del sito ha una fonte, una scheda dell'Atlante, un inventario, i file propri di uno studio o la tabella delle stringhe, e il generatore la verifica contro quella fonte. Viene per primo ciò che uno script ha eseguito, e nulla si afferma oltre; i risultati negativi restano, un dato in ingresso resta tale. Ogni riga si legge in quattro registri, Racconto, Ricerca, Atlas e Standard, e porta il bollino di stato dell'Atlante: calcolato, standard ricalcolato, dato in ingresso, nostra lettura, aperto; una riga proposta porta anche il contorno che lo dice. Il sito è autonomo e si collega all'Atlante una volta sola, alla sua pagina Music. L'Atlante, il sito e il suo generatore sono sotto la licenza PolyForm Noncommercial 1.0.0. Le pagine italiane non sono una traduzione: le racconto io, con le schede dell'Atlante in inglese accanto.

**new**

> Ogni frase del sito ha una fonte, una scheda dell'Atlante, un inventario, i file di uno studio o la tabella delle stringhe, e il generatore la verifica contro quella fonte. Viene per primo ciò che uno script ha eseguito, e nulla si afferma oltre; i risultati negativi restano, un dato in ingresso resta tale. Ogni riga si legge in quattro registri, Racconto, Ricerca, Atlas e Standard, e porta il bollino di stato dell'Atlante: calcolato, standard ricalcolato, dato in ingresso, nostra lettura, aperto. Il sito è autonomo e si collega all'Atlante una volta sola, alla sua pagina Music. L'Atlante, il sito e il suo generatore sono sotto la licenza PolyForm Noncommercial 1.0.0. Le pagine italiane non sono una traduzione: le racconto io, e le schede dell'Atlante restano in inglese nei registri Ricerca, Atlas e Standard, fuori dal filo della lettura.

### racconto `page:dictionary` (157 → 149 words)

**old**

> Il dizionario è la lente Musica dell'Atlante: trentaquattro voci, un termine dell'Atlante accanto a un termine della musica, con il grado della corrispondenza e la sua ragione fra parentesi. Esatto, sedici voci: i due lati sono un solo enunciato, come le maschere di dodici bit che sono gli insiemi di classi di altezza. Esatto con un dato in ingresso, una voce: l'operatore d'onda, con la velocità del mezzo misurata. Parziale, sette: una stessa costruzione su un altro gruppo o oggetto, come i modi di Walsh e la base di Fourier dell'anello. Analogia, due: somiglianza senza una mappa, come l'orologio ℤ₈ e l'orologio ℤ₁₂. Nessuno, otto: nessuna controparte dall'altra parte, come il prodotto della regola dei bit.
>
> La tabella si legge colonna per colonna: termine dell'Atlante, termine musicale, grado, evidenza, righe. Sotto, le letture accoppiano una riga alla voce che la legge, per evidenza, testo o id, raggruppate per la pagina in cui la riga è di casa.

**new**

> Il dizionario è la lente Musica dell'Atlante: trentaquattro voci, un termine dell'Atlante accanto a un termine della musica, con il grado della corrispondenza e la sua ragione fra parentesi. Esatto, sedici voci: i due lati sono un solo enunciato, come le maschere di dodici bit. Esatto con un dato in ingresso, una voce: l'operatore d'onda, con la velocità del mezzo misurata. Parziale, sette: una stessa costruzione su un altro gruppo o oggetto, come i modi di Walsh e la base di Fourier dell'anello. Analogia, due: somiglianza senza una mappa, come l'orologio ℤ₈ e l'orologio ℤ₁₂. Nessuno, otto: nessuna controparte dall'altra parte, come il prodotto della regola dei bit.
>
> La tabella si legge per colonne: il termine musicale in italiano, il grado, l'evidenza, le righe; il termine dell'Atlante e quello inglese stanno nella scheda a scomparsa di ogni riga. Sotto, le letture accoppiano una riga alla voce che la legge.

### racconto `row:INP-130` (137 → 136 words)

**old**

> La riga INP-130 è un dato in ingresso: ascoltare musica libera dopamina endogena nello striato al picco dell'eccitazione emotiva, misurata con la PET al [¹¹C]raclopride, e la fMRI sugli stessi ascoltatori e sulla stessa musica mostra il caudato più coinvolto durante l'anticipazione e il nucleus accumbens durante l'esperienza del picco (Salimpoor, Benovoy, Larcher, Dagher e Zatorre, Nature Neuroscience 14 (2011) 257); gli autori concludono che l'anticipazione di una ricompensa astratta può liberare dopamina lungo una via anatomica distinta da quella del piacere stesso. Nessun calcolo sulle etichette lo fornisce; la riga non ha verifiche. Lo studio lo affianca, a livello di enunciato, alla proposta di Koelsch, Vuust e Friston, che lega previsione e ricompensa come una congettura, e alla teoria dell'aspettativa di Huron, citata dalla sua scheda: è il dato su cui poggia la lettura di MUS-013.

**new**

> La riga INP-130 è un dato in ingresso: ascoltare musica libera dopamina endogena nello striato al picco dell'eccitazione emotiva, misurata con la PET al [¹¹C]raclopride, e la fMRI sugli stessi ascoltatori e sulla stessa musica mostra il caudato più coinvolto durante l'anticipazione e il nucleus accumbens durante l'esperienza del picco (Salimpoor, Benovoy, Larcher, Dagher e Zatorre, Nature Neuroscience 14 (2011) 257); gli autori concludono che l'anticipazione di una ricompensa astratta può liberare dopamina lungo una via anatomica distinta da quella del piacere stesso. Nessun calcolo sulle etichette lo fornisce; la riga non ha verifiche. Lo studio lo affianca, a livello di enunciato, all'ipotesi di Koelsch, Vuust e Friston, che lega previsione e ricompensa come una congettura, e alla teoria dell'aspettativa di Huron, citata dalla sua scheda: è il dato su cui poggia la lettura di MUS-013.

### string `release.stamp` (4 → 4 words)

**old**

> Edizione {release} · {dateWords}

**new**

> Edizione {release} · {dateWords}

### string `home.play.p` (71 → 71 words)

**old**

> La pagina Suoni ha i ventun clip scritti dalle verifiche e nove strumenti che suonano nel vostro browser i numeri stessi dell'Atlante: accordi sull'orologio, passeggiate sul toro delle triadi, ritmi euclidei, i modi di una catena e di un anello, la curva di dissonanza e i commi; e, dallo studio dei ponti, il Tonnetz come griglia del teorema cinese del resto, i due anelli accanto alla campana e le serie panintervallari.

**new**

> La pagina Suoni ha i ventun clip scritti dalle verifiche e nove strumenti che suonano nel vostro browser i numeri stessi dell'Atlante: accordi sull'orologio, passeggiate sul toro delle triadi, ritmi euclidei, i modi di una catena e di un anello, la curva di dissonanza e i commi; e, dalla pagina dei ponti, il Tonnetz come griglia del teorema cinese del resto, i due anelli accanto alla campana e le serie panintervallari.

### string `checks.intro` (45 → 33 words)

**old**

> I due script dello studio Music on the labels e i nove del pacchetto di The bridges drilled: che cosa calcola ciascuno, i suoi gruppi con una riga per verifica come la stampa il log, i controlli che devono fallire e le registrazioni delle esecuzioni.

**new**

> Gli undici script dietro le righe: che cosa calcola ciascuno, i suoi gruppi con una riga per verifica come la stampa il log, i controlli che devono fallire e le registrazioni delle esecuzioni.

### string `pics.intro` (35 → 32 words)

**old**

> Le tredici figure dello studio Music on the labels e le dodici di The bridges drilled, ciascuna disegnata dai file di dati delle verifiche stesse e mostrata con la sua didascalia e i suoi dati.

**new**

> Le tredici figure di Music on the labels e le dodici dei ponti, ciascuna disegnata dai file di dati delle verifiche stesse e mostrata con la sua didascalia e i suoi dati.

### string `src.intro` (44 → 42 words)

**old**

> Le fonti che i due studi citano, come i loro riferimenti le danno, l'articolo che lo studio dei ponti legge per intero, e ogni fonte che il lettore della letteratura del primo studio ha prelevato, con il collegamento e ciò che ne è tornato.

**new**

> Le fonti che i due studi citano, come i loro riferimenti le danno, l'articolo letto per intero per i ponti, e ogni fonte che il lettore della letteratura del primo studio ha prelevato, con il collegamento e ciò che ne è tornato.

### string `method.2` (81 → 83 words)

**old**

> Qui le schede sono le righe dell'Atlante, i suoi testi, le registrazioni delle verifiche e delle esecuzioni, la sua lente Musica e le sue letture; gli inventari sono gli indici delle figure e dei clip dei due studi; i file propri degli studi sono le pagine dei due studi, i file ROWS.md, BRIDGE.md e BRIDGES_DRILLED.md del pacchetto, gli enunciati degli script e i loro log; la tabella delle stringhe è content/strings.json, ogni stringa con il suo id e il suo perché.

**new**

> Qui le schede sono le righe dell'Atlante, i suoi testi, le registrazioni delle verifiche e delle esecuzioni, la sua lente Musica e le sue letture; gli inventari sono gli indici delle figure e dei clip dei due studi; i file propri degli studi sono le pagine dei due studi, i file ROWS.md, BRIDGE.md e BRIDGES_DRILLED.md dello studio dei ponti, gli enunciati degli script e i loro log; la tabella delle stringhe è content/strings.json, ogni stringa con il suo id e il suo perché.

### string `about.reads.p` (113 → 113 words)

**old**

> Le tavole del Cascade Atlas {atlas}, con lo studio Music on the labels integrato: le righe MUS-001 … MUS-013 e INP-124 … INP-130 e le righe dell'Atlante stesso che la pagina Music racconta, i loro testi di ricerca e per chi impara, la pagina Music con le sue otto catene e le nove aperture, lo stato di ogni riga, la lente Musica e le sue letture, le registrazioni dei due script di verifica e delle loro esecuzioni; e i file propri di quello studio: lo studio Music on the labels, le sue tredici figure con il loro indice, i dati delle figure, i dodici clip con il loro indice e i due log.

**new**

> Le tavole del Cascade Atlas {atlas}, che comprendono lo studio Music on the labels: le righe MUS-001 … MUS-013 e INP-124 … INP-130 e le righe dell'Atlante stesso che la pagina Music racconta, i loro testi di ricerca e per chi impara, la pagina Music con le sue otto catene e le nove aperture, lo stato di ogni riga, la lente Musica e le sue letture, le registrazioni dei due script di verifica e delle loro esecuzioni; e i file propri di quello studio: lo studio Music on the labels, le sue tredici figure con il loro indice, i dati delle figure, i dodici clip con il loro indice e i due log.

### string `about.notthere.p` (62 → 63 words)

**old**

> I testi per chi impara delle righe musicali non sono ancora scritti, né quelli delle aperture, né quelli delle trentasei righe proposte: nelle pagine inglesi il registro Racconto dice quelle righe con le parole degli studi, e lo dichiara; in queste le racconto io. Le tabelle degli studi, le loro appendici e l'opinione in prima persona del primo studio restano negli studi.

**new**

> I testi per chi impara delle righe musicali non sono ancora scritti, né quelli delle aperture, né quelli delle trentasei righe dei ponti: nelle pagine inglesi il registro Racconto dice quelle righe con le parole degli studi, e lo dichiara; in queste le racconto io. Le tabelle degli studi, le loro appendici e l'opinione in prima persona del primo studio restano negli studi.
