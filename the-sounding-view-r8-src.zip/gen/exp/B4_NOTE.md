# B4 note: what could not be placed

Four experiments built: alfven, layers, harmonics, streams (js, strings, data, spec, harness, screenshots at 1280 and 390; zero console errors).

- alfven: the Atlas has no gas sound speed, so the fast and slow magnetosonic curves between 0 and 90 degrees are not drawn (said on the page); the fast partial equals the Alfven pitch. `alfven_slope` is in omega_ce per omega_pe/c: v_A = 0.0117 c, not 0.0233 c. Mapping 110 Hz at k = 0.1 (spec), not 8 000 Hz.
- layers: no friction rate in the data, so only the MUS-153 sentence is shown; the warm triplet shares are only in a log line (not an array): 'no data here'. omega_ce <-> 2 000 Hz instead of 8 000 so the octave stays audible. C_eq11 (the printed, wrong eq. 11) is not drawn.
- harmonics: no harmonic weights in bernstein.json: bars not drawn (chord is unweighted). `damping.lor` is a copy of the tan grid, not rates; the Lorentzian is one point (tan = 1/40). Maxwellian whistler/ICW points below k = 0.18 are not certified and left out by the writer.
- streams: no arrays for the Lorentzian beams (MUS-120, 121) and no critical jump for eps = 1/8 or exact fluid edges; MUS-107 is not in the Atlas rows I read. The swell follows the picture's time, not the real e-folding.
- Unit conventions I inferred from the writers' code, not docstrings: the keys of `thresholds.computed` (kappa/beta/gamma), Y = Omega/omega in `side`, sin theta for the three R curves (stated in the log).
