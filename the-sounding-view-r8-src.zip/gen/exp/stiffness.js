// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// stiffness.js — The medium with two stiffnesses (MUS-050 … 055, MUS-075; clip 22)
(function () {
  'use strict';
  window.SDV_EXP = window.SDV_EXP || {};
  window.SDV_EXP['stiffness'] = { mount: function (root, data, S, kit) {
    var P = 'exp.stiffness.', el = kit.el, TAU = Math.PI * 2;
    var reduce = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    var F0 = data.unit.F_L_hz;                       // the stiffer spring's mode 2 is 440 Hz
    var PIC_HZ = 0.5, SLOW = Math.round(F0 / PIC_HZ); // the picture turns at 0.5 Hz where the sound is at 440 Hz
    var st = { kappa: 1, mu: 1 / 3, preset: 'poisson', branch: 'sound', paused: reduce, on: false, hear: 'sound', theta: 0, N: 12, t: 0 };
    root.classList.add('half');

    function cv(parent, a, m) { var d = el('div', { class: 'exp-cvwrap' }); parent.appendChild(d); return kit.canvas(d, a, m); }
    function txt(ctx, s, x, y, color, align, size) { ctx.fillStyle = color || kit.muted(); ctx.textAlign = align || 'left'; ctx.font = (size || 11) + 'px system-ui, sans-serif'; ctx.fillText(s, x, y); }
    function freq(spring, k) { return F0 * Math.sqrt(spring) * data.omega[k]; }    // data.omega[k] = sqrt(lambda_k): the Atlas's eigenvalues
    function setRatio(r) { if (r >= 1) { st.kappa = 1; st.mu = 1 / r; } else { st.kappa = r; st.mu = 1; } }

    // ---------------------------------------------------------------- (a) the lattice
    var pa = kit.panel_(root, P + 'panel.lattice', S, 'span');
    var lat = cv(pa, 0.5, 340);
    var ctlA = kit.controls(pa), presetBtns = {};
    [['air', 1, 0], ['mac', 0, 1], ['one', 1, 1], ['poisson', 1, 1 / 3]].forEach(function (p) {
      var b = kit.button(ctlA, P + 'preset.' + p[0], S, function () { st.kappa = p[1]; st.mu = p[2]; st.preset = p[0]; slider.set(ratioNow()); sync(); restrike(); });
      presetBtns[p[0]] = b;
    });
    function ratioNow() { var r = st.mu > 0 ? st.kappa / st.mu : 100; return kit.clamp(r, 0.01, 100); }
    var slider = kit.slider(ctlA, { S: S, id: P + 'ratio', min: 0.01, max: 100, value: 3, log: true, fmt: function (v) { return v < 1 ? '1/' + kit.num(1 / v, 1) : kit.num(v, 1); },
      onchange: function (v) { setRatio(v); st.preset = ''; sync(); restrike(); } });
    var seg = kit.seg(ctlA, { S: S, ids: [P + 'branch.sound', P + 'branch.shear'], values: ['sound', 'shear'], value: 'sound', onchange: function (v) { st.branch = v; } });
    var pauseB = kit.button(ctlA, 'exp.common.pause', S, function () { st.paused = !st.paused; pauseB.setAttribute('aria-pressed', String(st.paused)); });
    pauseB.setAttribute('aria-pressed', String(st.paused));
    var rdA = kit.readout(pa), mini = null, miniWrap = el('div', { class: 'exp-mini' }), miniLine;
    pa.appendChild(miniWrap);
    mini = cv(miniWrap, 0.28, 90);
    miniLine = el('p', { class: 'exp-line' }); miniWrap.appendChild(miniLine);
    miniLine.appendChild(el('span', { 'data-s': P + 'negbulk', text: S(P + 'negbulk') })); miniLine.appendChild(document.createTextNode(' ')); miniLine.appendChild(el('code', { text: 'MUS-051' })); miniLine.appendChild(document.createTextNode(' ')); miniLine.appendChild(kit.chip('computed'));
    kit.line(pa, P + 'lattice.note', S);
    var rdSlow = kit.readout(pa);
    rdSlow.textContent = S('exp.common.slowed').replace('{n}', String(SLOW));

    function active() { return st.branch === 'sound' ? st.kappa > 1e-9 : st.mu > 1e-9; }
    function drawLattice() {
      var ctx = lat.ctx, w = lat.w, h = lat.h, nx = 12, ny = 8, cs = Math.min((w - 40) / (nx - 1), (h - 30) / (ny - 1)), ox = (w - cs * (nx - 1)) / 2, oy = h - (h - cs * (ny - 1)) / 2;
      ctx.clearRect(0, 0, w, h);
      var spring = st.branch === 'sound' ? st.kappa : st.mu, on = active(), kk = TAU * 2 / nx, wt = on ? TAU * PIC_HZ * Math.sqrt(spring * data.lambda[2]) * st.t : 0, A = on ? 0.3 : 0;
      var ux = function (i) { return st.branch === 'sound' ? A * Math.cos(kk * i - wt) : 0; };
      var uy = function (i) { return st.branch === 'shear' ? A * Math.cos(kk * i - wt) : 0; };
      var X = function (i, j) { return ox + (i + ux(i)) * cs; }, Y = function (i, j) { return oy - (j + uy(i)) * cs; };
      var i, j;
      for (i = 0; i < nx - 1; i++) for (j = 0; j < ny - 1; j++) {
        var ph = kk * (i + 0.5) - wt, v = on ? -Math.sin(ph) : 0;
        if (st.branch === 'sound') { ctx.fillStyle = kit.cmap(v); ctx.beginPath(); ctx.moveTo(X(i, j), Y(i, j)); ctx.lineTo(X(i + 1, j), Y(i + 1, j)); ctx.lineTo(X(i + 1, j + 1), Y(i + 1, j + 1)); ctx.lineTo(X(i, j + 1), Y(i, j + 1)); ctx.closePath(); ctx.fill(); }
        else if (on && Math.abs(v) > 0.08) { kit.disc(ctx, ox + (i + 0.5) * cs, oy - (j + 0.5 + uy(i + 0.5)) * cs, 0.42 * cs * Math.abs(v), v > 0 ? 1 : -1, v > 0 ? kit.red : kit.blue); }
      }
      ctx.strokeStyle = kit.muted(); ctx.lineWidth = 0.8; ctx.globalAlpha = 0.6;
      for (j = 0; j < ny; j++) { ctx.beginPath(); for (i = 0; i < nx; i++) { if (i) ctx.lineTo(X(i, j), Y(i, j)); else ctx.moveTo(X(i, j), Y(i, j)); } ctx.stroke(); }
      for (i = 0; i < nx; i++) { ctx.beginPath(); for (j = 0; j < ny; j++) { if (j) ctx.lineTo(X(i, j), Y(i, j)); else ctx.moveTo(X(i, j), Y(i, j)); } ctx.stroke(); }
      ctx.globalAlpha = 1;
      for (i = 0; i < nx; i++) for (j = 0; j < ny; j++) {
        var x0 = ox + i * cs, y0 = oy - j * cs, x1 = X(i, j), y1 = Y(i, j);
        if (Math.hypot(x1 - x0, y1 - y0) > 3) kit.arrow(ctx, x0, y0, x1, y1, st.branch === 'sound' ? kit.blue : kit.red, 1);
        ctx.fillStyle = kit.ink(); ctx.beginPath(); ctx.arc(x1, y1, Math.max(2, cs * 0.07), 0, TAU); ctx.fill();
      }
      if (!on) { ctx.fillStyle = kit.panel(); ctx.globalAlpha = 0.85; ctx.fillRect(w / 2 - 70, h / 2 - 14, 140, 28); ctx.globalAlpha = 1; txt(ctx, S(P + 'zero'), w / 2, h / 2 + 5, kit.accent(), 'center', 14); }
    }
    function drawMini() {
      var show = st.kappa > 0 && st.mu > 0 && Math.abs(Math.log(st.kappa / st.mu)) < 0.12;
      miniWrap.style.display = show ? '' : 'none'; if (!show) return;
      var ctx = mini.ctx, w = mini.w, h = mini.h, p = Math.sin(TAU * 0.5 * st.t), s = h * 0.34 * (1 + 0.3 * p), cx = w / 2, cy = h / 2;
      ctx.clearRect(0, 0, w, h);
      ctx.fillStyle = kit.cmap(0.35 * p + 0.15); ctx.strokeStyle = kit.ink(); ctx.lineWidth = 1.5; ctx.fillRect(cx - s, cy - s, 2 * s, 2 * s); ctx.strokeRect(cx - s, cy - s, 2 * s, 2 * s);
      var L = 14 * Math.max(0, p), g = h * 0.5;
      kit.arrow(ctx, cx - s - g - 4, cy, cx - s - g + L, cy, kit.red, 1.6); kit.arrow(ctx, cx + s + g + 4, cy, cx + s + g - L, cy, kit.red, 1.6);
      kit.arrow(ctx, cx, cy - s - g - 4, cx, cy - s - g + L, kit.red, 1.6); kit.arrow(ctx, cx, cy + s + g + 4, cx, cy + s + g - L, kit.red, 1.6);
    }
    function readA() {
      var r = st.mu > 1e-9 ? Math.sqrt(st.kappa / st.mu) : Infinity, rr = st.kappa > 1e-9 ? Math.sqrt(st.mu / st.kappa) : Infinity;
      rdA.textContent = 'κ/μ = ' + (st.mu > 1e-9 ? kit.num(st.kappa / st.mu, 2) : '∞') + '   ·   c_S/c_P = ' + (st.kappa > 1e-9 ? kit.num(rr, 3) : '∞') + (Math.abs(rr - 1 / Math.sqrt(3)) < 0.01 ? '  (1/√3)' : '');
    }

    // ---------------------------------------------------------------- (b) two branches, one dispersion
    var pb = kit.panel_(root, P + 'panel.dispersion', S);
    var dc = cv(pb, 0.75, 300);
    var rdB = kit.readout(pb);
    function branchPts(spring) { return data.omega.map(function (o, k) { return [k, F0 * Math.sqrt(spring) * o]; }); }
    function drawDisp() {
      var ctx = dc.ctx, w = dc.w, h = dc.h, box = { l: 44, t: 12, r: w - 12, b: h - 34 };
      ctx.clearRect(0, 0, w, h);
      var ax = kit.axes(ctx, box, { xmin: 0, xmax: 6, ymin: 0, ymax: 900, xticks: [0, 1, 2, 3, 4, 5, 6], yticks: [0, 220, 440, 660, 880], xlabel: S(P + 'ax.k'), ylabel: S('exp.common.hz') });
      kit.curve(ctx, branchPts(st.kappa), ax.x, ax.y, kit.blue, 2); kit.curve(ctx, branchPts(st.mu), ax.x, ax.y, kit.red, 2);
      [[st.kappa, kit.blue], [st.mu, kit.red]].forEach(function (b) { for (var k = 1; k <= 6; k++) { ctx.fillStyle = b[1]; ctx.beginPath(); ctx.arc(ax.x(k), ax.y(freq(b[0], k)), 3.5, 0, TAU); ctx.fill(); } });
      txt(ctx, S(P + 'branch.sound'), box.l + 8, box.t + 14, kit.blue, 'left', 12); txt(ctx, S(P + 'branch.shear'), box.l + 8, box.t + 28, kit.red, 'left', 12);
      if (st.kappa > 1e-9 && st.mu > 1e-9) { var f4 = freq(st.mu, 4), f2 = freq(st.kappa, 2); if (Math.abs(f4 - f2) < 1) { ctx.strokeStyle = kit.accent(); ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(ax.x(3), ax.y(f2), 8, 0, TAU); ctx.stroke(); } }
    }
    function readB() {
      var a = freq(st.kappa, 2), b = freq(st.mu, 4);
      rdB.textContent = 'f₂(sound) = ' + kit.num(a, 1) + ' Hz   ·   f₄(shear) = ' + kit.num(b, 1) + ' Hz' + '';
    }

    // ---------------------------------------------------------------- (c) the duality dial
    var pc = kit.panel_(root, P + 'panel.dial', S);
    var cc = cv(pc, 0.62, 260), ctlC = kit.controls(pc);
    kit.slider(ctlC, { S: S, id: P + 'dial', min: 0, max: 90, step: 1, value: 0, fmt: function (v) { return Math.round(v) + '°'; }, onchange: function (v) { st.theta = v * Math.PI / 180; readC(); } });
    var rdC = kit.readout(pc), grades = el('div', { class: 'exp-grades' });
    kit.grade(grades, 'exact', 'exp.common.grade.exact', S); grades.lastChild.appendChild(el('span', { 'data-s': P + 'grade.shear', text: ' ' + S(P + 'grade.shear') }));
    kit.grade(grades, 'none', 'exp.common.grade.none', S); grades.lastChild.appendChild(el('span', { 'data-s': P + 'grade.pressure', text: ' ' + S(P + 'grade.pressure') }));
    pc.appendChild(grades); kit.line(pc, P + 'dial.fits', S); kit.line(pc, P + 'dial.sentence', S);
    function readC() { var c = Math.cos(st.theta), s = Math.sin(st.theta); rdC.textContent = 'E = ' + kit.num(c, 2) + ' · twist + ' + kit.num(s, 2) + ' · velocity   ·   B = ' + kit.num(c, 2) + ' · velocity − ' + kit.num(s, 2) + ' · twist'; }
    function drawDial() {
      var ctx = cc.ctx, w = cc.w, h = cc.h, c = Math.cos(st.theta), s = Math.sin(st.theta), wt = TAU * PIC_HZ * st.t;
      ctx.clearRect(0, 0, w, h);
      var mid = h * 0.36, amp = h * 0.26, x0 = 20, x1 = w - 20, i, n = 7;
      ctx.strokeStyle = kit.muted(); ctx.lineWidth = 0.8; ctx.beginPath(); ctx.moveTo(x0, mid); ctx.lineTo(x1, mid); ctx.stroke();
      var T = function (x) { return Math.sin(TAU * 1.5 * x - wt); }, V = T;     // twist and velocity of the shear wave, in step
      var E = function (x) { return c * T(x) + s * V(x); }, B = function (x) { return c * V(x) - s * T(x); };
      [[E, kit.blue], [B, kit.red]].forEach(function (f) { ctx.strokeStyle = f[1]; ctx.lineWidth = 2; ctx.beginPath(); for (i = 0; i <= 120; i++) { var u = i / 120, xx = x0 + u * (x1 - x0), yy = mid - amp * f[0](u); if (i) ctx.lineTo(xx, yy); else ctx.moveTo(xx, yy); } ctx.stroke(); });
      var r1 = h * 0.62, r2 = h * 0.86;
      txt(ctx, S(P + 'glyph.twist'), x0, r1 - 24, kit.muted(), 'left', 11); txt(ctx, S(P + 'glyph.velocity'), x0, r2 - 24, kit.muted(), 'left', 11);
      for (i = 0; i < n; i++) {
        var u = (i + 0.5) / n, xx = x0 + u * (x1 - x0), tv = T(u);
        kit.disc(ctx, xx, r1, Math.max(2, 11 * Math.abs(tv)), tv >= 0 ? 1 : -1, tv >= 0 ? kit.red : kit.blue);
        kit.arrow(ctx, xx, r2 + 8 * tv, xx, r2 - 8 * tv, tv >= 0 ? kit.red : kit.blue, 1.6);
        ctx.globalAlpha = c * c; txt(ctx, S(P + 'sym.E'), xx + 14, r1 + 4, kit.blue, 'left', 13); ctx.globalAlpha = s * s; txt(ctx, S(P + 'sym.H'), xx + 14, r1 + 4, kit.red, 'left', 13);
        ctx.globalAlpha = c * c; txt(ctx, S(P + 'sym.B'), xx + 8, r2 + 4, kit.red, 'left', 13); ctx.globalAlpha = s * s; txt(ctx, S(P + 'sym.E'), xx + 8, r2 + 4, kit.blue, 'left', 13); ctx.globalAlpha = 1;
      }
    }

    // ---------------------------------------------------------------- (d) the ring tends to the string
    var pd = kit.panel_(root, P + 'panel.string', S);
    var sc = cv(pd, 0.55, 220), ctlD = kit.controls(pd);
    kit.slider(ctlD, { S: S, id: P + 'N', min: 12, max: 96, step: 1, value: 12, fmt: function (v) { return String(Math.round(v)); }, onchange: function (v) { st.N = Math.round(v); readD(); drawString(); restrike(); } });
    var rdD = kit.readout(pd); kit.line(pd, P + 'string.stable', S);
    function cents(k, N) { var wk = 2 * Math.sin(Math.PI * k / N), lim = k * TAU / N; return 1200 * Math.log(wk / lim) / Math.LN2; }
    function readD() { var a = []; for (var k = 2; k <= 6; k++) a.push(k + ': ' + kit.num(cents(k, st.N), 1)); rdD.textContent = 'N = ' + st.N + '   ·   ' + S('exp.common.cents') + '   ' + a.join('   '); }
    function drawString() {
      var ctx = sc.ctx, w = sc.w, h = sc.h, box = { l: 44, t: 12, r: w - 12, b: h - 34 };
      ctx.clearRect(0, 0, w, h);
      var ax = kit.axes(ctx, box, { xmin: 1.5, xmax: 6.5, ymin: -800, ymax: 0, xticks: [2, 3, 4, 5, 6], yticks: [-800, -400, 0], xlabel: S(P + 'ax.k'), ylabel: S('exp.common.cents') });
      var k, bw = (box.r - box.l) / 5 * 0.5;
      for (k = 2; k <= 6; k++) { var cv = kit.clamp(cents(k, st.N), -800, 0); ctx.fillStyle = kit.accent(); ctx.fillRect(ax.x(k) - bw / 2, ax.y(0), bw, ax.y(cv) - ax.y(0)); }
    }

    // ---------------------------------------------------------------- hear
    var ph = kit.panel_(root, P + 'panel.hear', S, 'span'), ctlH = kit.controls(ph), timer = null;
    var playB = kit.button(ctlH, 'exp.common.play', S, function () { st.on = !st.on; setPlay(); if (st.on) strike(); });
    function setPlay() { playB.textContent = S(st.on ? 'exp.common.mute' : 'exp.common.play'); playB.setAttribute('data-s', st.on ? 'exp.common.mute' : 'exp.common.play'); }
    kit.button(ctlH, 'exp.common.strike', S, function () { strike(); });
    kit.seg(ctlH, { S: S, ids: [P + 'hear.sound', P + 'hear.shear', P + 'hear.both'], values: ['sound', 'shear', 'both'], value: 'sound', onchange: function (v) { st.hear = v; restrike(); } });
    var rdH = kit.readout(ph); kit.line(ph, P + 'hear.line', S);
    function parts(spring, g) {
      var f1 = freq(spring, 1), out = [];
      if (spring <= 1e-9) return out;
      for (var k = 1; k <= 6; k++) { var f = freq(spring, k); out.push({ f: f, a: data.amp[k - 1] * g, decay: Math.min(4, data.tau_s * Math.sqrt(f1 / f)) }); }
      return out;
    }
    function strike() {
      if (!kit.audio()) { rdH.textContent = S('exp.common.noaudio'); return; }
      var g = st.hear === 'both' ? 0.6 : 1, all = [];
      if (st.hear !== 'shear') all = all.concat(parts(st.kappa, 1));
      if (st.hear !== 'sound') all = all.concat(parts(st.mu, 1));
      if (!all.length) { rdH.textContent = S(P + 'silent'); return; }
      kit.strike(all, g);
      rdH.textContent = all.map(function (p) { return kit.num(p.f, 0); }).join(' · ') + ' Hz';
    }
    function restrike() { if (!st.on) return; clearTimeout(timer); timer = setTimeout(strike, 250); }

    function sync() {
      Object.keys(presetBtns).forEach(function (k) { presetBtns[k].setAttribute('aria-pressed', String(st.preset === k)); presetBtns[k].style.borderWidth = st.preset === k ? '2.5px' : ''; });
      readA(); readB();
    }
    slider.set(3); sync(); readC(); readD(); setPlay();
    drawLattice(); drawMini(); drawDisp(); drawDial(); drawString();
    kit.loop(function (t, dt) { if (!st.paused) st.t += dt; drawLattice(); drawMini(); drawDisp(); drawDial(); drawString(); });
  } };
})();
