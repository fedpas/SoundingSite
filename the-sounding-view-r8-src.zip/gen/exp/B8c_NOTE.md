# B8c note: `dualcells`, four panels for the Tone chapter, under `duals`

Built: `dualcells.js` (393 lines), `dualcells.strings.json` (87 strings; rows MUS-240 … 244, MUS-238, 239, 002, 003, 025, SHP-004, SPR-003), `dualcells.data.json` (88 kB, `dual_cells.json` whole with the source line extended), `dualcells.spec.md` with its "as built" section, `_harness_dualcells.html` and the two screenshots. Console clean at 1280 and 390, and after clicking all 19 buttons and moving the 4 sliders to both ends.

## What the page draws
- **The tesseract and its cells**: the tesseract and the 16-cell turning together in 4D (double rotation, dropped to 3D, light perspective); a slider colours one of the eight cubic cells and marks the 16-cell's corner it stands for. The four ladders L₀ … L₃ with multiplicities and the shared parts A₁, A₂, A₃ as bands. Counts, ranks, Betti numbers, the 16-cell's spectra tested against the tesseract's L₃₋ₖ, the identity, and four strikes (vertex m/16, edge, square, 16-cell's vertex m/8).
- **The 600-cell and the 120-cell**: the 30-gon picture on the Coxeter plane coloured by ring, or turning in 4D; a corner and its 12 neighbours highlighted. The nine-level ladder (dim, χ(s), weight, cents) with the Plancherel line. The 120-cell on the same plane (1200 thin edges) and its ladder of every root of every factor coloured by field, with the certificate line. Three buttons: 600-cell, 120-cell, both in turn.
- **The column of octahedra**: the N = 6 column turning, coloured by sector (alike, or a third of a turn apart on each triangle); the bands with the chain dashed and the end modes' limit; the levels of N = 1 … 6 by sector; a 21-mode slider marking the eigenvalue on the bands; the N = 20 pluck curve with a cursor while the column sounds.
- **The π-flux**: four solids turning with the negative edges red; plain and frustrated ladders facing each other on √λ; the switching or its absence; A² = 3I for the cube.

## Mapping
f = 220 Hz × √λ/√2 for every button (the dual bells' mapping); decay 1.5 s; gains ≤ 0.28 in total per group. Slow-down of the pluck cursor 261×.

## Could not place, or with a caveat
- No eigenvectors in the data: the column's chosen mode is marked on the bands, not drawn as a shape; the sector colouring of the column is the ℤ₃ character, an illustration.
- Column levels carry no sector label: the page reads the sector from the multiplicity (odd → one symmetric level); checked offline against 4 − 4cos(πm/(N + 1)) for N = 1 … 6. If the data are re-pasted with sector labels, this rule should give way to them.
- Column per-mode weights are not in the data: the sector shares 1/3 and 2/3 split evenly (said in `hear`).
- The 9/2 limit is not a number in the data: the line is drawn at the mean of the N = 20 end modes and labelled with the row's words "end modes → 9/2".
- Flux solids have no coordinates in the data: written on the page in the data's numbering (verified offline: every data edge is a shortest pair).
- `cayley.cross`, `cayley.cell24`, the 120-cell's 4D corners, `poly`, `weight_factor`, per-root cents, `coxeter_plane.basis` and `simple_roots` are carried, not drawn.
- The cell is picked with a slider (1 … 8), not a seg, so that no string depends on the data's cell order.

## String ids (all `exp.dualcells.*`)
title, lead, see, hear, data, panel.tesseract, panel.icosian, panel.column, panel.flux, cv.tess, cv.c16, cv.proj, cv.L0, cv.L1, cv.L2, cv.L3, cv.A1, cv.A2, cv.A3, cv.lam, cell, b.vertex, b.edge, b.square, b.c16, rd.counts, rd.betti, ident, rd.c16, rd.eq, rd.neq, rd.cell, rd.strike, cap.tess, seg.plane, seg.turn, v600, b.c120, b.both, cv.c600, cv.c120, cv.irrep, cv.irrep0, cv.irreps, cv.irreps0, cv.w, cv.wroot, cv.cubic, rd.v600, rd.c600, plancherel, rd.cert, cap.icosian, seg.sym, seg.twist, mode, N, b.chain, cv.k, cv.sym, cv.tw, cv.chain, cv.end, cv.byN, cv.x, cv.t, cv.colsym, cv.coltw, rd.mode, rd.shares, rd.end, rd.levels, cap.column, sol.tetrahedron, sol.octahedron, sol.icosahedron, sol.cube, cv.plain, cv.signed, cv.signedc, cv.at, a2, rd.neg, rd.switch, rd.noswitch, rd.cents, cap.flux.
