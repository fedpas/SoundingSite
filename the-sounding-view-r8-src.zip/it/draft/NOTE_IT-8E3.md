# NOTE IT-8 E3 — experiment violinbody (155 strings)

File: it/draft/r8_E3.json (strings only). Checker: 0 errors, 0 warnings.

Terms (one hand with the violin experiment): strofinata/arco, scorrimento multiplo, rauco ("l'altro rauco" in the bow sound), il lupo, inviluppo, battimento lineare, balbettio (MUS-229's stutter), scordato (detuned), linee di ritardo, ponticello a smorzatore (dashpot), la finestra, piastra di Gough agli elementi finiti, limiti superiori ancora in discesa, venatura, la tavola di abete / il fondo di acero, fasce, catena, anima, cassa, piastre incernierate, nel vuoto (in vacuo), specchio, ammettenza del ponticello, dato in ingresso.
Choices: the string names stay G, D (as in the violin experiment's labels). Mode marks on the box: A (aria), r (respiro, English b), o, n; the caption cap.box3 names them the same way. Candidate labels "tenuta/libera, primo/secondo/terzo". "Strike" = Colpisci, "Play" = Suona, Mute = Silenzio. Notation, ids, check tags, numbers and all {placeholders} kept as printed.
Avoided "per prima" (temporal-prima risk) in cap.plate1: rephrased with the ordinal "primo modo".
Doubt: none on physics; texts follow the English claims exactly (nothing added to what the rows establish).
