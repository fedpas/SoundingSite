// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// rotor — a pure tone is a rotor (SPR-M01, MUS-001). The closed forms of the three spring kinds are those of ATLAS/engines/springEngine.js (oscillator0).
(function () {
  'use strict';
  window.SDV_EXP = window.SDV_EXP || {};
  var RM = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  function cents(r) { return 1200 * Math.log(r) / Math.LN2; }
  function rep(s, o) { for (var k in o) s = s.replace('{' + k + '}', o[k]); return s; }
  function cv(kit, parent, aspect) { var d = kit.el('div', { style: 'width:100%;min-width:0' }); parent.appendChild(d); return kit.canvas(d, aspect); }
  function txt(ctx, s, x, y, al, col, px) { ctx.fillStyle = col; ctx.font = (px || 11) + 'px system-ui, sans-serif'; ctx.textAlign = al || 'left'; ctx.fillText(s, x, y); }
  // one Play/Mute per panel (only one sounds at a time) and one Pause for the picture
  function transport(kit, S) {
    var st = { paused: RM }, cur = null, hasAudio = !!(window.AudioContext || window.webkitAudioContext), warned = false;
    st.pause = function (controls) {
      var p = kit.button(controls, 'exp.common.pause', S, function () { st.paused = !st.paused; show(); if (st.onpause) st.onpause(); });
      function show() { p.setAttribute('aria-pressed', String(st.paused)); p.style.background = st.paused ? 'var(--accent-tint)' : ''; }
      show(); return p;
    };
    st.player = function (controls, o) {
      var me = { on: false };
      var b = kit.button(controls, 'exp.common.play', S, function () {
        if (me.on) { me.stop(); return; }
        if (!hasAudio || !kit.audio()) { b.disabled = true; if (!warned) { warned = true; kit.line(controls.parentNode, 'exp.common.noaudio', S); } return; }
        if (cur && cur !== me) cur.stop();
        me.on = true; cur = me; label(); o.start();
      });
      function label() { var id = me.on ? 'exp.common.mute' : 'exp.common.play'; b.setAttribute('data-s', id); b.textContent = S(id); b.setAttribute('aria-pressed', String(me.on)); }
      me.stop = function () { if (!me.on) return; me.on = false; if (cur === me) cur = null; label(); o.stop(); };
      return me;
    };
    return st;
  }
  // the foot of every experiment: what you see, what you hear, the data line
  function foot(kit, S, root, slug) {
    var p = kit.panel_(root, 'exp.common.see', S, 'span');
    kit.line(p, 'exp.' + slug + '.see', S);
    p.appendChild(kit.el('h3', { 'data-s': 'exp.common.hear', text: S('exp.common.hear') }));
    kit.line(p, 'exp.' + slug + '.hear', S);
    p.appendChild(kit.el('p', { class: 'exp-source' }, [kit.el('b', { 'data-s': 'exp.common.data', text: S('exp.common.data') }), ' · ', kit.el('span', { 'data-s': 'exp.' + slug + '.data', text: S('exp.' + slug + '.data') })]));
  }
  var TAU = Math.PI * 2;
  // SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 (springEngine.js, oscillator0): the phase vector (x, q) of x'' = -k x for k > 0, k < 0, k = 0
  var KINDS = { circle: [1, 1], hyper: [1, -1], line: [0, 1] };
  function osc0(kind, w, t, x0, q0) {
    var a = KINDS[kind][0], b = KINDS[kind][1], Bsq = -a * b;
    if (Bsq === -1) return { x: x0 * Math.cos(w * t) + q0 * Math.sin(w * t), q: q0 * Math.cos(w * t) - x0 * Math.sin(w * t) };
    if (Bsq === 1) return { x: x0 * Math.cosh(w * t) - q0 * Math.sinh(w * t), q: q0 * Math.cosh(w * t) - x0 * Math.sinh(w * t) };
    return { x: x0 + w * q0 * t, q: q0 };
  }
  var RANGE = { circle: 1.3, hyper: 2.6, line: 1.5 };
  function state(kind, ph) { // ph: turns of the picture (circle) or the fraction of one run (the others)
    if (kind === 'circle') return osc0('circle', 1, ph * TAU, 1, 0);
    var f = ph - Math.floor(ph);
    return kind === 'hyper' ? osc0('hyper', 1, f * 1.5, 1, 0) : osc0('line', 1, f * 2.4, -1, 0.9);
  }
  // one phase portrait: velocity across, position up; the orbits of the kind and the point
  function portrait(ctx, kind, cx, cy, u, ph, big, col) {
    var R = RANGE[kind], i, q, pts, s;
    ctx.save(); ctx.beginPath(); ctx.rect(cx - R * u, cy - R * u, 2 * R * u, 2 * R * u); ctx.clip();
    ctx.strokeStyle = kit_muted; ctx.lineWidth = 0.6; ctx.setLineDash([2, 3]);
    ctx.beginPath(); ctx.moveTo(cx - R * u, cy); ctx.lineTo(cx + R * u, cy); ctx.moveTo(cx, cy - R * u); ctx.lineTo(cx, cy + R * u); ctx.stroke(); ctx.setLineDash([]);
    ctx.lineWidth = 1; ctx.strokeStyle = kit_muted; ctx.globalAlpha = 0.55;
    if (kind === 'circle') { [0.5, 1].forEach(function (r) { ctx.beginPath(); ctx.arc(cx, cy, r * u, 0, TAU); ctx.stroke(); }); }
    else if (kind === 'hyper') { [0.4, 1].forEach(function (c) { ctx.beginPath(); for (i = -60; i <= 60; i++) { q = i / 60 * 2.6; var x = Math.sqrt(c + q * q); if (i === -60) ctx.moveTo(cx + q * u, cy - x * u); else ctx.lineTo(cx + q * u, cy - x * u); } ctx.stroke(); }); }
    else { [-0.9, -0.45, 0, 0.45, 0.9].forEach(function (qq) { ctx.beginPath(); ctx.moveTo(cx + qq * u, cy - R * u); ctx.lineTo(cx + qq * u, cy + R * u); ctx.stroke(); }); }
    ctx.globalAlpha = 1; ctx.restore();
    s = state(kind, ph);
    var px = cx + s.q * u, py = cy - s.x * u;
    if (kind === 'circle') { ctx.strokeStyle = col; ctx.lineWidth = big ? 1.6 : 1.2; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(px, py); ctx.stroke(); }
    ctx.fillStyle = col; ctx.beginPath(); ctx.arc(px, py, big ? 5 : 3.5, 0, TAU); ctx.fill();
    return { x: px, y: py, s: s };
  }
  var kit_muted = '#6b7470';

  window.SDV_EXP.rotor = { mount: function (root, data, S, kit) {
    root.classList.add('half');
    kit_muted = kit.muted();
    var T = transport(kit, S), accent = kit.accent(), ink = kit.ink(), F2 = 10, DRAW0 = 12, FPIC = 0.5;
    var kind = 'circle', f = 220, tau = 0, mode = 'two', df = 2, vA = null, vB = [];

    // ---- panel a: the rotor
    var pa = kit.panel_(root, 'exp.rotor.panel.a', S);
    var cA = cv(kit, pa, 0.6), cS = cv(kit, pa, 0.34), ctlA = kit.controls(pa);
    kit.seg(ctlA, { ids: ['exp.rotor.k.circle', 'exp.rotor.k.hyper', 'exp.rotor.k.line'], values: ['circle', 'hyper', 'line'], value: 'circle', S: S, onchange: function (v) { kind = v; if (vA) vA.set(null, kind === 'circle' ? 0.15 : 0); draw(); } });
    var fs = kit.slider(ctlA, { id: 'exp.common.frequency', S: S, min: 110, max: 440, step: 1, value: 220, fmt: function (v) { return kit.num(v, 0) + ' ' + S('exp.common.hz'); }, onchange: function (v) { f = v; if (vA) vA.set(f, null); draw(); } });
    T.player(ctlA, { start: function () { vA = kit.voice({ f: f, gain: kind === 'circle' ? 0.15 : 0 }); }, stop: function () { if (vA) vA.stop(); vA = null; } });
    T.pause(ctlA);
    var rdA = kit.readout(pa), rdA2 = kit.readout(pa);
    kit.line(pa, 'exp.rotor.line.onlycircle', S);

    // ---- panel b: two rotors
    var pb = kit.panel_(root, 'exp.rotor.panel.b', S);
    var cB = cv(kit, pb, 0.95), ctlB = kit.controls(pb);
    kit.seg(ctlB, { ids: ['exp.rotor.m.two', 'exp.rotor.m.fifth', 'exp.rotor.m.just'], values: ['two', 'tempered', 'just'], value: 'two', S: S, onchange: function (v) { mode = v; sl.el.style.opacity = v === 'two' ? 1 : 0.4; if (playB.on) { stopB(); startB(); } draw(); } });
    var sl = kit.slider(ctlB, { id: 'exp.rotor.df', S: S, min: 0, max: 12, step: 0.1, value: 2, fmt: function (v) { return kit.num(v, 1) + ' ' + S('exp.common.hz'); }, onchange: function (v) { df = v; if (playB.on && mode === 'two' && vB[1]) vB[1].set(220 + df, null); draw(); } });
    function voicesB() {
      var f1 = 220, f2 = mode === 'tempered' ? f1 * Math.pow(2, 7 / 12) : mode === 'just' ? 1.5 * f1 : f1 + df;
      return mode === 'two' ? [[f1, 0.12], [f2, 0.12]] : [[f1, 0.12], [f2, 0.12], [3 * f1, 0.04], [2 * f2, 0.06]];
    }
    function startB() { vB = voicesB().map(function (v) { return kit.voice({ f: v[0], gain: v[1] }); }); }
    function stopB() { vB.forEach(function (v) { v.stop(); }); vB = []; }
    var playB = T.player(ctlB, { start: startB, stop: stopB });
    var rdB = kit.readout(pb), rdB2 = kit.readout(pb);
    kit.line(pb, 'exp.rotor.line.just', S);
    foot(kit, S, root, 'rotor');

    // ---- drawing
    function drawA() {
      var ctx = cA.ctx, w = cA.w, h = cA.h; ctx.clearRect(0, 0, w, h);
      var R = RANGE[kind], u = (h / 2 - 8) / R, cx = h / 2, cy = h / 2;
      var ph = kind === 'circle' ? tau * FPIC : tau * FPIC * 0.6;
      var tx0 = h + 8, tw = w - tx0 - 6;
      var P = portrait(ctx, kind, cx, cy, u, ph, true, accent);
      // the trace of the shadow: position against time
      ctx.strokeStyle = kit_muted; ctx.lineWidth = 0.6; ctx.setLineDash([2, 3]); ctx.beginPath(); ctx.moveTo(tx0, cy); ctx.lineTo(tx0 + tw, cy); ctx.stroke(); ctx.setLineDash([]);
      ctx.strokeStyle = ink; ctx.lineWidth = 1.6; ctx.beginPath();
      var N = 160, i, head;
      if (kind === 'circle') {
        var W = 2.5; for (i = 0; i <= N; i++) { var a = i / N * W, s = state('circle', ph - a * 1); var X = tx0 + a / W * tw, Y = cy - s.x * u; if (i) ctx.lineTo(X, Y); else ctx.moveTo(X, Y); }
        head = tx0;
      } else {
        var f0 = ph - Math.floor(ph); for (i = 0; i <= N; i++) { var p = f0 * i / N, s2 = state(kind, p); var X2 = tx0 + p * tw, Y2 = cy - s2.x * u; if (i) ctx.lineTo(X2, Y2); else ctx.moveTo(X2, Y2); }
        head = tx0 + f0 * tw;
      }
      ctx.stroke();
      ctx.strokeStyle = accent; ctx.lineWidth = 0.9; ctx.setLineDash([3, 3]); ctx.beginPath(); ctx.moveTo(P.x, P.y); ctx.lineTo(head, P.y); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = accent; ctx.beginPath(); ctx.arc(head, P.y, 3.5, 0, TAU); ctx.fill();
      txt(ctx, S('exp.rotor.c.vel'), cx + R * u - 2, cy + 12, 'right', kit_muted, 10);
      txt(ctx, S('exp.rotor.c.pos'), cx + 4, cy - R * u + 10, 'left', kit_muted, 10);
      txt(ctx, S('exp.rotor.c.time'), tx0 + tw - 2, cy + 12, 'right', kit_muted, 10);
      // the three small portraits
      var c2 = cS.ctx, w2 = cS.w, h2 = cS.h; c2.clearRect(0, 0, w2, h2);
      ['circle', 'hyper', 'line'].forEach(function (k, j) {
        var cw = w2 / 3, ccx = cw * (j + 0.5), ccy = (h2 - 16) / 2 + 3, uu = (h2 - 16 - 8) / 2 / RANGE[k];
        if (k === kind) { c2.strokeStyle = accent; c2.lineWidth = 1.5; c2.strokeRect(j * cw + 3, 1, cw - 6, h2 - 2); }
        portrait(c2, k, ccx, ccy, uu, k === 'circle' ? tau * FPIC : tau * FPIC * 0.6, false, k === kind ? accent : kit_muted);
        txt(c2, S('exp.rotor.k.' + k), ccx, h2 - 4, 'center', k === kind ? ink : kit_muted, 10);
      });
      var w0 = TAU * f;
      rdA.textContent = 'f = ' + kit.num(f, 0) + ' ' + S('exp.common.hz') + ' · ω = ' + kit.num(w0, 1) + ' rad/s · ' + (kind === 'circle' ? 'ẍ = −ω²x' : kind === 'hyper' ? 'ẍ = +ω²x' : 'ẍ = 0') + ' · x(t) = ' + (kind === 'circle' ? 'cos ωt' : kind === 'hyper' ? 'cosh ωt' : 'x₀ + vt');
      rdA2.textContent = S('exp.common.slowed').replace('{n}', kit.num(f / FPIC, 0));
    }
    function drawB() {
      var ctx = cB.ctx, w = cB.w, h = cB.h; ctx.clearRect(0, 0, w, h);
      var f1 = 220, f2 = mode === 'tempered' ? f1 * Math.pow(2, 7 / 12) : mode === 'just' ? 1.5 * f1 : f1 + df;
      var fa, fb, aA, aB;
      if (mode === 'two') { fa = f1; fb = f2; aA = 1; aB = 1; } else { fa = 3 * f1; fb = 2 * f2; aA = 1 / 3; aB = 1 / 2; }
      var dA = DRAW0, dB = DRAW0 + (fb - fa), s0 = tau / F2, topH = h * 0.42, r = Math.min(w / 7.5, topH / 2 - 10), sc = r / (aA + aB);
      var thA = TAU * dA * s0, thB = TAU * dB * s0, ay = topH / 2 - 4;
      var cxs = [w * 0.17, w * 0.5, w * 0.83];
      cxs.forEach(function (cx) { ctx.strokeStyle = kit_muted; ctx.lineWidth = 0.8; ctx.beginPath(); ctx.arc(cx, ay, r, 0, TAU); ctx.stroke(); });
      var vA1 = [Math.cos(thA) * aA * sc, -Math.sin(thA) * aA * sc], vB1 = [Math.cos(thB) * aB * sc, -Math.sin(thB) * aB * sc];
      kit.arrow(ctx, cxs[0], ay, cxs[0] + vA1[0], ay + vA1[1], kit.blue, 1.8);
      kit.arrow(ctx, cxs[1], ay, cxs[1] + vB1[0], ay + vB1[1], kit.red, 1.8);
      kit.arrow(ctx, cxs[2], ay, cxs[2] + vA1[0], ay + vA1[1], kit.blue, 1.2);
      kit.arrow(ctx, cxs[2] + vA1[0], ay + vA1[1], cxs[2] + vA1[0] + vB1[0], ay + vA1[1] + vB1[1], kit.red, 1.2);
      kit.arrow(ctx, cxs[2], ay, cxs[2] + vA1[0] + vB1[0], ay + vA1[1] + vB1[1], accent, 2);
      var ids = mode === 'two' ? ['exp.rotor.b.lower', 'exp.rotor.b.upper'] : ['exp.rotor.b.p3', 'exp.rotor.b.p2'];
      txt(ctx, S(ids[0]), cxs[0], topH + 2, 'center', kit_muted, 10); txt(ctx, S(ids[1]), cxs[1], topH + 2, 'center', kit_muted, 10); txt(ctx, S('exp.rotor.b.sum'), cxs[2], topH + 2, 'center', kit_muted, 10);
      // the sum against time, with its envelope: window of 2 s of the sound, the head at s0
      var y0 = topH + 18 + (h - topH - 22) / 2, yh = (h - topH - 30) / 2, Wt = 2, i, N = Math.round(w * 1.2);
      ctx.strokeStyle = kit_muted; ctx.lineWidth = 0.6; ctx.setLineDash([2, 3]); ctx.beginPath(); ctx.moveTo(4, y0); ctx.lineTo(w - 4, y0); ctx.stroke(); ctx.setLineDash([]);
      [1, -1].forEach(function (sg) {
        ctx.strokeStyle = accent; ctx.lineWidth = 1.3; ctx.setLineDash([4, 3]); ctx.beginPath();
        for (i = 0; i <= N; i++) { var s = s0 - Wt + Wt * i / N, E = Math.sqrt(aA * aA + aB * aB + 2 * aA * aB * Math.cos(TAU * (dB - dA) * s)); var X = 4 + (w - 8) * i / N, Y = y0 - sg * E / (aA + aB) * yh; if (i) ctx.lineTo(X, Y); else ctx.moveTo(X, Y); }
        ctx.stroke(); ctx.setLineDash([]);
      });
      ctx.strokeStyle = ink; ctx.lineWidth = 1.2; ctx.beginPath();
      for (i = 0; i <= N; i++) { var s1 = s0 - Wt + Wt * i / N, v = aA * Math.cos(TAU * dA * s1) + aB * Math.cos(TAU * dB * s1); var X1 = 4 + (w - 8) * i / N, Y1 = y0 - v / (aA + aB) * yh; if (i) ctx.lineTo(X1, Y1); else ctx.moveTo(X1, Y1); }
      ctx.stroke();
      txt(ctx, S('exp.rotor.b.trace'), 6, topH + 17, 'left', kit_muted, 10);
      var beat = Math.abs(fb - fa);
      rdB.textContent = mode === 'two' ? '|f₂ − f₁| = ' + kit.num(beat, 2) + ' ' + S('exp.common.hz') + ' · f₁ = 220, f₂ = ' + kit.num(f2, 1)
        : '|3f₁ − 2f₂| = ' + kit.num(beat, 3) + ' ' + S('exp.common.hz') + ' (f₁ = 220, f₂ = ' + kit.num(f2, 2) + ')' + (mode === 'tempered' ? ' · f₁ = 261.6: ' + kit.num(Math.abs(3 * 261.6255653 - 2 * 261.6255653 * Math.pow(2, 7 / 12)), 3) + ' ' + S('exp.common.hz') : '');
      rdB2.textContent = S('exp.common.slowed').replace('{n}', String(F2)) + ' · ' + S('exp.rotor.line.lowered').replace('{n}', String(DRAW0)).replace('{m}', kit.num(fa, 0));
    }
    function draw() { drawA(); drawB(); }
    T.onpause = draw; window.addEventListener('resize', draw);
    sl.el.style.opacity = 1;
    kit.loop(function (t, dt) { if (!T.paused) tau += dt; draw(); });
    draw();
  } };
})();
