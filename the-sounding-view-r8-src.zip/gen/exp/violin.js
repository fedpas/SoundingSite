// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// violin.js — The violin: the bowed string, the plate, the added piece, the air, the wolf (MUS-223, 225, 224, 227, 230, 228, 226, 229)
(function () {
  'use strict';
  window.SDV_EXP = window.SDV_EXP || {};
  window.SDV_EXP['violin'] = { mount: function (root, data, S, kit) {
    var P = 'exp.violin.', el = kit.el, TAU = Math.PI * 2, OUT = S('exp.common.outside');
    var reduce = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    var H = data.helmholtz, STR = data.strings.filter(function (s) { return s.name; }), SC = data.schelleng, PL = data.plate, PO = data.post, AIR = data.air, WO = data.wolf;
    var st = { t: 0, paused: reduce, beta: 0.1, vb: 0.1, str: 'G', F: 0.4, body: 'string', nu: '0.39', mode: 0, held: 'free', hm: 2, ml: 1, pc: 'free', pw: 0, pp: 'post', asp: 7.8, area: 1, wq: 0 };
    var L_STR = 0.325;
    // ------------------------------------------------------------ helpers
    function grid(parent) { var d = el('div'); d.style.cssText = 'display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:12px;align-items:start'; parent.appendChild(d); return d; }
    function cv(parent, a, m) { var d = el('div'); parent.appendChild(d); return kit.canvas(d, a, m); }
    function txt(c, s, x, y, color, align, size) { c.fillStyle = color || kit.muted(); c.textAlign = align || 'left'; c.font = (size || 11) + 'px system-ui, sans-serif'; c.fillText(s, x, y); }
    function fill(s, o) { for (var k in o) s = s.split('{' + k + '}').join(o[k]); return s; }
    function R(id, o) { return fill(S(P + id), o || {}); }
    function frac(s) { if (s == null) return null; var p = String(s).split('/'); return p.length === 2 ? +p[0] / +p[1] : +p[0]; }
    function line(parent, id) { return kit.line(parent, P + id, S); }
    function show(e, on) { (e.el || e).style.display = on ? '' : 'none'; }
    function nearest(arr, v) { var b = 0; arr.forEach(function (x, i) { if (Math.abs(x - v) < Math.abs(arr[b] - v)) b = i; }); return b; }
    // Legendre tables on an (n+1)-point grid of [-1, 1]; the field W = sum c P_i(x) P_j(y) of the data's coefficients
    var LPc = {};
    function LP(n) { if (LPc[n]) return LPc[n]; var T = []; for (var d = 0; d < 24; d++) T.push(new Float64Array(n + 1)); for (var g = 0; g <= n; g++) { var x = -1 + 2 * g / n; T[0][g] = 1; T[1][g] = x; for (d = 1; d < 23; d++) T[d + 1][g] = ((2 * d + 1) * x * T[d][g] - d * T[d - 1][g]) / (d + 1); } return (LPc[n] = T); }
    function legField(coeffs, n) { var T = LP(n), F = [], j, i, m = 0; for (j = 0; j <= n; j++) { F.push(new Float64Array(n + 1)); } coeffs.forEach(function (c) { var a = T[c[0]], b = T[c[1]], v = c[2]; for (j = 0; j <= n; j++) { var bj = b[j] * v; for (i = 0; i <= n; i++) F[j][i] += a[i] * bj; } }); for (j = 0; j <= n; j++) for (i = 0; i <= n; i++) m = Math.max(m, Math.abs(F[j][i])); return { F: F, n: n, m: m || 1 }; }
    function fnField(fn, n) { var F = [], m = 0; for (var j = 0; j <= n; j++) { F.push(new Float64Array(n + 1)); for (var i = 0; i <= n; i++) { F[j][i] = fn(-1 + 2 * i / n, -1 + 2 * j / n); m = Math.max(m, Math.abs(F[j][i])); } } return { F: F, n: n, m: m || 1 }; }
    // the square map: colour W·amp (kit.cmap) and the zero contours by marching squares
    function plateMap(c, fd, ox, oy, side, amp, nodal) {
      var n = fd.n, F = fd.F, cs = side / n, i, j;
      for (j = 0; j < n; j++) for (i = 0; i < n; i++) { c.fillStyle = kit.cmap(amp * (F[j][i] + F[j][i + 1] + F[j + 1][i] + F[j + 1][i + 1]) / (4 * fd.m)); c.fillRect(ox + i * cs, oy + side - (j + 1) * cs, cs + 0.6, cs + 0.6); }
      if (nodal !== false) {
        c.strokeStyle = kit.ink(); c.lineWidth = 1.4; c.beginPath();
        var X = [[0, 0], [1, 0], [1, 1], [0, 1]];
        for (j = 0; j < n; j++) for (i = 0; i < n; i++) {
          var v = [F[j][i], F[j][i + 1], F[j + 1][i + 1], F[j + 1][i]], pts = [];
          for (var e = 0; e < 4; e++) { var a0 = v[e], b0 = v[(e + 1) % 4]; if ((a0 < 0) !== (b0 < 0)) { var f = a0 / (a0 - b0), p0 = X[e], p1 = X[(e + 1) % 4]; pts.push([ox + (i + p0[0] + f * (p1[0] - p0[0])) * cs, oy + side - (j + p0[1] + f * (p1[1] - p0[1])) * cs]); } }
          for (e = 0; e + 1 < pts.length; e += 2) { c.moveTo(pts[e][0], pts[e][1]); c.lineTo(pts[e + 1][0], pts[e + 1][1]); }
        }
        c.stroke();
      }
      c.strokeStyle = kit.muted(); c.lineWidth = 1; c.strokeRect(ox, oy, side, side);
    }
    function P2(ox, oy, side, x, y) { return [ox + (x + 1) / 2 * side, oy + side - (y + 1) / 2 * side]; }
    // ------------------------------------------------------------ one sound for the whole experiment
    var SND = null, noAudio = null;
    function setBtn(b, on) { var id = on ? 'exp.common.mute' : 'exp.common.play'; b.textContent = S(id); b.setAttribute('data-s', id); }
    function stopSnd() { if (SND) { try { SND.stop(); } catch (e) { } if (SND.btn) setBtn(SND.btn, false); SND = null; } }
    function toggle(kind, btn, start) {
      if (SND && SND.kind === kind) { stopSnd(); return; }
      stopSnd(); var a = kit.audio(); if (!a) { if (!noAudio) noAudio = kit.line(root, 'exp.common.noaudio', S); return; }
      var s = start(a); SND = { kind: kind, btn: btn, stop: s.stop, upd: s.upd }; setBtn(btn, true);
    }
    function upd(kind) { if (SND && SND.kind === kind && SND.upd) SND.upd(); }

    // ================================================================ (i) the bowed string
    var p1 = kit.panel_(root, P + 'panel.string', S), g1 = grid(p1);
    var cS = cv(g1, 0.72, 340), cW = cv(g1, 0.72, 340);
    var k1 = kit.controls(p1);
    var playS = kit.button(k1, 'exp.common.play', S, function () { toggle('string', playS, startString); });
    var pauseB = kit.button(k1, 'exp.common.pause', S, function () { st.paused = !st.paused; pauseB.setAttribute('aria-pressed', String(st.paused)); }); pauseB.setAttribute('aria-pressed', String(st.paused));
    kit.seg(k1, { S: S, ids: STR.map(function (s) { return P + 'str.' + s.name; }), values: STR.map(function (s) { return s.name; }), value: st.str, onchange: function (v) { st.str = v; readS(); upd('string'); } });
    kit.seg(k1, { S: S, ids: [P + 'body.string', P + 'body.body'], values: ['string', 'body'], value: st.body, onchange: function (v) { st.body = v; upd('string'); } });
    var k1b = kit.controls(p1);
    kit.slider(k1b, { S: S, id: P + 'beta', min: 1 / 30, max: 1 / 5, log: true, value: st.beta, fmt: function (v) { return '1/' + kit.num(1 / v, 1); }, onchange: function (v) { st.beta = v; readS(); upd('string'); } });
    kit.slider(k1b, { S: S, id: P + 'vb', min: 0.05, max: 0.3, step: 0.005, value: st.vb, fmt: function (v) { return kit.num(v, 3) + ' m/s'; }, onchange: function (v) { st.vb = v; readS(); upd('string'); } });
    kit.slider(k1b, { S: S, id: P + 'force', min: 0.05, max: 3, log: true, value: st.F, fmt: function (v) { return kit.num(v, 2) + ' N'; }, onchange: function (v) { st.F = v; readS(); upd('string'); } });
    var rS1 = kit.readout(p1), rS2 = kit.readout(p1), rS3 = kit.readout(p1), rS4 = kit.readout(p1), rSlow = kit.readout(p1);
    ['cap.corner', 'cap.slip', 'cap.saw', 'cap.fifths', 'cap.wedge', 'cap.inputs', 'cap.measured', 'hear.string'].forEach(function (k) { line(p1, k); });
    function curStr() { return STR.filter(function (s) { return s.name === st.str; })[0]; }
    // Schelleng's lines: log F interpolated in log beta along the data, and in log v_b across the data's three bow speeds
    function lim(kind, beta, vb) {
      var vs = SC.vb; if (vb < vs[0] - 1e-9 || vb > vs[vs.length - 1] + 1e-9) return null;
      var vals = vs.map(function (v) { var key = String(v), arr = SC[kind][key]; return kit.interp(SC.beta.map(function (b, i) { return [Math.log(b), Math.log(arr[i])]; }), Math.log(beta)); });
      if (vals.some(function (x) { return x == null; })) return null;
      return Math.exp(kit.interp(vs.map(function (v, i) { return [Math.log(v), vals[i]]; }), Math.log(kit.clamp(vb, vs[0], vs[vs.length - 1]))));
    }
    function regime() { var lo = lim('Fmin', st.beta, st.vb), hi = lim('Fmax', st.beta, st.vb); if (lo == null || hi == null) return { r: null }; return { r: st.F < lo ? 'below' : st.F > hi ? 'above' : 'in', lo: lo, hi: hi }; }
    function readS() {
      var s = curStr(), b = st.beta, xb = b * L_STR;
      rS1.textContent = R('str.rd1', { b: kit.num(b, 4), n: s.name, ft: kit.num(s.f_tet, 3), fj: kit.num(s.f_just, 3), c: (s.cents > 0 ? '+' : '') + kit.num(s.cents, 3) });
      var amp = st.vb * L_STR * L_STR / (4 * s.c * xb), Fb = s.Z0 * st.vb / b;   // the data's amplitude law: v_b l²/(4 c x_b), bridge force Z0 v_b/β
      rS2.textContent = R('str.rd2', { a: kit.num(amp * 1000, 3), F: kit.num(Fb, 3), S: kit.num(2 * Fb, 3), z: kit.num(s.Z0, 4), c: kit.num(s.c, 1), j: kit.num(st.vb / b, 2) });
      var g = regime();
      rS3.textContent = g.r == null ? R('wedge.rd.out', { v: kit.num(st.vb, 3), o: OUT }) : R('wedge.rd', { v: kit.num(st.vb, 3), b: kit.num(b, 4), lo: kit.num(g.lo, 4), hi: kit.num(g.hi, 3), f: kit.num(st.F, 2), r: S(P + 'wedge.' + g.r) });
      rS4.textContent = R('wedge.star', { s: kit.num(SC.beta_star, 7), n: kit.num(1 / SC.beta_star, 0) });
      rSlow.textContent = S('exp.common.slowed').replace('{n}', kit.num(Math.round(2 * s.f_just), 0));
    }
    function drawString() {
      var c = cS.ctx, w = cS.w, h = cS.h, s = st.t % 2, b = st.beta; c.clearRect(0, 0, w, h);
      var x0 = 30, x1 = w - 30, yc = h * 0.27, A = h * 0.8, X = function (x) { return x0 + x * (x1 - x0); }, Y = function (y) { return yc - y * A; };
      c.setLineDash([2, 4]); c.strokeStyle = kit.muted(); c.lineWidth = 1; [1, -1].forEach(function (sg) { c.beginPath(); for (var i = 0; i <= 60; i++) { var x = i / 60; if (i) c.lineTo(X(x), Y(sg * x * (1 - x))); else c.moveTo(X(x), Y(0)); } c.stroke(); }); c.setLineDash([]);
      var xc = s < 1 ? s : 2 - s, yh = (s < 1 ? 1 : -1) * xc * (1 - xc);     // the corner: ct mod 2l reflected, on the parabola K x(l − x)
      c.strokeStyle = kit.ink(); c.lineWidth = 2; c.beginPath(); c.moveTo(X(0), Y(0)); c.lineTo(X(xc), Y(yh)); c.lineTo(X(1), Y(0)); c.stroke();
      c.fillStyle = kit.accent(); c.beginPath(); c.arc(X(xc), Y(yh), 3.5, 0, TAU); c.fill();
      c.fillStyle = kit.ink(); c.fillRect(X(0) - 3, yc - 14, 3, 28); c.fillRect(X(1), yc - 14, 3, 28);
      txt(c, S(P + 'cv.bridge'), X(0), yc + 30, kit.muted(), 'left', 10); txt(c, S(P + 'cv.nut'), X(1), yc + 30, kit.muted(), 'right', 10);
      var yb = (xc >= b ? b / xc * yh : (1 - b) / (1 - xc) * yh);
      c.strokeStyle = kit.warm(); c.lineWidth = 3; c.beginPath(); c.moveTo(X(b), Y(yb) - 10); c.lineTo(X(b), Y(yb) + 10); c.stroke(); txt(c, S(P + 'cv.bow'), X(b) + 4, yc - A * 0.27, kit.warm(), 'left', 10);
      // the bridge force (the data's sawtooth) and the velocity at the bow (two-valued: slip for β, stick for 1 − β)
      var bx = { l: 30, r: w * 0.5 - 8, t: h * 0.6, b: h - 22 }, vx = { l: w * 0.5 + 18, r: w - 12, t: h * 0.6, b: h - 22 };
      var ax = kit.axes(c, bx, { xmin: 0, xmax: 2, ymin: -1.1, ymax: 1.1, xticks: [0, 1, 2] });
      kit.curve(c, H.sawtooth.t.map(function (t, i) { return [t, H.sawtooth.F[i]]; }), ax.x, ax.y, kit.red, 1.6);
      c.strokeStyle = kit.accent(); c.beginPath(); c.moveTo(ax.x(s), bx.t); c.lineTo(ax.x(s), bx.b); c.stroke(); txt(c, S(P + 'cv.saw'), bx.l + 4, bx.t - 4, kit.muted(), 'left', 10);
      var av = kit.axes(c, vx, { xmin: 0, xmax: 2, ymin: -0.35, ymax: 1.05, xticks: [0, 1, 2] }), pts = [];
      [[0, 1 - b], [b, 1 - b], [b, -b], [2 - b, -b], [2 - b, 1 - b], [2, 1 - b]].forEach(function (p) { pts.push(p); });
      kit.curve(c, pts, av.x, av.y, kit.blue, 1.6);
      c.strokeStyle = kit.muted(); c.setLineDash([2, 3]); c.beginPath(); c.moveTo(vx.l, av.y(0)); c.lineTo(vx.r, av.y(0)); c.stroke(); c.setLineDash([]);
      c.strokeStyle = kit.accent(); c.beginPath(); c.moveTo(av.x(s), vx.t); c.lineTo(av.x(s), vx.b); c.stroke();
      txt(c, S(P + 'cv.vel'), vx.l + 4, vx.t - 4, kit.muted(), 'left', 10); txt(c, S(P + 'cv.slip'), av.x(0) + 3, av.y(1 - b) + 12, kit.blue, 'left', 10); txt(c, S(P + 'cv.stick'), av.x(1), av.y(-b) - 4, kit.blue, 'center', 10);
      txt(c, 'ct/l', bx.r, bx.b + 16, kit.muted(), 'right', 10); txt(c, 'ct/l', vx.r, vx.b + 16, kit.muted(), 'right', 10);
    }
    function drawWedge() {
      var c = cW.ctx, w = cW.w, h = cW.h, box = { l: 52, r: w - 10, t: 10, b: h - 36 }; c.clearRect(0, 0, w, h);
      var ax = kit.axes(c, box, { xmin: SC.beta[0], xmax: SC.beta[SC.beta.length - 1], xlog: true, ymin: 1e-3, ymax: 10, ylog: true, xticks: [0.03, 0.05, 0.1, 0.2], yticks: [0.001, 0.01, 0.1, 1, 10], xlabel: S(P + 'cv.beta'), ylabel: S(P + 'cv.force') });
      c.save(); c.beginPath(); c.rect(box.l, box.t, box.r - box.l, box.b - box.t); c.clip();
      var lo = [], hi = []; SC.beta.forEach(function (b) { var a = lim('Fmin', b, st.vb), z = lim('Fmax', b, st.vb); if (a != null) lo.push([b, a]); if (z != null) hi.push([b, z]); });
      if (lo.length) { c.fillStyle = kit.accent(); c.globalAlpha = 0.12; c.beginPath(); hi.forEach(function (p, i) { if (i) c.lineTo(ax.x(p[0]), ax.y(p[1])); else c.moveTo(ax.x(p[0]), ax.y(p[1])); }); lo.slice().reverse().forEach(function (p) { c.lineTo(ax.x(p[0]), ax.y(p[1])); }); c.closePath(); c.fill(); c.globalAlpha = 1;
        kit.curve(c, hi, ax.x, ax.y, kit.accent(), 2); kit.curve(c, lo, ax.x, ax.y, kit.accent(), 2, [6, 4]);
        txt(c, S(P + 'cv.fmax'), ax.x(hi[3][0]), ax.y(hi[3][1]) - 6, kit.accent(), 'left', 11); txt(c, S(P + 'cv.fmin'), ax.x(lo[22][0]), ax.y(lo[22][1]) + 14, kit.accent(), 'left', 11);
        txt(c, S(P + 'cv.play'), ax.x(0.08), ax.y(0.1), kit.accent(), 'center', 11);
      } else txt(c, OUT, (box.l + box.r) / 2, (box.t + box.b) / 2, kit.warm(), 'center', 13);
      H.beta_examples.forEach(function (b) { c.strokeStyle = kit.muted(); c.beginPath(); c.moveTo(ax.x(b), box.b); c.lineTo(ax.x(b), box.b - 8); c.stroke(); });
      var g = regime(), px = ax.x(st.beta), py = ax.y(st.F);
      c.fillStyle = g.r === 'in' ? kit.ink() : kit.red; c.beginPath(); c.arc(px, py, 5, 0, TAU); c.fill();
      c.restore();
    }

    // ---- the string's sound: a sawtooth (partials 1/n to the 30th), low-passed, optionally through three body peaks
    function waves(ctx) { var n = 31, re = new Float32Array(n), im = new Float32Array(n), re2 = new Float32Array(n), im2 = new Float32Array(n); for (var k = 1; k < n; k++) { im[k] = 1 / k; if (k <= 8) im2[k] = 1 / (k * k); } return { full: ctx.createPeriodicWave(re, im), thin: ctx.createPeriodicWave(re2, im2) }; }
    function startString(a) {
      var ctx = a.ctx, W = waves(ctx), osc = ctx.createOscillator(), lp = ctx.createBiquadFilter(), dry = ctx.createGain(), wet = ctx.createGain(), out = ctx.createGain();
      lp.type = 'lowpass'; lp.frequency.value = 4500; osc.setPeriodicWave(W.full); osc.connect(lp); lp.connect(dry); dry.connect(out);
      var node = lp; [280, 455, 545].forEach(function (f) { var q = ctx.createBiquadFilter(); q.type = 'peaking'; q.frequency.value = f; q.Q.value = 15; q.gain.value = 12; node.connect(q); node = q; }); node.connect(wet); wet.connect(out);
      var nb = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate), d = nb.getChannelData(0); for (var i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
      var ns = ctx.createBufferSource(), bp = ctx.createBiquadFilter(), ng = ctx.createGain(); ns.buffer = nb; ns.loop = true; bp.type = 'bandpass'; bp.Q.value = 1.2; ng.gain.value = 0; ns.connect(bp); bp.connect(ng); ng.connect(a.master);
      out.gain.value = 0; out.connect(a.master); osc.start(); ns.start();
      function u() {
        var s = curStr(), g = regime(), t = ctx.currentTime, f = s.f_just, r = g.r || 'in';
        osc.setPeriodicWave(r === 'below' ? W.thin : W.full); osc.frequency.setTargetAtTime(r === 'below' ? 2 * f : f, t, 0.02); bp.frequency.setTargetAtTime(f, t, 0.02);
        ng.gain.setTargetAtTime(r === 'above' ? 0.1 : 0, t, 0.03);
        dry.gain.setTargetAtTime(st.body === 'body' ? 0 : 1, t, 0.03); wet.gain.setTargetAtTime(st.body === 'body' ? 0.45 : 0, t, 0.03);
        out.gain.setTargetAtTime(Math.min(0.25, 0.06 + 0.6 * st.vb), t, 0.03);
      }
      u();
      return { upd: u, stop: function () { var t = ctx.currentTime; out.gain.setTargetAtTime(0, t, 0.02); ng.gain.setTargetAtTime(0, t, 0.02); osc.stop(t + 0.15); ns.stop(t + 0.15); } };
    }

    // ================================================================ (ii) the plate
    var p2 = kit.panel_(root, P + 'panel.plate', S), g2 = grid(p2);
    var cP = cv(g2, 1, 360), cQ = cv(g2, 0.62, 260);
    var k2 = kit.controls(p2);
    var strikeB = kit.button(k2, 'exp.common.strike', S, function () { stopSnd(); strikePlate(); });
    kit.seg(k2, { S: S, ids: [P + 'nu.03', P + 'nu.039'], values: ['0.3', '0.39'], value: st.nu, onchange: function (v) { st.nu = v; readP(); } });
    kit.seg(k2, { S: S, ids: [P + 'plate.free', P + 'plate.held'], values: ['free', 'held'], value: st.held, onchange: function (v) { st.held = v; show(segM, v === 'free'); show(segH, v === 'held'); setPlate(); } });
    var k2b = kit.controls(p2);
    var segM = kit.seg(k2b, { S: S, ids: [1, 2, 3, 4, 5, 6, 7, 8].map(function (i) { return P + 'mode.' + i; }), values: [0, 1, 2, 3, 4, 5, 6, 7], value: 0, onchange: function (v) { st.mode = v; setPlate(); } });
    var segH = kit.seg(k2b, { S: S, ids: [P + 'held.1', P + 'held.2', P + 'held.3'], values: [0, 1, 2], value: st.hm, onchange: function (v) { st.hm = v; setPlate(); } }); show(segH, false);
    var k2c = kit.controls(p2); k2c.appendChild(el('span', { class: 'exp-lab', 'data-s': P + 'mass', text: S(P + 'mass') }));
    kit.seg(k2c, { S: S, ids: PL.mass_loaded.map(function (q, i) { return P + 'mass.' + i; }), values: PL.mass_loaded.map(function (q, i) { return i; }), value: st.ml, onchange: function (v) { st.ml = v; readP(); } });
    var rP1 = kit.readout(p2), rP2 = kit.readout(p2), rPm = kit.readout(p2), rP3 = kit.readout(p2), rP4 = kit.readout(p2), rPslow = kit.readout(p2);
    var ln039 = line(p2, 'plate.shape039'), lnHeldNu = line(p2, 'plate.heldnu');
    ['cap.ritz', 'cap.plate', 'cap.std', 'cap.held', 'cap.mass', 'cap.w1', 'cap.photo'].forEach(function (k) { line(p2, k); });
    var rBeam = kit.readout(p2); line(p2, 'hear.plate');
    var NYL = PL.nylon, HZ = NYL.hz_per_lambda2, MODES = PL.modes['0.39'], HELD = PL.held['0.39'], fdP = null;
    var w1 = PL.report_W1, Cw = Math.pow(Math.sin(w1.k), 2) / Math.pow(Math.sinh(w1.k), 2);   // the data's form: cos kx cos ky − (sin²k/sinh²k) cosh kx cosh ky
    var fdW1 = fnField(function (x, y) { return Math.cos(w1.k * x) * Math.cos(w1.k * y) - Cw * Math.cosh(w1.k * x) * Math.cosh(w1.k * y); }, 60);
    // the held modes: W = sum c_ij P_i P_j + c1 r² ln r + c2 r⁴ ln r (the data's basis, evaluated)
    function heldField(m, n) { var fd = legField(m.coeffs, n), F = fd.F, g = m.singular, mx = 0; for (var j = 0; j <= n; j++) for (var i = 0; i <= n; i++) { var x = -1 + 2 * i / n, y = -1 + 2 * j / n, r2 = x * x + y * y, lr = r2 > 0 ? 0.5 * Math.log(r2) : 0; F[j][i] += g.r2lnr * r2 * lr + g.r4lnr * r2 * r2 * lr; mx = Math.max(mx, Math.abs(F[j][i])); } fd.m = mx || 1; return fd; }
    var PHOTO = HELD[2], fdHeld3 = heldField(PHOTO, 60);
    function curMode() { return st.held === 'held' ? HELD[st.hm] : MODES[st.mode]; }
    function setPlate() { fdP = st.held === 'held' ? heldField(curMode(), 48) : legField(curMode().coeffs, 48); readP(); }
    function readP() {
      var m = curMode(), held = st.held === 'held', nu039 = st.nu === '0.39';
      show(ln039, !nu039 && !held); show(lnHeldNu, held && !nu039);
      if (held) {
        var dash = function (v) { return v == null ? '–' : kit.num(v, 4); };
        rP1.textContent = R('plate.rd.held', { c: m['class'], k: String(m.k), l: kit.num(m.lambda2, 4), f: kit.num(m.f_Hz, 1) });
        rP2.textContent = R('plate.rd.cross', { m: dash(m.midline), d: dash(m.diagonal), e: dash(m.edge) });
      } else {
        var l2 = PL.lambda2[st.nu][st.mode];
        rP1.textContent = nu039 ? R('plate.rd', { c: m['class'], l: kit.num(l2, 4), nu: st.nu }) : R('plate.rd03', { l: kit.num(l2, 4), nu: st.nu });
        rP2.textContent = nu039 ? R('plate.rd.hz1', { f: kit.num(l2 * HZ, 1) }) : R('plate.rd.std', { s: PL.standard_nu03.map(function (v) { return kit.num(v, 3); }).join(', ') });
      }
      rP3.textContent = R('plate.rd.in', { L: kit.num(NYL.L * 100, 0), H: kit.num(NYL.H * 1000, 0), E: kit.num(NYL.E / 1e9, 1), nu: String(NYL.nu), rho: String(NYL.rho), h: kit.num(HZ, 4) });
      var ML = PL.mass_loaded[st.ml]; rPm.textContent = R('mass.rd', { m: String(ML.m_ratio), l: kit.num(ML.lambda2_ss3, 3), r: kit.num(ML.ring_radius, 3), f: kit.num(ML.lambda2_ss3 * HZ, 1) });
      rP4.textContent = R('w1.rd', { l: kit.num(NYL.report_product.lambda2, 2), f: kit.num(NYL.report_product.f, 1), q: kit.num(NYL.report_product.f / NYL.held_f[1], 4), h2: kit.num(NYL.held_f[1], 1), r: kit.num(w1.edge_residual, 4), h: kit.num(NYL.held_f[2], 1), x: kit.num(NYL.photo_f_ratio, 2), m1: String(NYL.measured[0]), m2: String(NYL.measured[1]), e1: kit.num(NYL.E_needed_GPa[0], 2), e2: kit.num(NYL.E_needed_GPa[1], 2) });
      rPslow.textContent = S('exp.common.slowed.pic').replace('{n}', kit.num(Math.round((held ? m.lambda2 : PL.lambda2['0.39'][st.mode]) * HZ / 0.5), 0));
      rBeam.textContent = R('beam.rd', { p: data.beam.roots_half.plus.map(function (v) { return kit.num(v, 10); }).join(', '), m: data.beam.roots_half.minus.map(function (v) { return kit.num(v, 10); }).join(', '), r: data.beam.roots_full.map(function (v) { return kit.num(v, 10); }).join(', ') });
    }
    function drawPlate() {
      var c = cP.ctx, w = cP.w, h = cP.h, side = Math.min(w, h) - 30, ox = (w - side) / 2, oy = 6; c.clearRect(0, 0, w, h);
      plateMap(c, fdP, ox, oy, side, Math.cos(TAU * 0.5 * st.t), true);
      c.fillStyle = kit.ink(); [[-1, -1], [1, -1], [1, 1], [-1, 1]].forEach(function (q) { var p = P2(ox, oy, side, q[0], q[1]); c.beginPath(); c.arc(p[0], p[1], 3, 0, TAU); c.fill(); });
      var pc = P2(ox, oy, side, 0, 0); c.strokeStyle = kit.ink(); c.lineWidth = 1.5; c.beginPath(); c.arc(pc[0], pc[1], st.held === 'held' ? 5 : 3, 0, TAU); if (st.held === 'held') c.fill(); else c.stroke();
      txt(c, st.held === 'held' ? S(P + 'cv.heldc') : S(P + 'cv.free'), ox, h - 8, kit.muted(), 'left', 11);
    }
    var w1dirty = true; window.addEventListener('resize', function () { w1dirty = true; });
    function drawW1() {
      if (!w1dirty) return; w1dirty = false;
      var c = cQ.ctx, w = cQ.w, h = cQ.h, side = Math.min(w / 2 - 14, h - 42), oy = 6; c.clearRect(0, 0, w, h);
      var o1 = w / 4 - side / 2, o2 = 3 * w / 4 - side / 2;
      plateMap(c, fdW1, o1, oy, side, 0.6, true); plateMap(c, fdHeld3, o2, oy, side, 0.6, true);
      txt(c, S(P + 'cv.w1'), w / 4, oy + side + 16, kit.ink(), 'center', 11); txt(c, S(P + 'cv.held'), 3 * w / 4, oy + side + 16, kit.ink(), 'center', 11);
      txt(c, kit.num(NYL.report_product.f, 1) + ' Hz', w / 4, oy + side + 29, kit.muted(), 'center', 10); txt(c, kit.num(NYL.held_f[2], 1) + ' Hz', 3 * w / 4, oy + side + 29, kit.muted(), 'center', 10);
    }
    function strikePlate() {
      var a = kit.audio(); if (!a) { if (!noAudio) noAudio = kit.line(root, 'exp.common.noaudio', S); return; }
      var fs = MODES.map(function (m, i) { return PL.lambda2['0.39'][i] * HZ; });
      if (st.held === 'held') { var ss = []; MODES.forEach(function (m, i) { if (m['class'] === 'SS' && i !== 1) ss.push(i); }); fs[ss[0]] = HELD[0].f_Hz; fs[ss[1]] = HELD[1].f_Hz; fs.push(HELD[2].f_Hz); fs.sort(function (a, b) { return a - b; }); }
      kit.strike(fs.map(function (f, i) { return { f: f, a: 1 / (i + 1), decay: 1.0 }; }), 0.14);
    }

    // ================================================================ (iii) the added piece
    var p3 = kit.panel_(root, P + 'panel.post', S), g3 = grid(p3);
    var c3a = el('div'), c3b = el('div'); g3.appendChild(c3a); g3.appendChild(c3b);
    var cC = cv(c3a, 0.55, 260), k3 = kit.controls(c3a);
    kit.seg(k3, { S: S, ids: [P + 'post.free', P + 'post.held3', P + 'post.held67'], values: ['free', 'held3', 'held67'], value: 'free', onchange: function (v) { st.pc = v; readC(); } });
    var rC = kit.readout(c3a), lnNoVec = line(c3a, 'post.novec'); line(c3a, 'cap.chain');
    var g3b = grid(c3b), cQp = cv(g3b, 0.8, 240), cPm = cv(g3b, 1, 240), k3b = kit.controls(c3b);
    var OMS = PO.response.map(function (r) { return r.omega; });
    kit.slider(k3b, { S: S, id: P + 'post.omega', min: 0, max: OMS.length - 1, step: 1, value: 0, fmt: function (v) { return kit.num(OMS[Math.round(v)], 1); }, onchange: function (v) { st.pw = Math.round(v); setPost(); } });
    kit.seg(k3b, { S: S, ids: [P + 'post.no', P + 'post.yes'], values: ['free', 'post'], value: st.pp, onchange: function (v) { st.pp = v; setPost(); } });
    var rQ = kit.readout(c3b); line(c3b, 'cap.post'); line(c3b, 'cap.mono'); line(p3, 'hear.post');
    var fdR = null;
    function setPost() { var r = PO.response[st.pw]; fdR = legField(st.pp === 'post' ? r.coeffs_post : r.coeffs_free, 48); rQ.textContent = R('post.rd.q', { w: kit.num(r.omega, 1), a: kit.num(r.Q_free, 1), b: kit.sci(r.Q_post, 3) }); }
    function readC() {
      var key = st.pc === 'held3' ? 'sum_held3' : st.pc === 'held67' ? 'sum_held67' : 'sum_free', s = PO.chain[key];
      rC.textContent = R('post.rd', { s: s, d: kit.num(frac(s), 5), w: PO.chain.omega2 }); show(lnNoVec, st.pc === 'held67');
    }
    function drawChain() {
      var c = cC.ctx, w = cC.w, h = cC.h, N = PO.chain.N, x0 = 24, x1 = w - 24, yc = h * 0.52, dx = (x1 - x0) / (N + 1); c.clearRect(0, 0, w, h);
      var xs = (st.pc === 'held3' ? PO.chain.x_held3 : PO.chain.x_free).map(frac), sc = h * 0.11, ph = Math.cos(TAU * 0.5 * st.t);
      c.fillStyle = kit.muted(); c.fillRect(x0 - 6, yc - 30, 6, 60); c.fillRect(x1, yc - 30, 6, 60);
      var mx = (x0 + x1) / 2; c.setLineDash([4, 4]); c.strokeStyle = kit.violet; c.beginPath(); c.moveTo(mx, 8); c.lineTo(mx, h - 18); c.stroke(); c.setLineDash([]); txt(c, S(P + 'cv.mirror'), mx, h - 6, kit.violet, 'center', 10);
      var pts = [[x0, yc]]; xs.forEach(function (v, i) { pts.push([x0 + (i + 1) * dx, yc - (v == null ? 0 : v) * sc * ph]); }); pts.push([x1, yc]);
      c.strokeStyle = kit.muted(); c.lineWidth = 1; c.beginPath(); pts.forEach(function (p, i) { if (i) c.lineTo(p[0], p[1]); else c.moveTo(p[0], p[1]); }); c.stroke();
      pts.slice(1, -1).forEach(function (p, i) {
        var held = (st.pc === 'held3' && i === 2) || (st.pc === 'held67' && (i === 5 || i === 6));
        c.fillStyle = held ? kit.ink() : kit.accent(); c.globalAlpha = st.pc === 'held67' && !held ? 0.45 : 1; c.beginPath(); c.arc(p[0], p[1], held ? 6 : 5, 0, TAU); c.fill(); c.globalAlpha = 1;
        if (held) { c.strokeStyle = kit.ink(); c.beginPath(); c.moveTo(p[0], p[1] + 6); c.lineTo(p[0], h - 22); c.stroke(); }
        txt(c, String(i + 1), p[0], yc + 52, kit.muted(), 'center', 9);
      });
      kit.arrow(c, x0 + 4 * dx, yc + 40, x0 + 4 * dx, yc + 14, kit.red, 2); kit.arrow(c, x0 + 9 * dx, yc - 40, x0 + 9 * dx, yc - 14, kit.blue, 2);
    }
    function drawQ() {
      var c = cQp.ctx, w = cQp.w, h = cQp.h, box = { l: 46, r: w - 8, t: 8, b: h - 34 }; c.clearRect(0, 0, w, h);
      var ax = kit.axes(c, box, { xmin: 0, xmax: 70, ymin: 1e-4, ymax: 20, ylog: true, xticks: [0, 20, 40, 60], yticks: [0.0001, 0.01, 1], xlabel: S(P + 'cv.lam'), ylabel: S(P + 'cv.q') });
      kit.curve(c, PO.omega.map(function (o, i) { return [o, Math.max(1e-4, Math.abs(PO.Q_post[i]))]; }), ax.x, ax.y, kit.accent(), 1.6);
      c.strokeStyle = kit.ink(); c.lineWidth = 2.5; c.beginPath(); c.moveTo(box.l, box.b - 1); c.lineTo(box.r, box.b - 1); c.stroke(); txt(c, S(P + 'cv.qzero'), box.l + 4, box.b - 6, kit.ink(), 'left', 10);
      var xo = ax.x(OMS[st.pw]); c.strokeStyle = kit.warm(); c.setLineDash([2, 3]); c.beginPath(); c.moveTo(xo, box.t); c.lineTo(xo, box.b); c.stroke(); c.setLineDash([]);
    }
    function drawPm() {
      var c = cPm.ctx, w = cPm.w, h = cPm.h, side = Math.min(w, h) - 12, ox = (w - side) / 2, oy = 6; c.clearRect(0, 0, w, h);
      plateMap(c, fdR, ox, oy, side, Math.cos(TAU * 0.5 * st.t), true);
      var d = PO.drive.d, a = P2(ox, oy, side, d, PO.drive.y_b), b = P2(ox, oy, side, -d, PO.drive.y_b);
      c.font = '700 14px system-ui, sans-serif'; c.textAlign = 'center'; c.fillStyle = kit.red; c.fillText('+F', a[0] + 10, a[1] - 6); c.fillStyle = kit.blue; c.fillText('−F', b[0] - 10, b[1] - 6);
      [[a, kit.red], [b, kit.blue]].forEach(function (q) { c.fillStyle = q[1]; c.beginPath(); c.arc(q[0][0], q[0][1], 4, 0, TAU); c.fill(); });
      if (st.pp === 'post') { var p = P2(ox, oy, side, PO.post[0], PO.post[1]); c.fillStyle = kit.ink(); c.beginPath(); c.arc(p[0], p[1], 5, 0, TAU); c.fill(); txt(c, S(P + 'cv.post'), p[0] + 8, p[1] + 4, kit.ink(), 'left', 10); }
      c.setLineDash([4, 4]); c.strokeStyle = kit.violet; var m0 = P2(ox, oy, side, 0, -1), m1 = P2(ox, oy, side, 0, 1); c.beginPath(); c.moveTo(m0[0], m0[1]); c.lineTo(m1[0], m1[1]); c.stroke(); c.setLineDash([]);
    }

    // ================================================================ (iv) the air
    var p4 = kit.panel_(root, P + 'panel.air', S), g4 = grid(p4);
    var cH = cv(g4, 0.62, 260), cA = cv(g4, 0.62, 260), k4 = kit.controls(p4);
    var playA = kit.button(k4, 'exp.common.play', S, function () { toggle('air', playA, function () { knock(); return { upd: knock, stop: function () { } }; }); });
    kit.slider(k4, { S: S, id: P + 'air.aspect', min: 1, max: 20, log: true, value: st.asp, fmt: function (v) { return kit.num(v, 2) + ' : 1'; }, onchange: function (v) { st.asp = v; readA(); upd('air'); } });
    kit.seg(k4, { S: S, ids: [P + 'air.a4', P + 'air.a5', P + 'air.a6'], values: [0, 1, 2], value: 1, onchange: function (v) { st.area = v; readA(); } });
    var rA1 = kit.readout(p4), rA2 = kit.readout(p4); ['cap.air', 'cap.air2', 'hear.air'].forEach(function (k) { line(p4, k); });
    var A0R = AIR.violin.round_hole.A0_elastic, LA = AIR.aspect.map(Math.log);
    function airAt(key, r) { return kit.interp(LA.map(function (x, i) { return [x, AIR[key][i]]; }), Math.log(r)); }
    function A0(r) { var cr = airAt('C_ratio', r); return cr == null ? null : A0R * Math.sqrt(cr); }   // f ∝ √C, from the circular hole's A0
    function fAsp(i) { var a = AIR.violin.L_m / 2, S2 = AIR.violin.areas_cm2[i] * 1e-4; return Math.PI * a * a / S2; }   // an ellipse of the hole's length and area
    function readA() {
      var cr = airAt('C_ratio', st.asp), pr = airAt('perimeter_ratio', st.asp), f = A0(st.asp);
      rA1.textContent = f == null ? OUT : R('air.rd', { c: kit.num(cr, 4), p: kit.num(pr, 4), f: kit.num(f, 1), s: kit.num(12 * Math.log2(f / A0R), 2), r: kit.num(A0R, 1) });
      rA2.textContent = R('air.rd.f', { a: String(AIR.violin.areas_cm2[st.area]), x: kit.num(fAsp(st.area), 2), f: kit.num(AIR.violin.A0_elastic[st.area], 1), g: kit.num(AIR.violin.A0_rigid[st.area], 1), m1: String(AIR.violin.measured_band[0]), m2: String(AIR.violin.measured_band[1]) });
    }
    function drawHole() {
      var c = cH.ctx, w = cH.w, h = cH.h, base = (h / 2 - 16) / 4.6; c.clearRect(0, 0, w, h);   // equal area: semi-axes base·√r and base/√r
      [w * 0.3, w * 0.7].forEach(function (x, k) { c.save(); c.translate(x, h / 2); c.rotate(k ? 0.12 : -0.12); c.fillStyle = kit.ink(); c.globalAlpha = 0.85; c.beginPath(); c.ellipse(0, 0, base * Math.sqrt(st.asp), base / Math.sqrt(st.asp), Math.PI / 2, 0, TAU); c.fill(); c.restore(); });
      c.strokeStyle = kit.muted(); c.setLineDash([3, 3]); c.beginPath(); c.arc(w / 2, h / 2, base, 0, TAU); c.stroke(); c.setLineDash([]);
      txt(c, S(P + 'cv.hole'), w / 2, h - 8, kit.muted(), 'center', 11);
    }
    function drawA0() {
      var c = cA.ctx, w = cA.w, h = cA.h, box = { l: 46, r: w - 10, t: 10, b: h - 34 }; c.clearRect(0, 0, w, h);
      var ax = kit.axes(c, box, { xmin: 1, xmax: 20, xlog: true, ymin: 250, ymax: 330, xticks: [1, 2, 5, 10, 20], yticks: [260, 280, 300, 320], xlabel: S(P + 'cv.aspect'), ylabel: S(P + 'cv.a0') });
      var mb = AIR.violin.measured_band; c.fillStyle = kit.accent(); c.globalAlpha = 0.12; c.fillRect(box.l, ax.y(mb[1]), box.r - box.l, ax.y(mb[0]) - ax.y(mb[1])); c.globalAlpha = 1; txt(c, S(P + 'cv.band'), box.r - 4, ax.y(mb[1]) - 3, kit.accent(), 'right', 10);
      var pts = []; for (var i = 0; i <= 80; i++) { var r = Math.exp(Math.log(20) * i / 80); pts.push([r, A0(r)]); } kit.curve(c, pts, ax.x, ax.y, kit.ink(), 1.6);
      AIR.violin.areas_cm2.forEach(function (s, k) { var x = ax.x(fAsp(k)), y = ax.y(AIR.violin.A0_elastic[k]); c.fillStyle = k === st.area ? kit.warm() : kit.muted(); c.beginPath(); c.arc(x, y, k === st.area ? 5 : 3.5, 0, TAU); c.fill(); });
      txt(c, S(P + 'cv.fhole'), ax.x(fAsp(st.area)) + 7, ax.y(AIR.violin.A0_elastic[st.area]) + 4, kit.warm(), 'left', 10);
      var f = A0(st.asp); if (f != null) { c.strokeStyle = kit.accent(); c.lineWidth = 2; c.beginPath(); c.moveTo(ax.x(st.asp), box.b); c.lineTo(ax.x(st.asp), ax.y(f)); c.stroke(); c.fillStyle = kit.accent(); c.beginPath(); c.arc(ax.x(st.asp), ax.y(f), 4, 0, TAU); c.fill(); }
    }
    function knock() { var a = kit.audio(), f = A0(st.asp); if (!a || f == null) return; var Q = 20, tau = Q / (Math.PI * f), t0 = a.ctx.currentTime + 0.01, o = a.ctx.createOscillator(), g = a.ctx.createGain(); o.frequency.value = f; g.gain.setValueAtTime(0, t0); g.gain.linearRampToValueAtTime(0.3, t0 + 0.002); g.gain.setTargetAtTime(0, t0 + 0.002, tau); o.connect(g); g.connect(a.master); o.start(t0); o.stop(t0 + 10 * tau + 0.05); }

    // ================================================================ (v) the wolf
    var p5 = kit.panel_(root, P + 'panel.wolf', S), g5 = grid(p5);
    var cF = cv(g5, 0.7, 280), cB = cv(g5, 0.7, 280), k5 = kit.controls(p5);
    var playW = kit.button(k5, 'exp.common.play', S, function () { toggle('wolf', playW, startWolf); });
    kit.slider(k5, { S: S, id: P + 'wolf.q', min: 0, max: WO.Q_list.length - 1, step: 1, value: 0, fmt: function (v) { return kit.num(WO.Q_list[Math.round(v)], 1); }, onchange: function (v) { st.wq = Math.round(v); readWolf(); upd('wolf'); } });
    var rW1 = kit.readout(p5), rW2 = kit.readout(p5), rWslow = kit.readout(p5); ['cap.wolf', 'cap.wolf2', 'hear.wolf'].forEach(function (k) { line(p5, k); });
    var WIN = 0.4, WSLOW = 10;
    function wr() { return WO.roots_exact[st.wq]; }
    function readWolf() {
      var r = wr(), d = r[2] - r[0];
      rW1.textContent = R('wolf.rd', { q: kit.num(WO.Q_list[st.wq], 1), f1: kit.num(r[0], 3), f2: kit.num(r[2], 3), g1: kit.num(r[1], 3), g2: kit.num(r[3], 3), d: kit.num(d, 3), t: kit.num(1000 / d, 1) });
      rW2.textContent = R('wolf.rd.th', { q: kit.num(WO.Q_threshold, 3), s: kit.num(WO.split_formula, 3), e: kit.num(WO.split_exact_Q30, 4) });
      rWslow.textContent = S('exp.common.slowed.pic').replace('{n}', String(WSLOW));
    }
    function drawF() {
      var c = cF.ctx, w = cF.w, h = cF.h, box = { l: 50, r: w - 10, t: 10, b: h - 34 }; c.clearRect(0, 0, w, h);
      var ax = kit.axes(c, box, { xmin: 4, xmax: 31, ymin: 168, ymax: 182, xticks: [5, 10, 15, 20, 25, 30], yticks: [170, 175, 180], xlabel: S(P + 'cv.qq'), ylabel: S(P + 'cv.ref') });
      var Q = WO.Q_list, E = WO.roots_exact, Qd = WO.roots_quadratic, ord = Q.map(function (q, i) { return i; }).sort(function (a, b) { return Q[a] - Q[b]; });
      [0, 2].forEach(function (k) { kit.curve(c, ord.map(function (i) { return [Q[i], Qd[i][k]]; }), ax.x, ax.y, kit.warm(), 1.3, [4, 3]); kit.curve(c, ord.map(function (i) { return [Q[i], E[i][k]]; }), ax.x, ax.y, kit.blue, 1.8); });
      ord.forEach(function (i) { [0, 2].forEach(function (k) { c.fillStyle = kit.blue; c.beginPath(); c.arc(ax.x(Q[i]), ax.y(E[i][k]), 2.5, 0, TAU); c.fill(); }); });
      c.strokeStyle = kit.muted(); c.setLineDash([2, 3]); c.beginPath(); c.moveTo(box.l, ax.y(WO.f_b)); c.lineTo(box.r, ax.y(WO.f_b)); c.stroke();
      c.strokeStyle = kit.red; c.beginPath(); c.moveTo(ax.x(WO.Q_threshold), box.t); c.lineTo(ax.x(WO.Q_threshold), box.b); c.stroke(); c.setLineDash([]);
      txt(c, S(P + 'cv.qstar'), ax.x(WO.Q_threshold) + 4, box.b - 6, kit.red, 'left', 10); txt(c, S(P + 'cv.fb'), box.r - 4, ax.y(WO.f_b) - 4, kit.muted(), 'right', 10);
      txt(c, S(P + 'cv.exact'), box.r - 4, box.t + 12, kit.blue, 'right', 10); txt(c, S(P + 'cv.quad'), box.r - 4, box.t + 25, kit.warm(), 'right', 10);
      var r = wr(); c.strokeStyle = kit.accent(); c.lineWidth = 2; c.beginPath(); c.arc(ax.x(Q[st.wq]), ax.y(r[0]), 6, 0, TAU); c.moveTo(ax.x(Q[st.wq]) + 6, ax.y(r[2])); c.arc(ax.x(Q[st.wq]), ax.y(r[2]), 6, 0, TAU); c.stroke();
    }
    function drawBeat() {
      var c = cB.ctx, w = cB.w, h = cB.h, box = { l: 30, r: w - 10, t: 18, b: h - 34 }, r = wr(); c.clearRect(0, 0, w, h);
      var ax = kit.axes(c, box, { xmin: 0, xmax: WIN * 1000, ymin: -2.1, ymax: 2.1, xticks: [0, 100, 200, 300, 400], xlabel: S(P + 'cv.t') });
      function y(t) { return Math.exp(-TAU * r[1] * t) * Math.cos(TAU * r[0] * t) + Math.exp(-TAU * r[3] * t) * Math.cos(TAU * r[2] * t); }
      function env(t) { var a = Math.exp(-TAU * r[1] * t), b = Math.exp(-TAU * r[3] * t); return Math.sqrt(a * a + b * b + 2 * a * b * Math.cos(TAU * (r[2] - r[0]) * t)); }
      var cur = (st.t / WSLOW) % WIN, n = Math.max(400, Math.round((box.r - box.l) * 3)), pts = [], ep = [], em = [];
      for (var i = 0; i <= n; i++) { var t = WIN * i / n; if (t > cur) break; pts.push([t * 1000, y(t)]); }
      for (i = 0; i <= 200; i++) { var tt = WIN * i / 200, e = env(tt); ep.push([tt * 1000, e]); em.push([tt * 1000, -e]); }
      kit.curve(c, pts, ax.x, ax.y, kit.ink(), 0.8); kit.curve(c, ep, ax.x, ax.y, kit.accent(), 1.6); kit.curve(c, em, ax.x, ax.y, kit.accent(), 1.6);
      txt(c, S(P + 'cv.beat'), box.l + 4, 12, kit.muted(), 'left', 10);
    }
    function startWolf(a) {
      var r = wr(), v1 = kit.voice({ f: r[0], gain: 0.12 }), v2 = kit.voice({ f: r[2], gain: 0.12 });
      return { upd: function () { var q = wr(); v1.set(q[0], 0.12); v2.set(q[2], 0.12); }, stop: function () { v1.stop(); v2.stop(); } };
    }

    // ================================================================ start
    readS(); setPlate(); readC(); setPost(); readA(); readWolf();
    kit.loop(function (t, dt) { if (!st.paused) st.t += dt; drawString(); drawWedge(); drawPlate(); drawW1(); drawChain(); drawQ(); drawPm(); drawHole(); drawA0(); drawF(); drawBeat(); });
  } };
})();
