// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// check_r6.mjs — the narrator's own check of a release-6 draft (it/draft/r6_E1.json or r6_E2.json) before the merge.
// Usage: node it/draft/check_r6.mjs it/draft/r3_A.json        (exit 1 on any error; warnings are for the narrator's eye)
// Checks: the ids are exactly the narrator's (it/draft/r6_assign.json), each once; the banned words and the process words
// as gen/lib/italian.mjs matches them (the checker's own functions); no stub marks, no markup, no TeX; the placeholders
// of each string kept; the lengths (narrations by the manifest's range, titles at most 14 words and no final period);
// English left in the text (a heuristic: English function words outside the proper names).
import fs from 'node:fs';
import path from 'node:path';
import url from 'node:url';

const HERE = path.dirname(url.fileURLToPath(import.meta.url));
const SITE = path.resolve(HERE, '..', '..');
const { bannedHits, processHits, stripNames } = await import(url.pathToFileURL(path.join(SITE, 'gen', 'lib', 'italian.mjs')).href);
const J = (p) => JSON.parse(fs.readFileSync(p, 'utf8'));
const M = J(path.join(SITE, 'gen', 'content', 'it', 'MANIFEST_R6.json'));
const EN = new Map(J(path.join(SITE, 'gen', 'content', 'strings.json')).strings.map((s) => [s.id, s]));
for (const s of (M.experiments && M.experiments.strings) || []) if (!EN.has(s.id)) EN.set(s.id, s);
for (const s of (M.strings_new || []).concat(M.strings_changed || [])) if (!EN.has(s.id)) EN.set(s.id, s);
const A = J(path.join(HERE, 'r6_assign.json'));
const file = process.argv[2];
if (!file) { console.log('usage: node it/draft/check_r6.mjs it/draft/r6_X.json'); process.exit(2); }
const D = J(path.resolve(file));
const who = D.narrator;
if (!A[who]) { console.log(`"narrator" must be one of ${Object.keys(A).join(', ')}`); process.exit(1); }
const as = A[who];
let errors = 0, warnings = 0;
const err = (m) => { errors++; console.log('  ERROR ' + m); };
const warn = (m) => { warnings++; console.log('  warn  ' + m); };
const words = (t) => String(t).trim().split(/\s+/).filter(Boolean).length;
const EN_FN = /\b(the|and|of|with|which|is|are|from|into|that|this|for|its|by|not|on|at|as)\b/giu;
const englishLeft = (t) => { const s = stripNames(t).replace(/\b[A-Z]{2,}[\w.·-]*/g, ' '); const m = s.match(EN_FN) || []; return m; };
const textChecks = (where, t, { stamp = false, about = false } = {}) => {
  if (typeof t !== 'string' || !t.trim()) return err(`${where}: empty text`);
  if (/\[bozza\]/i.test(t)) err(`${where}: still a stub`);
  if (/<\/?[a-z][^>]*>/i.test(t)) err(`${where}: markup in the text`);
  if (/\*\*|__|`/.test(t)) err(`${where}: markdown in the text`);
  if (/\$|\\[a-zA-Z]/.test(t)) err(`${where}: TeX in the text (write the notation as the records print it: ω², ℤ₁₂, √3)`);
  const b = bannedHits(t, { stamp }); if (b.length) err(`${where}: banned word(s): ${[...new Set(b)].join(', ')}`);
  const p = about ? [] : processHits(t, 'it'); if (p.length) err(`${where}: process word(s): ${[...new Set(p)].join(', ')}`); // the Method page alone may say where the work comes from (as the site's checker allows)
  const e = englishLeft(t); if (e.length >= 2) warn(`${where}: English words left? ${[...new Set(e.map((x) => x.toLowerCase()))].join(', ')}`);
};
const lengthRange = (s) => { const m = /(\d+)\s*[–-]\s*(\d+)/.exec(String(s || '')); return m ? [+m[1], +m[2]] : null; };
const mN = new Map(M.narrations.map((n) => [n.target, n]));
const mT = new Map(M.titles.map((t) => [t.target, t]));

// narrations
const seenN = new Set();
for (const it of D.racconto || []) {
  const where = `racconto ${it.id}`;
  if (it.id !== 'r:' + it.target) err(`${where}: id must be "r:" + target`);
  if (seenN.has(it.target)) err(`${where}: target twice`); seenN.add(it.target);
  if (!as.narrations.includes(it.target) && !as.rewrite_narrations.includes(it.target) && !(as.check_only || []).includes(it.target)) err(`${where}: not this narrator's target`);
  if (!Array.isArray(it.tells) || !it.tells.length) err(`${where}: tells must list what the narration draws on`);
  textChecks(where, it.text);
  const r = lengthRange(mN.get(it.target) && mN.get(it.target).length);
  if (r) { const n = words(it.text); if (n < r[0] * 0.9 || n > r[1] * 1.1) warn(`${where}: ${n} words (asked ${r[0]}–${r[1]})`); }
  if (!it.why) warn(`${where}: no why`);
}
for (const t of as.narrations) if (!seenN.has(t)) err(`racconto: missing r:${t}`);
// titles
const seenT = new Set();
for (const it of D.titoli || []) {
  const where = `titoli ${it.id}`;
  if (it.id !== 't:' + it.target) err(`${where}: id must be "t:" + target`);
  if (seenT.has(it.target)) err(`${where}: target twice`); seenT.add(it.target);
  if (!as.titles.includes(it.target) && !as.rewrite_titles.includes(it.target)) err(`${where}: not this narrator's target`);
  textChecks(where, it.text);
  const what = (mT.get(it.target) && mT.get(it.target).what) || '';
  const lim = /≤\s*(\d+)\s*words/.exec(what);
  const n = words(it.text);
  if (lim && n > +lim[1]) warn(`${where}: ${n} words (at most ${lim[1]})`);
  if (!lim && n > 40) warn(`${where}: ${n} words`);
  if (/no final period/.test(what) && /\.\s*$/.test(it.text) && !/…\s*$/.test(it.text)) err(`${where}: no final period on a title`);
}
for (const t of as.titles) if (!seenT.has(t)) err(`titoli: missing t:${t}`);
// strings
const seenS = new Set();
const ph = (t) => [...String(t).matchAll(/\{[a-zA-Z0-9_.]+\}/g)].map((m) => m[0]).sort().join(' ');
for (const it of D.strings || []) {
  const where = `strings ${it.id}`;
  if (seenS.has(it.id)) err(`${where}: twice`); seenS.add(it.id);
  if (!as.strings.includes(it.id)) err(`${where}: not this narrator's string`);
  const en = EN.get(it.id);
  if (!en) { err(`${where}: no such English string`); continue; }
  textChecks(where, it.text, { stamp: it.id === 'release.stamp', about: /^(about\.|method\.)/.test(it.id) });
  if (it.id.startsWith('exp.') && it.text.length > 1.7 * en.text.length + 12) warn(`${where}: Italian is much longer than the English label (${it.text.length} vs ${en.text.length} characters)`);
  if (ph(en.text) !== ph(it.text)) err(`${where}: placeholders ${ph(en.text) || '(none)'} in English, ${ph(it.text) || '(none)'} in Italian`);
}
for (const s of as.strings) if (!seenS.has(s)) err(`strings: missing ${s}`);
console.log(`${path.basename(file)}: ${seenN.size} narrations, ${seenT.size} titles, ${seenS.size} strings; ${errors} errors, ${warnings} warnings`);
process.exit(errors ? 1 : 0);
