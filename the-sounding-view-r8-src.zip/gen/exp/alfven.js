// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// alfven.js — "Sound beside the field": the field line as a string, the two speeds across it, a wave in a moving medium.
(function () {
  'use strict';
  window.SDV_EXP = window.SDV_EXP || {};
  var SL = 'alfven', P = 'exp.alfven.';
  window.SDV_EXP[SL] = { mount: function (root, data, S, kit) {
    var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
    root.classList.add('two');
    var VA = data.alfven_slope;                 // the Alfvén line omega = VA k, in omega_ce per (omega_pe/c)
    var VAc = VA / 2;                           // the same in units of c: omega_pe = 2 omega_ce in the data's plasma
    function rat(p) { return (p[0] / p[1]) / VA; }  // omega/k of a branch's first point against the Alfvén slope
    var rR = rat(data.R_low[0]), rL = rat(data.L_low[0]), rX = rat(data.X_low[0]);
    var F0 = 110, K0 = 0.1;                     // k = 0.1 omega_pe/c  <->  110 Hz
    var st = { k: 0.1, u: 0, snd: false, paused: reduce, t: 0, doppler: null, hasAudio: true };
    function cvs(panel, a, m) { var b = kit.el('div'); panel.appendChild(b); return kit.canvas(b, a, m); }
    function freq() { return F0 * st.k / K0; }

    // ---------------------------------------------------------------- (a) the field line as a string
    var pa = kit.panel_(root, P + 'panel.line', S);
    var ctl = kit.controls(pa);
    var bPlay = kit.button(ctl, 'exp.common.play', S, function () {
      st.snd = !st.snd;
      bPlay.textContent = S(st.snd ? 'exp.common.mute' : 'exp.common.play'); bPlay.setAttribute('data-s', st.snd ? 'exp.common.mute' : 'exp.common.play');
      if (st.snd) { if (!kit.audio()) { st.hasAudio = false; note.style.display = ''; st.snd = false; return; } startDoppler(); } else stopDoppler();
    });
    kit.button(ctl, 'exp.common.pluck', S, pluck);
    var bPause = kit.button(ctl, 'exp.common.pause', S, function () { st.paused = !st.paused; bPause.setAttribute('aria-pressed', String(st.paused)); });
    bPause.setAttribute('aria-pressed', String(st.paused));
    var kS = kit.slider(ctl, { id: P + 'k', S: S, min: 0.05, max: 0.4, step: 0.01, value: 0.1, fmt: function (v) { return kit.num(v, 2); }, onchange: function (v) { st.k = v; update(); } });
    var note = kit.line(pa, 'exp.common.noaudio', S, 'exp-note'); note.style.display = 'none';
    var cv = cvs(pa, 0.42, 300);
    kit.line(pa, P + 'cap.line', S);
    var rdA = kit.readout(pa), rdS = kit.readout(pa);

    // ---------------------------------------------------------------- (b) the two speeds
    var pb = kit.panel_(root, P + 'panel.speeds', S);
    var cp = cvs(pb, 0.8, 330);
    kit.line(pb, P + 'cap.speeds', S);
    kit.line(pb, P + 'cap.notdrawn', S, 'exp-note');
    var rdB = kit.readout(pb);

    // ---------------------------------------------------------------- (c) a wave in a moving medium
    var pc = kit.panel_(root, P + 'panel.doppler', S, 'span');
    var ctl2 = kit.controls(pc);
    var uS = kit.slider(ctl2, { id: P + 'u', S: S, min: -0.9, max: 0.9, step: 0.05, value: 0, fmt: function (v) { return (v > 0 ? '+' : '') + kit.num(v, 2) + ' v_A'; }, onchange: function (v) { st.u = v; update(); } });
    var cd = cvs(pc, 0.26, 190);
    kit.line(pc, P + 'cap.doppler', S);
    var rdC = kit.readout(pc);

    // ---------------------------------------------------------------- sound
    function pluck() {
      st.t = 0;
      if (!st.snd) return;
      var f = freq();
      kit.strike([{ f: f, a: 1, decay: 0.9 }, { f: f * 2, a: 0.25, decay: 0.45 }, { f: f * rX, a: 0.6, decay: 0.7 }], 0.14);
    }
    function startDoppler() { if (st.doppler) return; st.doppler = kit.voice({ f: freq() * (1 + st.u), gain: 0.06, type: 'sine' }); }
    function stopDoppler() { if (st.doppler) { st.doppler.stop(); st.doppler = null; } }
    function update() {
      if (st.doppler) st.doppler.set(freq() * (1 + st.u), 0.06);
      var w = VA * st.k, wd = w * st.u;
      rdC.textContent = 'ω = ' + kit.num(w, 5) + ' ω_ce   k·U = ' + kit.num(wd, 5) + ' ω_ce   ω′ = ω + k·U = ' + kit.num(w + wd, 5) + ' ω_ce   (' + kit.num(freq() * (1 + st.u), 1) + ' Hz)';
      rdA.textContent = 'v_A = ' + kit.num(VA, 4) + ' (ω_ce per ω_pe/c) = ' + kit.num(VAc, 4) + ' c;  ω = v_A k = ' + kit.num(w, 5) + ' ω_ce at k = ' + kit.num(st.k, 2) + ' ω_pe/c  →  ' + kit.num(freq(), 1) + ' Hz';
    }
    update();

    // ---------------------------------------------------------------- drawing
    var WID = 0.08;
    function bump(s) { var a = 0; for (var j = -1; j <= 1; j++) { var q = (s + j) / (WID * 0.1 / st.k); a += Math.exp(-q * q); } return a; }
    function drawLine(t) {
      var c = cv.ctx, W = cv.size().w, H = cv.h; c.clearRect(0, 0, W, H);
      var T = 4, v = 1 / T, s0 = (st.t * v) % 1, fade = Math.exp(-st.t / 14);
      var rows = 5, mid = 2, ink = kit.ink(), acc = kit.accent();
      c.font = '11px system-ui, sans-serif'; c.fillStyle = kit.muted(); c.textAlign = 'left';
      c.fillText('B₀', 6, 14);
      for (var r = 0; r < rows; r++) {
        var y0 = H * (0.18 + 0.64 * r / (rows - 1)), env = Math.exp(-Math.pow((r - mid) / 1.15, 2));
        var live = true, amp = H * 0.16 * env * fade;
        c.strokeStyle = r === mid ? acc : kit.muted(); c.lineWidth = r === mid ? 2 : 1; c.beginPath();
        for (var i = 0; i <= 200; i++) {
          var x = i / 200, y = y0 - (live ? amp * 0.5 * (bump(x - 0.5 - s0) + bump(x - 0.5 + s0)) : 0);
          if (i === 0) c.moveTo(x * W, y); else c.lineTo(x * W, y);
        }
        c.stroke();
        // parcels tied to the line
        c.fillStyle = r === mid ? acc : ink;
        for (var p = 0; p < 12; p++) { var xp = (p + 0.5) / 12, yp = y0 - (live ? amp * 0.5 * (bump(xp - 0.5 - s0) + bump(xp - 0.5 + s0)) : 0); c.beginPath(); c.arc(xp * W, yp, r === mid ? 3.2 : 2.2, 0, 6.2832); c.fill(); }
      }
      kit.arrow(c, W * 0.5 + 6, H - 8, W * 0.5 + 6 + 26, H - 8, kit.muted(), 1.2);
      var f = freq(), wcross = 4 * WID * 0.1 / st.k, n = Math.max(1, Math.round(f * wcross * T));
      rdS.textContent = S('exp.common.slowed').replace('{n}', kit.num(n, 0));
    }
    function drawPolar() {
      var c = cp.ctx, W = cp.size().w, H = cp.h; c.clearRect(0, 0, W, H);
      var cx = W / 2, cy = H / 2, R = Math.min(W, H) * 0.40 / 1.1, muted = kit.muted();
      c.strokeStyle = muted; c.lineWidth = 1; c.fillStyle = muted; c.font = '11px system-ui, sans-serif'; c.textAlign = 'center';
      [0.5, 1].forEach(function (q) { c.setLineDash(q === 1 ? [] : [3, 3]); c.beginPath(); c.arc(cx, cy, R * q, 0, 6.2832); c.stroke(); }); c.setLineDash([]);
      c.beginPath(); c.moveTo(cx - R * 1.15, cy); c.lineTo(cx + R * 1.15, cy); c.moveTo(cx, cy - R * 1.15); c.lineTo(cx, cy + R * 1.15); c.stroke();
      c.fillText('B₀', cx + R * 1.15 - 8, cy - 6); c.fillText('v_A', cx + R + 2, cy + 14);
      // the shear Alfvén wave: v_A cos θ (a circle through the origin)
      c.strokeStyle = kit.blue; c.lineWidth = 1.6; c.beginPath();
      for (var i = 0; i <= 120; i++) { var th = -Math.PI + 2 * Math.PI * i / 120, rr = Math.cos(th) * R; var x = cx + rr * Math.cos(th), y = cy - rr * Math.sin(th); if (i === 0) c.moveTo(x, y); else c.lineTo(x, y); }
      c.stroke();
      // the data's points: along B (R and L, their low ends) and across B (X)
      function pt(r, th, col, lab, dx, dy) { c.fillStyle = col; c.beginPath(); c.arc(cx + r * R * Math.cos(th), cy - r * R * Math.sin(th), 4.5, 0, 6.2832); c.fill(); c.fillStyle = col; c.textAlign = 'left'; c.fillText(lab, cx + r * R * Math.cos(th) + dx, cy - r * R * Math.sin(th) + dy); }
      pt(rR, 0, kit.red, 'R', 8, -8); pt(rL, 0, kit.blue, 'L', 8, 14); pt(rR, Math.PI, kit.red, 'R', -16, -8); pt(rL, Math.PI, kit.blue, 'L', -16, 14);
      pt(rX, Math.PI / 2, kit.accent(), 'X', 8, 4); pt(rX, -Math.PI / 2, kit.accent(), 'X', 8, 4);
      rdB.textContent = 'ω/k ÷ v_A:  R ' + kit.num(rR, 4) + ',  L ' + kit.num(rL, 4) + ' (along B₀, first points of the branches);  X ' + kit.num(rX, 4) + ' (across B₀)';
    }
    function drawDoppler(t) {
      var c = cd.ctx, W = cd.size().w, H = cd.h; c.clearRect(0, 0, W, H);
      var k = st.k, nw = 2 + 20 * k, kk = 2 * Math.PI * nw, w = 2 * Math.PI / 4, wp = w * (1 + st.u);
      c.strokeStyle = kit.muted(); c.lineWidth = 1; c.setLineDash([3, 3]); c.beginPath();
      for (var i = 0; i <= 240; i++) { var x = i / 240, y = H / 2 - H * 0.3 * Math.cos(kk * x - w * t); if (i === 0) c.moveTo(x * W, y); else c.lineTo(x * W, y); } c.stroke(); c.setLineDash([]);
      c.strokeStyle = kit.accent(); c.lineWidth = 2; c.beginPath();
      for (i = 0; i <= 240; i++) { x = i / 240; y = H / 2 - H * 0.3 * Math.cos(kk * x - wp * t); if (i === 0) c.moveTo(x * W, y); else c.lineTo(x * W, y); } c.stroke();
      // the observer at rest: a dot at x = 1/2 following the wave seen there
      c.fillStyle = kit.ink(); c.beginPath(); c.arc(W / 2, H / 2 - H * 0.3 * Math.cos(kk * 0.5 - wp * t), 4, 0, 6.2832); c.fill();
    }
    var clock = 0;
    kit.loop(function (t, dt) {
      if (!st.paused) { st.t += dt; clock += dt; }
      drawLine(); drawPolar(); drawDoppler(clock);
    });
    explain(root, SL, S, kit);
  } };

  function explain(root, slug, S, kit) {
    var p = kit.panel_(root, null, S, 'span');
    var a = kit.panel_(p, 'exp.common.see', S); kit.line(a, 'exp.' + slug + '.see', S);
    var h = kit.panel_(p, 'exp.common.hear', S); kit.line(h, 'exp.' + slug + '.hear', S);
    var d = kit.el('p', { class: 'exp-source' }, [kit.el('b', { 'data-s': 'exp.common.data', text: S('exp.common.data') }), ' ', kit.el('span', { 'data-s': 'exp.' + slug + '.data', text: S('exp.' + slug + '.data') })]); p.appendChild(d);
  }
})();
