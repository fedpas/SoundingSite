// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// manifest_titoli.mjs — writes content/it/MANIFEST_TITOLI.json for the Italian narrators (BRIEF_R2b.md §2): every target of
// the third Italian table titoli.json (the short titles, claims, captions and labels of the Italian pages) with the English
// material it stands on, the length asked, and where the page renders it; then strings_new (the strings added in the
// second pass, with their English text and why), strings_changed (the strings whose English text changed in the second
// pass, old and new) and strings_removed. Usage: node gen/manifest_titoli.mjs [REPO]
import fs from 'node:fs';
import path from 'node:path';
import { load, applyPart, textKey, firstSentence, GEN, SITE } from './lib/sources.mjs';
import { mdPlain } from './lib/md.mjs';
import { SCRIPTS } from './lib/pack.mjs';
import { processHits } from './lib/italian.mjs';

const REPO = path.resolve(process.argv[2] || process.env.SDV_ATLAS || path.join(path.dirname(SITE), 'repo'));
const D = load(REPO);
const P = D.pack;
const J = (p) => JSON.parse(fs.readFileSync(p, 'utf8'));
const cur = J(path.join(GEN, 'content', 'strings.json')).strings;
const curById = new Map(cur.map((s) => [s.id, s]));
const S = (id) => (curById.get(id) || { text: '' }).text;
const targets = [];
const T = (target, what, material, length, where) => targets.push({ target, id: 't:' + target, what, material, length, where });
const SECS = D.placements.order.map((id, i) => { const s = D.page.sections.find((x) => x.id === id); return { id, n: i + 1, slug: D.placements.sections[id].slug, title: s.title, lead: s.lead, chain: [...D.chains.values()].find((c) => c.section === id) }; });
const research = (id) => { const t = D.texts.get(textKey(id, 'research', 'full')); return t ? t.body : null; };
const statusOf = (id) => (D.status[id] ? D.status[id].status : (P.rows.get(id) || {}).status);

// the sections, their chains and their cards
for (const s of SECS) {
  const lead = research(s.lead);
  const rows = s.chain.rows.map((r) => `${r} (${statusOf(r)})`);
  T(`section:${s.slug}`, `the title of section ${s.n} (${s.slug}): the page's h1 and the home card's title`, { titles: s.title, lead: { id: s.lead, text: lead }, rows }, '≤ 8 words', `${s.slug}.html h1; index.html the card's title`);
  T(`section:${s.slug}:sub`, `one line under the title of section ${s.n}: the Italian counterpart of its physics and mathematics titles, in one line`, { titles: s.title, lead: { id: s.lead, text: firstSentence(lead) } }, 'one line, ≤ 16 words', `${s.slug}.html under the h1`);
  T(`chain:${s.slug}`, `the heading of the rows' list on section ${s.n}'s page (the chain's title)`, { chain: s.chain.id, titles: s.chain.title, rows }, '≤ 10 words', `${s.slug}.html, the heading above the rows`);
  T(`card:section:${s.slug}`, `the home card's text for section ${s.n}: what the section is about, in two or three sentences`, { titles: s.title, lead: { id: s.lead, text: lead }, rows }, '40–70 words', `index.html, the card's text`);
}
// the page of the bridges
const byline = P.study.byId.get('top.2').text, abstract = P.study.byId.get('top.3').text;
T('page:bridges', 'the h1 of the page of the bridges (EN "The bridges")', { study: 'The bridges drilled', en: { title: S('b.title'), sub: S('b.sub'), lead: S('b.lead') }, byline, abstract: abstract.slice(0, 1200) }, '≤ 6 words', 'bridges.html h1; the navigation says Ponti');
T('page:bridges:sub', 'the one-line subtitle under the h1 of the page of the bridges', { en: { title: S('b.title'), sub: S('b.sub'), lead: S('b.lead') }, abstract: abstract.slice(0, 1200) }, 'one line, ≤ 16 words', 'bridges.html under the h1');
T('page:bridges:head', 'the one line that replaces the study\'s byline: what the study is, for whom, when (no process words: not "round", "pack", "merged", "proposed", "release 4.4.9", "owner", "research note", "drill")', { byline, en: { lead: S('b.lead') } }, 'one line, ≤ 25 words', 'bridges.html under the subtitle; the English byline stands in a disclosure beneath it');
T('card:page:bridges', 'the home card\'s text for the page of the bridges: the eleven bridges, what was computed, what the reader finds', { en: { card: S('b.lead') }, abstract: abstract.slice(0, 1600), rows: [...P.rows.values()].map((r) => `${r.id} (${r.status})`) }, '40–70 words', 'index.html, the ninth card\'s text');
// the rows: the Atlas's 27 and the 36 of the bridges
for (const s of SECS) for (const id of s.chain.rows) { const row = D.rows.get(id); T(`row:${id}`, `the one-line claim of the row ${id} (section ${s.slug}), the head of its block: ≤ 14 words, no final period`, { id, status: statusOf(id), homePhys: row.homePhys || null, homeMath: row.homeMath || null, researchFirst: firstSentence(research(id)), enHead: row.homePhys || firstSentence(research(id)) }, '≤ 14 words, no final period', `${s.slug}.html#${id}, the block's head`); }
for (const it of P.items) for (const id of it.rows) { const r = P.rows.get(id); T(`row:${id}`, `the one-line claim of the row ${id} (item ${it.item} of the bridges), the head of its block: ≤ 14 words, no final period`, { id, status: r.status, homePhys: mdPlain(r.fields.homePhys), homeMath: mdPlain(r.fields.homeMath), researchFirst: firstSentence(r.research), enHead: mdPlain(r.fields.homePhys) }, '≤ 14 words, no final period', `bridges.html#${id}, the block's head`); }
// the figures
for (const f of D.figures) T(`fig:${f.file.replace(/\.svg$/, '')}`, `the Italian caption of the figure ${f.file} (Music on the labels)`, { file: f.file, caption: mdPlain(f.caption), data: mdPlain(f.data), rows: mdPlain(f.row) }, '15–45 words', `pictures.html and the section pages (the home for music_map.svg): the caption under the figure; the English caption stands in a disclosure`);
for (const f of P.figures) T(`fig:${f.file.replace(/\.svg$/, '')}`, `the Italian caption of the figure ${f.file} (the bridges)`, { file: f.file, caption: mdPlain(f.caption), data: mdPlain(f.data), rows: mdPlain(f.row) }, '15–45 words', `pictures.html and bridges.html: the caption under the figure; the English caption stands in a disclosure`);
// the clips
for (const c of [...D.clips, ...P.clips]) { const nn = c.file.split('_')[0]; T(`clip:${nn}`, `the short title of the clip ${c.file}`, { file: c.file, seconds: c.seconds, heardFirst: firstSentence(mdPlain(c.heard)), heard: mdPlain(c.heard) }, '≤ 10 words', `sounds.html#clip-${nn} (and the section or bridges page that holds the clip): the title line beside the clip's number`); }
// the items of the bridges
for (const it of P.items) T(`item:${it.item}`, `the Italian title of the item ${it.item} of the bridges (the heading of its part on the page)`, { en: S('b.item.' + it.item), bridgeTitle: it.bridge.title, bridges: [...it.bridge.table.keys()], rows: it.rows }, '≤ 10 words', `bridges.html#item-${it.item}, the heading`);
// the eleven bridges
for (const [n, r] of P.bridges) { T(`bridge:${n}`, `the Italian name of bridge ${n}`, { n, bridge: mdPlain(r.bridge), before: mdPlain(r[P.bridgesHead[2]]), after: mdPlain(r[P.bridgesHead[3]]), item: mdPlain(r[P.bridgesHead[4]]) }, '≤ 8 words', `bridges.html#bridges-table, the Italian table's second column`); T(`bridge:${n}:why`, `what decided bridge ${n}'s grade, in one line (the grade words themselves are strings: the table shows them beside this line)`, { n, bridge: mdPlain(r.bridge), before: mdPlain(r[P.bridgesHead[2]]), after: mdPlain(r[P.bridgesHead[3]]), item: mdPlain(r[P.bridgesHead[4]]) }, '≤ 25 words', `bridges.html#bridges-table, the Italian table's last column`); }
// the lens
D.lens.dictionary.forEach((e, i) => T(`lens:${i + 1}`, `the Italian music term of the lens entry ${i + 1}`, { n: i + 1, atlas: e.atlas, term: e.term, match: e.match, rows: e.rows || [], evidence: e.evidence || [] }, '≤ 10 words', `dictionary.html#lens-${i + 1}, the column "termine musicale" (the English term beside it, small, in a disclosure)`));
// the paper's dictionary
P.dictionary.rows.forEach((r) => T(`paper:${r.n}`, `the Italian for the Atlas column of row ${r.n} of the paper's dictionary (the object named, in the Atlas's words)`, { n: r.n, acoustics: mdPlain(r.a), electromagnetism: mdPlain(r.b), atlas: mdPlain(r.c) }, '≤ 10 words', `bridges.html#dictionary and dictionary.html#paper, the Italian column; the English table stands in a disclosure`));
// the scripts
for (const [key, label] of [['checks/selfcheck/round36/music_sound.py', 'music_sound'], ['checks/selfcheck/round36/music_symmetry.py', 'music_symmetry']]) { const rec = D.checks.get(key); T(`check:${label}`, `one line: what ${label}.py computes`, { script: label + '.py', what: rec.what, groups: rec.ids.map((x) => x.id), checks: D.runs.get(key).ok, controls: rec.controls }, '≤ 16 words', `checks.html#${label}, the line under the script's name`); }
for (const key of SCRIPTS) { const s = P.scripts.get(key); const tail = P.logs[key].find((l) => /^ALL OK/.test(l)); T(`check:${key}`, `one line: what ${key}.py computes`, { script: key + '.py', what: s.head, groups: s.order, run: tail, scope: s.scope }, '≤ 16 words', `checks.html#${key}, the line under the script's name`); }

// the strings of the second pass, against the first pass's table (../scratch/strings_r2a.json) and release 1's
const prev = J(path.join(SITE, '..', 'scratch', 'strings_r2a.json')).strings;
const prevById = new Map(prev.map((s) => [s.id, s]));
const strings_new = cur.filter((s) => !prevById.has(s.id)).map((s) => ({ id: s.id, text: s.text, why: s.why, ...(s.optional ? { optional: true } : {}) }));
const strings_changed = cur.filter((s) => prevById.has(s.id) && prevById.get(s.id).text !== s.text).map((s) => ({ id: s.id, text: s.text, was: prevById.get(s.id).text, why: s.why }));
const strings_removed = prev.filter((s) => !curById.has(s.id)).map((s) => ({ id: s.id, was: s.text }));
// the first pass's Italian tables (../scratch/it_pass1/, the narrators' merged tables of release 2 as rejected) read for
// the process words of BRIEF_R2b.md §0 still in them: the ids the second pass must reword, whether or not the English changed
const pass1 = (f) => { const fp = path.join(SITE, '..', 'scratch', 'it_pass1', f); return fs.existsSync(fp) ? J(fp) : null; };
const hitsOf = (items, textOf) => items.map((x) => [x, processHits(textOf(x), 'it')]).filter(([, h]) => h.length).map(([x, h]) => ({ id: x.id, words: [...new Set(h)] }));
const s1 = pass1('strings_it.json'), r1 = pass1('racconto.json');
const strings_it_to_reword = s1 ? hitsOf(s1.strings.filter((x) => curById.has(x.id) && !/^(about\.|method\.)/.test(x.id)), (x) => x.text) : []; // About / Il metodo may say it
const racconto_to_reword = r1 ? hitsOf(r1.items.filter((x) => x.target !== 'page:about'), (x) => x.text) : [];
const manifest = {
  about: "The manifest of the third Italian table, content/it/titoli.json (BRIEF_R2b.md §2): the short titles, claims, captions and labels the Italian pages show in their reading flow, one item per target below ({ id: 't:' + target, target, text, why }). Each target has what it is, the English material it stands on (the section's titles and lead, the row's homePhys and first research sentence, the figure's caption, the clip's 'what is heard', the item's BRIDGE.md heading, the bridge's row of the table, the lens entry, the paper row's columns, the script's first paragraph), the length asked and where the page renders it. Then strings_new (the strings added in the second pass, English text and why), strings_changed (the strings whose English text changed in the second pass: the process words left the flow; the Italian is reworded for the new text), strings_removed (ids no longer in strings.json), strings_it_to_reword and racconto_to_reword (the items of the first pass's Italian tables that still carry a process word, with the words found: each must be reworded in the second pass, whether or not its English changed). Written by gen/manifest_titoli.mjs.",
  rules: { text: 'plain text, no HTML, no markdown; names, ids, file names and notation as the records print them; numbers as the records print them', banned: 'the banned words of it/VOICE_IT.md, and the process words of BRIEF_R2b.md §0 in every table: round N, pacchetto, integrato/non integrato, proposto/a, release or versione with a number, proprietario, nota di ricerca, and any word for drill; the study titles stay as they are (Music on the labels, The bridges drilled) but The bridges drilled is named only on Fonti and Il metodo', claims: 'row:<id>: one line, ≤ 14 words, no final period, the claim as the narrator would head the block (not the id, not the English)' },
  counts: { targets: targets.length, byKind: Object.fromEntries([...new Set(targets.map((t) => t.target.split(':')[0]))].map((k) => [k, targets.filter((t) => t.target.split(':')[0] === k).length])), strings_new: strings_new.length, strings_changed: strings_changed.length, strings_removed: strings_removed.length, strings_total: cur.length, strings_it_to_reword: strings_it_to_reword.length, racconto_to_reword: racconto_to_reword.length },
  remarks: [
    "r:page:about says that a proposed row carries the outline that says so (\"una riga proposta porta anche il contorno che lo dice\"): since the second pass no row is marked; the sentence must go. Its \"con le schede dell'Atlante in inglese accanto\" is now: the records stand inside the three record registers and inside the collapsed cards, out of the reading flow.",
    "r:page:dictionary describes the columns of the English lens table (termine dell'Atlante, termine musicale, grado, evidenza, righe): on the Italian table the Atlas term and the English term are inside each row's collapsed card; the visible columns are the Italian term (t:lens:<n>), the grade, the evidence and the rows.",
    "r:page:sounds says the rows the clips illustrate are proposed (\"le righe che illustrano sono proposte\"): the sentence must go (rule 0).",
    "b.col.after reads After in English; the first pass made it Proposto. It is in strings_it_to_reword.",
    "set.* and rhy.*: the word only; a set's numbers in braces come from the data and are added by the page. The Forte names 4-Z15 and 4-Z29 are ids and have no string.",
  ],
  targets, strings_new, strings_changed, strings_removed, strings_it_to_reword, racconto_to_reword,
};
fs.writeFileSync(path.join(GEN, 'content', 'it', 'MANIFEST_TITOLI.json'), JSON.stringify(manifest, null, 1) + '\n');
console.log(`MANIFEST_TITOLI.json: ${targets.length} targets (${JSON.stringify(manifest.counts.byKind)}), ${strings_new.length} new strings, ${strings_changed.length} changed, ${strings_removed.length} removed; to reword for process words: ${strings_it_to_reword.length} strings_it, ${racconto_to_reword.length} narrations`);
