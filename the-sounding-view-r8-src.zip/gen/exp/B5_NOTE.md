# B5 note: three experiments corrected

Built: streams, harmonics, layers (js, strings, data, spec section "Corrected", harness, screenshots at 1280 and 390). Console: clean (no error or warning) in all three at both widths.

## What changed
- streams: two new panels. "The two beams warm up" (MUS-120): gamma against k for a/v0 = 0, 1/4, 1/2, 3/4 from `figure.beams`, band edges as ticks, cursor and readouts of the rule (cold growth less |k|a, checked on the data to 4e-16) and of k_c; a box lets the phase-space bending take this rate. "The bump on the tail warms" (MUS-121): exact, first-order and fluid rates, certified points and peaks from `bot` and `bot_width`; Swell sounds the exact growth in real time (cap 0.3, 3 s). Data: `lor_beams`, `bot`, `bot_width` whole.
- harmonics: bars Lambda_n(lambda), n = 0 ... 8, computed by the certified Miller recurrence (sixty orders above, Neumann normalisation); seven certified lambda marked; sum and 2 T_8 printed; Strike weights the chord by Lambda_n. Data: `bessel`.
- layers: the warm triplet in panel (b) (temperature and form switches, log-log 1 - C plot, R = 1 - C, cold A = 1), a hot-electron ramp panel (MUS-192, 194), a path panel (MUS-198). Data: `triplet_fluid_161`, `xb`. Rows MUS-192, 194, 197, 198 added.

## What I could not place, or placed with a caveat
- layers, |E_y| normalisation: the fluid ramp's |E_y| is about 0.07 to 0.21 against 0.39 to 1.16 for the kinetic ramp, both said to be for a unit incident E_y (the writer builds the fluid's E_y from the first component of MUS-152's system, the kinetic's from the second). I could not tell from the writer or `units` whether this is a normalisation difference, so each trace is scaled to its own largest and the largest are printed. Worth a look by the Atlas side.
- layers, Re E_x: drawn near the layer only (|x'| <= 0.8). The ramp's samples are sparse beyond |x'| = 1 (about 0.4 apart against a 0.2 wavelength on the dense side), so the field along the wave would alias there; the whole-ramp view shows |E_y| and says so on the canvas.
- layers: the Y = 2/5 ramps (`0.4_*`) and the steps are not drawn. The animated crests are kinematic, built from the data's own Re k2 (dense side) and Re k1 (low-density side); their direction (toward the layer on the dense side) is taken from the rows' text, not from a sign convention of the data.
- streams: a = v0 has no curve (not in the data); the page says every root is damped. The a_b = 0 peak of the bump sits on the left edge of the log axis. The first-order rate at the narrowest widths (up to 320) is clipped by the axis at 500.
- streams: the readout evaluates the closed form (v0^2 - a^2)/(v0^2 + a^2)^2 at the chosen a and prints it beside the array's k_edge; it draws nothing from it.
- harmonics: the lambda slider is separate from the orbit's k_perp rho slider, as the brief says.

## New string ids
streams: panel.lor, panel.bot, lw.0, lw.14, lw.12, lw.34, lw.1, lk, lor.drive, cap.lor, rd.gam, rd.rule, rd.edge, rd.edge.in, rd.edge.out, rd.damped, rd.src.lor, bw, bw.swell, bt.exact, bt.first, bt.fluid, bt.cert, bt.peak, cap.bot, rd.bot, rd.bot.cert, rd.bot.peaks. Changed text: cap.phase, see, hear, data.
harmonics: lam, cv.w, cap.bars, rd.w, rd.sum, rd.cert, rd.method. Changed text: cap.gyr, see, hear, data.
layers: form.full, form.rs, form.mom, form.fluid, tv.20, tv.40, tv.80, tv.160, cv.omc, cv.vt, cap.triplet, rd.tri, tri.leave.kin, tri.leave.fl, tri.cold, panel.hot, hot.kin, hot.fl, hot.dens, hot.ey, hot.ex, hot.energy, hot.crests, hot.nearonly, cap.hot, rd.hot1, rd.hot2, panel.path, path.y910, path.y25, path.y27, cv.xs, cv.lam, path.full, path.first, path.cert, path.dense, path.low, path.turn, cap.path, rd.path.dense, rd.path.low, rd.turn, path.never. Changed text: cap.shares, hear, see, data.
All with `id` under `exp.<slug>.` and a `why`; unchanged strings are byte-identical.

## Addendum: layers, Y = 2/5 and the sharp step
- Hot electrons' panel: switch Y = 9/10 · Y = 2/5 (`ramps['0.4_fluid'|'0.4_kinetic']`, same subsampling, stated in `source`); readouts and caption name the Y and where each converted wave leaves (Y = 9/10: hot electrons at the dense end, backward; fluid at the low-density end; Y = 2/5: both at the low-density end, forward).
- New panel "A sharp step" (MUS-193): `xb.steps` and `xb.steps_X`; switches Y and momentum form · Ram and Schultz; four bars; values match the row (momentum, Y = 9/10: 0.176371, 0.806485, 0.017144; Y = 2/5: 0.208024, 0.609770, 0.182206). The caption says the values are exact over the field of the wavenumbers and that the two sides are not in pressure balance.
- The |E_y| scale flagged above is explained by the writer (coordinator's finding): the incident wave is a unit coefficient of each form's normalized mode vector, not a unit E_y; the fluid's vector is dominated by v_x (about 7 |E_y| at X = 0.0666), so its E_y is about a seventh of the kinetic form's. Per-trace scaling kept; the caption says why. This replaces the open question in the first list.
- New string ids (layers): rd.hot.y910, rd.hot.y25, panel.step, step.low, step.dense, step.c.dense, step.c.low, cap.step, rd.step. Changed text: cap.hot. The Y switches reuse path.y910 and path.y25; the step's form switch reuses form.mom and form.rs.
