// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// streams.js — two streams and the sheet: growth, and over-reflection.
(function () {
  'use strict';
  window.SDV_EXP = window.SDV_EXP || {};
  var SL = 'streams', P = 'exp.streams.';
  window.SDV_EXP[SL] = { mount: function (root, data, S, kit) {
    var D = data, reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
    root.classList.add('half');
    var PHZ = 330, WB = 2;                              // omega_p <-> 330 Hz; the picture's omega_b is 2 rad/s
    var st = { lw: '1/2', lk: 0.5, lor: false, bw: 0.1, a: 0.87, warm: false, snd: false, paused: reduce, t: 0, hold: 0, kh: 6, s: '3/5', M: 3.5, voice: null };
    var CAP = 0.9, A0 = 0.01;
    function cvs(panel, a, m) { var b = kit.el('div'); panel.appendChild(b); return kit.canvas(b, a, m); }
    function lorRows(w) { return w === '1' ? null : D.lor_beams[w].rows; }
    function lorGam() { var r = lorRows(st.lw); return r ? kit.interp(r, st.lk) : null; }
    function gam() { if (st.lor) { var gl = lorGam(); return gl == null ? 0 : Math.max(0, gl); } var c = st.warm ? D.beams_warm_half : D.beams_cold; return kit.interp(D.beams_a.map(function (a, i) { return [a, c[i]]; }), st.a) || 0; }
    function clipBox(c, box) { c.save(); c.beginPath(); c.rect(box.l, box.t, box.r - box.l, box.b - box.t); c.clip(); }
    var nf;

    // ---------------------------------------------------------------- (a) two streams
    var pa = kit.panel_(root, P + 'panel.beams', S);
    var ca = kit.controls(pa);
    var bPlay = kit.button(ca, 'exp.common.play', S, function () {
      if (!st.snd) { if (!kit.audio()) { nf.style.display = ''; return; } st.snd = true; st.voice = kit.voice({ f: PHZ, gain: 0.0, type: 'sine' }); }
      else { st.snd = false; if (st.voice) st.voice.stop(); st.voice = null; }
      bPlay.textContent = S(st.snd ? 'exp.common.mute' : 'exp.common.play'); bPlay.setAttribute('data-s', st.snd ? 'exp.common.mute' : 'exp.common.play');
    });
    kit.button(ca, 'exp.common.reset', S, function () { st.t = 0; st.hold = 0; });
    var bP = kit.button(ca, 'exp.common.pause', S, function () { st.paused = !st.paused; bP.setAttribute('aria-pressed', String(st.paused)); }); bP.setAttribute('aria-pressed', String(st.paused));
    kit.seg(ca, { ids: [P + 'warm.off', P + 'warm.on'], values: [false, true], value: false, S: S, onchange: function (v) { st.warm = v; st.t = 0; draw(); } });
    var kS = kit.slider(ca, { id: P + 'a', S: S, min: 0.02, max: 1.8, step: 0.01, value: st.a, fmt: function (v) { return kit.num(v, 2); }, onchange: function (v) { st.a = v; st.t = 0; draw(); } });
    nf = kit.line(pa, 'exp.common.noaudio', S, 'exp-note'); nf.style.display = 'none';
    var cvPh = cvs(pa, 0.5, 280);
    kit.line(pa, P + 'cap.phase', S);
    var rdPh = kit.readout(pa);
    var cvG = cvs(pa, 0.5, 240);
    kit.line(pa, P + 'cap.growth', S);
    var rdG = kit.readout(pa);
    var cvR = cvs(pa, 0.42, 200);
    kit.line(pa, P + 'cap.res', S);
    var rdR = kit.readout(pa);
    var cvE = cvs(pa, 0.5, 230);
    kit.line(pa, P + 'cap.edge', S);
    var rdE = kit.readout(pa);

    // ---------------------------------------------------------------- (a2) the two beams warm up (MUS-120)
    var LW = [['0', 'lw.0'], ['1/4', 'lw.14'], ['1/2', 'lw.12'], ['3/4', 'lw.34'], ['1', 'lw.1']], LWV = { '0': '0', '1/4': '¼', '1/2': '½', '3/4': '¾', '1': '1' };
    var pl = kit.panel_(root, P + 'panel.lor', S);
    var cl = kit.controls(pl);
    kit.seg(cl, { ids: LW.map(function (w) { return P + w[1]; }), values: LW.map(function (w) { return w[0]; }), value: st.lw, S: S, onchange: function (v) { st.lw = v; st.t = 0; draw(); } });
    kit.slider(cl, { id: P + 'lk', S: S, min: 0.025, max: 1.475, step: 0.025, value: st.lk, fmt: function (v) { return kit.num(v, 3); }, onchange: function (v) { st.lk = v; st.t = 0; draw(); } });
    kit.check(cl, P + 'lor.drive', S, false, function (v) { st.lor = v; st.t = 0; draw(); });
    var cvLb = cvs(pl, 0.6, 300);
    kit.line(pl, P + 'cap.lor', S);
    var rdLb1 = kit.readout(pl), rdLb2 = kit.readout(pl), rdLb3 = kit.readout(pl);

    // ---------------------------------------------------------------- (a3) the bump on the tail warms (MUS-121)
    var pw = kit.panel_(root, P + 'panel.bot', S);
    var cw = kit.controls(pw);
    kit.slider(cw, { id: P + 'bw', S: S, min: 0.001, max: 1, log: true, value: st.bw, fmt: function (v) { return kit.num(v, v < 0.01 ? 4 : 3); }, onchange: function (v) { st.bw = v; drawBot(); } });
    kit.button(cw, P + 'bw.swell', S, swell);
    var cvBt = cvs(pw, 0.62, 320);
    kit.line(pw, P + 'cap.bot', S);
    var rdBt1 = kit.readout(pw), rdBt2 = kit.readout(pw);

    // ---------------------------------------------------------------- (b) wind over water, the sheet
    var pb = kit.panel_(root, P + 'panel.sheet', S);
    var cb = kit.controls(pb);
    kit.seg(cb, { ids: [P + 'kh.5', P + 'kh.6', P + 'kh.7'], values: [5, 6, 7], value: 6, S: S, onchange: function (v) { st.kh = v; draw(); } });
    var cvK = cvs(pb, 0.5, 220);
    kit.line(pb, P + 'cap.kh', S);
    var cvM = cvs(pb, 0.55, 260);
    kit.line(pb, P + 'cap.sheet', S);
    var rdM = kit.readout(pb);
    var cvU = cvs(pb, 0.4, 180);
    kit.line(pb, P + 'cap.roll', S);

    // ---------------------------------------------------------------- (c) over-reflection
    var pc = kit.panel_(root, P + 'panel.refl', S, 'span');
    var cc = kit.controls(pc);
    kit.seg(cc, { ids: [P + 's.35', P + 's.45', P + 's.1213'], values: ['3/5', '4/5', '12/13'], value: '3/5', S: S, onchange: function (v) { st.s = v; draw(); } });
    kit.slider(cc, { id: P + 'm', S: S, min: 0.05, max: 4.99, step: 0.01, value: st.M, fmt: function (v) { return kit.num(v, 2); }, onchange: function (v) { st.M = v; draw(); } });
    kit.button(cc, P + 'send', S, send);
    var cvRf = cvs(pc, 0.4, 260);
    kit.line(pc, P + 'cap.refl', S);
    var rdRf = kit.readout(pc);
    var cvL = cvs(pc, 0.4, 260);
    kit.line(pc, P + 'cap.loci', S);
    var rdL = kit.readout(pc);
    var cv3 = cvs(pc, 0.3, 200);
    kit.line(pc, P + 'cap.g3', S);
    var rd3 = kit.readout(pc);

    // ---------------------------------------------------------------- sound
    function Rat() { var fr = st.s.split('/'), s = fr[0] / fr[1]; var R = D.ss_R[st.s]; return { s: s, R: kit.interp(D.ss_M.map(function (m, i) { return [m, R[i]]; }), st.M) }; }
    function send() {
      if (!st.snd) return; var r = Rat().R; if (r == null) return;
      kit.tone({ f: PHZ, gain: 0.1, dur: 0.35, at: 0 });
      kit.tone({ f: PHZ, gain: Math.min(0.3, 0.1 * r), dur: 0.5, at: 0.7 });
    }

    var BWL = D.bot_width.map(function (r) { return [Math.log(r[0]), Math.log(r[1]), Math.log(r[2])]; });
    function botAt(a) { // exact and first-order growth at a_b/v_b = a: linear in log a and log growth between the 46 widths
      var la = Math.log(a); return { g: Math.exp(kit.interp(BWL.map(function (r) { return [r[0], r[1]]; }), la)), g1: Math.exp(kit.interp(BWL.map(function (r) { return [r[0], r[2]]; }), la)) };
    }
    function swell() { // the plasma frequency swelling at the exact growth rate of the slider's width, in real time, three seconds, gain capped at 0.3
      if (!st.snd) return; var A = kit.audio(); if (!A) return;
      var rate = botAt(st.bw).g * 2 * Math.PI * PHZ, g0 = 0.003, cap = 0.3, T = 3, ctx = A.ctx, t0 = ctx.currentTime + 0.02;
      var tc = Math.log(cap / g0) / rate, tr = Math.min(tc, T - 0.1), top = Math.min(cap, g0 * Math.exp(rate * tr));
      var o = ctx.createOscillator(), g = ctx.createGain(); o.frequency.value = PHZ; o.type = 'sine';
      g.gain.setValueAtTime(g0, t0); g.gain.exponentialRampToValueAtTime(top, t0 + tr); g.gain.setValueAtTime(top, t0 + T - 0.1); g.gain.linearRampToValueAtTime(0, t0 + T);
      o.connect(g); g.connect(A.master); o.start(t0); o.stop(t0 + T + 0.05);
    }

    // ---------------------------------------------------------------- drawing
    function drawPhase(dt) {
      var c = cvPh.ctx, W = cvPh.size().w, H = cvPh.h; c.clearRect(0, 0, W, H);
      var g = gam(), box = { l: 34, r: W - 8, t: 8, b: H - 22 };
      if (!st.paused) { if (st.t * 0 + A0 * Math.exp(g * WB * st.t) < CAP) st.t += dt; else { st.hold += dt; if (st.hold > 1.2) { st.t = 0; st.hold = 0; } } }
      var A = Math.min(CAP, A0 * Math.exp(g * WB * st.t));
      c.strokeStyle = kit.muted(); c.lineWidth = 1; c.strokeRect(box.l, box.t, box.r - box.l, box.b - box.t);
      c.fillStyle = kit.muted(); c.font = '11px system-ui, sans-serif'; c.textAlign = 'center'; c.fillText('x', (box.l + box.r) / 2, H - 6); c.save(); c.translate(11, H / 2); c.rotate(-Math.PI / 2); c.fillText('v / v₀', 0, 0); c.restore();
      var N = 220;
      for (var i = 0; i < N; i++) {
        var sgn = i % 2 ? 1 : -1, x0 = ((i * 0.6180339) % 1), x = (x0 + sgn * 0.08 * st.t) % 1; if (x < 0) x += 1;
        var v = sgn * (1 - A * sgn * Math.cos(2 * Math.PI * x)) * 1; var px = box.l + x * (box.r - box.l), py = (box.t + box.b) / 2 - v * (box.b - box.t) / 2 * 0.62;
        c.fillStyle = sgn > 0 ? kit.red : kit.blue; c.beginPath(); c.arc(px, py, 2.2, 0, 6.2832); c.fill();
      }
      if (st.voice) st.voice.set(PHZ, 0.3 * Math.pow(A / CAP, 1.2));
      rdPh.textContent = 'A = ' + kit.num(A, 2) + ' v₀;  ' + S('exp.common.slowed').replace('{n}', kit.num(Math.round(2 * Math.PI * PHZ / WB), 0)) + ' ' + S(P + 'kin') + (st.lor ? ' ' + S(P + 'rd.src.lor') : '');
    }
    function drawGrowth() {
      var c = cvG.ctx, W = cvG.size().w, H = cvG.h; c.clearRect(0, 0, W, H);
      var box = { l: 40, r: W - 8, t: 10, b: H - 32 };
      var ax = kit.axes(c, box, { xmin: 0, xmax: 1.8, ymin: 0, ymax: 0.55, xticks: [0, 0.5, 1, 1.5], yticks: [0, 0.25, 0.5], xlabel: 'k v₀ / ω_b', ylabel: 'γ / ω_b' });
      kit.curve(c, D.beams_a.map(function (a, i) { return [a, D.beams_cold[i]]; }), ax.x, ax.y, kit.ink(), st.warm ? 1.2 : 2.2);
      kit.curve(c, D.beams_a.map(function (a, i) { return [a, D.beams_warm_half[i]]; }), ax.x, ax.y, kit.accent(), st.warm ? 2.2 : 1.2);
      var g = gam(); c.fillStyle = kit.warm(); c.beginPath(); c.arc(ax.x(st.a), ax.y(g), 5, 0, 6.2832); c.fill();
      c.font = '11px system-ui, sans-serif'; c.textAlign = 'left'; c.fillStyle = kit.ink(); c.fillText(S(P + 'warm.off'), box.l + 6, box.t + 12); c.fillStyle = kit.accent(); c.fillText(S(P + 'warm.on'), box.l + 70, box.t + 12);
      var mx = 0, am = 0; D.beams_cold.forEach(function (v, i) { if (v > mx) { mx = v; am = D.beams_a[i]; } });
      rdG.textContent = 'k v₀/ω_b = ' + kit.num(st.a, 2) + ':  γ = ' + kit.num(g, 4) + ' ω_b;   cold: largest ' + kit.num(mx, 4) + ' ω_b at ' + kit.num(am, 2);
    }
    function drawRes() {
      var c = cvR.ctx, W = cvR.size().w, H = cvR.h; c.clearRect(0, 0, W, H);
      var box = { l: 46, r: W - 8, t: 10, b: H - 32 };
      var ax = kit.axes(c, box, { xmin: 0.9, xmax: 1.1, ymin: 0.03, ymax: 0.075, xticks: [0.9, 1.0, 1.1], yticks: [0.04, 0.06], xlabel: 'k v / ω_p', ylabel: 'γ / ω_p' });
      var wk = D.resonance_k.map(function (k, i) { return [k, D.weak[i]]; }), bu = D.resonance_k.map(function (k, i) { return [k, D.bun_h[i]]; });
      kit.curve(c, wk, ax.x, ax.y, kit.ink(), 1.8); kit.curve(c, bu, ax.x, ax.y, kit.red, 1.8);
      [[D.beam, kit.ink()], [D.buneman, kit.red]].forEach(function (b) { c.strokeStyle = b[1]; c.setLineDash([4, 3]); c.beginPath(); c.moveTo(box.l, ax.y(b[0].lead)); c.lineTo(box.r, ax.y(b[0].lead)); c.stroke(); c.setLineDash([]); c.fillStyle = b[1]; c.beginPath(); c.arc(ax.x(b[0].peak_k), ax.y(b[0].peak_growth), 4, 0, 6.2832); c.fill(); });
      c.font = '11px system-ui, sans-serif'; c.textAlign = 'left'; c.fillStyle = kit.ink(); c.fillText(S(P + 'weak'), box.l + 6, box.t + 12); c.fillStyle = kit.red; c.fillText(S(P + 'bun'), box.l + 100, box.t + 12);
      rdR.textContent = S(P + 'weak') + ': peak ' + kit.num(D.beam.peak_growth, 4) + ' at k v/ω_p = ' + kit.num(D.beam.peak_k, 3) + ', cube-root rate ' + kit.num(D.beam.lead, 4) + ' (' + kit.num((D.beam.lead / D.beam.peak_growth - 1) * 100, 1) + '% above);  ' + S(P + 'bun') + ': peak ' + kit.num(D.buneman.peak_growth, 4) + ', cube-root rate ' + kit.num(D.buneman.lead, 4) + ' (' + kit.num((D.buneman.lead / D.buneman.peak_growth - 1) * 100, 1) + '% above)';
    }
    function drawEdge() {
      var c = cvE.ctx, W = cvE.size().w, H = cvE.h; c.clearRect(0, 0, W, H);
      var box = { l: 40, r: W - 8, t: 10, b: H - 32 }, B = D.band, rows = B.rows;
      var ax = kit.axes(c, box, { xmin: 1, xmax: 6, ymin: 0, ymax: 1.0, xticks: [1, 2, 3, 4, 5, 6], yticks: [0, 0.5, 1], xlabel: 'v₀ / v_t', ylabel: 'k_max v_t / ω_p' });
      function ser(key) { return rows.filter(function (r) { return r[key] != null; }).map(function (r) { return [r.v0, r[key]]; }); }
      kit.curve(c, ser('kinetic').filter(function (p) { return p[1] > 0; }), ax.x, ax.y, kit.ink(), 2.2);
      kit.curve(c, ser('fluid1'), ax.x, ax.y, kit.blue, 1.4); kit.curve(c, ser('fluid3'), ax.x, ax.y, kit.red, 1.4);
      c.strokeStyle = kit.accent(); c.setLineDash([4, 3]); c.beginPath(); c.moveTo(ax.x(B.threshold[0]), box.t); c.lineTo(ax.x(B.threshold[0]), box.b); c.stroke(); c.setLineDash([]);
      c.fillStyle = kit.warm(); c.beginPath(); c.arc(ax.x(B.widest[0]), ax.y(B.widest[1]), 4.5, 0, 6.2832); c.fill();
      c.font = '11px system-ui, sans-serif'; c.textAlign = 'left'; c.fillStyle = kit.ink(); c.fillText(S(P + 'kin.name'), box.l + 6, box.t + 12); c.fillStyle = kit.blue; c.fillText(S(P + 'fl1'), box.l + 70, box.t + 12); c.fillStyle = kit.red; c.fillText(S(P + 'fl3'), box.l + 150, box.t + 12);
      var f1 = rows.filter(function (r) { return r.fluid1 != null; })[0], f3 = rows.filter(function (r) { return r.fluid3 != null; })[0];
      rdE.textContent = S(P + 'kin.name') + ': edge at v₀ = ' + kit.num(B.threshold[0], 4) + ' v_t;  ' + S(P + 'fl1') + ' from ' + kit.num(f1.v0, 3) + ', ' + S(P + 'fl3') + ' from ' + kit.num(f3.v0, 3) + ' (grid step 0.025);  widest band ' + kit.num(B.widest[1], 4) + ' at ' + kit.num(B.widest[0], 3) + ' v_t';
    }
    function drawKH() {
      var c = cvK.ctx, W = cvK.size().w, H = cvK.h; c.clearRect(0, 0, W, H);
      var box = { l: 40, r: W - 8, t: 10, b: H - 32 };
      var ax = kit.axes(c, box, { xmin: 0, xmax: 8, ymin: 0, ymax: 12, xticks: [0, 2, 4, 6, 8], yticks: [0, 5, 10], xlabel: 'k', ylabel: S(P + 'cv.growth') });
      [[5, kit.muted()], [6, kit.blue], [7, kit.red]].forEach(function (p) { kit.curve(c, D.kh_k.map(function (k, i) { return [k, D.kh['dU' + p[0]][i]]; }), ax.x, ax.y, p[1], p[0] === st.kh ? 2.6 : 1.1); });
      c.font = '11px system-ui, sans-serif'; c.textAlign = 'left'; [[5, kit.muted()], [6, kit.blue], [7, kit.red]].forEach(function (p, j) { c.fillStyle = p[1]; c.fillText('ΔU = ' + p[0], box.l + 6 + j * 60, box.t + 12); });
    }
    function drawSheet() {
      var c = cvM.ctx, W = cvM.size().w, H = cvM.h; c.clearRect(0, 0, W, H);
      var box = { l: 40, r: W - 8, t: 10, b: H - 32 };
      var ax = kit.axes(c, box, { xmin: 0, xmax: 10, ymin: 0, ymax: 1.15, xticks: [0, 2, 4, 6, 8, 10], yticks: [0, 0.5, 1], xlabel: 'M = ΔU / c', ylabel: 'γ / k c' });
      var cols = { equal: kit.ink(), eps27: kit.red, eps1_8: kit.blue, oblique_3_5: kit.accent() };
      Object.keys(D.sheet).forEach(function (k) { kit.curve(c, D.sheet_M.map(function (m, i) { return [m, D.sheet[k][i]]; }), ax.x, ax.y, cols[k], 1.8); });
      D.sheet_points.forEach(function (p) { c.fillStyle = kit.ink(); c.beginPath(); c.arc(ax.x(p[0]), ax.y(p[1]), 3.2, 0, 6.2832); c.fill(); });
      [[D.miles.dUc_over_cplus[2], kit.ink()], [D.miles.dUc_over_cplus[0], kit.red]].forEach(function (m) { c.strokeStyle = m[1]; c.setLineDash([4, 3]); c.beginPath(); c.moveTo(ax.x(m[0]), box.t); c.lineTo(ax.x(m[0]), box.b); c.stroke(); c.setLineDash([]); });
      c.font = '11px system-ui, sans-serif'; c.textAlign = 'left'; ['equal', 'eps27', 'eps1_8', 'oblique_3_5'].forEach(function (k, j) { c.fillStyle = cols[k]; c.fillText(S(P + 'sh.' + k), box.l + 6 + (j % 2) * 150, box.t + 12 + 13 * Math.floor(j / 2)); });
      rdM.textContent = S(P + 'crit') + ': ' + kit.num(D.miles.dUc_over_cplus[2], 3) + ' c (' + S(P + 'sh.equal') + '),  ' + kit.num(D.miles.dUc_over_cplus[0], 3) + ' c₊ (' + S(P + 'sh.eps27') + ')';
    }
    function drawRoll(t) {
      var c = cvU.ctx, W = cvU.size().w, H = cvU.h; c.clearRect(0, 0, W, H);
      var g = Math.min(1.9, 0.08 + ((t * 0.35) % 2.1)), kk = 2 * Math.PI * 2 / W;
      c.fillStyle = 'rgba(194,74,58,0.08)'; c.fillRect(0, 0, W, H / 2); c.fillStyle = 'rgba(43,95,158,0.08)'; c.fillRect(0, H / 2, W, H / 2);
      kit.arrow(c, 12, H * 0.25, 70, H * 0.25, kit.red, 1.5); kit.arrow(c, 70, H * 0.75, 12, H * 0.75, kit.blue, 1.5);
      c.strokeStyle = kit.ink(); c.lineWidth = 2; c.beginPath(); var R = (g * 0.5) / kk * 0.5; R = Math.min(R, H * 0.3);
      for (var i = 0; i <= 300; i++) { var s = i / 300 * W, ph = kk * s, x = s + R * g * 0.55 * Math.cos(ph) * 1, y = H / 2 - R * Math.sin(ph) * (0.6 + 0.4 * Math.min(1, g)); if (i === 0) c.moveTo(x, y); else c.lineTo(x, y); }
      c.stroke();
    }
    function drawRefl() {
      var c = cvRf.ctx, W = cvRf.size().w, H = cvRf.h; c.clearRect(0, 0, W, H);
      var box = { l: 40, r: W - 8, t: 10, b: H - 32 }, r = Rat(), R = D.ss_R[st.s];
      var ax = kit.axes(c, box, { xmin: 0, xmax: 5, ymin: 0, ymax: 3, xticks: [0, 1, 2, 3, 4, 5], yticks: [0, 1, 2, 3], xlabel: 'M = ΔU / c', ylabel: '|R|' });
      // the band where |R| > 1
      var on = null; D.ss_M.forEach(function (m, i) { var amp = R[i] > 1.0001; if (amp && on == null) on = m; if ((!amp || i === D.ss_M.length - 1) && on != null) { c.fillStyle = 'rgba(194,74,58,0.14)'; c.fillRect(ax.x(on), box.t, ax.x(m) - ax.x(on), box.b - box.t); on = null; } });
      clipBox(c, box); kit.curve(c, D.ss_M.map(function (m, i) { return [m, R[i]]; }), ax.x, ax.y, kit.ink(), 1.8); c.restore();
      c.strokeStyle = kit.muted(); c.setLineDash([3, 3]); c.beginPath(); c.moveTo(box.l, ax.y(1)); c.lineTo(box.r, ax.y(1)); c.stroke(); c.setLineDash([]);
      var pole = D.poles.filter(function (p) { return Math.abs(p[0] - r.s) < 1e-6; })[0];
      if (pole) [pole[1], pole[2]].forEach(function (m) { c.strokeStyle = kit.warm(); c.lineWidth = 1.4; c.beginPath(); c.moveTo(ax.x(m), box.t); c.lineTo(ax.x(m), box.b); c.stroke(); });
      c.strokeStyle = kit.accent(); c.lineWidth = 1.4; c.beginPath(); c.moveTo(ax.x(st.M), box.t); c.lineTo(ax.x(st.M), box.b); c.stroke();
      rdRf.textContent = 'M = ' + kit.num(st.M, 2) + ':  |R| = ' + (r.R == null ? S('exp.common.outside') : kit.num(r.R, 3)) + '   sin θ = ' + st.s + (pole ? ';  poles at M = ' + kit.num(pole[2], 4) + ' and ' + kit.num(pole[1], 4) : '');
    }
    function drawLoci() {
      var c = cvL.ctx, W = cvL.size().w, H = cvL.h; c.clearRect(0, 0, W, H);
      var box = { l: 40, r: W - 8, t: 10, b: H - 32 }, Lc = D.loci;
      var ax = kit.axes(c, box, { xmin: 0, xmax: 90, ymin: 0, ymax: 8, xticks: [0, 30, 45, 60, 90], yticks: [0, 2, 4, 6, 8], xlabel: 'θ (degrees)', ylabel: 'M' });
      clipBox(c, box);
      [['ordinary_edge', kit.blue], ['amplified_edge', kit.red], ['pole_rest', kit.warm()], ['pole_two_stream', kit.ink()]].forEach(function (p) { kit.curve(c, Lc.theta_deg.map(function (t, i) { return [t, Lc[p[0]][i]]; }), ax.x, ax.y, p[1], 1.7); });
      c.restore();
      var j = 0, best = 1e9; Lc.theta_deg.forEach(function (t, i) { if (Math.abs(t - 45) < best) { best = Math.abs(t - 45); j = i; } });
      c.fillStyle = kit.ink(); c.beginPath(); c.arc(ax.x(Lc.theta_deg[j]), ax.y(Lc.pole_rest[j]), 4.5, 0, 6.2832); c.fill();
      c.font = '11px system-ui, sans-serif'; c.textAlign = 'left'; [['loc.o', kit.blue], ['loc.a', kit.red], ['loc.r', kit.warm()], ['loc.t', kit.ink()]].forEach(function (p, i) { c.fillStyle = p[1]; c.fillText(S(P + p[0]), box.l + 150 + (i % 2) * 0 , box.t + 12 + 13 * i); });
      rdL.textContent = 'θ = ' + kit.num(Lc.theta_deg[j], 2) + '°: M = ' + kit.num(Lc.pole_rest[j], 4) + ' (' + S(P + 'loc.r') + '), ' + kit.num(Lc.pole_two_stream[j], 4) + ' (' + S(P + 'loc.t') + ')';
    }
    function draw3() {
      var c = cv3.ctx, W = cv3.size().w, H = cv3.h; c.clearRect(0, 0, W, H);
      var box = { l: 40, r: W - 8, t: 10, b: H - 32 }, g = D.g3;
      var ax = kit.axes(c, box, { xmin: 0, xmax: 6, ymin: 0, ymax: 0.6, xticks: [0, 2, 4, 6], yticks: [0, 0.25, 0.5], xlabel: 'ΔU / c', ylabel: 'γ / |k| c' });
      kit.curve(c, g.dU.map(function (d, i) { return [d, g.along[i]]; }), ax.x, ax.y, kit.muted(), 1.6);
      kit.curve(c, g.dU.map(function (d, i) { return [d, g.best[i]]; }), ax.x, ax.y, kit.accent(), 2.2);
      c.strokeStyle = kit.warm(); c.setLineDash([4, 3]); c.beginPath(); c.moveTo(ax.x(Math.sqrt(3)), box.t); c.lineTo(ax.x(Math.sqrt(3)), box.b); c.stroke(); c.setLineDash([]);
      c.font = '11px system-ui, sans-serif'; c.textAlign = 'left'; c.fillStyle = kit.muted(); c.fillText(S(P + 'g3.along'), box.l + 6, box.t + 12); c.fillStyle = kit.accent(); c.fillText(S(P + 'g3.best'), box.l + 110, box.t + 12);
      var ce = D.crit_exact['27,1']; rd3.textContent = S(P + 'stiff') + ': ΔU_c = ' + kit.num(ce[0], 3) + ' c  (ρ₂/ρ₁ = 27, equal sound speeds);  ' + S(P + 'g3.max') + ' ' + kit.num(g.best[g.best.length - 1], 3) + ' |k| c';
    }
    function drawLor() {
      var c = cvLb.ctx, W = cvLb.size().w, H = cvLb.h; c.clearRect(0, 0, W, H);
      var box = { l: 46, r: W - 10, t: 14, b: H - 52 }, B = D.lor_beams, keys = ['0', '1/4', '1/2', '3/4'];
      var ax = kit.axes(c, box, { xmin: 0, xmax: 1.5, ymin: -0.2, ymax: 0.55, xticks: [0, 0.5, 1, 1.5], yticks: [-0.2, 0, 0.25, 0.5], ylabel: 'γ / ω_b' });
      c.fillStyle = kit.muted(); c.font = '11px system-ui, sans-serif'; c.textAlign = 'center'; c.fillText('k v₀ / ω_b', (box.l + box.r) / 2, H - 4);
      c.strokeStyle = kit.ink(); c.lineWidth = 1; c.beginPath(); c.moveTo(box.l, ax.y(0)); c.lineTo(box.r, ax.y(0)); c.stroke();
      clipBox(c, box);
      keys.forEach(function (w) { var sel = w === st.lw; c.globalAlpha = sel ? 1 : 0.4; kit.curve(c, B[w].rows, ax.x, ax.y, sel ? kit.accent() : kit.muted(), sel ? 2.8 : 1.3); c.globalAlpha = 1; });
      c.restore();
      c.font = '11px system-ui, sans-serif'; c.textAlign = 'left';
      keys.forEach(function (w) { var m = B[w].rows.reduce(function (a, r) { return r[1] > a[1] ? r : a; }); c.fillStyle = w === st.lw ? kit.accent() : kit.muted(); c.fillText(LWV[w], ax.x(m[0]) + 5, ax.y(m[1]) - 3); });
      // the band edges as ticks on the k axis, their values under it (staggered where they crowd)
      var es = keys.map(function (w) { return { w: w, k: B[w].k_edge }; }).sort(function (a, b) { return a.k - b.k; }), prev = -1e9, row = 0;
      c.textAlign = 'left'; c.fillStyle = kit.muted(); c.fillText('k_c', 4, box.b + 30);
      es.forEach(function (e) {
        var x = ax.x(e.k), sel = e.w === st.lw; row = (x - prev < 32) ? 1 - row : 0; prev = x;
        c.fillStyle = sel ? kit.accent() : kit.muted(); c.beginPath(); c.moveTo(x, box.b); c.lineTo(x - 4, box.b - 8); c.lineTo(x + 4, box.b - 8); c.closePath(); c.fill();
        c.textAlign = 'center'; c.fillText(kit.num(e.k, 3), x, box.b + 30 + 12 * row);
      });
      var r = lorRows(st.lw), g = lorGam(), cold = kit.interp(B['0'].rows, st.lk), a = st.lw === '1' ? 1 : fracOf(st.lw);
      c.strokeStyle = kit.warm(); c.lineWidth = 1.2; c.beginPath(); c.moveTo(ax.x(st.lk), box.t); c.lineTo(ax.x(st.lk), box.b); c.stroke();
      if (g != null) { c.fillStyle = kit.warm(); c.beginPath(); c.arc(ax.x(st.lk), ax.y(Math.max(-0.2, g)), 4.5, 0, 6.2832); c.fill(); }
      if (!r) { rdLb1.textContent = S(P + 'rd.damped'); rdLb2.textContent = ''; rdLb3.textContent = ''; return; }
      rdLb1.textContent = S(P + 'rd.gam').replace('{a}', LWV[st.lw]).replace('{k}', kit.num(st.lk, 3)).replace('{g}', kit.num(g, 5));
      rdLb2.textContent = S(P + 'rd.rule').replace('{c}', kit.num(cold, 5)).replace('{ka}', kit.num(st.lk * a, 5)).replace('{r}', kit.num(cold - st.lk * a, 5));
      var ke = B[st.lw].k_edge;
      rdLb3.textContent = S(P + 'rd.edge').replace('{kc}', kit.num(ke, 4)).replace('{kc2}', kit.num(ke * ke, 4)).replace('{f}', kit.num(2 * (1 - a * a) / Math.pow(1 + a * a, 2), 4)).replace('{state}', S(P + (st.lk < ke ? 'rd.edge.in' : 'rd.edge.out')));
    }
    function fracOf(w) { var p = w.split('/'); return p.length === 2 ? p[0] / p[1] : +w; }
    function drawBot() {
      var c = cvBt.ctx, W = cvBt.size().w, H = cvBt.h; c.clearRect(0, 0, W, H);
      var box = { l: 58, r: W - 10, t: 10, b: H - 36 }, BW = D.bot_width, Bt = D.bot;
      var ax = kit.axes(c, box, { xmin: 0.001, xmax: 1, xlog: true, ymin: 5e-5, ymax: 500, ylog: true, xticks: [0.001, 0.01, 0.1, 1], yticks: [0.0001, 0.001, 0.01, 0.1, 1, 10, 100], xlabel: 'a_b / v_b', ylabel: 'γ / ω_p' });
      clipBox(c, box);
      kit.curve(c, BW.map(function (r) { return [r[0], r[2]]; }), ax.x, ax.y, kit.red, 1.6, [5, 3]);
      kit.curve(c, BW.map(function (r) { return [r[0], r[1]]; }), ax.x, ax.y, kit.ink(), 2.2);
      c.strokeStyle = kit.blue; c.lineWidth = 1.6; c.setLineDash([2, 3]); c.beginPath(); c.moveTo(box.l, ax.y(Bt.fluid)); c.lineTo(ax.x(0.05), ax.y(Bt.fluid)); c.stroke(); c.setLineDash([]);
      c.restore();
      Bt.transition.forEach(function (p) { c.fillStyle = kit.ink(); c.beginPath(); c.arc(ax.x(p[0]), ax.y(p[2]), 3.8, 0, 6.2832); c.fill(); });
      Bt.peaks.forEach(function (p) { c.strokeStyle = kit.accent(); c.lineWidth = 1.8; c.beginPath(); c.arc(p[0] > 0 ? ax.x(p[0]) : box.l, ax.y(p[2]), 7, 0, 6.2832); c.stroke(); });
      var cur = botAt(st.bw);
      c.strokeStyle = kit.warm(); c.lineWidth = 1.2; c.beginPath(); c.moveTo(ax.x(st.bw), box.t); c.lineTo(ax.x(st.bw), box.b); c.stroke();
      c.fillStyle = kit.warm(); c.beginPath(); c.arc(ax.x(st.bw), ax.y(cur.g), 4.5, 0, 6.2832); c.fill();
      c.font = '11px system-ui, sans-serif'; c.textAlign = 'right';
      [['bt.exact', kit.ink()], ['bt.first', kit.red], ['bt.fluid', kit.blue], ['bt.cert', kit.ink()], ['bt.peak', kit.accent()]].forEach(function (p, j) { c.fillStyle = p[1]; c.fillText(S(P + p[0]), box.r - 6, box.t + 14 + 13 * j); });
      var near = Bt.transition.filter(function (p) { return Math.abs(Math.log(p[0] / st.bw)) < 0.03; })[0];
      rdBt1.textContent = S(P + 'rd.bot').replace('{a}', kit.num(st.bw, st.bw < 0.01 ? 4 : 3)).replace('{g}', kit.num(cur.g, 5)).replace('{g1}', kit.num(near ? near[3] : cur.g1, 5)).replace('{f}', kit.num(cur.g / Bt.fluid, 2)).replace('{fl}', kit.num(Bt.fluid, 4)) + (near ? ' ' + S(P + 'rd.bot.cert') : '');
      rdBt2.textContent = S(P + 'rd.bot.peaks') + ' ' + Bt.peaks.map(function (p) { return 'a_b/v_b = ' + kit.num(p[0], 1) + ': k v_b/ω_p = ' + kit.num(p[1], 4) + ', γ = ' + kit.num(p[2], 5) + (p[3] != null ? ' (' + kit.num(p[3], 5) + ')' : ''); }).join(';  ');
    }
    function draw() { drawLor(); drawBot(); drawGrowth(); drawRes(); drawEdge(); drawKH(); drawSheet(); drawRefl(); drawLoci(); draw3(); }
    var tt = 0; draw();
    kit.loop(function (t, dt) { drawPhase(dt); if (!st.paused) tt += dt; drawRoll(tt); });
    window.addEventListener('resize', draw);
    explain(root, SL, S, kit);
  } };
  function explain(root, slug, S, kit) {
    var p = kit.panel_(root, null, S, 'span');
    var a = kit.panel_(p, 'exp.common.see', S); kit.line(a, 'exp.' + slug + '.see', S);
    var h = kit.panel_(p, 'exp.common.hear', S); kit.line(h, 'exp.' + slug + '.hear', S);
    p.appendChild(kit.el('p', { class: 'exp-source' }, [kit.el('b', { 'data-s': 'exp.common.data', text: S('exp.common.data') }), ' ', kit.el('span', { 'data-s': 'exp.' + slug + '.data', text: S('exp.' + slug + '.data') })]));
  }
})();
