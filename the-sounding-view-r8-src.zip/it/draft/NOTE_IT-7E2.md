# NOTE IT-7 E2 — the strings of the experiment violin

128 strings written (exp.violin.*), no narrations or titles. Checker: 0 errors, 0 warnings.

Terms: la corda strofinata, l'arco, lo spigolo, il cuneo di Schelleng, il ponticello, il capotasto (nut), l'anima (post), le effe, la sbarra (kept as in the continuum experiment, not "barra"), il modo a X / a torsione / ad anello, la piastra tenuta al centro, il pezzo aggiunto, la conduttanza, il lupo, il battimento, scorrimento / aderenza, quinte senza battimenti, dente di sega (sawtooth), dati in ingresso.
Left as printed: the string picker letters G D A E (the readout prints the data's letters), A0, B1−, B1+, Q, Q*, all symbols and file/check names.
"La = 440 Hz" in cap.fifths (English "A = 440 Hz") to avoid confusion with A0.
Doubt: "Colpisci" and "Suona" in exp.violin.hear refer to the common buttons (Suona, Colpisci, Silenzio).

## Second pass (28 strings: 12 new, 16 changed)
r7_E2.json now holds only those 28. New terms: la massa dell'eccitatore (in masse della piastra), massa puntiforme, anello nodale al centro, limiti superiori di Ritz, semilato, mediana. The photograph is the third held mode (archi che tagliano i punti medi dei lati). 1.955 cent is MUS-010's 701.955 − 700 per fifth, a twelfth of the Pythagorean comma. Wolf: "nessuna soglia netta" for the exact roots; "tremolio" for the slow beat below Q*.
Doubt: none beyond the physics as given.
