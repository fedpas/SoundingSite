# NOTE IT-6 E1

Wrote r6_E1.json: nine row narrations MUS-200 ... MUS-208 (200-202 Calcolato; 203, 204 Standard ricalcolato; 205-208 Calcolato) with titles; headings chain:xb-triplet and chain:ox-step; captions of fig_xb_triplet (4 panels) and fig_ox_step (a, b, c, c', d), told not translated; one-line titles of music_xb_triplet and music_ox_step; the five strings (checks.intro thirty, pics.intro trentatre, about.bridges.rows and about.reads.pack naming the four works plainly, checks.light.p); rewrites of section:layers (third paragraph: the two new chains and the experiment) and checks:light (nineteen scripts: fifteen of the tables, four read from their own files).

Terms: il tripletto (not "triplete" of r5), la cavita, il taglio L, il taglio O / X lento, l'onda X lenta / veloce, l'onda cinetica, il foglio (the resonance sheet), la lacuna (gap), la confluenza, la finestra O-X, N_z ottimo (N_z,opt kept in notation), la fuga per tunnel, la banda delle coppie complesse, il flusso unitario. Forms: primo ordine completo, forme di Ram e Schultz / della quantita di moto.

Checked and kept: none left as check_only; both rewritten. Banned-word grep passes in the checker (no versione, ora, nuovo, ultimo, prima).

Doubts: MUS-201's "a meno di un centesimo" speaks of C in units of incident power, as in r5. MUS-208's "fuga" (leak) is the English "tunnelling leak T = e^{-pi eta}"; "perdita" avoided because it would clash with the lossy sheet. Captions run 107 and 110 words (asked up to 110).
