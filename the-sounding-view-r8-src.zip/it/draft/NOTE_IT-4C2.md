# NOTE_IT-4C2

Written: it/draft/r4_C2.json (40 narrations, 77 titles, 24 rewritten check_only; 0 errors from check_r4.mjs).

Italian titles given: gyration's harmonics = "Le armoniche della girazione"; fading wave = "L'onda che si smorza e quella che cresce". Other chapters are named plainly in part:light (no C1 file existed): fluido magnetizzato, strati, i due flussi con il foglio di vortici.

check_only rewritten (24): MUS-049, 066, 055, 065, 070, 087, 080, INP-138, INP-135, INP-139, MUS-086, 068, 067, 061, 051, section:aether (INP-133..135 sentence dropped), section:spin (INP sentences dropped), part:light (nine chapters, four movements), checks:light (fifteen scripts), page:home, page:sounds, page:checks (26 scripts), page:dictionary (62 entries), page:about (experiments).
Kept (19): MUS-063, 053, 076, 079, 058, 057, 083, 075, 072, 074, 084, 002, INP-137, INP-134 (no English in plan4 file), INP-133, section:plasma, section:complements, page:pictures, page:sources.

Doubts: page:dictionary grade counts (exact 36, exact with input 2, partial 4, analogy 7, none 13) are derived from the old 47 plus the grades of entries 48-62 as the material prints them; verify against the table. page:pictures keeps "ventinove figure" (no new count given). MUS-066 mentions the analysis page file acoustic_spin_torque.html. Glossary: "onda fischiante" (whistler), "manichetta" (firehose), "girazione" (gyration), "lorentziana".
