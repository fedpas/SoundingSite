# NOTE IT-4D2

Written: `it/draft/r4_D2.json`, 401 strings (stiffness, spin, plasmawaves, coupling, whistler, alfven, layers, harmonics, landau, streams). Placeholders checked against the English; checker 0 errors.

Terms: anello del suono / di taglio, molla di trazione / di taglio, rigidezza, modulo di compressione, spigolo temporale, nodo di pressione, campo di potenza. "sheet" (resonance sheet, vortex sheet) = lamina; "wave packet" = treno d'onda (pacchetto is banned); "nose" (whistler) = naso; "gauge" and "whistler"/"firehose"/"e-folding" kept as terms of art; "Strike" and "Reset" are named in prose as Percuoti / Reset, "Play" as Play, "Send" as Invia (D1's exp.common.* should agree: Play, Percuoti, Reset).
Doubt: whistler cap wcap1 quotes a sentence in guillemets, translated.
