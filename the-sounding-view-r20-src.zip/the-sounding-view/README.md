<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors -->
# The Sounding View — deployable source (release 2)

A standalone static website: music, read with the Cascade Atlas. Release 2 carries the eight sections of the Atlas's page *Music*, the page *The bridges drilled* (the study of round 37, proposed and not merged), nine instruments that play the Atlas's numbers, and the whole site in English and in Italian (a narrator's telling, not a translation). The Italian pages are the narrator's: titles, claims, leads, captions and the Racconto register are Italian, and the Atlas's English records sit in the Ricerca · Atlas · Standard registers and in collapsed cards. The release notes are `RELEASE_NOTES.md`.

**The site is the folder `out/`.** It is committed here, already built and checked, because building it needs two inputs this repository does not carry (the Atlas's source and the pack of round 37, below). A host deploys `out/` as it is: no build step, no dependencies, no server code. The site also opens from the disk (`out/index.html`).

## Deploy

- **Vercel.** Import the repository (or run `npx vercel --prod` in this folder). `vercel.json` sets framework *Other*, no build, output directory `out`, and the content types the site needs (`.py`, `.log`, `.sh`, `.md` as `text/plain`, `.ogg` as `audio/ogg`). Nothing to configure in the dashboard.
- **Netlify.** Connect the repository or drag the folder `out/` onto the dashboard; `netlify.toml` sets the publish folder and the same content types.
- **GitHub Pages.** `.github/workflows/pages.yml` publishes `out/` on every push to `main`: in the repository's *Settings → Pages* set *Source* to *GitHub Actions*. (Pages sets content types by extension itself; the scripts and logs open as text in the browser.)
- **Any static host.** Upload the contents of `out/` to the web root. All links are relative, so the site also works under a sub-path (`example.org/sounding/`). Serve `.ogg` as `audio/ogg` and `.py`, `.log` as `text/plain` where the host lets you.

A local look: `npm run serve` (no install needed) and open `http://localhost:8080/`.

The site's one link into the Atlas is on *About* (`out/about.html` and `out/it/about.html`, `data-atlas-link`): `https://toy-model-v0.vercel.app/#/music`. To point it elsewhere, change `ATLAS_URL` in `gen/build.mjs` and the address the checker accepts in `gen/check.mjs`, rebuild, and commit `out/`.

## Rebuild (optional)

The generator is `gen/` (Node 20 or later; `npm install` brings KaTeX 0.16.47 and Playwright 1.56, the latter for the tests and the screenshots only). It reads, outside this repository:

- the Atlas's source at release 4.4.9 with round 36 merged (`one-rule-src-4.4.9`, its `content/`, `checks/selfcheck/round36/`, `docs/round36/`) — pass its path as the argument or as `SDV_ATLAS`;
- the pack of round 37, `round37_bridges_pack` (`checks/selfcheck/round37/`, `docs/round37/`) — pass its path as `SDV_PACK`;
- round 36's twelve clips as Ogg Vorbis, here in `audio_ogg/` (the script sets `SDV_OGG=audio_ogg`).

```
npm install
SDV_ATLAS=/path/to/one-rule-src-4.4.9 SDV_PACK=/path/to/round37_bridges_pack npm run site:build   # writes out/; 1 s
SDV_ATLAS=... SDV_PACK=... npm run site:check                                                     # 0 errors, 0 warnings required
npm run site:test                                                                                 # the synthesizer: 37 assertions (Chromium)
npm run site:shots                                                                                # screenshots into record/shots/ (not committed)
```

`SDV_IT=off` builds the English site alone; `SDV_IT=partial` renders missing Italian narrations as placeholders. The build refuses to finish when an Italian string or narration is missing. See `record/SITE_NOTES.md` for how the generator works and what it verifies, `NOTE_R2.md` and `BRIEF_R2.md` for the builder's record, and `it/VOICE_IT.md`, `it/draft/`, `it/REVIEW_IT.md` for the Italian narrator's contract, deliveries and review.

## Layout

```
out/          the site (deploy this): 16 pages, out/it/ the 16 Italian pages, katex/, figures/, audio/, checks/, content/version.json
gen/          the generator: build.mjs, check.mjs, test_sounds.mjs, shoot.cjs, manifest_it.mjs, lib/, content/ (the string tables and maps; content/it/ the three Italian tables: strings_it, racconto, titoli), assets/, figures/
it/           the Italian side's record (voice contract, the narrators' drafts and notes, the review)
audio_ogg/    round 36's twelve clips as Ogg Vorbis (a build input)
record/       SITE_NOTES.md, build_log.json, check_log.json, test_sounds.json, shots_report.json
tools/        serve.mjs, a dependency-free static server for a local look
vercel.json · netlify.toml · .github/workflows/pages.yml   the three deploy configurations
```

## Licence

The Cascade Atlas, its tables, figures, scripts and clips, and this site with its generator, are under the PolyForm Noncommercial License 1.0.0 (`LICENSE`). Required Notice: Copyright (c) 2026 the Cascade Atlas authors. KaTeX is MIT (its fonts ship in `out/katex/`); the text fonts are loaded from Google Fonts at run time, with the system fonts as the fallback.
