// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// check.mjs — verifies the built site (../out) against its sources, as the sister site's check_mockup.mjs does:
//  1. every traced block: its text equals its source (a record of the Atlas, an inventory row, the study's sentences),
//     or the declared part of it, and the page shows exactly that text in the element data-b=…
//  2. every [data-s] element shows its string of content/strings.json, and every string has an id, a text and a why
//  3. no untraced sentence: outside the traced elements a page holds no run of three words (ids, numbers, names of files
//     and checks, single letters and symbols are not sentences)
//  4. the chips: each status chip is the status of its row in derived/status.json, drawn as the Atlas draws it
//  5. every row block has its four registers; the Story register says where its text comes from
//  6. links and files: every internal link and anchor resolves, every image, clip, script and stylesheet ships; the site
//     links to the Atlas exactly once (About, data-atlas-link, to #/music)
//  7. formulas: every formula's TeX renders with KaTeX; no KaTeX error on any page
//  8. file://: no script fetches data; content/version.json names the Atlas release, the site release and the date
//  9. the inventories are all shown: 13 + 12 figures with their captions, 12 + 9 clips, 34 lens entries, the 2 + 9 logs
//     (89 + 311 ok lines, 12 + 45 controls), the pack's scripts and logs under checks/round37/
// 10. the proposed rows (round 37's pack): each chip is the status its ROWS.md gives, with the marking "proposed"
// 11. the Italian pages (out/it/, lib/italian.mjs): every data-s against strings_it.json, every data-r against
//     racconto.json (its target on the page, each item rendered once), every tells id on the site, no banned word,
//     lang="it", the language switch both ways, the stamp
// Usage: node gen/check.mjs [REPO]       exit 0 when clean
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { load, resolve, applyPart, norm, GEN, SITE } from './lib/sources.mjs';
import { scriptsP } from './lib/scripts.mjs';
import { SCRIPTS } from './lib/pack.mjs';
import { loadItalian, bannedHits, IT_MODE } from './lib/italian.mjs';

const require = createRequire(import.meta.url);
const katex = (() => { try { return require('katex'); } catch { return require('/opt/npm-tools/node_modules/katex'); } })();
const REPO = path.resolve(process.argv[2] || process.env.SDV_ATLAS || path.join(path.dirname(SITE), 'repo'));
const OUT = path.resolve(process.env.SDV_OUT || path.join(SITE, 'out'));
const D = load(REPO);
const P = D.pack;
const trace = JSON.parse(fs.readFileSync(path.join(GEN, 'build', 'trace.json'), 'utf8'));
const VERSION = JSON.parse(fs.readFileSync(path.join(OUT, 'content', 'version.json'), 'utf8'));
const errors = [], warns = [];
const err = (m) => errors.push(m);
const fill = (t) => String(t).replace(/\{atlas\}/g, VERSION.atlas).replace(/\{release\}/g, VERSION.release).replace(/\{date\}/g, VERSION.date);
const pages = Object.fromEntries(fs.readdirSync(OUT).filter((f) => f.endsWith('.html')).map((f) => [f, fs.readFileSync(path.join(OUT, f), 'utf8')]));
const ITDIR = path.join(OUT, 'it');
const isIt = (f) => f.startsWith('it/');
const IT = IT_MODE === 'off' ? null : loadItalian(GEN, D.site);
if (fs.existsSync(ITDIR)) { if (IT) for (const f of fs.readdirSync(ITDIR).filter((f) => f.endsWith('.html'))) pages['it/' + f] = fs.readFileSync(path.join(ITDIR, f), 'utf8'); else warns.push('out/it/ holds Italian pages, which this check (SDV_IT=off) does not read'); }
const decode = (s) => s.replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&');
const counts = { blocks: 0, strings: 0, chips: 0, rows: 0, links: 0, formulas: 0, narrations: 0 };
const INSTRUMENTS = ['clock', 'tonnetz', 'rhythm', 'chain', 'gliss', 'commas', 'crt', 'rings', 'rows'];
const ROW_PAGES = new Map(); for (const s of D.placements.order) for (const r of [...D.chains.values()].find((c) => c.section === s).rows) ROW_PAGES.set(r, D.placements.sections[s].slug);

// ------------------------------------------------------------ html helpers
// a formula read back as the TeX it renders: $…$ (inline) or $$…$$ (a display), from its data-tex
function untmath(h) {
  let out = '', at = 0;
  for (;;) {
    const re = /<span class="(tmath|dmath)" data-tex="([^"]*)">/g;
    re.lastIndex = at;
    const m = re.exec(h);
    if (!m) return out + h.slice(at);
    const tex = decode(m[2]), dd = m[1] === 'dmath' ? '$$' : '$';
    const sre = /<(\/?)span\b[^>]*>/g;
    sre.lastIndex = m.index + m[0].length;
    let depth = 1, s;
    while ((s = sre.exec(h))) { depth += s[1] ? -1 : 1; if (depth === 0) break; }
    out += h.slice(at, m.index) + dd + tex + dd;
    at = s ? s.index + s[0].length : h.length;
  }
}
function closeOf(html, open, tag) {
  const re = new RegExp(`<(/?)${tag}(?=[\\s>/])[^>]*>`, 'g');
  re.lastIndex = html.indexOf('>', open) + 1;
  let depth = 1, m;
  while ((m = re.exec(html))) { if (m[0].endsWith('/>')) continue; depth += m[1] ? -1 : 1; if (depth === 0) return { inner: m.index, end: m.index + m[0].length }; }
  return null;
}
function elementText(html, attr, id) {
  const at = html.indexOf(`${attr}="${id}"`);
  if (at < 0) return null;
  const open = html.lastIndexOf('<', at);
  const tag = /^<([a-zA-Z0-9]+)/.exec(html.slice(open))[1];
  const c = closeOf(html, open, tag);
  if (!c) return null;
  const inner = untmath(html.slice(html.indexOf('>', at) + 1, c.inner));
  return norm(decode(inner.replace(/<[^>]+>/g, '')));
}

// ------------------------------------------------------------ 1. traced blocks
const ids = new Map();
for (const b of trace.blocks) {
  const where = `${b.page}#${b.blockId}`;
  const k = `${b.page}|${b.blockId}`;
  if (ids.has(k)) err(`duplicate block id ${where}`);
  ids.set(k, b);
  let expected;
  try { expected = applyPart(resolve(D, b.source), b.part || null); } catch (e) { err(`${where}: ${e.message}`); continue; }
  if (norm(expected) !== norm(b.text)) { err(`${where}: trace text differs from its source ${JSON.stringify(b.source)}`); continue; }
  const html = pages[b.page + '.html'];
  if (!html) { err(`${where}: page missing`); continue; }
  const shown = elementText(html, 'data-b', b.blockId);
  if (shown == null) { err(`${where}: no element data-b on the page`); continue; }
  const want = norm(['script', 'md', 'study', 'lines', 'ids'].includes(b.render) ? scriptsP(b.text) : b.text);
  if (shown !== want) err(`${where}: the page shows other text than its source:\n   page:   ${shown.slice(0, 200)}\n   source: ${want.slice(0, 200)}`);
  counts.blocks++;
}
for (const [f, html] of Object.entries(pages)) {
  const page = f.replace(/\.html$/, '');
  for (const m of html.matchAll(/data-b="([^"]+)"/g)) if (!ids.has(`${page}|${m[1]}`)) err(`${f}: data-b="${m[1]}" not in the trace`);
}

// ------------------------------------------------------------ 2. site strings
const STR = JSON.parse(fs.readFileSync(path.join(GEN, 'content', 'strings.json'), 'utf8')).strings;
const seenId = new Set();
for (const s of STR) {
  if (!s.id || !s.text || !s.why) err(`strings.json: an entry without id, text or why: ${JSON.stringify(s).slice(0, 80)}`);
  if (seenId.has(s.id)) err(`strings.json: duplicate id ${s.id}`);
  seenId.add(s.id);
}
const used = new Set();
for (const [f, html] of Object.entries(pages)) {
  if (isIt(f) && !IT) continue;
  const table = isIt(f) ? IT.strings : D.site, tname = isIt(f) ? 'strings_it.json' : 'strings.json';
  for (const m of html.matchAll(/data-s="([^"]+)"/g)) {
    const id = m[1];
    if (!isIt(f)) used.add(id);
    const s = table.get(id);
    if (!s) { err(`${f}: data-s="${id}" is not in ${tname}`); continue; }
    const shown = elementText(html, 'data-s', id);
    // every element with this data-s: check each occurrence
    let at = 0, n = 0;
    for (;;) {
      const i = html.indexOf(`data-s="${id}"`, at);
      if (i < 0) break;
      const t = elementText(html.slice(html.lastIndexOf('<', i)), 'data-s', id);
      if (t !== norm(fill(s.text))) err(`${f}: data-s="${id}" shows "${(t || '').slice(0, 80)}", not its string`);
      at = i + 10; n++;
    }
    if (shown == null) err(`${f}: data-s="${id}" has no text`);
    counts.strings++;
  }
}
for (const s of STR) if (!used.has(s.id) && !s.optional) warns.push(`strings.json: ${s.id} is shown on no page`);

// ------------------------------------------------------------ 3. no untraced sentence
const SKIP_TAGS = new Set(['script', 'style', 'svg', 'code', 'audio', 'head', 'noscript', 'pre', 'math', 'select', 'option']);
function residue(html) {
  const body = html.slice(html.indexOf('<body'));
  const out = [];
  const re = /<(\/?)([a-zA-Z0-9]+)([^>]*)>|([^<]+)/g;
  const stack = [];
  let skip = 0, m;
  while ((m = re.exec(body))) {
    if (m[4] != null) { if (!skip) out.push(m[4]); continue; }
    const [, close, tag0, attrs] = m;
    const tag = tag0.toLowerCase();
    if (/^(br|img|input|meta|link|source|hr|wbr|area|col|embed|param|track)$/.test(tag) || attrs.endsWith('/')) continue;
    if (!close) {
      const skipThis = SKIP_TAGS.has(tag) || /\sdata-(b|s|r)="/.test(attrs) || /class="[^"]*\b(tmath|dmath|katex|rid)\b/.test(attrs);
      stack.push(skipThis);
      if (skipThis) skip++;
      out.push(' ');
    } else {
      const s = stack.pop();
      if (s) skip--;
      out.push(' ');
    }
  }
  return norm(decode(out.join('')));
}
const WORD = /^[\p{L}][\p{L}'’-]*[\p{L}]$/u;
for (const [f, html] of Object.entries(pages)) {
  const text = residue(html);
  const toks = text.split(/\s+/);
  let run = [];
  const flush = () => { if (run.length >= 3) err(`${f}: untraced text "${run.join(' ').slice(0, 120)}"`); run = []; };
  for (const t of toks) {
    const w = t.replace(/^[(“"‘]+|[)”"’.,;:!?]+$/g, '');
    if (WORD.test(w) && w.length >= 2) run.push(w); else flush();
  }
  flush();
}

// ------------------------------------------------------------ 4. chips
const WORDS = { computed: 'chip.computed', 'standard-recomputed': 'chip.standard-recomputed', standard: 'chip.standard', theorem: 'chip.theorem', input: 'chip.input', ours: 'chip.ours', open: 'chip.open', meta: 'chip.meta' };
for (const [f, html] of Object.entries(pages)) {
  for (const m of html.matchAll(/<span class="chip chip--([a-z-]+)" data-status-of="([^"]+)" data-s="([^"]+)">/g)) {
    const pr = P.rows.get(m[2]);
    const st = pr ? { status: pr.status } : D.status[m[2]];
    if (!st) { err(`${f}: a chip for ${m[2]}, which has no status`); continue; }
    if (m[1] !== st.status) err(`${f}: ${m[2]}'s chip is ${m[1]}, its status ${st.status}`);
    if (m[3] !== WORDS[st.status]) err(`${f}: ${m[2]}'s chip says ${m[3]}`);
    // a proposed row's chip carries the marking "proposed" beside it; an Atlas row's never does
    const after = html.slice(m.index + m[0].length, m.index + m[0].length + 260);
    const marked = /^[^<]*<\/span> <span class="chip chip--proposed" data-s="chip.proposed">/.test(after);
    if (pr && !marked) err(`${f}: ${m[2]} is proposed but its chip has no "proposed" marking`);
    if (!pr && marked) err(`${f}: ${m[2]} is a row of the Atlas, marked proposed`);
    counts.chips++;
  }
}

// ------------------------------------------------------------ 5. row blocks: four registers, a source line in Story
for (const [f, html] of Object.entries(pages)) {
  for (const m of html.matchAll(/<article class="row( row--proposed)?" id="([^"]+)" data-status="([^"]+)"/g)) {
    const c = closeOf(html, m.index, 'article');
    const inner = html.slice(m.index, c.end);
    const id = m[2], proposed = !!m[1];
    for (const r of ['story', 'research', 'atlas', 'standard']) if ((inner.match(new RegExp(`class="reg reg--${r}"`, 'g')) || []).length !== 1) err(`${f}#${id}: register ${r} missing or doubled`);
    const storyInner = (closeOf(inner, inner.indexOf('class="reg reg--story"'), 'div') || {}).inner;
    const story = inner.slice(inner.indexOf('class="reg reg--story"'), storyInner);
    if (isIt(f)) { if (!new RegExp(`data-r(?:-missing)?="r:row:${id}"`).test(story)) err(`${f}#${id}: the Racconto register has no narration r:row:${id}`); for (const r of ['research', 'atlas', 'standard']) if (!new RegExp(`class="reg reg--${r}"><p class="src-line it-note" data-s="it.records">`).test(inner)) err(`${f}#${id}: register ${r} without its Italian line`); }
    else if (!/class="src-line"/.test(story)) err(`${f}#${id}: Story without its source line`);
    const want = proposed ? (P.rows.get(id) || {}).status : (D.status[id] || {}).status;
    if (proposed && !P.rows.has(id)) err(`${f}#${id}: a proposed row the pack does not propose`);
    if (!proposed && P.rows.has(id)) err(`${f}#${id}: a row of the pack shown as a row of the Atlas`);
    if (want !== m[3]) err(`${f}#${id}: data-status ${m[3]} against ${want}`);
    counts.rows++;
  }
}
for (const dir of Object.keys(pages).some(isIt) && IT ? ['', 'it/'] : ['']) {
  for (const s of D.placements.order) {
    const p = D.placements.sections[s];
    const html = pages[dir + p.slug + '.html'];
    if (!html) { err(`${dir}${p.slug}.html missing`); continue; }
    const chain = [...D.chains.values()].find((c) => c.section === s);
    const order = [...html.matchAll(/<article class="row" id="([^"]+)"/g)].map((m) => m[1]);
    if (order.join(' ') !== chain.rows.join(' ')) err(`${dir}${p.slug}.html: the rows are not the chain's, in its order (${order.join(' ')})`);
    for (const c of p.clips) if (!html.includes(`src="${dir ? '../' : ''}audio/${c}.ogg"`)) err(`${dir}${p.slug}.html: clip ${c} missing`);
  }
  // the page of the drill: every proposed row once, in the items' order of ROWS.md, each with its item
  const bh = pages[dir + 'bridges.html'];
  if (!bh) { err(`${dir}bridges.html missing`); continue; }
  const order = [...bh.matchAll(/<article class="row row--proposed" id="([^"]+)" data-status="[^"]+" data-proposed="([^"]+)"/g)].map((m) => [m[1], m[2]]);
  const want = P.items.flatMap((it) => it.rows.map((r) => [r, it.item]));
  if (JSON.stringify(order) !== JSON.stringify(want)) err(`${dir}bridges.html: the proposed rows are not the items' rows in their order`);
  for (const im of D.bridgesMap.items) for (const c of im.clips) if (!bh.includes(`src="${dir ? '../' : ''}audio/${c}.ogg"`)) err(`${dir}bridges.html: clip ${c} missing`);
}

// ------------------------------------------------------------ 6. links and files; the one Atlas link
const ATLAS_HOST = 'toy-model-v0.vercel.app';
let atlasLinks = 0;
const anchors = Object.fromEntries(Object.entries(pages).map(([f, h]) => [f, new Set([...h.matchAll(/\sid="([^"]+)"/g)].map((m) => m[1]))]));
for (const [f, html] of Object.entries(pages)) {
  const body = html.replace(/<script[\s\S]*?<\/script>/g, '');
  for (const m of body.matchAll(/<a\b([^>]*)\shref="([^"]+)"/g)) {
    const href = decode(m[2]);
    counts.links++;
    if (href.includes(ATLAS_HOST)) {
      atlasLinks++;
      if (!/^(it\/)?about\.html$/.test(f) || !/data-atlas-link/.test(m[0] + body.slice(m.index, m.index + 300).split('>')[0])) err(`${f}: a link to the Atlas outside About's one link: ${href}`);
      if (href !== 'https://toy-model-v0.vercel.app/#/music') err(`${f}: the Atlas link points to ${href}`);
      continue;
    }
    if (/^(https?:|mailto:)/.test(href)) continue;
    const [file, anchor] = href.split('#');
    const target = file ? path.normalize(path.join(path.dirname(f), file)) : f;
    if (!fs.existsSync(path.join(OUT, target))) { err(`${f}: link to a missing file ${href}`); continue; }
    if (anchor && target.endsWith('.html') && !(anchors[target] || new Set()).has(anchor)) err(`${f}: link to a missing anchor ${href}`);
  }
  for (const m of html.matchAll(/<(?:img|audio|script|source)\b[^>]*\ssrc="([^"]+)"/g)) if (!/^https?:/.test(m[1]) && !fs.existsSync(path.join(OUT, path.dirname(f), m[1]))) err(`${f}: missing file ${m[1]}`);
  for (const m of html.matchAll(/<link\b[^>]*\shref="([^"]+)"/g)) if (!/^https?:/.test(m[1]) && !fs.existsSync(path.join(OUT, path.dirname(f), m[1]))) err(`${f}: missing file ${m[1]}`);
  for (const m of html.matchAll(/<script\b[^>]*\ssrc="(https?:[^"]+)"/g)) err(`${f}: a script from the network, ${m[1]}`);
}
// one link to the Atlas per language: About's, in English and, on the Italian About, the same link
const languages = 1 + (Object.keys(pages).some(isIt) ? 1 : 0);
if (atlasLinks !== languages) err(`the site links to the Atlas ${atlasLinks} times, not once per language (${languages})`);
const css = fs.readFileSync(path.join(OUT, 'katex', 'katex.min.css'), 'utf8');
for (const m of css.matchAll(/url\((fonts\/[^)]+\.woff2)\)/g)) if (!fs.existsSync(path.join(OUT, 'katex', m[1]))) err(`katex: missing font ${m[1]}`);

// ------------------------------------------------------------ 7. formulas
for (const [f, html] of Object.entries(pages)) {
  if (/katex-error/.test(html)) err(`${f}: a KaTeX error is on the page`);
  for (const m of html.matchAll(/<span class="(tmath|dmath)" data-tex="([^"]*)">/g)) {
    try { katex.renderToString(decode(m[2]), { displayMode: m[1] === 'dmath', throwOnError: true, strict: 'ignore', trust: true }); counts.formulas++; } catch (e) { err(`${f}: the TeX ${m[2].slice(0, 60)} does not render: ${e.message.slice(0, 80)}`); }
  }
}
const htmlData = Object.values(pages).reduce((n, h) => n + (h.match(/data-src="[^"]+"/g) || []).length, 0);

// ------------------------------------------------------------ 8. file:// and the version
for (const js of ['site.js', 'sounds.js', 'sounds-data.js']) {
  const t = fs.readFileSync(path.join(OUT, js), 'utf8');
  if (/\bfetch\s*\(|XMLHttpRequest|import\s*\(/.test(t)) err(`${js}: reaches data over the network (file:// pages fetch nothing)`);
  if (!/PolyForm-Noncommercial-1\.0\.0/.test(t.split('\n')[0])) err(`${js}: no licence line`);
}
for (const k of ['site', 'release', 'atlas', 'date']) if (!VERSION[k]) err(`version.json: no ${k}`);
if (VERSION.atlas !== D.pkg.version) err(`version.json names the Atlas ${VERSION.atlas}, the repository is ${D.pkg.version}`);
if (!VERSION.pack || VERSION.pack.standing !== 'proposed, not merged' || !VERSION.pack.studyDate) err('version.json does not name the pack as proposed, not merged, with its study\'s date');
for (const [f, html] of Object.entries(pages)) {
  if (isIt(f)) { const st = IT && IT.strings.get('release.stamp'); const want = st ? fill(st.text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;') : null; if (!want || !html.includes(`data-s="release.stamp">${want}<`) || !want.includes(D.pkg.version)) err(`${f}: no Italian release stamp naming the Atlas ${D.pkg.version}`); continue; }
  if (!html.includes(`built from the Cascade Atlas ${D.pkg.version}`)) err(`${f}: no release stamp of ${D.pkg.version}`);
}

// ------------------------------------------------------------ 9. the inventories shown
const pic = pages['pictures.html'];
for (const fg of D.figures) { if (!pic.includes(`src="figures/${fg.file}"`)) err(`pictures.html: ${fg.file} missing`); if (!fs.existsSync(path.join(OUT, 'figures', fg.file))) err(`figures/${fg.file} not shipped`); }
if (D.figures.length !== 13) err(`FIGURES_INDEX.md lists ${D.figures.length} figures, not 13`);
for (const fg of P.figures) { if (!pic.includes(`src="figures/round37/${fg.file}"`)) err(`pictures.html: ${fg.file} missing`); if (!pages['bridges.html'].includes(`src="figures/round37/${fg.file}"`)) err(`bridges.html: ${fg.file} missing`); if (!fs.existsSync(path.join(OUT, 'figures', 'round37', fg.file))) err(`figures/round37/${fg.file} not shipped`); }
if (P.figures.length !== 12) err(`the pack's FIGURES_INDEX.md lists ${P.figures.length} figures, not 12`);
const snd = pages['sounds.html'];
for (const c of [...D.clips, ...P.clips]) { const o = c.file.replace(/\.wav$/, '.ogg'); if (!snd.includes(`src="audio/${o}"`)) err(`sounds.html: ${o} missing`); if (!fs.existsSync(path.join(OUT, 'audio', o))) err(`audio/${o} not shipped`); }
if (D.clips.length !== 12) err(`INDEX.md lists ${D.clips.length} clips, not 12`);
if (P.clips.length !== 9) err(`the pack's INDEX.md lists ${P.clips.length} clips, not 9`);
for (const n of ['crt', 'rings', 'rows', 'clock', 'tonnetz', 'rhythm', 'chain', 'gliss', 'commas']) if (!snd.includes(`id="i-${n}" data-inst="${n}"`)) err(`sounds.html: the instrument ${n} is missing`);
const dictRows = (pages['dictionary.html'].match(/<tr id="lens-\d+">/g) || []).length;
if (dictRows !== D.lens.dictionary.length || dictRows !== 34) err(`dictionary.html: ${dictRows} lens entries, the lens has ${D.lens.dictionary.length}`);
for (const pg of ['dictionary.html', 'bridges.html']) { const n = (pages[pg].match(/<tr id="pd-[^"]+">/g) || []).length; if (n !== P.dictionary.rows.length) err(`${pg}: ${n} rows of the paper's dictionary, DICTIONARY.md has ${P.dictionary.rows.length}`); }
for (const l of ['music_sound.log', 'music_symmetry.log', 'music_sound.faults.log', 'music_symmetry.faults.log', 'music_sound.py', 'music_symmetry.py']) if (!fs.existsSync(path.join(OUT, 'checks', l))) err(`checks/${l} not shipped`);
for (const s of SCRIPTS) for (const ext of ['.py', '.log', '.faults.log']) if (!fs.existsSync(path.join(OUT, 'checks', 'round37', s + ext))) err(`checks/round37/${s}${ext} not shipped`);
for (const l of ['README.md', 'run_all.sh']) if (!fs.existsSync(path.join(OUT, 'checks', 'round37', l))) err(`checks/round37/${l} not shipped`);
const okLines = (pages['checks.html'].match(/<li class="ok" data-b="log:/g) || []).length;
if (okLines !== 89) err(`checks.html shows ${okLines} ok lines, the two logs have 89`);
const okLines37 = (pages['checks.html'].match(/<li class="ok" data-b="plog:/g) || []).length;
if (okLines37 !== 311) err(`checks.html shows ${okLines37} ok lines of the pack's logs, the nine logs have 311`);
const controls = (pages['checks.html'].match(/<li data-b="fault:/g) || []).length, controls37 = (pages['checks.html'].match(/<li data-b="pfault:/g) || []).length;
if (controls !== 12 || controls37 !== 45) err(`checks.html shows ${controls} + ${controls37} controls, not 12 + 45`);
const bridgeRows = (pages['bridges.html'].match(/<tr id="bridge-\d+">/g) || []).length;
if (bridgeRows !== 11) err(`bridges.html: ${bridgeRows} bridges in the table, not 11`);


// ------------------------------------------------------------ 11. the Italian pages
const itPages = Object.entries(pages).filter(([f]) => isIt(f));
if (IT && itPages.length) {
  const full = IT_MODE === 'full';
  const soft = (m) => (full ? err(m) : warns.push(m));
  // the two tables: every id of strings.json in strings_it.json, each with a text and a why; no duplicate target; no stub in the final build
  if (!IT.present) err('content/it/strings_it.json or racconto.json is missing');
  for (const id of IT.missingIds) soft(`strings_it.json lacks ${id}`);
  for (const [id, st] of IT.strings) { if (!D.site.has(id)) warns.push(`strings_it.json: ${id} is no id of strings.json`); if (!st.text || !st.why) err(`strings_it.json: ${id} has no text or no why`); if (st.stub) soft(`strings_it.json: ${id} is a stub`); }
  for (const t of IT.duplicates) err(`racconto.json: the target ${t} appears twice`);
  for (const [target, it] of IT.racconto) { if (it.id !== 'r:' + target) err(`racconto.json: ${it.id} is not r:${target}`); if (!it.text || !it.why) err(`racconto.json: ${it.id} has no text or no why`); if (it.stub) soft(`racconto.json: ${it.id} is a stub`); if (/<[a-z][^>]*>|\*\*|^#/m.test(it.text)) err(`racconto.json: ${it.id} holds markup`); }
  // the banned words of VOICE_IT.md, in both tables (whole words, every form; the stamp may say release)
  for (const [id, st] of IT.strings) { const h = bannedHits(st.text, { stamp: id === 'release.stamp' }); if (h.length) err(`strings_it.json: ${id} uses a banned word: ${[...new Set(h)].join(', ')}`); }
  for (const [, it] of IT.racconto) { const h = bannedHits(it.text); if (h.length) err(`racconto.json: ${it.id} uses a banned word: ${[...new Set(h)].join(', ')}`); }
  // what a narration may tell: a row on the site, a study section, a clip, a figure, a script or a check tag, a file of the pack, a figure data file, the lens
  const rowOnSite = (id) => ROW_PAGES.has(id) || P.rows.has(id);
  const secId = (n) => 's' + n.replace('.', '-');
  const tellOk = (t) => {
    let m;
    if (rowOnSite(t)) return true;
    if (D.rows.has(t) && /^MUS-7/.test(t)) return true; // a lead of the page music
    if ((m = /^study:§(\d+(?:\.\d+)?)$/.exec(t))) return D.study.bySec.has(secId(m[1]));
    if ((m = /^study:(top|refs|appA)(?:\.\d+)?$/.exec(t))) return true;
    if ((m = /^drill:§(\d+(?:\.\d+)?)$/.exec(t))) return P.study.bySec.has(secId(m[1]));
    if ((m = /^drill:§part 2$/.exec(t))) return P.study.bySec.has('p2');
    if ((m = /^drill:(top|refs|appA|p2)(?:\.\d+)?$/.exec(t))) return true;
    if ((m = /^drill:(.+)$/.exec(t))) return fs.existsSync(path.join(P.dir, 'docs', 'round37', m[1])) || fs.existsSync(path.join(P.dir, 'checks', 'selfcheck', 'round37', m[1].replace(/^checks\//, '')));
    if ((m = /^clip:(\d\d[a-c]?)$/.exec(t))) return [...D.clips, ...P.clips].some((c) => c.file.startsWith(m[1] + '_'));
    if ((m = /^fig:(.+)$/.exec(t))) return D.figByFile.has(m[1] + '.svg') || P.figByFile.has(m[1] + '.svg');
    if ((m = /^check:(music_\w+)\.py$/.exec(t))) return SCRIPTS.includes(m[1]) || ['music_sound', 'music_symmetry'].includes(m[1]);
    if ((m = /^check:([a-z]{2}·[A-Z0-9]+)$/.exec(t))) return [...P.scripts.values()].some((sc) => sc.order.includes(m[1])) || [...D.checks.values()].some((c) => (c.ids || []).some((x) => x.id === m[1]));
    if ((m = /^instrument:(\w+)$/.exec(t))) return INSTRUMENTS.includes(m[1]);
    if ((m = /^lens:(.+)$/.exec(t))) return m[1] === 'mus' || (/^\d+$/.test(m[1]) && +m[1] >= 1 && +m[1] <= D.lens.dictionary.length) || D.lens.dictionary.some((e) => e.atlas === m[1] || e.term === m[1]);
    if (t === 'about') return true;
    if (/\.json$/.test(t)) return !!(D.figdata[t] || P.figdata[t]);
    return false;
  };
  for (const [, it] of IT.racconto) for (const t of it.tells || []) if (!tellOk(t)) err(`racconto.json: ${it.id} tells ${t}, which is not on the site`);
  // the pages: lang="it", the stamp (checked above), the switch both ways, every narration at its target, each once
  const seen = new Map();
  const targetOk = (f, html, at, target) => {
    const page = f.replace(/^it\//, '').replace(/\.html$/, '');
    const inside = (openRe, tag) => { let last = -1, m; const re = new RegExp(openRe, 'g'); while ((m = re.exec(html)) && m.index < at) { const c = closeOf(html, m.index, tag); if (c && c.end > at) last = m.index; } return last >= 0; };
    let m;
    if ((m = /^row:(.+)$/.exec(target))) return inside(`<article class="row(?: row--proposed)?" id="${m[1]}"`, 'article');
    if ((m = /^section:(.+)$/.exec(target))) return page === m[1];
    if ((m = /^page:(.+)$/.exec(target))) return m[1] === 'home' ? page === 'index' : m[1] === 'acoustics' ? page === 'bridges' && inside('<section class="b-dict" id="dictionary">', 'section') : page === m[1];
    if ((m = /^instrument:(.+)$/.exec(target))) return page === 'sounds' && inside(`<section class="inst" id="i-${m[1]}"`, 'section');
    if ((m = /^clip:(.+)$/.exec(target))) return page === 'sounds' && inside(`<div class="clip" id="clip-${m[1]}">`, 'div');
    if ((m = /^bridges:item:(.+)$/.exec(target))) return page === 'bridges' && inside(`<section class="b-item" id="item-${m[1]}">`, 'section');
    if (target === 'bridges:table') return page === 'bridges' && inside('<section class="b-table" id="bridges-table">', 'section');
    if (target === 'bridges:opinion') return page === 'bridges' && inside('<section class="b-opinion" id="opinion">', 'section');
    if (target === 'checks:round37') return page === 'checks' && inside('<section class="script script--r37" id="round37">', 'section');
    if (target === 'pictures:round37') return page === 'pictures' && inside('<section class="pics" id="round37">', 'section');
    return false;
  };
  for (const [f, html] of itPages) {
    if (!/<html lang="it"/.test(html)) err(`${f}: no lang="it"`);
    const page = f.replace(/^it\//, '');
    if (!html.includes(`<nav class="lang"`) || !html.includes(`href="../${page}" hreflang="en" data-s="lang.en"`) || !html.includes(`href="${page}" aria-current="page" hreflang="it" data-s="lang.it"`)) err(`${f}: the language switch does not point both ways`);
    const en = pages[page];
    if (!en || !en.includes(`href="it/${page}" hreflang="it" data-s="lang.it"`) || !en.includes(`href="${page}" aria-current="page" hreflang="en" data-s="lang.en"`)) err(`${page}: the language switch to it/${page} is missing`);
    for (const m of html.matchAll(/<div class="racc[^"]*" data-r="([^"]+)">/g)) {
      const id = m[1], target = id.replace(/^r:/, '');
      const it = IT.racconto.get(target);
      if (!it) { err(`${f}: data-r="${id}" is not in racconto.json`); continue; }
      seen.set(target, (seen.get(target) || 0) + 1);
      const shown = elementText(html, 'data-r', id);
      if (shown !== norm(it.text)) err(`${f}: data-r="${id}" shows other text than racconto.json's`);
      if (!targetOk(f, html, m.index, target)) err(`${f}: data-r="${id}" does not stand at its target`);
      counts.narrations++;
    }
    for (const m of html.matchAll(/data-r-missing="([^"]+)"/g)) soft(`${f}: the narration ${m[1]} is missing (a placeholder stands in)`);
  }
  for (const [target, it] of IT.racconto) { const n = seen.get(target) || 0; if (n !== 1) err(`racconto.json: ${it.id} is rendered ${n} times, not once`); }
  for (const [f, html] of Object.entries(pages)) if (!isIt(f) && !/<html lang="en"/.test(html)) err(`${f}: no lang="en"`);
}

const report = { errors: errors.length, warnings: warns.length, counts: { ...counts, htmlData, okLines, okLines37, controls, controls37, dictRows, proposedRows: P.rows.size, figures: D.figures.length + P.figures.length, clips: D.clips.length + P.clips.length, pages: Object.keys(pages).filter((f) => !isIt(f)).length, pagesIt: Object.keys(pages).filter(isIt).length } };
const checkLog = JSON.stringify({ ...report, mode: IT_MODE, errorList: errors, warnList: warns }, null, 1);
fs.writeFileSync(path.join(GEN, 'build', 'check_log.json'), checkLog);
fs.writeFileSync(path.join(SITE, 'record', 'check_log.json'), checkLog); // the record of the run, beside the notes
for (const e of errors.slice(0, 60)) console.log('ERROR ' + e);
if (errors.length > 60) console.log(`… and ${errors.length - 60} more`);
for (const w of warns.slice(0, 20)) console.log('warn  ' + w);
console.log(`check: ${errors.length} errors, ${warns.length} warnings · ${counts.blocks} traced blocks, ${counts.strings} site strings shown, ${counts.chips} chips, ${counts.rows} row blocks, ${counts.links} links, ${counts.formulas} formulas (${htmlData} with \\htmlData), ${okLines} + ${okLines37} log lines of ok checks, ${controls} + ${controls37} controls, ${dictRows} lens entries, ${report.counts.pages} pages${report.counts.pagesIt ? ` + ${report.counts.pagesIt} in Italian (${counts.narrations} narrations)` : ''}`);
process.exit(errors.length ? 1 : 0);
