// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// fourier12 — Fourier on the twelve (MUS-011, MUS-016, MUS-017, LAB-047)
(function () {
  'use strict';
  window.SDV_EXP = window.SDV_EXP || {};
  window.SDV_EXP['fourier12'] = {
    mount: function (root, data, S, kit) {
      var TAU = Math.PI * 2, el = kit.el, NS = 'exp.fourier12.', snd = false, live = [], timers = [], names = data.names;
      var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      var moving = !reduce, T = 0, k = 1, mask = [1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0], g = null, stage = 'set', gs = 12;
      function hz(pc) { return 261.6256 * Math.pow(2, pc / 12); }
      function cell(p) { var c = el('div', { style: 'min-width:0;overflow:hidden' }); p.appendChild(c); return c; }
      function silence() { live.forEach(function (t) { t.stop(); }); live = []; timers.forEach(clearTimeout); timers = []; }
      function pcs() { var r = []; for (var i = 0; i < 12; i++) if (mask[i]) r.push(i); return r; }
      function chord() { if (!snd) return; silence(); var p = pcs(); p.forEach(function (x) { live.push(kit.tone({ f: hz(x), gain: 0.2 / Math.sqrt(Math.max(1, p.length)), dur: 1.2 })); }); }
      function dft(f, kk) { var re = 0, im = 0; for (var x = 0; x < 12; x++) { var a = -TAU * kk * x / 12; re += f[x][0] * Math.cos(a) - f[x][1] * Math.sin(a); im += f[x][0] * Math.sin(a) + f[x][1] * Math.cos(a); } return [re, im]; }
      function ind() { return mask.map(function (v) { return [v, 0]; }); }
      function absAll() { var f = ind(), o = []; for (var j = 0; j <= 6; j++) { var z = dft(f, j); o.push(Math.hypot(z[0], z[1])); } return o; }
      function pulse() { if (!snd) return; var a = absAll(), best = 1; for (var j = 2; j <= 6; j++) if (a[j] > a[best] + 1e-9) best = j; silence(); for (var bar = 0; bar < 2; bar++) for (var q = 0; q < best; q++) (function (t) { timers.push(setTimeout(function () { if (snd) kit.click(q === 0 ? 1100 : 800, 0.18); }, t)); })(bar * 2000 + q * 2000 / best); }
      g = ind();
      root.classList.add('half');

      // ---------------------------------------------- (a) twelve phasors
      var pa = kit.panel_(root, NS + 'panel.a', S, 'span'), wa = el('div', { style: 'display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:10px' }); pa.appendChild(wa);
      var d1 = kit.canvas(cell(wa), 0.8, 300), d2 = kit.canvas(cell(wa), 0.8, 300), ca = kit.controls(pa), boxes = [];
      var pb0 = kit.button(ca, 'exp.common.play', S, function () { snd = !snd; pb0.textContent = S(snd ? 'exp.common.mute' : 'exp.common.play'); pb0.setAttribute('data-s', snd ? 'exp.common.mute' : 'exp.common.play'); if (snd) { if (!kit.audio()) kit.line(root, 'exp.common.noaudio', S); chord(); } else silence(); });
      kit.button(ca, NS + 'chord', S, chord); kit.button(ca, NS + 'pulse', S, pulse);
      var sk = kit.slider(ca, { id: 'exp.common.mode', S: S, min: 0, max: 6, step: 1, value: k, fmt: function (v) { return String(v); }, onchange: function (v) { k = v; } });
      kit.check(ca, NS + 'motion', S, moving, function (v) { moving = v; });
      var sel = el('select', { 'aria-label': S(NS + 'preset') }); sel.appendChild(el('option', { value: '-1', text: S(NS + 'preset') }));
      data.sets.forEach(function (s, i) { sel.appendChild(el('option', { value: String(i), text: s.name })); }); ca.appendChild(sel);
      sel.addEventListener('change', function () { var i = +sel.value; if (i < 0) return; var m = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; data.sets[i].pcs.forEach(function (x) { m[x] = 1; }); setMask(m); });
      var tg = el('div', { class: 'exp-controls' }); pa.appendChild(tg);
      for (var i = 0; i < 12; i++) (function (i) { var l = el('label', { class: 'exp-check' }), inp = el('input', { type: 'checkbox' }); inp.checked = !!mask[i]; inp.addEventListener('change', function () { mask[i] = inp.checked ? 1 : 0; changed(); }); l.appendChild(inp); l.appendChild(el('span', { text: names[i] })); tg.appendChild(l); boxes.push(inp); })(i);
      function setMask(m) { mask = m.slice(); boxes.forEach(function (b, j) { b.checked = !!mask[j]; }); changed(); }
      function changed() { g = ind(); chord(); }
      var ra = kit.readout(pa); kit.line(pa, NS + 'a.note', S);
      d1.el.addEventListener('click', function (e) { var r = d1.el.getBoundingClientRect(), b = d1.box; if (!b) return; var x = e.clientX - r.left, j = Math.round((x - b.x0) / b.step - 0.5); if (j >= 0 && j <= 6) { k = j; sk.set(j); } });
      function drawA() {
        var s = d1.size(), c = d1.ctx, W = s.w, H = s.h, a = absAll(), n = pcs().length, box = { l: 34, t: 14, r: W - 8, b: H - 28 }; c.clearRect(0, 0, W, H);
        var ymax = Math.max(4, Math.ceil(Math.max.apply(null, a) + 0.5), n ? Math.sqrt(data.amiot[n] || 0) + 0.5 : 0);
        var ax = kit.axes(c, box, { xmin: 0, xmax: 7, ymin: 0, ymax: ymax, xticks: [], yticks: [0, Math.round(ymax / 2), ymax], xlabel: 'k' });
        d1.box = { x0: ax.x(0), step: ax.x(1) - ax.x(0) };
        for (var j = 0; j <= 6; j++) { var x0 = ax.x(j + 0.15), x1 = ax.x(j + 0.85), y = ax.y(a[j]); c.fillStyle = j === k ? kit.accent() : kit.muted(); c.globalAlpha = j === k ? 0.9 : 0.4; c.fillRect(x0, y, x1 - x0, box.b - y); c.globalAlpha = 1; c.fillStyle = kit.muted(); c.font = '11px system-ui, sans-serif'; c.textAlign = 'center'; c.fillText(String(j), (x0 + x1) / 2, box.b + 14); }
        if (n >= 1 && n <= 11) { var ym = Math.sqrt(data.amiot[n]); c.strokeStyle = kit.warm(); c.lineWidth = 1.6; c.setLineDash([5, 3]); c.beginPath(); c.moveTo(box.l, ax.y(ym)); c.lineTo(box.r, ax.y(ym)); c.stroke(); c.setLineDash([]); }
        // the phasors for k: the set's notes as unit vectors e^(2 pi i j k / 12), head to tail
        var s2 = d2.size(), c2 = d2.ctx, W2 = s2.w, H2 = s2.h, p = pcs(), sc = 1, rot = moving ? T * 0.6 : 0, x = 0, y = 0, cx = W2 / 2, cy = H2 / 2;
        c2.clearRect(0, 0, W2, H2); var tot = [0, 0]; p.forEach(function (j) { var ang = -TAU * j * k / 12; tot[0] += Math.cos(ang); tot[1] += Math.sin(ang); });
        var c0 = [-tot[0] / 2, -tot[1] / 2], ext = 1, qx = c0[0], qy = c0[1]; p.forEach(function (j) { var an = -TAU * j * k / 12; qx += Math.cos(an); qy += Math.sin(an); ext = Math.max(ext, Math.abs(qx), Math.abs(qy)); }); ext = Math.max(ext, Math.abs(c0[0]), Math.abs(c0[1])); sc = Math.min(W2, H2) * 0.45 / ext; c2.strokeStyle = kit.muted(); c2.globalAlpha = 0.3; c2.beginPath(); c2.arc(cx, cy, sc, 0, TAU); c2.stroke(); c2.globalAlpha = 1;
        function R(v) { var cr = Math.cos(rot), sr = Math.sin(rot); return [cx + (v[0] * cr - v[1] * sr) * sc, cy - (v[0] * sr + v[1] * cr) * sc]; }
        x = c0[0]; y = c0[1];
        p.forEach(function (j) { var ang = -TAU * j * k / 12, nx = x + Math.cos(ang), ny = y + Math.sin(ang), A = R([x, y]), B = R([nx, ny]); kit.arrow(c2, A[0], A[1], B[0], B[1], kit.accent(), 1.5); x = nx; y = ny; });
        var A0 = R(c0), B0 = R([c0[0] + tot[0], c0[1] + tot[1]]); kit.arrow(c2, A0[0], A0[1], B0[0], B0[1], kit.warm(), 3.4);
        var pre = ''; data.sets.forEach(function (st) { if (st.pcs.length === p.length && st.pcs.every(function (q) { return mask[q]; })) pre = '   |â(' + k + ')|² = ' + st.abs2_exact[String(k)]; });
        ra.textContent = 'k = ' + k + '   |â(k)| = ' + kit.num(a[k], 4) + pre + '   |A| = ' + n + (n >= 1 && n <= 11 ? '   max |â|² = ' + kit.num(data.amiot[n], 3) : '');
      }

      // ---------------------------------------------- (b) the CRT grid
      var pb = kit.panel_(root, NS + 'panel.b', S), db = kit.canvas(cell(pb), 0.78, 300), cb = kit.controls(pb);
      kit.seg(cb, { ids: [NS + 'stage.set', NS + 'stage.rows', NS + 'stage.cols'], values: ['set', 'rows', 'cols'], value: stage, S: S, onchange: function (v) { stage = v; } });
      kit.button(cb, NS + 'X', S, function () { g = g.map(function (_, x) { return g[(x + 11) % 12]; }); });
      kit.button(cb, NS + 'Z', S, function () { g = g.map(function (z, x) { var a = TAU * x / 12, ca_ = Math.cos(a), sa = Math.sin(a); return [z[0] * ca_ - z[1] * sa, z[0] * sa + z[1] * ca_]; }); });
      kit.button(cb, 'exp.common.reset', S, function () { g = ind(); });
      var rb = kit.readout(pb); kit.line(pb, NS + 'b.note', S);
      function cellAt(a, b) { return (4 * a + 3 * b) % 12; }
      function drawB() {
        var s = db.size(), c = db.ctx, W = s.w, H = s.h, cw = (W - 10) / 4, ch = (H - 10) / 3, a, b, q, p; c.clearRect(0, 0, W, H);
        // rows then columns: G(a, q) = sum_b g(a, b) e^(-2 pi i q b / 4); F(p, q) = sum_a G(a, q) e^(-2 pi i p a / 3)
        var G = [], F = [], err = 0, kk;
        for (a = 0; a < 3; a++) { G[a] = []; for (q = 0; q < 4; q++) { var re = 0, im = 0; for (b = 0; b < 4; b++) { var z = g[cellAt(a, b)], an = -TAU * q * b / 4; re += z[0] * Math.cos(an) - z[1] * Math.sin(an); im += z[0] * Math.sin(an) + z[1] * Math.cos(an); } G[a][q] = [re, im]; } }
        for (p = 0; p < 3; p++) { F[p] = []; for (q = 0; q < 4; q++) { var re2 = 0, im2 = 0; for (a = 0; a < 3; a++) { var w = G[a][q], an2 = -TAU * p * a / 3; re2 += w[0] * Math.cos(an2) - w[1] * Math.sin(an2); im2 += w[0] * Math.sin(an2) + w[1] * Math.cos(an2); } F[p][q] = [re2, im2]; } }
        for (kk = 0; kk < 12; kk++) { var d = dft(g, kk), f = F[kk % 3][kk % 4]; err = Math.max(err, Math.hypot(d[0] - f[0], d[1] - f[1])); }
        for (a = 0; a < 3; a++) for (b = 0; b < 4; b++) {
          var x0 = 5 + b * cw, y0 = 5 + a * ch, pc = cellAt(a, b), v, lab;
          if (stage === 'set') { v = g[pc]; lab = names[pc]; } else if (stage === 'rows') { v = G[a][b]; lab = 'a' + a + ' q' + b; } else { v = F[a][b]; lab = 'k=' + (function () { for (var j = 0; j < 12; j++) if (j % 3 === a && j % 4 === b) return j; })(); }
          var m = Math.hypot(v[0], v[1]), mx = stage === 'set' ? 1 : 4;
          c.fillStyle = kit.accent(); c.globalAlpha = 0.08 + 0.55 * kit.clamp(m / mx, 0, 1); c.fillRect(x0 + 1, y0 + 1, cw - 2, ch - 2); c.globalAlpha = 1; c.strokeStyle = kit.muted(); c.lineWidth = 1; c.strokeRect(x0 + 1, y0 + 1, cw - 2, ch - 2);
          c.fillStyle = kit.muted(); c.font = '10px system-ui, sans-serif'; c.textAlign = 'left'; c.fillText(lab, x0 + 5, y0 + 12); c.textAlign = 'right'; c.fillText(kit.num(m, 2), x0 + cw - 5, y0 + ch - 6);
          var hx = x0 + cw / 2, hy = y0 + ch / 2 + 2, hr = Math.min(cw, ch) * 0.28, ang = m > 1e-9 ? Math.atan2(v[1], v[0]) : 0;
          if (m > 1e-9) kit.arrow(c, hx, hy, hx + hr * Math.cos(ang), hy - hr * Math.sin(ang), kit.ink(), 1.6);
          if (stage === 'set') { var ch_ = -TAU * k * pc / 12; c.globalAlpha = 0.8; kit.arrow(c, hx, hy, hx + hr * 0.8 * Math.cos(ch_), hy - hr * 0.8 * Math.sin(ch_), kit.warm(), 1.2); c.globalAlpha = 1; }
        }
        rb.textContent = '(a, b) = (1, 3) ↔ 1   max |rows·columns − direct| = ' + err.toExponential(1);
      }

      // ---------------------------------------------- (c) the Gauss sum of the clock
      var pc2 = kit.panel_(root, NS + 'panel.c', S), dc = kit.canvas(cell(pc2), 0.9, 320), cc = kit.controls(pc2);
      kit.slider(cc, { id: NS + 'steps', S: S, min: 0, max: 12, step: 1, value: gs, fmt: function (v) { return String(v); }, onchange: function (v) { gs = v; } });
      var rc = kit.readout(pc2), g1 = el('p', { class: 'exp-line' }), g2 = el('p', { class: 'exp-line' }); pc2.appendChild(g1); pc2.appendChild(g2);
      kit.grade(g1, 'exact', 'exp.common.grade.exact', S); g1.appendChild(document.createTextNode(' ')); g1.appendChild(el('span', { 'data-s': NS + 'c.exact', text: S(NS + 'c.exact') }));
      kit.grade(g2, 'none', 'exp.common.grade.none', S); g2.appendChild(document.createTextNode(' ')); g2.appendChild(el('span', { 'data-s': NS + 'c.none', text: S(NS + 'c.none') }));
      function walk(c, n, q, x0, y0, sc, steps, col) {
        var x = 0, y = 0, pts = [[0, 0]], j; for (j = 0; j < n; j++) { var ang = TAU * q(j); x += Math.cos(ang); y += Math.sin(ang); pts.push([x, y]); }
        var cx = (Math.min.apply(null, pts.map(function (p) { return p[0]; })) + Math.max.apply(null, pts.map(function (p) { return p[0]; }))) / 2, cy = (Math.min.apply(null, pts.map(function (p) { return p[1]; })) + Math.max.apply(null, pts.map(function (p) { return p[1]; }))) / 2;
        function P(p) { return [x0 + (p[0] - cx) * sc, y0 - (p[1] - cy) * sc]; }
        for (j = 0; j < Math.min(steps, n); j++) { var A = P(pts[j]), B = P(pts[j + 1]); kit.arrow(c, A[0], A[1], B[0], B[1], col, 1.4); }
        var e = P(pts[0]), f = P(pts[n]); if (steps >= n) kit.arrow(c, e[0], e[1], f[0], f[1], kit.warm(), 3); return pts[n];
      }
      function drawC() {
        var s = dc.size(), c = dc.ctx, W = s.w, H = s.h; c.clearRect(0, 0, W, H); var wide = W > 520;
        var big = walk(c, 12, function (j) { return j * j / 12; }, wide ? W * 0.27 : W / 2, wide ? H / 2 : H * 0.3, Math.min(W, H) * (wide ? 0.11 : 0.09), gs, kit.accent());
        var z4 = walk(c, 4, function (j) { return 3 * j * j / 4; }, wide ? W * 0.62 : W * 0.28, wide ? H * 0.28 : H * 0.78, Math.min(W, H) * 0.14, gs >= 12 ? 4 : Math.min(gs, 4), kit.blue);
        var z3 = walk(c, 3, function (j) { return 4 * j * j / 3; }, wide ? W * 0.85 : W * 0.72, wide ? H * 0.28 : H * 0.78, Math.min(W, H) * 0.14, gs >= 12 ? 3 : Math.min(gs, 3), kit.red);
        c.fillStyle = kit.muted(); c.font = '12px system-ui, sans-serif'; c.textAlign = 'center'; c.fillText('ℤ₁₂', wide ? W * 0.27 : W / 2, wide ? H - 10 : H * 0.55); c.fillText('ℤ₄', wide ? W * 0.62 : W * 0.28, wide ? H * 0.5 : H * 0.97); c.fillText('ℤ₃', wide ? W * 0.85 : W * 0.72, wide ? H * 0.5 : H * 0.97);
        if (wide) c.fillText('×', W * 0.735, H * 0.28);
        var pr = [z4[0] * z3[0] - z4[1] * z3[1], z4[0] * z3[1] + z4[1] * z3[0]];
        rc.textContent = 'Σ ζ^(j²) = ' + kit.num(big[0], 3) + ' + ' + kit.num(big[1], 3) + ' i  (' + data.gauss.x2_12.sum + ')   ℤ₄: ' + data.gauss.Z4_part_3a2_4.sum + '   ℤ₃: ' + data.gauss.Z3_part_4b2_3.sum + '   product ' + kit.num(pr[0], 3) + ' + ' + kit.num(pr[1], 3) + ' i';
      }

      var pz = kit.panel_(root, 'exp.common.see', S); kit.line(pz, NS + 'see', S);
      var ph = kit.panel_(root, 'exp.common.hear', S); kit.line(ph, NS + 'hear', S);
      var pdt = el('p', { class: 'exp-line' }); pdt.appendChild(el('strong', { 'data-s': 'exp.common.data', text: S('exp.common.data') })); pdt.appendChild(document.createTextNode(' ')); pdt.appendChild(el('span', { 'data-s': NS + 'data', text: S(NS + 'data') }));
      root.appendChild(el('div', { class: 'exp-panel span' }, [pdt]));
      kit.loop(function (t, dt) { if (moving) T += dt; drawA(); drawB(); drawC(); });
    }
  };
})();
