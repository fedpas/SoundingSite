#!/usr/bin/env python3
"""Checks for the Italian narrator's tables: banned words (as the site's checker matches them),
word counts against the manifest's lengths, no HTML/markdown/TeX, placeholders kept, ids complete."""
import json, re, sys

BANNED = re.compile(r"\b(adesso|nuov[oaie]|recent[ei]|ultim[oaie]|aggiornat[oaie]|precedent[ei]|corrett[oaie]|sostituit[oaie]|superat[oaie]|version[ei]|release|new)\b", re.I)
ROUND = re.compile(r"\bround\s*\d+\b", re.I)
ORA = re.compile(r"(?<!['’])\bora\b", re.I)
PRIMA = re.compile(r"(\b(come|di|da)\s+prima\b)|(\bprima\s*(di|che|del|della|dei|delle|dello|degli|dell['’]|d['’])\b)|(\bprima\s*[,.;:!?)]|\bprima\s*$)", re.I)
HTML = re.compile(r"<[a-zA-Z/][^>]*>")
MD = re.compile(r"(\*\*|__|^#|`|\\\(|\\\[|\\frac|\\sqrt)", re.M)

def banned(text, allow_release=False):
    hits = []
    for m in BANNED.finditer(text):
        w = m.group(0)
        if allow_release and w.lower() in ("release", "versione", "versioni"):
            continue
        hits.append(w)
    hits += [m.group(0) for m in ROUND.finditer(text)]
    hits += [m.group(0) for m in ORA.finditer(text)]
    hits += [m.group(0) for m in PRIMA.finditer(text)]
    return hits

def words(text):
    return len([t for t in re.split(r"\s+", text.strip()) if t])

def main(manifest_path, racconto_path, strings_it_path, strings_en_path):
    m = json.load(open(manifest_path, encoding="utf-8"))
    rac = json.load(open(racconto_path, encoding="utf-8"))
    sit = json.load(open(strings_it_path, encoding="utf-8"))
    sen = json.load(open(strings_en_path, encoding="utf-8"))
    errors = []
    targets = {t["target"]: t for t in m["targets"]}
    # --- racconto
    seen = set()
    counts = []
    for it in rac["items"]:
        tg = it["target"]
        if tg in seen: errors.append(f"target twice: {tg}")
        seen.add(tg)
        if tg not in targets: errors.append(f"target not in manifest: {tg}"); continue
        mt = targets[tg]
        if it["id"] != "r:" + tg: errors.append(f"id mismatch: {it['id']}")
        if it["tells"] != mt["tells"]: errors.append(f"tells differ from manifest: {tg}")
        lo, hi = [int(x) for x in mt["length"].replace("–", "-").split("-")]
        n = words(it["text"])
        counts.append((tg, n, lo, hi))
        if not (lo <= n <= hi): errors.append(f"length {tg}: {n} words, wants {lo}–{hi}")
        b = banned(it["text"])
        if b: errors.append(f"banned in {tg}: {b}")
        if HTML.search(it["text"]): errors.append(f"html in {tg}")
        if MD.search(it["text"]): errors.append(f"markdown/tex in {tg}")
        if not it.get("why"): errors.append(f"no why: {tg}")
    # --- strings
    new_ids = {s["id"] for s in m["strings_new"]}
    changed = {s["id"]: s for s in m["strings_changed"]}
    en = {s["id"]: s for s in sen["strings"]}
    mine = [i for i in en if i not in new_ids]
    got = {s["id"]: s for s in sit["strings"]}
    for i in mine:
        if i not in got: errors.append(f"string missing: {i}"); continue
        t = got[i]["text"]
        en_text = changed[i]["text"] if i in changed else en[i]["text"]
        ph_en = sorted(re.findall(r"\{[a-z]+\}", en_text)); ph_it = sorted(re.findall(r"\{[a-z]+\}", t))
        if ph_en != ph_it: errors.append(f"placeholders differ in {i}: {ph_en} vs {ph_it}")
        b = banned(t, allow_release=(i == "release.stamp"))
        if b: errors.append(f"banned in string {i}: {b}")
        if HTML.search(t): errors.append(f"html in string {i}")
        if not got[i].get("why"): errors.append(f"no why: string {i}")
        if not t.strip(): errors.append(f"empty string {i}")
    extra = [i for i in got if i not in mine]
    if extra: errors.append(f"strings not mine: {extra}")
    if len(got) != 220: errors.append(f"strings count {len(got)} != 220")
    print(f"items: {len(rac['items'])}, narration words: {sum(c[1] for c in counts)}, strings: {len(got)}, string words: {sum(words(s['text']) for s in sit['strings'])}")
    for tg, n, lo, hi in counts:
        flag = "" if lo <= n <= hi else "  <-- OUT"
        print(f"  {tg:22s} {n:4d}  [{lo}–{hi}]{flag}")
    if errors:
        print("ERRORS:"); [print("  " + e) for e in errors]; sys.exit(1)
    print("OK: no banned word, every length in range, 220 strings, placeholders kept")

if __name__ == "__main__":
    main(*sys.argv[1:5])
