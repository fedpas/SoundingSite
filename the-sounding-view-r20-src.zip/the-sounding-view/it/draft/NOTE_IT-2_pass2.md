# NOTE_IT-2_pass2 — the narrator IT-2's second pass

Delivered in `site/it/draft/`:

- `titoli_bridges.json` — 117 items, one per target of my share in `gen/content/it/MANIFEST_TITOLI.json`, `{ id: "t:" + target, target, text, why }`: the page of the bridges (`page:bridges`, `page:bridges:sub`, `page:bridges:head`, `card:page:bridges`), the one-line claims of the 36 rows `row:MUS-014` … `row:MUS-049`, the captions of the twelve figures (`fig:two_clocks`, `fig:crt_tonnetz`, `fig:fig_johnson_tonnetz`, `fig:fig_bell_levels`, `fig:fig_288`, `fig:fig_harmonic_ring`, `fig:two_cuts`, `fig:fig_rows`, `fig:fig_chain`, `fig:fig_sets`, `fig:fig_motors`, `fig:fig_grades`), the title lines of `clip:13` … `clip:21`, the titles of the eight `item:*`, the 22 `bridge:<n>` / `bridge:<n>:why`, the 17 `paper:<row>` (0, 1a, 1b, 2 … 15), the nine `check:music_*`.
- `pass2_edits_bridges.json` — `{"racconto": [{target, text}], "strings": [{id, text} | {id, drop: true}]}`: the 46 narrations and the 26 strings of my half of the merged tables that change (the full new text, built on the merged, reviewed text: the reviewers' changes are kept), plus the 9 strings the builder removed, marked `drop: true`. I did not edit `gen/content/it/racconto.json` or `strings_it.json`.
- `check_IT-2_pass2.py` — the standalone check (below). Run from anywhere: `python3 -I site/it/draft/check_IT-2_pass2.py`.

The two JSON files load (`python3 -c 'import json; json.load(open(...))'`, exit 0).

## The manifest's keys

I followed `MANIFEST_TITOLI.json`. Its keys are the ones you listed: the figures are `fig:<svg basename>` (so `fig:fig_288`, `fig:two_clocks`), the scripts `check:music_clock12` (no `.py`), the paper rows `paper:0`, `paper:1a`, `paper:1b`, `paper:2` … `paper:15`, the bridges `bridge:1` … `bridge:11` with `bridge:<n>:why`. Its lengths differ a little from VOICE_IT.md's table: `page:bridges` "≤ 6 words", `page:bridges:sub` "one line, ≤ 16 words", `page:bridges:head` "one line, ≤ 25 words"; the rest as VOICE_IT.md (row ≤ 14 no final period, fig 15–45, clip ≤ 10, item ≤ 10, bridge ≤ 8 / why ≤ 25, paper ≤ 10, check ≤ 16, card 40–70). The manifest's `what` for `page:bridges:head` still says "what the study is, for whom, when": I wrote what the page is and left out the date and the "for whom", as VOICE_IT.md's table asks (no byline, no date, no owner).

## What I wrote (titoli_bridges.json)

- **The page.** `page:bridges` = "I ponti" (the navigation already says Ponti). `page:bridges:sub` = "Undici ponti fra l'Atlante e la musica, ciascuno con il suo grado e il suo calcolo". `page:bridges:head` = "Uno studio di undici ponti fra l'Atlante e la musica, letti sulle etichette: che cosa ciascuno unisce, che cosa lo regge, con quale grado" (24 words, no byline, no date, no owner, no process word). `card:page:bridges` (67 words): the eleven bridges as the study's lead lists them, the four grades, "dove un grado stava per un calcolo mancante, il calcolo c'è", the counts 36 / 12 / 9 — never "proposte". IT-1's optional `pass2_strings_new_r1.json` holds `b.sub`, `b.lead`, `b.card.p` for the same places: if the builder renders the titoli targets, mine stand; if it renders the strings, IT-1's are fine too (they say the same things; "ciascuno graduato" there is a rougher Italian than "ciascuno con il suo grado").
- **The items** (≤ 10 tokens; a colon instead of the English dash, to stay inside the limit with the bridges' numbers): "L'orologio: i ponti 4, 7 e 9"; "Le etichette di dodici: i ponti 3, 6 e 8"; "Dualità e campana: i ponti 5, 2, 1 e 11"; "Il cammino: l'altra metà del ponte 7"; "Le serie come strumento: i ponti 3 e 6"; "L'anello senza le sue ipotesi: il ponte 1"; "Il corpo rigido sui motori dell'Atlante: il ponte 11"; "Suono e luce sul nucleo, e l'articolo: il ponte 2".
- **The bridges.** The name is what the bridge joins, with the record's ↔ ("il passo della molla ↔ anello, corda, tono"; "etichette ↔ insiemi di classi di altezza"; "dualità di Lewin ↔ il corpo rigido"). The `why` says what decided the grade, from the "after" cell of BRIDGES_DRILLED.md's table and the item's BRIDGE.md, in ≤ 25 tokens, with the grade's reason and not the work's words (bridge 4: "I due orologi condividono esattamente un ℤ₄, calcolato, e nessuna pratica musicale lo usa; la regola con il modulo 12 gira nel codice dell'Atlante"; bridge 10: "Gli stati delle righe seguono la regola dell'Atlante, esatto; le notazioni come vedute restano parziali: il grado non cambia"). No final period on the names and the whys (table cells).
- **The rows.** One line each from the row's `homePhys` (and `homeMath` where the physics line is thin: MUS-026, MUS-027, MUS-042), ≤ 14 tokens, no final period, no id and no English; the status words are not in the line (the chip shows them), except MUS-049, whose claim is a reading: "Acustica ed elettromagnetismo come una sola veduta da due lati: una lettura nostra". The numbers are the records' (9 985 920; 3856; 224 and 352; 4096; √j).
- **The figures.** From FIGURES_INDEX.md's captions as the manifest carries them: what the figure shows and what to look at ("Guardate…", "Seguite la quinta lungo la diagonale…"), 40–44 tokens each, the records' numbers (0.0195; 12, 41, 53, 306, 665; 42 of 50; 36 sets up to 14). "Commi" for the plural of comma, as the reviewers wrote it in the merged racconto.
- **The clips.** Title lines after INDEX.md's "what is heard" ("Il 3-cubo pizzicato: tre parziali 1, √2, √3"; "Il cuneo: l'accordo della Nonna di Slonimsky").
- **The paper rows.** The Atlas column in the Atlas's words, ≤ 10 tokens: the object the Atlas holds, and "nessuna riga" where it holds none, the grade left to the table ("Cl(1,3) ≅ M₂(ℍ); la stella di Hodge, etichetta massima"; "il quadripotenziale come dato in ingresso; nessuna riga per l'acustica"; "nessuna riga: nessuna densità di spin nell'Atlante"; "lo spigolo temporale di Dirac; la traduzione è nostra").
- **The scripts.** One line each: the bridges the script crosses and what it computes, from the README's lines ("I ponti 4, 7 e 9: l'orologio delle dodici classi contro quello delle etichette, Gauss, Weil").

Terminology beyond the first NOTE: *il grado d'arrivo* for the grade after (beside *il grado di partenza*; "proposto" is a process word in every table now); *attraversare* / *percorrere* a bridge, never a drill word; *la pagina dei ponti*, *i ponti*, *lo studio dei ponti* for the page and the study (its title *The bridges drilled* named only on Fonti and Il metodo); *le schede dell'Atlante* for the records and *schede a scomparsa* for the disclosures, IT-1's words; *questa edizione del sito* for "release 2" on Il metodo (IT-1's stamp says Edizione); *i file dello studio* for the pack; *le notazioni come vedute* (bridge 10); *una lettura nostra* unchanged.

## The bookkeeping cuts (pass2_edits_bridges.json)

What I searched for on my half of the merged tables (62 narrations, 176 strings after the builder's 9 removals), after the reviewers' changes, which I kept: round N, pacchetto, integrato / non integrato (every form), proposto/a/i/e, release, versione, 4.4.9, proprietario, nota di ricerca, consegna (the brief), every drill word (sondare/sondato, trivellare, perforare, drill), "The bridges drilled" outside Fonti and Il metodo, and the first pass's banned list. Found and changed, in short (the full old → new of every edit is at the end of this note):

- `page:bridges`: rewritten (215 → 215 words): no "nota di ricerca scritta per il proprietario", no "The bridges drilled", no "sondato", no "righe proposte", no "Nulla è integrato nelle tavole: lo studio è conservato come pacchetto…"; the page opens with the eleven bridges as the study's lead lists them, the grades of *Music on the labels*, the three questions ("Tre domande guidano lo studio"), the counts, "Ogni numero di questa pagina è una riga di un log".
- `bridges:table`: "La tabella è quella del BRIDGES_DRILLED.md del pacchetto, le schede dei capitoli riunite" → "La tabella riunisce le schede degli otto capitoli nell'ordine dei ponti"; "il grado proposto" → "il grado d'arrivo" (94 → 92).
- `bridges:item:clock`, `duality`: "sonda i ponti" → "attraversa i ponti"; `clock`, `labels`: "I gradi proposti:" → "I gradi:"; `walk`, `rings`: "Il grado proposto:" → "Il grado:"; `acoustics`: "l'articolo che il proprietario ha allegato" → "l'articolo".
- The 36 rows: "La riga MUS-0nn, proposta, …" → "La riga MUS-0nn …" (MUS-014: ", proposta e non integrata nelle tavole," cut; MUS-016, MUS-036, MUS-044: "proposta con lo stato standard, ricalcolato" → "con lo stato standard, ricalcolato"; MUS-049: "una lettura nostra, proposta, senza una verifica propria" → "una lettura nostra, senza una verifica propria"). MUS-043 besides: "integrati daccapo" → "ricostruiti daccapo" (the series re-integrated coefficient by coefficient; "integrati" would read as the process word) and "La consegna si aspettava il contrario" → "Ci si poteva aspettare il contrario" (the brief is the work's).
- `page:acoustics`: "una proposta del pacchetto" → "una riga dei ponti"; "la sede e la scelta che spetta al proprietario" → "la sede e ciò che resta da decidere".
- `checks:round37`: "del pacchetto" → "dei ponti"; "sonda" → "attraversa"; "Nulla è integrato nelle tavole: le righe che questi script sostengono sono proposte." → "Ogni riga dei ponti poggia su un gruppo di questi script, e da lì viene il suo stato." (154 → 159).
- The strings: the 24 of the manifest's `strings_changed` that are mine, re-worded for the new English (`home.more.bridges`, `b.title` → "I ponti", `b.table.p`, `b.items.note`, `b.rows` → "Le righe", `b.rows.note`, `src.paper`, `blk.from.research.p`, `blk.research.p`, `atl.proposed` → "lo stato che la regola dà", `atl.home.proposed` → "Dove avrebbe sede", `std.bridge.proposed` → "d'arrivo", `checks.r37` → "Gli script dei ponti", `checks.r37.p`, `checks.r37.readme`, `pics.r37` → "Le dodici figure dei ponti", `pics.r37.p`, `dict.paper.p`, `dict.paper.cand.p`, `i8.p`, `method.4`, `about.italian.p`); two of them already matched the new English and are not in the file (`b.question.note` "Con le parole dello studio: il §1 e l'apertura della sua seconda parte."; `i9.p` "…suonate con la regola di disposizione dello studio…"). Besides the manifest's list: `b.col.after` "Proposto" → "D'arrivo" (its English "After" did not change; it is in `strings_it_to_reword`); `dict.paper.more` "…nella pagina The bridges drilled:" → "…nella pagina I ponti:" (its English still names *The bridges drilled* on the Dictionary page: the builder may want to change it too); `about.reads.pack` and `about.reads.pack.k` (Il metodo; their English is unchanged) re-worded without "pacchetto" / "integrato": "I file dello studio The bridges drilled, conservati e non ancora nelle tavole: …" and "Ciò che quei file dicono di sé stessi:". The 9 removed strings (`it.records`, `card.rows.proposed`, `b.kicker`, `b.standing`, `b.stamp.k`, `b.item.bridge`, `chip.proposed`, `chip.legend.proposed`, `sounds.clips.r37`) are marked `drop: true`.
- On Il metodo the title *The bridges drilled* stays in `method.4`, `about.reads.pack` (and `BRIDGES_DRILLED.md`, a file name), and on Fonti in `src.refs2` and `src.paper`, as the brief allows; "release 2" is told as "questa edizione del sito", "round 37" does not appear.

Every edited narration stays inside its range of `MANIFEST.json` after the cut (the 36 rows 126–134 of 60–140; the items 161–177 of 120–180; `page:bridges` 215 of 150–220; `bridges:table` 92 of 60–100; `page:acoustics` 175 of 120–180; `checks:round37` 159 of 100–160); a residual scan of my whole half with the edits applied (62 narrations, 176 strings) finds no process word and no banned word left, and *The bridges drilled* only in `src.refs2`, `method.4` and `about.reads.pack`.

## The checks

`check_IT-2_pass2.py` reads the two manifests, `strings.json` and my two files, and checks: every titoli item is a target of `MANIFEST_TITOLI.json` and of my share, none twice, every `id` is `t:` + target, a `why` on each, every length inside the manifest's limit (tokens split on whitespace, the strictest count), no final period on the one-line kinds (title, subtitle, head, rows, clips, items, bridges and whys, paper rows, scripts), no markup, no *The bridges drilled* in the titoli; every edited narration inside its `MANIFEST.json` range; every edited string an id of `strings.json` with the English's brace placeholders kept (none of mine has one); the banned words of VOICE_IT.md as `gen/lib/italian.mjs` matches them (plus "nota di ricerca", "4.4.9") and the process words of BRIEF_R2b.md §0 (pacchetto, integrato/a/i/e, proposto/a/i/e, proprietario, sondare and the drill words, drill/drilled) in every text, the process words allowed on Il metodo only (where the only hits are the title *The bridges drilled* and the file name BRIDGES_DRILLED.md, reported as notes). Its last run printed: `titoli 117 items, edits: 46 narrations, 26 strings (9 dropped), errors 0`.

## Every edit, old → new

### racconto `page:bridges` (215 → 215 words)

**old**

> Questa pagina racconta lo studio The bridges drilled, una nota di ricerca scritta per il proprietario dell'Atlante. Lo studio Music on the labels aveva dato un grado a dieci ponti fra l'Atlante e la teoria musicale, e parecchi di quei gradi stavano per un calcolo mancante, non per un legame mancante. Qui ogni ponte viene sondato: dove il calcolo mancava, lo si fa; dove la portata dell'Atlante si fermava a un passo dagli oggetti della musica, il calcolo dell'Atlante viene portato fin là. Il proprietario aveva chiesto tre cose: lasciare che la musica guidi sull'orologio, con il modulo 12 accanto al modulo 8 delle etichette; continuare a esplorare come la musica si è organizzata intorno ai due gruppi diedrali sulle triadi; smettere di dire «fuori portata» ed estendere invece l'Atlante, con script che provino gli enunciati.
>
> Il risultato sono nove script, 311 verifiche e 45 controlli, trentasei righe proposte, dodici figure e nove clip; un undicesimo ponte, verso il corpo rigido, trovato per strada; una seconda parte che riprende le quattro domande lasciate aperte e legge per intero l'articolo di Burns, Daniel, Alexander e Dressel. Ogni numero di questa pagina è una riga di un log. Nulla è integrato nelle tavole: lo studio è conservato come pacchetto, e tutto ciò che leggete qui è proposto.

**new**

> Undici ponti uniscono le etichette dell'Atlante alla musica: l'orologio, gli insiemi di classi di altezza, le triadi e i loro due gruppi, la trasformata di Fourier, l'anello, il corpo rigido, il suono accanto alla luce. Lo studio Music on the labels aveva dato un grado a dieci di essi, esatto, parziale, analogia o nessuno, e parecchi di quei gradi stavano per un calcolo mancante, non per un legame mancante. Qui ogni ponte viene percorso fino in fondo: dove il calcolo mancava, lo si fa; dove la portata dell'Atlante si fermava a un passo dagli oggetti della musica, il calcolo dell'Atlante viene portato fin là. Tre domande guidano lo studio: lasciare che la musica guidi sull'orologio, con il modulo 12 accanto al modulo 8 delle etichette; continuare a esplorare come la musica si è organizzata intorno ai due gruppi diedrali sulle triadi; smettere di dire «fuori portata» ed estendere invece l'Atlante, con script che provino gli enunciati.
>
> Il risultato sono nove script, 311 verifiche e 45 controlli, trentasei righe, dodici figure e nove clip; un undicesimo ponte, verso il corpo rigido, trovato per strada; una seconda parte che riprende le quattro domande lasciate aperte e legge per intero l'articolo di Burns, Daniel, Alexander e Dressel. Ogni numero di questa pagina è una riga di un log.

### racconto `bridges:table` (94 → 92 words)

- «è quella del BRIDGES_DRILLED.md del pacchetto,» → «riunisce»
- «» → «degli otto capitoli nell'ordine»
- «capitoli riunite.» → «ponti.»
- «proposto:» → «d'arrivo:»

### racconto `bridges:item:clock` (176 → 175 words)

- «sonda» → «attraversa»
- «gradi proposti:» → «gradi:»

### racconto `bridges:item:labels` (162 → 161 words)

- «gradi proposti:» → «gradi:»

### racconto `bridges:item:duality` (176 → 176 words)

- «sonda» → «attraversa»

### racconto `bridges:item:walk` (173 → 172 words)

- «grado proposto:» → «grado:»

### racconto `bridges:item:rings` (178 → 177 words)

- «grado proposto:» → «grado:»

### racconto `bridges:item:acoustics` (170 → 165 words)

- «che il proprietario ha allegato,» → «»

### racconto `row:MUS-014` (134 → 128 words)

- «MUS-014, proposta e non integrata nelle tavole,» → «MUS-014»

### racconto `row:MUS-015` (133 → 132 words)

- «MUS-015, proposta,» → «MUS-015»

### racconto `row:MUS-017` (129 → 128 words)

- «MUS-017, proposta,» → «MUS-017»

### racconto `row:MUS-018` (135 → 134 words)

- «MUS-018, proposta,» → «MUS-018»

### racconto `row:MUS-019` (131 → 130 words)

- «MUS-019, proposta,» → «MUS-019»

### racconto `row:MUS-020` (133 → 132 words)

- «MUS-020, proposta,» → «MUS-020»

### racconto `row:MUS-021` (134 → 133 words)

- «MUS-021, proposta,» → «MUS-021»

### racconto `row:MUS-022` (128 → 127 words)

- «MUS-022, proposta,» → «MUS-022»

### racconto `row:MUS-023` (133 → 132 words)

- «MUS-023, proposta,» → «MUS-023»

### racconto `row:MUS-024` (136 → 135 words)

- «MUS-024, proposta,» → «MUS-024»

### racconto `row:MUS-025` (137 → 136 words)

- «MUS-025, proposta,» → «MUS-025»

### racconto `row:MUS-026` (129 → 128 words)

- «MUS-026, proposta,» → «MUS-026»

### racconto `row:MUS-027` (133 → 132 words)

- «MUS-027, proposta,» → «MUS-027»

### racconto `row:MUS-028` (137 → 136 words)

- «MUS-028, proposta,» → «MUS-028»

### racconto `row:MUS-029` (134 → 133 words)

- «MUS-029, proposta,» → «MUS-029»

### racconto `row:MUS-030` (137 → 136 words)

- «MUS-030, proposta,» → «MUS-030»

### racconto `row:MUS-031` (136 → 135 words)

- «MUS-031, proposta,» → «MUS-031»

### racconto `row:MUS-032` (128 → 127 words)

- «MUS-032, proposta,» → «MUS-032»

### racconto `row:MUS-033` (130 → 129 words)

- «MUS-033, proposta,» → «MUS-033»

### racconto `row:MUS-034` (133 → 132 words)

- «MUS-034, proposta,» → «MUS-034»

### racconto `row:MUS-035` (133 → 132 words)

- «MUS-035, proposta,» → «MUS-035»

### racconto `row:MUS-037` (131 → 130 words)

- «MUS-037, proposta,» → «MUS-037»

### racconto `row:MUS-038` (133 → 132 words)

- «MUS-038, proposta,» → «MUS-038»

### racconto `row:MUS-039` (136 → 135 words)

- «MUS-039, proposta,» → «MUS-039»

### racconto `row:MUS-040` (135 → 134 words)

- «MUS-040, proposta,» → «MUS-040»

### racconto `row:MUS-041` (131 → 130 words)

- «MUS-041, proposta,» → «MUS-041»

### racconto `row:MUS-042` (133 → 132 words)

- «MUS-042, proposta,» → «MUS-042»

### racconto `row:MUS-043` (130 → 129 words)

- «MUS-043, proposta,» → «MUS-043»
- «integrati» → «ricostruiti»
- «La consegna» → «Ci»
- «aspettava» → «poteva aspettare»

### racconto `row:MUS-045` (132 → 131 words)

- «MUS-045, proposta,» → «MUS-045»

### racconto `row:MUS-046` (134 → 133 words)

- «MUS-046, proposta,» → «MUS-046»

### racconto `row:MUS-047` (130 → 129 words)

- «MUS-047, proposta,» → «MUS-047»

### racconto `row:MUS-048` (127 → 126 words)

- «MUS-048, proposta,» → «MUS-048»

### racconto `row:MUS-016` (135 → 134 words)

- «proposta» → «»

### racconto `row:MUS-036` (133 → 132 words)

- «proposta» → «»

### racconto `row:MUS-044` (133 → 132 words)

- «proposta» → «»

### racconto `row:MUS-049` (129 → 128 words)

- «proposta,» → «»

### racconto `page:acoustics` (176 → 175 words)

- «proposta del pacchetto.» → «riga dei ponti.»
- «la scelta» → «ciò»
- «spetta al proprietario.» → «resta da decidere.»

### racconto `checks:round37` (154 → 159 words)

- «del pacchetto» → «dei ponti»
- «sonda» → «attraversa»
- «Nulla è integrato nelle tavole: le righe che» → «Ogni riga dei ponti poggia su un gruppo di»
- «script sostengono sono proposte.» → «script, e da lì viene il suo stato.»

### string `home.more.bridges`

- old: gli undici ponti dello studio, trentasei righe proposte, dodici figure e nove clip
- new: undici ponti fra l'Atlante e la musica, trentasei righe, dodici figure e nove clip

### string `b.title`

- old: The bridges drilled
- new: I ponti

### string `b.table.p`

- old: La tabella riassuntiva del BRIDGES_DRILLED.md del pacchetto: ogni ponte con il suo grado di partenza, il grado che lo studio propone e il capitolo le cui verifiche lo hanno deciso.
- new: Ogni ponte con il grado di partenza, il grado d'arrivo e che cosa lo ha deciso.

### string `b.col.after`

- old: Proposto
- new: D'arrivo

### string `b.items.note`

- old: Nell'ordine dello studio; ogni capitolo con i ponti che sonda, le sezioni dello studio che lo raccontano, le sue righe proposte, le sue figure, i suoi clip e il suo strumento.
- new: Nell'ordine dello studio; ogni capitolo con i ponti che attraversa, le sezioni dello studio che lo raccontano, le sue righe, le sue figure, i suoi clip e il suo strumento.

### string `b.rows`

- old: Le righe proposte
- new: Le righe

### string `b.rows.note`

- old: Le righe proposte nel ROWS.md del capitolo, ciascuna con lo stato che la regola dell'Atlante le darebbe; nessuna è integrata nelle tavole. Il selettore di registro in alto sceglie che cosa mostra ogni riga.
- new: Le righe del capitolo, ciascuna con il suo bollino di stato. Il selettore di registro in alto sceglie che cosa mostra ogni riga.

### string `src.paper`

- old: L'articolo che lo studio legge per intero: Burns, Daniel, Alexander e Dressel, Spacetime geometry of acoustics and electromagnetism, arXiv:2305.11448 v2, DOI 10.1007/s40509-024-00317-8.
- new: L'articolo letto per intero per i ponti: Burns, Daniel, Alexander e Dressel, Spacetime geometry of acoustics and electromagnetism, arXiv:2305.11448 v2, DOI 10.1007/s40509-024-00317-8.

### string `blk.from.research.p`

- old: Non c'è ancora un testo narrativo: il testo di ricerca della riga, come proposto nel ROWS.md del capitolo.
- new: Non c'è ancora un testo narrativo: il testo di ricerca della riga.

### string `blk.research.p`

- old: Il testo di ricerca proposto nel ROWS.md del capitolo.
- new: Il testo di ricerca della riga, dai file dello studio.

### string `atl.proposed`

- old: proposta: lo stato che la regola le darebbe
- new: lo stato che la regola dà

### string `atl.home.proposed`

- old: Sede proposta
- new: Dove avrebbe sede

### string `std.bridge.proposed`

- old: proposto
- new: d'arrivo

### string `checks.r37`

- old: I nove script del pacchetto
- new: Gli script dei ponti

### string `checks.r37.p`

- old: Gli script del pacchetto, i loro log e i loro controlli, letti come file propri dello studio: nulla di essi è integrato nelle tavole dell'Atlante, e le righe che sostengono sono proposte.
- new: I nove script dietro le righe dei ponti: che cosa calcola ciascuno, i suoi gruppi con una riga per verifica, i controlli che devono fallire, e i secondi di ogni esecuzione.

### string `checks.r37.readme`

- old: Il README del pacchetto
- new: Il README degli script

### string `pics.r37`

- old: Le dodici figure di The bridges drilled
- new: Le dodici figure dei ponti

### string `pics.r37.p`

- old: Disegnate dagli script del pacchetto dai dati delle figure; le loro righe sono righe proposte della pagina The bridges drilled.
- new: Disegnate dagli script delle verifiche dai dati delle figure; le loro righe sono nella pagina I ponti.

### string `dict.paper.p`

- old: Le Tabelle 3 e 4 dell'articolo che lo studio legge, affiancate da una terza colonna nelle parole dell'Atlante, dal DICTIONARY.md del capitolo sull'acustica; i gradi sono quelli del capitolo.
- new: Le Tabelle 3 e 4 dell'articolo sull'acustica e l'elettromagnetismo che lo studio dei ponti legge per intero, affiancate da una terza colonna nelle parole dell'Atlante; i gradi sono dello studio.

### string `dict.paper.cand.p`

- old: Le lacune della terza colonna e le correzioni dell'articolo: per ciascuno, che cosa calcolerebbe una verifica, dove avrebbe sede e che cosa decide il proprietario, come li elenca il capitolo.
- new: Le lacune della terza colonna e le correzioni dell'articolo: per ciascuno, che cosa calcolerebbe una verifica, dove avrebbe sede e che cosa resta da decidere, come li elenca lo studio.

### string `dict.paper.more`

- old: I dieci candidati e le sviste di stampa sono nella pagina The bridges drilled:
- new: I dieci candidati e le sviste di stampa sono nella pagina I ponti:

### string `i8.p`

- old: I suoni dei §7 e §13 dello studio dai loro numeri esatti: l'anello di dodici masse uguali risolto per i parziali 1 … 6, che nessuna molla può costruire, contro l'anello a primi vicini; gli anelli che le molle positive suonano davvero; i due anelli le cui molle o masse variano lungo l'anello; e il 12-cubo e il 3-cubo pizzicati come campane.
- new: I suoni delle campane e degli anelli dai loro numeri esatti: l'anello di dodici masse uguali risolto per i parziali 1 … 6, che nessuna molla può costruire, contro l'anello a primi vicini; gli anelli che le molle positive suonano davvero; i due anelli le cui molle o masse variano lungo l'anello; e il 12-cubo e il 3-cubo pizzicati come campane.

### string `method.4`

- old: Uno studio le cui righe non sono integrate si può leggere lo stesso: il sito legge il pacchetto dello studio The bridges drilled come file propri dello studio (lo studio stesso, i ROWS.md dei suoi capitoli, i suoi script, log, figure e clip) e segna come proposta ogni riga che ne trae. Il verificatore controlla quei blocchi contro i file del pacchetto, come controlla gli altri contro le tavole dell'Atlante.
- new: Uno studio le cui righe non sono ancora nelle tavole dell'Atlante si può leggere lo stesso: questa edizione del sito legge i file dello studio The bridges drilled come file propri dello studio (lo studio stesso, i ROWS.md dei suoi capitoli, i suoi script, log, figure e clip) e dà a ogni riga che ne trae lo stato che la regola le dà, senza altro sulla sua pagina: che le sue righe siano di uno studio, e non ancora dell'Atlante, è detto qui soltanto. Il verificatore controlla quei blocchi contro i file dello studio, come controlla gli altri contro le tavole dell'Atlante.

### string `about.reads.pack`

- old: Il pacchetto dello studio The bridges drilled, conservato e non integrato: lo studio, i ROWS.md e i BRIDGE.md degli otto capitoli, BRIDGES_DRILLED.md, i nove script con i loro log e controlli, le dodici figure con il loro indice e i loro dati, i nove clip con il loro indice, e il dizionario dell'articolo del capitolo sull'acustica.
- new: I file dello studio The bridges drilled, conservati e non ancora nelle tavole: lo studio, i ROWS.md e i BRIDGE.md degli otto capitoli, BRIDGES_DRILLED.md, i nove script con i loro log e controlli, le dodici figure con il loro indice e i loro dati, i nove clip con il loro indice, e il dizionario dell'articolo del capitolo sull'acustica.

### string `about.reads.pack.k`

- old: La parola del pacchetto su sé stesso:
- new: Ciò che quei file dicono di sé stessi:

### string `about.italian.p`

- old: Il sito ha un lato italiano, raccontato e non tradotto: un narratore racconta in italiano ogni pagina, sezione, riga, clip e strumento, le schede dell'Atlante restano accanto in inglese, e la cornice del sito è del narratore; le due tavole content/it/strings_it.json e racconto.json sono controllate dal verificatore come ogni altro blocco.
- new: Il sito ha un lato italiano, raccontato e non tradotto: un narratore racconta in italiano ogni pagina, sezione, riga, figura, clip e strumento, e la cornice del sito è del narratore, così che chi legge legga italiano da cima a fondo; le schede dell'Atlante restano in inglese, dentro i tre registri delle schede e dentro le schede a scomparsa che le tengono; le tre tavole content/it/strings_it.json, racconto.json e titoli.json sono controllate dal verificatore come ogni altro blocco.
