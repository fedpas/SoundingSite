#!/usr/bin/env python3
"""IT-1's second-pass check, standalone: run from it/draft/ as
   python3 -I check_IT-1_pass2.py ../../gen/content/it/MANIFEST_TITOLI.json ../../gen/content/it/MANIFEST.json titoli_r1.json pass2_edits_r1.json
Checks: every item of titoli_r1.json is a target of MANIFEST_TITOLI.json (my 120), within its length, without final period where the
kind is a title/claim/label, without a banned word (it/VOICE_IT.md) or a process word (BRIEF_R2b.md §0); every edit of
pass2_edits_r1.json within MANIFEST.json's range and without those words; the JSON loads."""
import json, re, sys
BANNED = re.compile(r"\b(adesso|nuov[oaie]|recent[ei]|ultim[oaie]|aggiornat[oaie]|precedent[ei]|corrett[oaie]|sostituit[oaie]|superat[oaie]|version[ei]|release|new)\b", re.I)
ROUND = re.compile(r"\bround\s*\d+\b", re.I); ORA = re.compile(r"(?<!['’])\bora\b", re.I)
PRIMA = re.compile(r"(\b(come|di|da)\s+prima\b)|(\bprima\s*(di|che|del|della|dei|delle|dello|degli|dell['’]|d['’])\b)|(\bprima\s*[,.;:!?)]|\bprima\s*$)", re.I)
PROCESS = re.compile(r"(\bpacchett\w*|\bintegrat\w*|\bpropost[aeio]\b|\bedizion\w*|\bproprietari\w*|nota di ricerca|\b4\.4\.\d+\b|\btrivell\w*|\bsondat\w*|\bperfora\w*|\bconservat\w*|\bmerged\b|\bpack\b|\bdrill\w*)", re.I)
def banned(t, stamp=False):
    t = t.replace("The bridges drilled", "The bridges")
    h = [m.group(0) for m in BANNED.finditer(t) if not (stamp and m.group(0).lower() in ("release","versione","versioni"))]
    h += [m.group(0) for m in ROUND.finditer(t)] + [m.group(0) for m in ORA.finditer(t)] + [m.group(0) for m in PRIMA.finditer(t)]
    h += [m.group(0) for m in PROCESS.finditer(t) if not (stamp and m.group(0).lower().startswith("edizion"))]
    return h
def words(t): return len([x for x in re.split(r"\s+", t.strip()) if x])
mt, m1, tit, ed = [json.load(open(p, encoding="utf-8")) for p in sys.argv[1:5]]
MT = {t["target"]: t for t in mt["targets"]}; M1 = {t["target"]: t for t in m1["targets"]}
err = []
seen = set()
for it in tit["items"]:
    tg = it["target"]; L = MT[tg]["length"] if tg in MT else None
    if tg in seen: err.append(f"twice {tg}")
    seen.add(tg)
    if L is None: err.append(f"not in manifest {tg}"); continue
    if it["id"] != "t:" + tg: err.append(f"id {it['id']}")
    n = words(it["text"]); mx = re.search(r"≤\s*(\d+)", L); r = re.search(r"(\d+)\s*[–-]\s*(\d+)", L)
    if mx and n > int(mx.group(1)): err.append(f"{tg}: {n} > {mx.group(1)}")
    if r and not (int(r.group(1)) <= n <= int(r.group(2))): err.append(f"{tg}: {n} not in {L}")
    if tg.split(":")[0] in ("section","chain","row","clip","lens","check") and it["text"].rstrip().endswith("."): err.append(f"{tg}: final period")
    b = banned(it["text"])
    if b: err.append(f"{tg}: banned {b}")
    if re.search(r"<[a-zA-Z/][^>]*>|\*\*|`", it["text"]): err.append(f"{tg}: html/markdown")
for e in ed["racconto"]:
    lo, hi = [int(x) for x in M1[e["target"]]["length"].replace("–","-").split("-")]
    n = words(e["text"])
    if not (lo <= n <= hi): err.append(f"edit {e['target']}: {n} not in {lo}–{hi}")
    b = banned(e["text"])
    if b: err.append(f"edit {e['target']}: banned {b}")
for e in ed["strings"]:
    b = banned(e["text"], stamp=(e["id"] == "release.stamp"))
    if b: err.append(f"edit string {e['id']}: banned {b}")
print(f"titoli items: {len(tit['items'])}; edits: {len(ed['racconto'])} narrations, {len(ed['strings'])} strings")
if err: print("ERRORS:"); [print("  " + x) for x in err]; sys.exit(1)
print("OK: lengths in range, no banned or process word, no final period on titles, claims and labels")
