# NOTE_R3 — release 3 of The Sounding View (site builder, 3 November 2026)

Everything is in `site_r3/` (SITE2 and the stage source untouched). English: **0 errors, 0 warnings** (`SDV_IT=off`). With the Italian stubs (`SDV_IT=partial`): 0 errors, 261 warnings (the stubs). `test_sounds.mjs`: 43 of 43 (release 2's 37 + 6 for instrument 10). `shoot.cjs`: 184 shots of 46 pages, 0 problems. I looked myself at the home, a part page (Part III), a Part III chapter (aether), the bridges map, and Sounds (instrument 10 in two states) at 1280 and 390.

## What was built

4 parts, 12 chapters, 23 pages (+23 Italian), 109 row blocks (64 Atlas rows + 45 of the study: 38 MUS rows incl. MUS-049/080, 7 inputs INP-133…139), 29 figures (13 + 12 + 4), 22 clips (12 + 9 + 1), 10 instruments, 17 scripts (2 + 9 + 6), 47 lens entries, 206 readings, 522 site strings. `version.json` names Atlas 4.4.10 and the round-38 pack (standing "proposed, not merged"), and round 37's pack as merged.

## Decisions (the most reasonable reading, no questions asked)

1. **Loader.** 4.4.10's release carries scripts but empty logs/figdata/audio and no round docs; logs, figdata, audio and the round-36 study come from the archive `../repo` (`SDV_ARCHIVE`). Round-36/37 scripts are byte-identical to the archive's.
2. **Round 37 is Atlas now.** MUS-014…049 and INP-131/132 are Atlas rows (`rowBlock`; evidence from `checks.json`, log lines from the study's logs, Story from the study's prose). Round 38's rows use `packRowBlock` (research text as Story, since the pack has no prose for rows; no home field; no lens block). MUS-045…048 are Atlas rows, MUS-049 (rewritten by the pack) and MUS-080 are shown from the pack, all in the chapter *Sound and light, side by side*. The tone chapter drops MUS-045…049.
3. **Inputs** INP-133…135 stand in aether and INP-136…139 in spin, before the first row that depends on them.
4. **Figures** show on every chapter whose rows intersect the figure's row column; the home map stays the home's. Pictures is grouped by study (13 + 12 + 4 as the brief counts), not by part.
5. **Outputs named for studies**, not rounds: `figures/bridges|light/`, `audio/…`, `checks/bridges|light/`; round 36 stays at the root.
6. **Bridges map**: five chapters from the brief; bridge 10 (unchanged, in no chapter) in a closing "Left as it was" table; the twelfth line is the plasma bridge "P" (no "before" in its BRIDGE.md: shown as —). The old items prose, the opinion and the references were dropped from the page (the Italian narrations of release 2 for them are retired, not lost).
7. **Part IV** is one page: `question.html` is both the part and the chapter (no breadcrumb on it).
8. **Paper's dictionary** (table, candidates, slips) lives on the Dictionary page (narration `r:page:acoustics` renders there); the chapter *Sound and light, side by side* points to it.
9. **Instrument 10** unit: the stiffer spring puts its mode 2 at 440 Hz (as clip 22 does, F_T = 254.034 Hz for μ = κ/3); max 880 Hz. κ/μ slider is logarithmic, 10⁻²…10²; air and MacCullagh are presets outside the slider. Sounds groups follow the brief literally: Sound = chain, rings, gliss, commas, stiff; Twelve = clock, tonnetz, rhythm, crt, rows.
10. **Reference menu** is a `<details>` (no script); the strip wraps instead of scrolling so the dropdown is not clipped. Nav: Sound, Twelve, Sound beside light, The question, Bridges, Sounds, Reference; no numbers.
11. **About** is called Method in the nav (`nav.about`); the page file stays `about.html`; it is the one place that says the part *Sound beside light* reads a study whose rows are not yet the Atlas's, and holds the one Atlas link.
12. Strings the Italian pages never show (part, chapter and bridge-chapter titles, leads and cards: the narrator tells those through targets) are marked `enOnly` in `strings.json` and exempt from the Italian table.
13. A fix in the reader: round 38's `music_spin` and `music_variation` logs head their groups `[tag]` (no `(n)`), and a tag may head several blocks; `logGroup` reads both.

## The Italian side

`content/it/MANIFEST_R3.json` (first written 2026-11-03T20:02Z, regenerated since (last run below); later than the hour the brief asked for, because the loader and the structure had to settle first): **62 narrations** (46 rows, 4 chapters, 3 parts, 5 bridge chapters, instrument stiff, clip 22, checks:light, pictures:light), **101 titles** (46 rows, 13 lens entries 35–47, 8 section titles/subs, 8 cards, 6 scripts, 5 bridge chapters, 4 parts, 4 chains, 4 figures, bridges P and P:why, clip 22), **66 new strings** and **32 changed** (old Italian kept as `previousIt`), plus a `review` list. Stubs carry `"stub": true` in `racconto.json`, `titoli.json`, `strings_it.json`; the full build refuses them. Moved targets were renamed with their text (`checks:round37` → `checks:bridges`, `pictures:round37` → `pictures:bridges`); retired targets (the eight item narrations, `bridges:table`, `bridges:opinion`, ten titles, 34 strings) are in `content/it/retired_r2.json` for the narrators to draw on. `MANIFEST_TITOLI.json`'s target list was brought up to date.

Review list (low priority unless noted): MUS-049 (**doubtful**: rewritten by the pack), MUS-016/037/046 (homeMath changed), MUS-004, LNS-137, SPR-M01 (text/depends changed), `section:tone` (lost MUS-045…049), the pages whose counts changed, and ~25 rows whose research texts D115 folded.

## Open

- The narrators' tables (above); then the full build and check, and shots of the Italian pages with real text.
- Pictures groups by study, not by part (the brief's counts 13 + 12 + 4 read as studies).
- The English check has no independent test of the stiff instrument's drawing; its numbers are tested.
