// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// plasmawaves.js — The two plasma waves (MUS-076, 077, 085, 086, 099)
(function () {
  'use strict';
  window.SDV_EXP = window.SDV_EXP || {};
  window.SDV_EXP['plasmawaves'] = { mount: function (root, data, S, kit) {
    var P = 'exp.plasmawaves.', el = kit.el, TAU = Math.PI * 2, FP = 330, PIC_HZ = 0.5;
    var reduce = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    var st = { k: 0.5, warm: false, t: 0, paused: reduce, on: false, snd: 'plasma' }, voice = null;
    var KS = data.k, N = KS.length;
    var pts = function (arr) { return arr.map(function (y, i) { return [KS[i], y]; }); };
    var BG = pts(data.bohm_gross), HI = pts(data.high), LO = pts(data.low), IA = pts(data.ion_acoustic);
    function cv(parent, a, m) { var d = el('div', { class: 'exp-cvwrap' }); parent.appendChild(d); return kit.canvas(d, a, m); }
    function txt(ctx, s, x, y, color, align, size) { ctx.fillStyle = color || kit.muted(); ctx.textAlign = align || 'left'; ctx.font = (size || 11) + 'px system-ui, sans-serif'; ctx.fillText(s, x, y); }
    function wBG(k) { var v = kit.interp(BG, k); return v == null ? 1 : v; }
    function wLow(k) { var v = kit.interp(LO, k); return v == null ? 0 : v; }
    function vg(k) { var h = 0.04, a = Math.max(KS[0], k - h), b = Math.min(KS[N - 1], k + h); return (wBG(b) - wBG(a)) / (b - a); }
    function fmod() { return FP * wLow(st.k); }
    function wrap(u) { return u - Math.floor(u + 0.5); }

    // ---------------------------------------------------------------- (a) the electron slab
    var pa = kit.panel_(root, P + 'panel.slab', S, 'span');
    var ac = cv(pa, 0.34, 190), ctlA = kit.controls(pa);
    kit.seg(ctlA, { S: S, ids: [P + 'cold', P + 'warm'], values: [false, true], value: false, onchange: function (v) { st.warm = v; st.t = 0; readA(); applySound(); } });
    var pauseB = kit.button(ctlA, 'exp.common.pause', S, function () { st.paused = !st.paused; pauseB.setAttribute('aria-pressed', String(st.paused)); }); pauseB.setAttribute('aria-pressed', String(st.paused));
    var rdA = kit.readout(pa); kit.line(pa, P + 'slab.line', S);
    var rdS = kit.readout(pa); rdS.textContent = S('exp.common.slowed').replace('{n}', String(Math.round(FP / PIC_HZ)));
    function readA() { rdA.textContent = st.warm ? 'ω = ' + kit.num(wBG(st.k), 3) + ' ω_p   ·   v_g = ' + kit.num(vg(st.k), 3) + '  (k = ' + kit.num(st.k, 2) + ')' : 'ω = 1.000 ω_p   ·   v_g = 0'; }
    function drawSlab() {
      var ctx = ac.ctx, w = ac.w, h = ac.h, x0 = 14, x1 = w - 14, L = x1 - x0, nd = 84, K = TAU * 6, i, r;
      ctx.clearRect(0, 0, w, h);
      var ph = Math.PI * st.t, om = st.warm ? wBG(st.k) : 1, uc = st.warm ? 0.5 + vg(st.k) * ph / (6 * TAU / st.k) : 0.5, amp = 1.1 / K;
      var disp = function (u) { var env = Math.exp(-Math.pow(wrap(u - uc) / 0.17, 2)); return st.warm ? -env * amp * Math.sin(K * u - om * ph) : -env * amp * Math.sin(K * u) * Math.cos(ph); };
      var ys = [h * 0.2, h * 0.34, h * 0.48], yE = h * 0.68, yI = h * 0.88;
      for (r = 0; r < 3; r++) for (i = 0; i < nd; i++) { var u = (i + 0.5 + r * 0.33) / nd, xx = x0 + (u + disp(u)) * L; ctx.fillStyle = kit.blue; ctx.beginPath(); ctx.arc(xx, ys[r], 2.2, 0, TAU); ctx.fill(); }
      for (i = 0; i < nd / 2; i++) { var uu = (i + 0.5) / (nd / 2), xi = x0 + uu * L, xe = disp(uu) / amp; ctx.fillStyle = kit.muted(); ctx.globalAlpha = 0.55; ctx.beginPath(); ctx.arc(xi, yI, 2.6, 0, TAU); ctx.fill(); ctx.globalAlpha = 1; if (Math.abs(xe) > 0.05) kit.arrow(ctx, xi - 5 * xe, yE, xi + 5 * xe, yE, xe > 0 ? kit.red : kit.blue, 1.3); }
      txt(ctx, S(P + 'lab.e'), 4, ys[0] - 8, kit.blue, 'left', 10); txt(ctx, S(P + 'lab.E'), 4, yE - 9, kit.muted(), 'left', 10); txt(ctx, S(P + 'lab.i'), 4, yI - 8, kit.muted(), 'left', 10);
    }

    // ---------------------------------------------------------------- (b) omega(k)
    var pb = kit.panel_(root, P + 'panel.disp', S);
    var dc = cv(pb, 0.8, 320), ctlB = kit.controls(pb);
    kit.slider(ctlB, { S: S, id: P + 'k', min: 0.1, max: 3.5, step: 0.05, value: 0.5, fmt: function (v) { return kit.num(v, 2); }, onchange: function (v) { st.k = v; readA(); readB(); applySound(); } });
    var rdB = kit.readout(pb);
    function readB() { rdB.textContent = 'ω(high) = ' + kit.num(kit.interp(HI, st.k), 4) + '   ·   ω(low) = ' + kit.num(kit.interp(LO, st.k), 5) + '   ·   m/M = ' + data.mass_ratio + '   ·   ω_pi = ' + kit.num(data.omega_pi, 5); }
    function drawDisp() {
      var ctx = dc.ctx, w = dc.w, h = dc.h, box = { l: 48, t: 12, r: w - 12, b: h - 34 };
      ctx.clearRect(0, 0, w, h);
      var ax = kit.axes(ctx, box, { xmin: 0, xmax: 4, ymin: 3e-4, ymax: 6, ylog: true, xticks: [0, 1, 2, 3, 4], yticks: [0.001, 0.01, 0.1, 1], xlabel: S(P + 'ax.k'), ylabel: S(P + 'ax.w') });
      kit.curve(ctx, HI, ax.x, ax.y, kit.blue, 2.2); kit.curve(ctx, BG, ax.x, ax.y, kit.ink(), 1.2, [5, 4]);
      kit.curve(ctx, LO, ax.x, ax.y, kit.red, 2.2); kit.curve(ctx, IA, ax.x, ax.y, kit.ink(), 1.2, [5, 4]);
      txt(ctx, S(P + 'curve.high'), box.l + 8, ax.y(2.2), kit.blue, 'left', 11); txt(ctx, S(P + 'curve.low'), box.l + 8, ax.y(0.012), kit.red, 'left', 11); txt(ctx, S(P + 'curve.dash'), box.r - 4, box.b - 6, kit.muted(), 'right', 10);
      var xk = ax.x(st.k); ctx.strokeStyle = kit.accent(); ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(xk, box.t); ctx.lineTo(xk, box.b); ctx.stroke();
      [[HI, kit.blue], [LO, kit.red]].forEach(function (c) { var v = kit.interp(c[0], st.k); if (v) { ctx.fillStyle = c[1]; ctx.beginPath(); ctx.arc(xk, ax.y(v), 4.5, 0, TAU); ctx.fill(); } });
    }

    // ---------------------------------------------------------------- (c) two fluids
    var pc = kit.panel_(root, P + 'panel.two', S);
    var tc = cv(pc, 0.62, 260), rdC = kit.readout(pc), rdC2 = kit.readout(pc);
    kit.line(pc, P + 'two.line', S); kit.line(pc, P + 'two.line2', S);
    function drawTwo() {
      var ctx = tc.ctx, w = tc.w, h = tc.h, x0 = 14, x1 = w - 14, L = x1 - x0, K = TAU * 3, n = 60, i;
      var fm = fmod(), fpic = Math.min(fm, 0.7), th = TAU * fpic * st.t, Aion = (1 + st.k * st.k), amp = 0.6 / K;
      ctx.clearRect(0, 0, w, h);
      var yP = h * 0.14, yE = h * 0.30, yEl = h * 0.46, yF = h * 0.62, yI = h * 0.78, yFi = h * 0.92;
      var xe = function (u, a) { return x0 + (u - a * amp * Math.sin(K * u - th)) * L; };
      for (i = 0; i < n; i++) {
        var u = (i + 0.5) / n;
        ctx.fillStyle = kit.blue; ctx.beginPath(); ctx.arc(xe(u, 1), yEl, 2.4, 0, TAU); ctx.fill();
        ctx.fillStyle = kit.red; ctx.beginPath(); ctx.arc(xe(u, 1), yI, 5, 0, TAU); ctx.fill();
        if (i % 3 === 0) {
          var s = Math.sin(K * u - th), x = x0 + u * L;
          kit.arrow(ctx, x - 7 * s, yP, x + 7 * s, yP, kit.blue, 1.4);       // the electrons' pressure force
          kit.arrow(ctx, x + 7 * s, yE, x - 7 * s, yE, kit.muted(), 1.4);    // the field's force on the electrons, the opposite
          kit.arrow(ctx, x - 7 * s * Aion, yFi, x + 7 * s * Aion, yFi, kit.muted(), 1.4); // the field's force on the ions
        }
      }
      txt(ctx, S(P + 'lab.press'), 4, yP - 7, kit.blue, 'left', 10); txt(ctx, S(P + 'lab.fe'), 4, yE - 7, kit.muted(), 'left', 10); txt(ctx, S(P + 'lab.e'), 4, yEl - 8, kit.blue, 'left', 10);
      txt(ctx, S(P + 'lab.i'), 4, yI - 10, kit.red, 'left', 10); txt(ctx, S(P + 'lab.fi'), 4, yFi - 9, kit.muted(), 'left', 10);
      rdC.textContent = 'f = ' + kit.num(fm, 2) + ' Hz   ·   n_i/n_e = ' + kit.num(Aion, 3) + '  (k = ' + kit.num(st.k, 2) + ')';
      rdC2.textContent = fm > 0.71 ? S('exp.common.slowed').replace('{n}', kit.num(fm / fpic, 1)) : '';
    }

    // ---------------------------------------------------------------- hear
    var ph = kit.panel_(root, P + 'panel.hear', S, 'span'), ctlH = kit.controls(ph);
    var playB = kit.button(ctlH, 'exp.common.play', S, function () { st.on = !st.on; playB.textContent = S(st.on ? 'exp.common.mute' : 'exp.common.play'); playB.setAttribute('data-s', st.on ? 'exp.common.mute' : 'exp.common.play'); applySound(); });
    kit.seg(ctlH, { S: S, ids: [P + 'snd.plasma', P + 'snd.ion'], values: ['plasma', 'ion'], value: 'plasma', onchange: function (v) { st.snd = v; applySound(); } });
    kit.button(ctlH, P + 'pulse', S, function () { pulse(); });
    var rdH = kit.readout(ph); kit.line(ph, P + 'hear.line', S);
    function stopVoice() { if (!voice) return; voice.stop(); voice = null; }
    function applySound() {
      var a = st.on ? kit.audio() : null;
      if (!st.on) { stopVoice(); return; }
      if (!a) { rdH.textContent = S('exp.common.noaudio'); return; }
      var f = st.warm ? FP * wBG(st.k) : FP;
      if (st.snd === 'plasma') {
        if (!voice || voice.kind !== 'plasma') { stopVoice(); var v = kit.voice({ f: f, gain: 0.14 }); voice = { kind: 'plasma', set: function (ff) { v.set(ff); }, stop: function () { v.stop(); } }; }
        voice.set(f); rdH.textContent = kit.num(f, 1) + ' Hz';
      } else {
        var fm = Math.max(fmod(), 0.05);
        if (!voice || voice.kind !== 'ion') {
          stopVoice(); var c = a.ctx, osc = c.createOscillator(), g = c.createGain(), lfo = c.createOscillator(), lg = c.createGain(); osc.frequency.value = FP; g.gain.value = 0; lfo.frequency.value = fm; lg.gain.value = 0.07;
          lfo.connect(lg); lg.connect(g.gain); osc.connect(g); g.connect(a.master); osc.start(); lfo.start(); g.gain.setTargetAtTime(0.07, c.currentTime, 0.03);
          voice = { kind: 'ion', lfo: lfo, set: function (ff) { lfo.frequency.setTargetAtTime(ff, c.currentTime, 0.03); }, stop: function () { var t = c.currentTime; lg.gain.setTargetAtTime(0, t, 0.02); g.gain.setTargetAtTime(0, t, 0.02); osc.stop(t + 0.15); lfo.stop(t + 0.15); } };
        }
        voice.set(fm); rdH.textContent = kit.num(FP, 0) + ' Hz  ×  ' + kit.num(fm, 3) + ' Hz   (' + kit.num(fm / FP, 5) + ')';
      }
    }
    function pulse() {
      if (!kit.audio()) { rdH.textContent = S('exp.common.noaudio'); return; }
      var ks = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6], vmin = vg(ks[0]), out = [];
      ks.forEach(function (k) { var t = 3 * vmin / vg(k); out.push([t, k]); });
      out.sort(function (a, b) { return a[0] - b[0]; });
      out.forEach(function (o) { kit.tone({ f: FP * wBG(o[1]), gain: 0.14, decay: 0.22, at: o[0] }); });
      rdH.textContent = out.map(function (o) { return 'k ' + kit.num(o[1], 1) + ' → ' + kit.num(o[0], 1) + ' s'; }).join('   ');
    }
    readA(); readB(); drawSlab(); drawDisp(); drawTwo();
    kit.loop(function (t, dt) { if (!st.paused) st.t += dt; drawSlab(); drawDisp(); drawTwo(); });
  } };
})();
