// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// torusband — the torus of triads and the band of dyads (MUS-007, MUS-008, MUS-022, LAB-016b)
(function () {
  'use strict';
  window.SDV_EXP = window.SDV_EXP || {};
  window.SDV_EXP['torusband'] = {
    mount: function (root, data, S, kit) {
      var TAU = Math.PI * 2, el = kit.el, NS = 'exp.torusband.', snd = false, live = [], timers = [], names = data.names;
      var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      var moving = !reduce, T = 0, vt = { yaw: 0.6, pit: 0.9 }, vb = { yaw: 0.4, pit: 1.0 }, walk = -1, showDual = false, sel = 0;
      var abOf = {}; data.cells.forEach(function (c) { abOf[c.pc] = [c.a, c.b]; });
      var byName = {}; data.triads.forEach(function (t, i) { byName[t.name] = i; });
      function hz(pc) { return 261.6256 * Math.pow(2, pc / 12); }
      function cell(p) { var c = el('div', { style: 'min-width:0;overflow:hidden' }); p.appendChild(c); return c; }
      function silence() { live.forEach(function (t) { t.stop(); }); live = []; timers.forEach(clearTimeout); timers = []; }
      function chordAt(p, at, dur) { p.forEach(function (x) { live.push(kit.tone({ f: hz(x), gain: 0.14, dur: dur || 0.5, at: at || 0.02 })); }); }
      function playBtn(parent) {
        var b = kit.button(parent, 'exp.common.play', S, function () {
          snd = !snd; b.textContent = S(snd ? 'exp.common.mute' : 'exp.common.play'); b.setAttribute('data-s', snd ? 'exp.common.mute' : 'exp.common.play');
          if (snd) { if (!kit.audio()) kit.line(root, 'exp.common.noaudio', S); } else silence();
        }); return b;
      }
      // ---- a tiny 3-D: rotate, project, painter's order
      function view(p, v) { var cy = Math.cos(v.yaw), sy = Math.sin(v.yaw), cp = Math.cos(v.pit), sp = Math.sin(v.pit), x = p[0] * cy - p[1] * sy, y = p[0] * sy + p[1] * cy, z = p[2]; return [x, y * cp - z * sp, y * sp + z * cp]; }
      function render(cv, items, v, sc) {
        var s = cv.size(), c = cv.ctx, W = s.w, H = s.h, u = Math.min(W, H) * sc; c.clearRect(0, 0, W, H);
        var out = items.map(function (it) {
          if (it.pts) { var q = it.pts.map(function (p) { return view(p, v); }); return { it: it, q: q, d: q.reduce(function (a, b) { return a + b[2]; }, 0) / q.length }; }
          var q1 = view(it.p, v); return { it: it, q: [q1], d: q1[2] };
        }).sort(function (a, b) { return a.d - b.d; });
        out.forEach(function (o) {
          var it = o.it, near = kit.clamp(0.55 + o.d * 0.18, 0.25, 1);
          if (it.pts) { c.strokeStyle = it.color; c.lineWidth = it.w || 1; c.globalAlpha = (it.a == null ? 1 : it.a) * near; c.beginPath(); o.q.forEach(function (p, i) { var x = W / 2 + p[0] * u, y = H / 2 - p[1] * u; if (i) c.lineTo(x, y); else c.moveTo(x, y); }); c.stroke(); }
          else { var x = W / 2 + o.q[0][0] * u, y = H / 2 - o.q[0][1] * u; c.globalAlpha = near; c.fillStyle = it.color; c.beginPath(); c.arc(x, y, it.r, 0, TAU); c.fill(); if (it.label) { c.fillStyle = kit.ink(); c.font = '10px system-ui, sans-serif'; c.textAlign = 'center'; c.fillText(it.label, x, y - it.r - 3); } }
        });
        c.globalAlpha = 1;
      }
      function drag(cv, v) {
        var down = null; cv.el.style.touchAction = 'none'; cv.el.style.cursor = 'grab';
        cv.el.addEventListener('pointerdown', function (e) { down = [e.clientX, e.clientY, v.yaw, v.pit]; try { cv.el.setPointerCapture(e.pointerId); } catch (x) { } moving = false; });
        cv.el.addEventListener('pointermove', function (e) { if (!down) return; v.yaw = down[2] + (e.clientX - down[0]) * 0.01; v.pit = kit.clamp(down[3] + (e.clientY - down[1]) * 0.01, 0.05, 3.1); });
        cv.el.addEventListener('pointerup', function () { down = null; });
      }

      root.classList.add('half');
      // ---------------------------------------------- (a) the torus
      var R0 = 2, r0 = 0.8;
      function tor(a, b) { var u = TAU * a / 3, v = TAU * b / 4; return [(R0 + r0 * Math.cos(v)) * Math.cos(u), (R0 + r0 * Math.cos(v)) * Math.sin(u), r0 * Math.sin(v)]; }
      var pa = kit.panel_(root, NS + 'panel.a', S), da = kit.canvas(cell(pa), 0.85, 340), ca = kit.controls(pa);
      playBtn(ca); kit.button(ca, NS + 'walk', S, function () { if (!snd) return; silence(); data.fifths_pcs.forEach(function (p, i) { chordAt([p, (p + 4) % 12, (p + 7) % 12], 0.02 + i * 0.5, 0.48); timers.push(setTimeout(function () { walk = i; }, i * 500)); }); timers.push(setTimeout(function () { walk = -1; }, 12 * 500)); });
      kit.check(ca, NS + 'motion', S, moving, function (v) { moving = v; });
      var ra = kit.readout(pa); kit.line(pa, NS + 'a.note', S);
      var tb = el('table', { class: 'exp-table' }), hr = el('tr'); hr.appendChild(el('th', { text: 'a \\ b' })); for (var b = 0; b < 4; b++) hr.appendChild(el('th', { text: String(b) })); tb.appendChild(hr);
      for (var a = 0; a < 3; a++) { var tr = el('tr'); tr.appendChild(el('th', { text: String(a) })); for (b = 0; b < 4; b++) { var cc = data.cells.filter(function (c) { return c.a === a && c.b === b; })[0]; tr.appendChild(el('td', { text: names[cc.pc] })); } tb.appendChild(tr); }
      pa.appendChild(tb); drag(da, vt);
      var torItems = [];
      (function () {
        var i, j, k, pts;
        for (i = 0; i < 12; i++) { pts = []; for (k = 0; k <= 24; k++) pts.push(tor(3 * i / 12, 4 * k / 24)); torItems.push({ pts: pts, color: kit.muted(), a: 0.18 }); pts = []; for (k = 0; k <= 24; k++) pts.push(tor(3 * k / 24, 4 * i / 12)); torItems.push({ pts: pts, color: kit.muted(), a: 0.18 }); }
        var seen = {};
        data.cells.forEach(function (p) { data.cells.forEach(function (q) { var d = ((q.pc - p.pc) % 12 + 12) % 12; if ([3, 4, 5].indexOf(d) < 0) return; var da_ = ((q.a - p.a) % 3 + 3) % 3, db = ((q.b - p.b) % 4 + 4) % 4; if (da_ === 2) da_ = -1; if (db === 3) db = -1; pts = []; for (k = 0; k <= 6; k++) pts.push(tor(p.a + da_ * k / 6, p.b + db * k / 6)); torItems.push({ pts: pts, color: d === 3 ? kit.blue : d === 4 ? kit.red : kit.violet, a: 0.7, w: 1.1 }); }); });
        void seen; void j;
        pts = []; for (k = 0; k <= 32; k++) pts.push(tor(0, 4 * k / 32)); torItems.push({ pts: pts, color: kit.warm(), w: 3, a: 0.9 });
        pts = []; for (k = 0; k <= 32; k++) pts.push(tor(3 * k / 32, 0)); torItems.push({ pts: pts, color: kit.accent(), w: 3, a: 0.9 });
        data.cells.forEach(function (c) { torItems.push({ p: tor(c.a, c.b), color: kit.ink(), r: 4, label: names[c.pc], pc: c.pc }); });
      })();
      function drawA() {
        var items = torItems.slice();
        if (walk >= 0) { var p = data.fifths_path[walk]; items.push({ p: tor(p[0], p[1]), color: kit.warm(), r: 8 }); }
        else { var f = (T * 0.3) % 12, i0 = Math.floor(f), p0 = data.fifths_path[i0], p1 = data.fifths_path[i0 + 1], t = f - i0; items.push({ p: tor(p0[0] + (p1[0] - p0[0]) * t, p0[1] + (p1[1] - p0[1]) * t), color: kit.warm(), r: 5 }); }
        render(da, items, vt, 0.17);
        ra.textContent = 'χ = ' + data.f[0] + ' − ' + data.f[1] + ' + ' + data.f[2] + ' = ' + (data.f[0] - data.f[1] + data.f[2]) + '   ℤ₃ × ℤ₄   pc = 4a + 3b';
      }

      // ---------------------------------------------- (b) the band of dyads
      var pb = kit.panel_(root, NS + 'panel.b', S), db_ = kit.canvas(cell(pb), 0.85, 340), cb = kit.controls(pb);
      kit.button(cb, NS + 'boundary', S, function () { if (!snd) return; silence(); data.boundary.forEach(function (d, i) { chordAt([d[0], d[1]], 0.02 + i * 0.3, 0.28); }); });
      kit.button(cb, NS + 'tritones', S, function () { if (!snd) return; silence(); data.tritones.forEach(function (d, i) { chordAt([d[0], d[1]], 0.02 + i * 0.5, 0.48); }); });
      var g1 = el('p', { class: 'exp-line' }); pb.appendChild(g1); g1.appendChild(kit.chip('standard-recomputed', 'LAB-016b')); g1.appendChild(document.createTextNode(' ')); g1.appendChild(el('span', { 'data-s': NS + 'b.nonor', text: S(NS + 'b.nonor') }));
      var rb = kit.readout(pb); drag(db_, vb);
      function band(s, k) { s = ((s % 12) + 12) % 12; if (s >= 6) { s -= 6; k = 12 - k; } var th = TAU * s / 6, w = (k - 6) / 6, h = 0.9, rr = 2 + w * h * Math.cos(th / 2); return [rr * Math.cos(th), rr * Math.sin(th), w * h * Math.sin(th / 2)]; }
      function reps(a, b) { var s = (a + b) / 2, k = b - a, o = []; for (var j = -2; j <= 3; j++) o.push([s + 6 * j, j % 2 === 0 ? k : 12 - k]); return o; }
      var bandItems = [];
      (function () {
        data.mob_cells.forEach(function (vs) {
          var cur = null, path = [];
          vs.concat([vs[0]]).forEach(function (d, i) { var rp = reps(d[0], d[1]), best = rp[0]; if (cur) { var bd = 1e9; rp.forEach(function (r) { var dd = Math.hypot(r[0] - cur[0], r[1] - cur[1]); if (dd < bd) { bd = dd; best = r; } }); } else best = rp.filter(function (r) { return r[0] >= 0 && r[0] < 12; })[0]; if (cur) for (var q = 1; q <= 4; q++) path.push([cur[0] + (best[0] - cur[0]) * q / 4, cur[1] + (best[1] - cur[1]) * q / 4]); else path.push(best); cur = best; });
          bandItems.push({ pts: path.map(function (p) { return band(p[0], p[1]); }), color: kit.muted(), a: 0.3 });
        });
        var bpts = []; for (var a = 0; a <= 12; a++) for (var q = 0; q < 4; q++) if (a < 12 || q === 0) bpts.push(band(a + q / 4, 0));
        bandItems.push({ pts: bpts, color: kit.warm(), w: 2.6, a: 0.95 });
        data.mob_v.forEach(function (v) { var a = v.ab[0], b = v.ab[1], tri = b - a === 6; bandItems.push({ p: band((a + b) / 2, b - a), color: v.boundary ? kit.warm() : tri ? kit.violet : kit.accent(), r: tri ? 4.5 : 3 }); });
      })();
      function drawB() { render(db_, bandItems, vb, 0.15); rb.textContent = data.mob_f[0] + ' − ' + data.mob_f[1] + ' + ' + data.mob_f[2] + ' = ' + (data.mob_f[0] - data.mob_f[1] + data.mob_f[2]) + '   ' + data.boundary.length + '   ' + data.tritones.length; }

      // ---------------------------------------------- (c) PLR as one-note changes on the flat Tonnetz
      var pc = kit.panel_(root, NS + 'panel.c', S, 'span'), dc = kit.canvas(cell(pc), 0.62, 380), cc2 = kit.controls(pc);
      ['P', 'L', 'R'].forEach(function (l) { kit.button(cc2, NS + 'move.' + l, S, function () { var nb = nbrs(sel); sel = nb[l]; if (snd) { silence(); chordAt(data.triads[sel].pcs, 0.02, 0.8); } }); });
      kit.check(cc2, NS + 'dual', S, false, function (v) { showDual = v; });
      var rc = kit.readout(pc); kit.line(pc, NS + 'c.note', S);
      function pcOf(v) { return ((7 * v[0] + 4 * v[1]) % 12 + 12) % 12; }
      function xyOf(v) { return [v[0] + v[1] / 2, v[1] * Math.sqrt(3) / 2]; }
      function nbrs(i) { var o = {}, nm = data.triads[i].name; data.dual_edges.forEach(function (e) { if (e.a === nm) o[e.label] = byName[e.b]; else if (e.b === nm) o[e.label] = byName[e.a]; }); return o; }
      function triOf(i) { return data.tri.filter(function (t) { return t.triad === data.triads[i].name; })[0]; }
      function flipOf(i, j) { var t = triOf(i).ij, pj = data.triads[j].pcs, old = 0, k; for (k = 0; k < 3; k++) if (pj.indexOf(pcOf(t[k])) < 0) old = k; var a = t[(old + 1) % 3], b = t[(old + 2) % 3]; return { old: t[old], nv: [a[0] + b[0] - t[old][0], a[1] + b[1] - t[old][1]], a: a, b: b }; }
      var minx = 1e9, maxx = -1e9, miny = 1e9, maxy = -1e9;
      [[-1.2, -1.3], [5.5, -1.3], [5.5, 4.4], [-1.2, 4.4]].forEach(function (q) { var p = xyOf(q); minx = Math.min(minx, p[0]); maxx = Math.max(maxx, p[0]); miny = Math.min(miny, p[1]); maxy = Math.max(maxy, p[1]); });
      var geo = {};
      function X(q) { var p = xyOf(q); return [geo.ox + p[0] * geo.sc, geo.oy - p[1] * geo.sc]; }
      function drawC() {
        var s = dc.size(), c = dc.ctx, W = s.w, H = s.h, i; c.clearRect(0, 0, W, H);
        var x0 = 0, x1 = 6.2, y0 = -1.1, y1 = 3.7; geo.sc = Math.min((W - 20) / (x1 - x0), (H - 20) / (y1 - y0)); geo.ox = (W - geo.sc * (x1 - x0)) / 2 - geo.sc * x0; geo.oy = (H + geo.sc * (y1 - y0)) / 2 + geo.sc * y0;
        var dm = data.domain.map(X); c.strokeStyle = kit.muted(); c.lineWidth = 1.2; c.setLineDash([5, 4]); c.beginPath(); dm.forEach(function (p, k) { if (k) c.lineTo(p[0], p[1]); else c.moveTo(p[0], p[1]); }); c.closePath(); c.stroke(); c.setLineDash([]);
        data.tri.forEach(function (t, k) { var pts = t.ij.map(X), me = data.triads[sel].name === t.triad; c.beginPath(); pts.forEach(function (p, q) { if (q) c.lineTo(p[0], p[1]); else c.moveTo(p[0], p[1]); }); c.closePath(); c.fillStyle = t.type === 'major' ? kit.red : kit.blue; c.globalAlpha = me ? 0.5 : 0.12; c.fill(); c.globalAlpha = 1; c.strokeStyle = kit.muted(); c.lineWidth = 0.8; c.stroke(); void k; });
        var seen = {}; c.font = '11px system-ui, sans-serif'; c.textAlign = 'center';
        data.tri.forEach(function (t) { t.ij.forEach(function (v) { var key = v.join(','); if (seen[key]) return; seen[key] = 1; var p = X(v); c.fillStyle = kit.ink(); c.beginPath(); c.arc(p[0], p[1], 3, 0, TAU); c.fill(); c.fillText(names[pcOf(v)], p[0], p[1] - 7); }); });
        var nb = nbrs(sel), cols = { P: kit.accent(), L: kit.violet, R: kit.warm() };
        ['P', 'L', 'R'].forEach(function (l) { var f = flipOf(sel, nb[l]), A = X(f.a), B = X(f.b), O = X(f.old), N = X(f.nv); c.setLineDash([4, 3]); c.strokeStyle = cols[l]; c.lineWidth = 1.3; c.beginPath(); c.moveTo(A[0], A[1]); c.lineTo(N[0], N[1]); c.lineTo(B[0], B[1]); c.stroke(); c.setLineDash([]); c.lineWidth = 2.4; c.beginPath(); c.arc(O[0], O[1], 9, 0, TAU); c.stroke(); c.beginPath(); c.arc(N[0], N[1], 9, 0, TAU); c.stroke(); c.fillStyle = cols[l]; c.font = 'bold 13px system-ui, sans-serif'; c.fillText(l, (O[0] + N[0]) / 2 + 10, (O[1] + N[1]) / 2); });
        if (showDual) { c.lineWidth = 1.2; data.dual_edges.forEach(function (e) { var p = data.dual_nodes[byName[e.a]].xy, q = data.dual_nodes[byName[e.b]].xy; if (Math.hypot(p[0] - q[0], p[1] - q[1]) > 1.6) return; var A = [geo.ox + p[0] * geo.sc, geo.oy - p[1] * geo.sc], B = [geo.ox + q[0] * geo.sc, geo.oy - q[1] * geo.sc]; c.strokeStyle = cols[e.label]; c.globalAlpha = 0.6; c.beginPath(); c.moveTo(A[0], A[1]); c.lineTo(B[0], B[1]); c.stroke(); c.globalAlpha = 1; }); }
        rc.textContent = data.triads[sel].name + '   P → ' + data.triads[nb.P].name + '   L → ' + data.triads[nb.L].name + '   R → ' + data.triads[nb.R].name;
      }
      dc.el.addEventListener('click', function (e) {
        var r = dc.el.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
        data.tri.forEach(function (t) { var P = t.ij.map(X); function sg(a, b, c) { return (a[0] - c[0]) * (b[1] - c[1]) - (b[0] - c[0]) * (a[1] - c[1]); } var q = [x, y], d1 = sg(q, P[0], P[1]), d2 = sg(q, P[1], P[2]), d3 = sg(q, P[2], P[0]); if (!((d1 < 0 || d2 < 0 || d3 < 0) && (d1 > 0 || d2 > 0 || d3 > 0))) { sel = byName[t.triad]; if (snd) { silence(); chordAt(data.triads[sel].pcs, 0.02, 0.8); } } });
      });

      var pz = kit.panel_(root, 'exp.common.see', S); kit.line(pz, NS + 'see', S);
      var ph = kit.panel_(root, 'exp.common.hear', S); kit.line(ph, NS + 'hear', S);
      var pdt = el('p', { class: 'exp-line' }); pdt.appendChild(el('strong', { 'data-s': 'exp.common.data', text: S('exp.common.data') })); pdt.appendChild(document.createTextNode(' ')); pdt.appendChild(el('span', { 'data-s': NS + 'data', text: S(NS + 'data') }));
      root.appendChild(el('div', { class: 'exp-panel span' }, [pdt]));
      kit.loop(function (t, dt) { if (moving) { T += dt; vt.yaw += dt * 0.25; vb.yaw += dt * 0.2; } drawA(); drawB(); drawC(); });
    }
  };
})();
