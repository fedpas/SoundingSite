<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors -->
# The Sounding View — release 8

*6 November 2026. Built from the Cascade Atlas, release 4.4.14, and from eight works after it read as their own files (their rows are not yet in the Atlas's tables): the kinetic X–B ramp, the kinetic triplet's cavity phase, the O–X step, the spin of sound on its probes, the violin, the violin in motion, the dual bells, and the duals one step further.*

Release 8 grows Part I at two places: the tone chapter ends with the duals of the Atlas's shapes, and the violin chapter sets the violin in motion.

## What changes

- **Two chains at the end of the tone chapter** (`tone.html`): *the dual bells* (MUS-238, MUS-239 — the octahedron and the cross-polytopes as spring networks, their plucked vertex with its two partials, the cross-polytope's interval closing towards a unison, the tetrahedron, the 24-cell, the icosahedron and the dodecahedron; the polyhedron as a 2-complex whose edge Laplacian carries the polyhedron's and its dual's spectra together) and *the duals one step further* (MUS-240 … MUS-244 — the tesseract as a 4-complex with four Laplacians and the 16-cell as its cells; the bells on groups, whose pluck weights are the group's Plancherel measure, up to the 600-cell; the 120-cell as the 600-cell's cells, its 27 levels certified exactly beyond ℚ(√5); a column of octahedra as a faster string with a twisting band; the π-flux on triangular faces, which turns the spring network over), read from their own files (`SDV_PACK_D`, `SDV_PACK_E`; `off` builds without either).
- **A second chain at the end of the violin chapter** (`violin.html`): *the violin in motion* (MUS-231 … MUS-237 — the photograph scored against the computed patterns, the post's moment converged, the bridge's admittance as an input, the bowed string simulated in time with Schelleng's diagram computed and the wolf looked for, a flat violin-shaped plate with the wood's grain, a box of two hinged plates with its air, a bass bar and a post), read from its own files (`SDV_PACK_W`).
- **Three experiments**: *The dual bells* and *The duals, one step further* at the head of the tone chapter (ten solids as turning wireframes with their partial ladders, the bells struck at one mapping; the tesseract and the 16-cell turning together with the four Laplacians' ladders; the 600-cell on its Coxeter plane and the 120-cell beside it, both struck; the column's bands; the frustrated solids), and *The violin in motion* under the violin's first experiment (the photograph's sand with the candidates' nodal lines and their scores; the post's moment converging; Schelleng's diagram as computed, with the simulated bridge force of each regime played back; the wolf's envelopes and the linear beat played; the violin-shaped plate's modes; the box, silent without bar and post).
- **The pages:** the checks page's fourth group holds the violin's two scripts and a fifth group the dual bells' two; the pictures page three more figures (the Coxeter-plane projections among them); the sources page's last section carries the three works' references.
- **The generator** lets an Atlas chapter add chains told on its section after its own (the tone chapter's two), and keeps the packs' groups generic (`PACK_GROUP_ORDER`); the Italian manifest follows.
- **Counts**: 237 row blocks, 34 scripts, 37 figures.

## Second build: the menus and the experiments' layout

- **"On this page" rebuilt from each page's own sections.** On a chapter page the menu now reads: the lead; the experiments, each by its title; each chain by its title (in the register you are reading), with its rows as small chips under it; the pictures; the clips; the instruments. The experiments stand under a heading of their own, and every section the menu names has an anchor. The reference pages gain the same rail: the Dictionary (grades, entries, readings, the paper's dictionary), the Checks (each group of scripts with its scripts), the Pictures (by part), the Sources (each section), Method (its sections), Sounds (the instruments by part, the clips, the experiments), and the report of the acoustic Beth experiment (its numbered sections). The rail scrolls when a menu is longer than the window.
- **The experiments' canvases follow their cell.** A canvas sized while its panel was still alone in its row kept that width when a table or a second canvas arrived beside it, and overlapped it on some windows; the kit now lets a cell shrink, caps a canvas at its cell, and re-sizes it when the cell moves (a resize observer), telling the module to redraw. A sweep of every page at five widths (390 … 1950 px) finds no canvas wider than its cell and none overlapping a neighbour, in either language.

## The Italian side

Four narrators: the fourteen rows with their three chain headings, three figure captions and three script lines, the rewrites of the tone and violin chapters' narrations and of Part I's card, the titles of three Atlas rows shown in the experiments' legends, the fifth group's narration, the count and group strings; and the three experiments' strings (301). Terms: *la campana duale*, *i politopi a croce*, *il laplaciano degli spigoli*, *il tesseratto*, *la 600-celle* e *la 120-celle*, *la misura di Plancherel*, *la colonna di ottaedri*, *il flusso π*, *la rete frustrata*; *la fotografia messa in punteggio*, *le linee di ritardo*, *il diagramma di Schelleng calcolato*, *le piastre incernierate*, *i modi B1− e B1+ del modello*.

## Verified

`gen/check.mjs`: 0 errors, 0 warnings in both languages; `test_sounds.mjs`; `shoot.cjs`, no console error, every experiment mounted; the three packs rerun on a fresh copy of the 4.4.14 kernel with every fault (23 + 29 + 39 checks; 17 + 26 + 28 faults).

---

# The Sounding View — release 7

*6 November 2026. Built from the Cascade Atlas, release 4.4.14, and from five works after it read as their own files (their rows are not yet in the Atlas's tables): the kinetic X–B ramp, the kinetic triplet's cavity phase, the O–X step, the spin of sound on its probes, and the violin.*

Release 7 adds a third chapter to Part I, *The violin*: a true object with pieces added, after the symmetric objects of the chapters before it.

## What changes

- **A new chapter in Part I, *The violin*** (`violin.html`), eight rows MUS-223 … MUS-230 of one chain told on the section of the tone, read from their own files as the other works are (`SDV_PACK_V`; `off` builds without the chapter). The bowed string's Helmholtz motion as a closed form (the corner on its parabola, the two-valued velocity, Benson's principle, the sawtooth at the bridge, the amplitude law); the four strings from their tensions (the open strings in beatless fifths are Pythagorean, 1.955 cents per fifth from equal temperament; impedances, the stiff E, the beats of the tempered fifths); Schelleng's two limits of the bow force and their crossing; the free bar in halves and the free square plate by Rayleigh–Ritz with exact rational matrices (the twist, the X, the ring; Leissa's values), the plate held at its centre converged with two singular functions, and the plate carrying a mass at its centre; a student report on the violin with its claims recomputed (the string's speed, the damping's sign, the post's amplitude, its first plate function against the free edge, its photograph identified by pattern with the third held mode and the frequency that does not follow); the added piece (an odd drive on a mirror-symmetric chain has a zero sum exactly; a post off the mirror breaks it; on the plate the post makes the monopole moment nonzero); the air of the box (Rayleigh's elliptic hole, the perimeter law, A0 with its inputs); the wolf (a string on a resonant bridge, the split, the criterion, the beat, and no sharp threshold in the exact equation).
- **The experiment *The violin: a bowed string, a plate, a post, its air, a wolf***, five panels at the chapter's head: the bowed string (the corner running on its parabola with the stick and slip at the bow and the sawtooth at the bridge; β, the bow speed, the string; Schelleng's wedge with the bow's point on it; the sawtooth heard raw or through three body resonances, and what lies below and above the wedge), the plate (the free modes at ν = 0.3 and 0.39 with their nodal lines, the three held modes, the driver's mass, the report's W₁ beside the photograph's mode; the plate struck), the added piece (the chain of twelve under an odd drive, free, one mass held, the pair held; the plate's monopole moment with and without the post, the driven plate drawn), the air (a hole from a circle to a slit at fixed area, its conductance and perimeter, A0 against the measured band; the hole's note), the wolf (the two coupled modes against Q, exact and in the near-coincidence model, the beat drawn and heard).
- **The pages:** the checks page gains a fourth group, the violin's script beside the two of Music on the labels; the pictures page the figure of the violin; the sources page the violin's references; the Method page names the five works read from their own files.
- **The generator** reads a pack whose script stands in another folder of the Atlas's checks and whose figure and script stand in their own group (`folder`, `group`); a chain chapter may be told on any section (`told`); a chapter whose pack is absent is left out with its experiment.
- **Counts**: 223 row blocks, 31 scripts, 34 figures; 21 504 traced blocks; 294 narrations, 1007 titles.

## The Italian side

Two narrators: the eight rows with their chain heading, figure caption and script line, the chapter's own narration and titles, the Method and count strings and the re-reading of Part I's page, the checks page and the pages whose counts changed; the 140 strings of the experiment. Terms: *la corda strofinata*, *lo spigolo di Helmholtz*, *il ponticello*, *l'anima*, *la catena del violino* (the bass bar, kept apart from *la catena di dodici masse*), *le effe*, *il modo a torsione / a X / ad anello*, *la piastra tenuta al centro*, *il pezzo aggiunto*, *la legge del perimetro*, *il lupo*, *una tesina di laurea (Durham, 2022)* for the report.

## Verified

`gen/check.mjs`: 0 errors, 0 warnings in both languages; `test_sounds.mjs` 43 of 43; `shoot.cjs` 240 shots of 60 pages, no console error, every experiment mounted; the violin pack rerun on a fresh copy of the 4.4.14 kernel with logs and figure data identical to its own (41 checks, 27 faults). The pack was independently reviewed before the site read it; the review's rectified photograph (a homography from the plate's four corners) decided the identification the chapter tells.

---

# The Sounding View — release 6

*6 November 2026. Built from the Cascade Atlas, release 4.4.14, and from four works after it read as their own files (their rows are not yet in the Atlas's tables): the kinetic X–B ramp, the kinetic triplet's cavity phase, the O–X step, and the spin of sound on its probes.*

Release 6 tells three more works beside the kinetic X–B ramp, and extends two experiments to draw them.

## What changes

- **Two more chains in the chapter *Waves that tunnel and turn into others*.** *The kinetic triplet's cavity phase* (MUS-200 … MUS-202): the conversion of the X wave on the cutoff–resonance–cutoff triplet against the position of its L cutoff — the kinetic maximum lies at a longer cavity than the cold zero of the phase and below 1, the shift grows from v_t/c = 1/20 to 1/40 and falls at each step below, the minimum stays a zero (exact at η_L = 2, 4, 6; the warm zero beside 2 by the sign change of the outgoing amplitude), the gentler triplets keep near the cold envelope. *The O–X step* (MUS-203 … MUS-208): the cold plasma at oblique incidence on a density ramp, the 4 × 4 system of the tangential fields and its cutoffs (the ordinary and the slow extraordinary wave cut off together at N_z² = Y/(1 + Y)), the exact steps, and the O wave turned into the slow X wave on MUS-161's ramp — three quarters at the optimal N_z where Mjølhus's formula says all, nearly all on the ramp stretched four to sixteen times — with no leak for the cold chain to the layer.
- **A second chain in the chapter *The spin of sound*.** *The spin of sound on its probes* (MUS-213 … MUS-221): the three-phase cube, whose body diagonal is a line of zero pressure with the velocity on a circle across it and the spin along it; the triangle's lowest pair as three travelling waves at 120° and the tetrahedron's node by symmetry; the small sphere's entrainment as an exact function of a/δ and of the density ratio, the rotation rate with its certified maxima inside the viscous layer, the thermal floor and its closed form (with the medium's share neglected); the two spins of sound and the Rayleigh wave's two through the depth; the deep-water wave's prograde orbit, its Stokes drift ρu_s = kS and its one unit of angular momentum per quantum; the still point of two standing water waves with its drift swirl; the Barnett bridge from the rotation of a surface wave to a spin.
- **The experiments.** *Mode conversion through layers* gains *The cavity's best length as the plasma cools* and *The O–X window*; *The spin of sound* gains *The special places* (the cube in four states with the view down the diagonal, the triangle with its node, the tetrahedron), *The still point of the water tank* (the still points, the orbits beneath, the floater, the Stokes-drift swirl, the travelling wave's orbits from the side) and *The smallest rotor* (the rate against a/δ for silica, gold, aluminium in air and the heavy limit, the certified maxima, the thermal floor against frequency).
- **Counts**: 215 row blocks, 30 scripts, 33 figures; 20 988 traced blocks; 284 narrations, 970 titles.

## The Italian side

Three narrators: the nine plasma rows with their two chain headings, two figure captions, two script lines, the five Method and count strings and the re-reading of the layers chapter and the checks page; the 128 strings of the two experiments extended; the nine spin rows with their chain heading, figure caption and script line and the re-reading of the spin chapter and the count pages. Terms settled by the coordinator: *il passo O–X*, *la soglia termica*, *la quota del mezzo*, *le particelle di fluido*, *il tripletto*.

## Verified

`gen/check.mjs`: 0 errors, 0 warnings in both languages; `test_sounds.mjs` 43 of 43; `shoot.cjs` 232 shots of 58 pages, no console error, every experiment mounted; the three new packs rerun on fresh copies of the 4.4.14 kernel with logs identical to theirs. The "smallest rotor" numbers carry the condition the spin pack's review added: the medium's share of the acoustic Beth design, 1 − (9/2)δ/a for a held sphere, is not computed and not small at the maxima.

---

# The Sounding View — release 5

*5 November 2026. Built from the Cascade Atlas, release 4.4.14, and from the kinetic X–B ramp, a work after 4.4.14 read as its own files (its rows are not yet in the Atlas's tables).*

Release 5 corrects three experiments that said "no data here" where the Atlas has the numbers, and tells the kinetic X–B ramp.

## What changes

- **Three experiments draw what they said they could not.** *Two streams and the sheet* draws the two Lorentzian beams (MUS-120: the growth against the wavenumber at a/v₀ = 0, ¼, ½, ¾, the band edges, the rule "the cold growth less |k|a", unstable exactly when v₀ > a) and the bump on the tail (MUS-121: the exact growth against the beam's width from the fluid rate to the first-order kinetic one, the five certified points, the four peaks), both from `kinetic.json`. *The gyration's harmonics* draws the harmonic weights Λₙ(λ) = Iₙ(λ)e^(−λ) as bars (MUS-177), computed on the page by the recurrence the Atlas certifies against its rational enclosures (Miller's, normalized by Neumann's identity, 1.1·10⁻¹⁵ at 268 values), with the seven certified λ marked and the tail bound printed; the chord Ω … 8Ω is weighted by them. *Mode conversion through layers* shows the triplet's shares — the fluid's (MUS-161) and, from the kinetic X–B ramp, the three first-order forms' (MUS-197) — the hot electrons' wave on the ramp against the fluid's at Y = 9/10 and 2/5 (MUS-192, MUS-194), the exact sharp step (MUS-193) and where the converted wave goes (MUS-198).
- **The kinetic X–B ramp**: ten rows, MUS-190 … MUS-199, as a chain of their own under the layers chain of the chapter *Waves that tunnel and turn into others* — Ram and Schultz's kinetic X–B equation and its flux, the hot tensor's full first order, the momentum form and its fluid limit, the local waves at the layer and the backward kinetic wave, interfaces and exact steps, the kinetic Budden ramp in three forms, the X wave from the dense side, the approach and the form dependence, the kinetic triplet, where the converted wave goes. They are read from the work's own files (its rows, its script `music_xb_ramp.py` with its log and fault log, its figure and figure data), carry the status those files give them (one standard-recomputed, nine computed), and are told as every row is, in the four registers, their checks' statements and log lines included; Method says they are not yet in the Atlas's tables. The script is the twenty-seventh on the Checks page, the figure the thirtieth on Pictures.
- **Counts**: 197 row blocks, 27 scripts, 30 figures; 19 850 traced blocks; 266 narrations, 921 titles.

## The Italian side

Two narrators: the ten rows (narration and title each), the chain's heading, the figure's caption, the script's line, the Method strings; and the 91 strings of the three experiments (79 added, 12 changed). The layers chapter's narration tells both chains; the pages of the checks and the pictures say the counts.

## Verified

`gen/check.mjs`: 0 errors, 0 warnings in both languages; `test_sounds.mjs` 43 of 43; `shoot.cjs` 232 shots of 58 pages, no console error, every experiment mounted. One point for the Atlas side: in `xb_ramp.json ramps` the fields are per unit amplitude of each form's normalized mode vector, not per unit incident E_y as the units line says (the writer's `scatter_solve` sets `f[iX] = 1` on the normalized vector; the fluid's vector is dominated by v_x = E_x/(iX), so its E_y is about a seventh of the kinetic form's); R, T, C are unaffected. The page scales each trace to its own largest and says why; `XB_RAMP_FIGDATA_NOTE.md` has the three-line fix for the writer.

---

# The Sounding View — release 4

*5 November 2026. Built from the Cascade Atlas, release 4.4.14.*

Release 4 reads the Atlas 4.4.14, where the rows of *Sound beside light* are table rows, and adds the experiments: a picture with a few switches and one sound, set above the rows of a chapter.

## What changes

- **187 row blocks** (64 + 45 + 78): the eight new chains of the Atlas (magnetized fluid, streams and the vortex sheet, kinetic and certified roots, layers, cyclotron damping, Bernstein waves) are told row by row, each row in the four registers.
- **Part III has nine chapters in four movements**: *The field* (sound and light side by side, the medium with two stiffnesses, the spin of sound), *The charged fluid*, *Beside the magnetic field* (a charged gas in a field, waves that tunnel, waves along and across the field), *Sound that fades or grows* (Landau damping and certified roots, streams and the vortex sheet).
- **Twenty-three experiments**, each on its chapter: the rotor, graphs, continuum and rings of the tone; the two tones; the clock ring and the sets; the circle of fifths; the triads; the band; the twelve Fourier coefficients; the field made visible; the picture that is not an image; two stiffnesses; the spin of sound; plasma waves and the coupling; the whistler and the Alfvén wave; the layers; cyclotron and Bernstein harmonics; the fading sound; two streams and a sheet. Each draws the Atlas's own figure data, maps its frequencies into hearing, says by how much it is slowed, and lists the rows it stands on, each with its chip.
- **The acoustic Beth experiment** has its page, `experiment.html`: the report as the Atlas holds it, with its figures, linked from the spin chapter.
- **Sounds** has a third group, the experiments. **Method** says what an experiment is.
- 26 scripts (the two of round 36, nine of round 37, fifteen of sound beside light), 62 lens entries with 342 readings, 29 figures and 22 clips.

## The experiments, as a rule

Each experiment draws the Atlas's own figure data (the files the check scripts write beside their logs) and never recomputes a dispersion relation, a root or a threshold; what moves is kinematic — a plane wave, a rotor, a gyration, parcels in a given field. Its sound maps the frequencies into hearing and keeps the ratios (a damping rate to a frequency, a group delay to a chirp); the page prints the mapping and by how much the picture is slowed. Every visible word is a traced string, in both languages; under each experiment the legend lists the rows it stands on, with their status chips, and the lens's grade where an analogy is drawn.

## The Italian side

Four narrators told the new material — 78 rows, 5 chapters and 4 movements, the page of the Beth experiment, 15 lens entries, 9 scripts, and the 787 strings of the experiments — and reviewed the 29 rows whose texts the Atlas edited (24 retold, 19 kept as they were). No stub is left.

## The recordings

The whistler experiment has a slot for NASA's recordings of whistlers, chorus and hiss (`audio/nasa/whistler.mp3`, `chorus.mp3`, `hiss.wav`, credited "Source: NASA"); when the files are absent the page links the recording instead. The University of Iowa's recordings stay links: their page states no terms of use.

## Verified

`check.mjs`: 0 errors, 0 warnings in both languages (19 262 traced blocks, 256 narrations, 902 titles). `test_sounds.mjs`: 43 of 43. `shoot.cjs`: 232 shots of 58 pages at 1280 and 390, every experiment mounted, no console error but the web fonts' fetch, which fails offline by design.

---
# The Sounding View — release 3

*3 November 2026. Built from the tables of the Cascade Atlas, release 4.4.10 (round 37 merged in D114, the record consolidated in D115), and from the pack of round 38, *Sound beside light*, read as a study's own files; its rows are not yet in the Atlas's tables.*

Release 3 changes the shape of the site and adds a part. The eight sections become **four parts and twelve chapters**; the bridges become a **map**; the Sounds page is grouped by part; the header has a **Reference** menu; every chapter has breadcrumbs and previous / next links across the whole story.

## What changes

- **Four parts** (`sound.html`, `twelve.html`, `light.html`, `question.html`) and **twelve chapters**: Part I tone, consonance; Part II clock, scales, groups, shapes, fourier; Part III complements, aether, plasma, spin; Part IV the question. The Atlas's own chains keep their order; round 37's rows stand in the chains where 4.4.10 put them.
- **Part III, *Sound beside light***: 45 rows (38 of the study and 7 inputs, INP-133 … 139) in four chapters, each row in the four registers; four figures; clip 22; the six scripts of the study with their logs and controls.
- **The bridges** (`bridges.html`) is a map of five chapters (*Two twelves*, *Twelve bits*, *Two dualities*, *What a ring can sound*, *Sound beside light*) with twelve lines — the eleven bridges and the plasma coupling — each graded before and after, what decided it in one sentence, and the chapters that hold its rows. Bridge 2 reads the regrade of *Sound beside light* (exact on the shear sector, none for the pressure, the word "translation" ours). No row blocks, and no study prose: the study's own question and method stay in the study.
- **Instrument 10, *Two stiffnesses*** (`sounds.js`): a ring of twelve masses with a stretch spring κ and a shear spring μ; presets air, MacCullagh, one speed, the Poisson solid; a κ/μ slider; the sound ring, the shear ring or both; both spectra drawn; the zero modes silent. Six new assertions in `test_sounds.mjs` (43 in all).
- **Reference** menu: Dictionary (47 lens entries, 206 readings, the paper's dictionary), Checks (17 scripts), Pictures (29 figures grouped by the part that holds their rows), Sources, Method (the former About), which says once, plainly, what the site reads; no pack's README is quoted.
- **Sounds** by part: the instruments and the 22 clips under the part that holds them.

## The counts (`content/version.json`)

23 pages and 23 in Italian; 109 row blocks (64 of the Atlas, 45 of the study); 29 figures; 22 clips; 10 instruments; 17 scripts; 47 lens entries and 206 readings.

## The Italian side

The three tables of release 2 carry over for every target that still exists. Two narrators told the new targets — 61 narrations, 101 titles, 95 strings — and retold the eight narrations whose subject changed: the home (four parts and two doors), the map of the bridges, the dictionary (47 entries), the sounds (22 clips, 10 instruments), the sources, the checks, the pictures (by part), and MUS-049 (now a computation). No stub is left; the Italian pages are Italian throughout.

## Verified

`check.mjs`: 0 errors, 0 warnings, both languages (11 714 traced blocks, 172 narrations, 527 titles). `test_sounds.mjs`: 43 of 43. `shoot.cjs`: 184 shots of 46 pages at 1280 and 390, 0 problems.

---

# The Sounding View — release 2

*2 November 2026. Built from the tables of the Cascade Atlas, release 4.4.9, with round 36 merged (its checks ran on 1 November 2026), and from the pack of round 37, *The bridges drilled* (a study of 2 November 2026 against 4.4.9; stored, not merged: its rows are proposed). In English and in Italian.*

Release 2 adds a page of its own for the bridges, three instruments, the pack's nine scripts, twelve figures and nine clips on the pages that hold such things, the paper's dictionary, and an Italian side told by a narrator. A reader of release 1 finds the same site with more in it: the same chips, the same four registers, and one short stamp.

## The second pass

The first form of this release was rejected by the owner: the Italian pages were a bilingual document — the English records stood in the reading flow and the narrator's Italian hung under them — and both languages carried the work's bookkeeping (the round, the pack, *proposed* and *merged*, the Atlas's version, the owner, the drill). The second pass, of the same day, rebuilt the Italian pages as the narrator's site: everything a reader reads — titles, claims, leads, captions, the clips' lines, the instruments' words, the tables' columns — is Italian, from three tables (the strings, the 122 narrations and, new, 237 titles: the sections' titles and cards, the 63 row claims, the figures' captions, the clips' titles, the items, the bridges, the lens terms, the paper's rows, the scripts' lines); the Atlas's English records stand only inside the three record registers, each opening with a small Italian label, and inside collapsed disclosures whose summaries are Italian; and the checker now proves it, tracing every text node of the Italian reading flow to the three tables or to an id, a number, a formula, a file name or a listed proper name. On both sides the bookkeeping left the reading flow: the page is *The bridges* / *I ponti*, its rows carry their status chip only, the stamp is one human line (*Release 2 · 2 November 2026*, *Edizione 2 · 2 novembre 2026*), and the provenance — the Atlas's version, the study whose rows are not yet in the tables — is said on About alone, and kept whole in `content/version.json` and here.

## What the release adds

- **The page *The bridges*** (`bridges.html`): the question and the method in the study's words (§1 and the opening of part 2, in a disclosure); the table of the eleven bridges from `BRIDGES_DRILLED.md` (bridge · before · after · what decided it, every cell traced); eight parts, one per item in the study's order — the clock, the labels of twelve, the duality and the bell, the walk, the rows as an instrument, the ring with its hypotheses removed, the rigid body on the Atlas's motors, sound and light on the kernel and the paper — each with the study's sections telling it (formulas set with KaTeX from the study's TeX), its rows as row blocks, its figures, its clips and its instrument; the paper's dictionary with its ten candidates; the opinion (§9) and what part 2 changes (§16); the way to the references.
- **A row block of the bridges** has the four registers of an Atlas row and reads the item's `ROWS.md` instead of the tables: Story the study's units for the row (else its research text, and the block says so); Research the research text; Atlas the claim in mathematics and in physics, the kind, the status the rule gives, the stage and ptype, what it rests on (the ids linked where the row is on the site), where it would live, the evidence with the script's statement for the group (the docstring's Statements section), the lines its log prints, the run's last line and seconds, and what the controls break; Standard the standard reference (its links live) and the bridge the item's `BRIDGE.md` grades for the row, before and after. The chip is the status's chip of release 1, and nothing else marks the row: that its rows are a study's, not yet the tables', is About's to say.
- **The other pages**: the home's ninth card (the bridges in one sentence, 36 rows by status); Checks with the scripts under the two studies' names — the two of *Music on the labels*, the nine of the bridges (311 ok lines in 44 groups, the 45 controls with their FAIL counts, the seconds of each run, the logs as text and as files under `checks/round37/` with their README and `run_all.sh`); Pictures with the twelve figures of the bridges after the thirteen (their rows linked to the row blocks); Sounds with the nine clips 13 … 21 after the twelve and three instruments after the six; Dictionary with a second part, the paper's dictionary (Tables 3 and 4 of Burns, Daniel, Alexander and Dressel carried into three columns, the counts, and the candidates on the page of the bridges); Sources with the references of the bridges (arXiv numbers and DOIs live) and the paper; About with the method's extension and the provenance of the release in one sentence.
- **Three instruments** (`sounds.js`, tested in `test_sounds.mjs`): **7. the Tonnetz as the CRT grid** — the twelve pitch classes on the 3 × 4 torus (a, b) ↦ 4a + 3b of `crt_tonnetz.json`, a cell sounding its pitch class or the triad on it, the fifth's diagonal, the two cycles ℤ₄ and ℤ₃, the mirror x ↦ 7x computed on the grid as (a, b) ↦ (a, −b) and compared with the file, with the arrows drawn; **8. the two rings and the bell** — the ring solved for the partials 1 … 6 (three stiffnesses negative, `harmonic_ring.json`) against the nearest-neighbour ring (the page's 2 sin(πk/12) compared with the file), the positive rings 7 … 12 and {4, 6, 7, 8, 9, 10} of `sets.json`, ring A and ring B of `clips_rings.json`, the 12-cube and 3-cube bells of `bell_levels.json`, each plucked at one mass with the character expansion's amplitudes, the partials drawn as a strip; **9. the all-interval rows** — the 3856 rows of `all_interval_rows.json` by number or preset (Berg's Lyric Suite row, the least and the greatest, Slonimsky's Grandmother chord), voiced by the rule of `audio/INDEX.md`, with retrograde, inversion and R = T₆, the classes under T, I and R and under Fripertinger's G₃, the first hexachord, the melody drawn.
- **The Italian side** (`out/it/`): every page again, `lang="it"`, with the switch EN · IT in the header. It is not a translation: a narrator — a professional of music, mathematics and physics, written by two narrators under one contract and read by an independent reviewer — tells the site in Italian, from three tables: 122 narrations (`content/it/racconto.json`: the home, the eight sections, the 27 + 36 rows, the pages, the nine instruments, the 21 clips, the page of the bridges with its table, its eight items, its opinion and the paper's dictionary, the scripts and the figures of the bridges), 237 titles (`content/it/titoli.json`: the sections' titles, sub-titles, chain headings and cards, the row claims that head the 63 row blocks, the 25 figures' captions, the 21 clips' titles, the items, the eleven bridges with their reasons, the 34 lens terms, the paper's rows, the scripts' lines), and the chrome in the narrator's words (`content/it/strings_it.json`, 453 strings, one per id of the English table). The reading flow of an Italian page is Italian throughout. The Atlas's records — the research texts, the Atlas register, the standard references, the study's prose, the logs, the English captions, the clip indexes, the lens record and its 124 readings, the paper's table — stay in the Atlas's English, but out of the flow: inside the three record registers, each opening with a small Italian label, and inside collapsed disclosures whose summaries are Italian (*l'apertura dell'Atlante, in inglese*; *dallo studio, in inglese*; *la scheda della figura, in inglese* …), with one note per page saying once that the record registers are the Atlas's English; so under the Italian label *Stato* in the Atlas register the record's word reads *computed* while the chip beside it reads *calcolato*: the rule, kept on purpose. The register switch reads *Racconto · Ricerca · Atlas · Standard*: Racconto shows the narrator's telling of the row under its Italian claim, the three others the records as the English page shows them. The checker verifies the Italian pages as it verifies the English ones, and the three tables: the narrations rendered exactly once at their targets, the titles at least once, every manifest target with an item, every `tells` id on the site, no banned word of the contract and no process word, and every text node of the reading flow traced to the tables or to an id, a number, a formula, a file name or a listed proper name. The record of the Italian side is in the source: `it/VOICE_IT.md` (the contract: the targets, the voice, the glossary, the banned words), `it/draft/NOTE_IT-1.md` and `it/draft/NOTE_IT-2.md` (the two narrators' notes: what was read, the terminology beyond the glossary, what was unclear and how it was told), and `it/REVIEW_IT.md` (the reviewer's pass: 24 edits applied in place, and the observations).

## The counts (`content/version.json`)

| | |
|---|---|
| pages | 16 in English (8 sections, the page of the drill, Sounds, Dictionary, Checks, Pictures, Sources, About, the home) and 16 in Italian |
| row blocks | 27 of the Atlas in 8 chains, and 36 rows of the bridges in 8 items, each in 4 registers |
| traced blocks | 3,902 on the English pages, 7,483 with the Italian ones, every one verified; 0 errors, 0 warnings |
| figures | 25 (13 + 12), with their captions and data |
| clips | 21 (12 + 9) |
| instruments | 9 |
| log lines | 89 + 311 ok lines of the eleven logs; 12 + 45 controls |
| formulas | 162 set with KaTeX on the English pages (16 displays with `\htmlData`) |
| strings | 455 in `content/strings.json` (220 of release 1, 185 of release 2's first pass, 59 added and 9 removed in its second), and 453 in Italian |
| narrations | 122, one per target, each rendered once |
| titles | 237 in `content/it/titoli.json`, one per target, each rendered at least once |
| screenshots | 128 (32 pages × 1280 and 390 px × light and dark), 0 console problems |

## The method, extended

- **A study's own files.** A study whose rows are not merged can still be read: the site reads the pack as the study's own files — its study (units and sentences, as *Music on the labels*), its items' `ROWS.md` (a reader of their format), `BRIDGE.md` and `BRIDGES_DRILLED.md`, the scripts' statements and logs, the figure and clip indexes, the dictionary — through trace sources `pack.*` that `lib/pack.mjs` resolves for the generator and for the checker alike. Such a row carries the status the rule gives it and nothing else on the page: its provenance is About's.
- **The Italian narrator.** The Italian pages add two traced elements, `data-r`, a narration of `racconto.json`, and `data-t`, a title of `titoli.json`; the checker resolves them as it resolves `data-b` and `data-s`, and proves the reading flow Italian (every other text node an id, a number, a formula, a file name or a listed proper name).
- **No bookkeeping in the flow.** The words of the work — the round, the pack, *proposed* and *merged*, the Atlas's version, the owner, the drill — are banned from the reading flow of both languages by the checker; About alone says where the release comes from. The studies' own words are records and keep their vocabulary (on the English page in the flow, on the Italian page in disclosures).
- **From the disk**, as before: the Italian pages share the stylesheet, the scripts, the figures, the clips and KaTeX with the English ones by relative paths; nothing is fetched.

## The synthesizer's test

`gen/test_sounds.mjs`: 37 assertions, 37 pass — the 20 of release 1 and 17 of release 2: the CRT grid's fifth diagonal recovered pitch class by pitch class from its FFT peaks, the mirror computed from the cells and compared with the file, the image of the diatonic set (seven consecutive fifths onto seven consecutive semitones) and the sets the mirror keeps, the fifth and the semitone on the torus; the solved ring's and the nearest-neighbour ring's partials within 0.1 %, the pluck's amplitudes 2/12 and 1/12 with the decays compensated, the 12-cube bell's twelve partials 220√j with the loudest at j = 6, the 3-cube bell's 1 : √2 : √3 with 3/8, 3/8, 1/8, the positive ring 7 … 12, ring A's ten audible partials; Berg's row voiced as `berg_row.json` prints it and recovered interval by interval, round(12 log₂(f_{j+1}/f_j)) mod 12, from the rendered melody, R = T₆ measured as √2 note by note, the rule on all 3856 rows (every melody ends a tritone above its first note and spans 11 to 21 semitones; exactly 176 rows have R = T₆), the least and the greatest rows as each other's inversion, the Grandmother chord's wedge.

## Two small things a reader may notice

- The chrome says "clip 7" where the clip labels print "Clip 07" (the files are numbered with two digits); the English and the Italian pages share the habit, which release 1 set.
- Under *Stato* in the Atlas register of the Italian pages the status prints the record's English word beside the Italian chip, as said above: records stay English, and the register says so in its label.
- The drawings are the studies' files: the 25 figures keep the labels their scripts drew, in English, on both sides; their captions are the narrator's on the Italian pages.

## The one link to the Atlas

Unchanged: About's "The Atlas — one rule: the page Music", to `https://toy-model-v0.vercel.app/#/music`, once per language (the Italian About carries the same link). To move it, change `ATLAS_URL` in `gen/build.mjs` and the address the checker accepts, and rebuild.

## How to host

Unzip and serve the folder with any static server, or open `index.html` (or `it/index.html`) from the disk. `.ogg` as `audio/ogg`, `.py`, `.log`, `.md` and `.sh` as `text/plain`. The two text fonts come from Google Fonts; without the network the system fonts are used.

## Licence and credits

- The Cascade Atlas, its tables, figures, scripts and clips, the pack of round 37, and this site with its generator, are under the PolyForm Noncommercial License 1.0.0. Required Notice: Copyright (c) 2026 the Cascade Atlas authors.
- The studies *Music on the labels* and *The bridges drilled* cite their sources by name; the Sources page lists them with their links. The paper the drill reads, Burns, Daniel, Alexander and Dressel, *Spacetime geometry of acoustics and electromagnetism* (arXiv:2305.11448 v2, DOI 10.1007/s40509-024-00317-8), is named there with its links.
- KaTeX (MIT licence) sets the formulas at build time; its stylesheet and fonts ship with the site. IBM Plex Sans and Newsreader are under the SIL Open Font License.

---

# The Sounding View — release 1

*2 November 2026. Built from the tables of the Cascade Atlas, release 4.4.9, with round 36 merged (its checks ran on 1 November 2026).*

The Sounding View is a standalone static website about music, read with the Atlas. It is the Atlas's reading of the study *Music on the labels* (round 36): a musical theory in nine parts, each statement sorted by what establishes it — computed on the labels, a textbook result recomputed, an input with its source, a reading of ours with its reason, or open. It is built the way its sister site, *The Shifted View*, is built, and it adds a Sounds page that plays the Atlas's own numbers.

Every sentence on the site comes from one of four places: a record of the Atlas, an inventory, a study's own files, or the site's own string table. The generator checks each one against its source.

## What the site reads

- **The Atlas 4.4.9** (`content/`): the rows MUS-001 … MUS-012, INP-124 … INP-130 and the Atlas's own rows the page `music` tells (SPR-M01, SPR-M16, ATY-040, LAB-046, LAB-047, LAB-016b, LNS-137); their research texts and, where they exist, their learner texts (`texts.json`); the page `music` with its eight sections, eight chains, nine leads (MUS-701, MUS-741 … MUS-748) and its own row MUS-013 (`content/chains/music/`); the status of every row (`derived/status.json`); the lens `mus` with its 34 entries (`lenses.json`) and its 124 readings (`lens_readings.json`); the records of the two scripts (`checks.json`) and their runs (`check_runs.json`); the page titles (`pages.json`).
- **Round 36's own files**: the study `docs/round36/music_on_the_labels.html` (its prose for the Story register, its abstract, its references), the thirteen figures with `figs/FIGURES_INDEX.md`, the literature's `lit/SOURCES.md`; `checks/selfcheck/round36/`: the two scripts, their logs and their faults logs, the figure data `figdata/*.json`, and the twelve clips with `audio/INDEX.md` (here as Ogg Vorbis).

## The pages (15)

- **Home** (`index.html`): the question in one paragraph, composed sentence by sentence from the study's abstract and the lead MUS-701; the study's map as the site's picture; the eight sections as cards, each with its lead and the count of its rows by status; the way to the Sounds page.
- **Eight section pages**, one per chain of the page `music`: `tone.html`, `consonance.html`, `clock.html`, `scales.html`, `groups.html`, `shapes.html`, `fourier.html`, `question.html`. Each has its titles (learner, physics, mathematics), its lead, the chain's rows in the Atlas's order with the chain's links between them, the section's figures (by FIGURES_INDEX.md's row column) and clips, and the instrument of the Sounds page that plays its numbers.
  - **A row** is a block with its id, its status chip and its claim, in **four registers** (the switch at the top: Story · Research · Atlas · Standard):
    - *Story*: the study's own prose for the row, traced to the study's section (21 rows); else the Atlas's learner text (5 rows); else the research text (ATY-040). The block says which.
    - *Research*: the row's research text.
    - *Atlas*: the row's claim in mathematics and in physics, its kind, status and badge, cells, what it rests on, the reason for its status, its release; its checks with the check's statement, the lines the log prints for its group (round 36), and the last run.
    - *Standard*: the standard reference (its links live), and the entries of the lens Music for the row.
  - **The chips** are the Atlas's: computed plain, standard grey-blue (MUS-003, LAB-016b: standard, recomputed), an input grey and dashed (INP-124 … INP-130), our reading amber and dashed (MUS-013), open violet and dotted.
- **Dictionary**: the lens Music, its 34 entries as a table (Atlas term · music term · grade · evidence · rows), the grades' legend with their counts (exact 16, exact with an input 1, partial 7, analogy 2, none 8), and the 124 readings of the Atlas's rows through the lens, grouped by the page where each row is at home.
- **Checks**: `music_sound.py` and `music_symmetry.py`, what each computes, its method, second route and controls; its 14 groups with every line of the logs (89 ok lines); the last lines; the twelve controls with their FAIL counts; the run records; the logs as text and as files (`checks/`); and the Atlas's other checks of the rows the pages tell.
- **Pictures**: the thirteen figures with their captions, their data files and their rows.
- **Sounds**: the twelve clips with what is heard and what they are built from, and six instruments (below).
- **Sources**: the study's references with their links, and every source of `SOURCES.md` with the link its literature reader fetched and what came back.
- **About**: the method, the four registers, the chips, what the site reads, what is not here, the one Atlas link, the licence and the credits.

## The Sounds page

A synthesizer in one plain JavaScript file (`sounds.js`, no library), reading its numbers from `sounds-data.js` (the figure data of the checks, copied by the generator). Sine oscillators summed as partials, 20 ms raised-cosine fades, a master gain at −6 dBFS, the AudioContext made on the first click. Beneath each instrument the page says where its numbers come from.

1. **The clock**: twelve toggles on a dial, 12-TET or just (the 5-limit ratios of `cents_table.json` for the seven diatonic degrees), chord or arpeggio; the cardinality, the interval vector, |f̂(k)| computed in the page, and the exact |f̂(k)|² = a + b√3 of `dft.json` for its twelve named sets, which are the presets.
2. **The Tonnetz walk**: the 24 triads at their centroids (`plr_dual.json`), with the P, L and R edges; click to hear a triad, P, L, R to move; the hexatonic and octatonic cycles, the LR cycle and Beethoven's nineteen chords as presets; the word and, in just intonation with the common tones held, the drift in cents — the hexatonic cycle comes back 128/125 sharp, and the first chord sounds again after it.
3. **Euclidean rhythms**: k and n up to 16, the necklace, Bjorklund's algorithm in the page, the clips' click sounds; the page says when its string matches E(k, n) of ms·EVEN (`even.json`); presets tresillo, cinquillo, the bossa-nova necklace, the bell E(7, 12), E(9, 16).
4. **The chain and the ring**: the modes of the chain of N = 1 … 8 masses (exact ω² from `chain_modes.json` for N ≤ 5), the twelve modes of the ring C₁₂, and the partials of the string, the stiff string, the free bar and the membrane (`partials.json`).
5. **The dissonance glissando**: clip 5's recipe, with the curve of `dissonance_curve.json` drawn and a marker on it; harmonic or bar partials.
6. **The commas**: the just and tempered fifths, the Pythagorean comma as two beating tones, and the major chord just and tempered, with the beat shown.

**The synthesizer's test** (`gen/test_sounds.mjs`, in the source): Chromium renders the page's engine into an OfflineAudioContext and measures the sound by FFT, as the Atlas's group mu·AUDIO measures its clips: 20 assertions, 20 pass — the major chord's 18 partials in 12-TET and in just intonation, the onsets of E(7, 12), E(3, 8) and E(5, 16) (each within 1 % of a pulse), the chain's five modes at 220.00, 425.01, 601.05, 736.13, 821.05 Hz, the ring's modes, the comma's beat at 3.0015 Hz, the hexatonic drift of 128/125, the glissando at the dissonance curve's minima, Bjorklund against even.json and against {⌊in/k⌋} for all 136 pairs, |f̂(k)| against dft.json.

## The method

- **Traced blocks.** Each block of text carries `data-b` (a record of the Atlas, a row of an inventory, sentences of the study) or `data-s` (a string of the site's table); the generator's trace says where each `data-b` comes from, and the checker resolves it again, compares the text, and compares what the page shows. Outside the traced elements no page holds a run of three words.
- **The study as a source.** The study is read into its units (paragraphs, list items, captions, displays) and their sentences; a Story block is a declared list of units or sentence ranges, recomputed by the checker. Its formulas are set at build time with KaTeX from the TeX the study carries; each display names its source through `\htmlData`.
- **From the disk.** The site opens from `file://`: nothing is fetched, the Sounds page's numbers are a script, the clips are `<audio>` elements, KaTeX's stylesheet and fonts ship with the site.

## The counts (`content/version.json`)

| | |
|---|---|
| pages | 15 (8 sections) |
| row blocks | 27 in 8 chains, each in 4 registers |
| traced blocks | about 1,700, every one verified; 0 errors |
| figures | 13, with their captions and data |
| clips | 12 |
| lens entries | 34; readings 124 |
| log lines | 89 ok lines of the two logs, 12 controls |
| formulas | 19 set with KaTeX (10 displays with `\htmlData`) |

## What is not here

- **The learner texts** of the music rows and of the nine leads: the storyteller has not written them. The Story register tells those rows in the study's own words and says so.
- The study's tables (Table 0, 4.1, 5.1, 5.2), its appendix, and its opinion in the first person (§8, "My opinion, plainly"): they stay in the study.
- A site-wide search.

## The one link to the Atlas

The site is standalone. Its only link into the Atlas is on About (`about.html`, `data-atlas-link`): "The Atlas — one rule: the page Music", to `https://toy-model-v0.vercel.app/#/music`. To move it, change `ATLAS_URL` in `gen/build.mjs` and the address the checker accepts (one line in `gen/check.mjs`), and rebuild.

## How to host

Unzip and serve the folder with any static server, or open `index.html` from the disk. `.ogg` as `audio/ogg`, `.py` and `.log` as `text/plain`. The two text fonts (IBM Plex Sans, Newsreader) come from Google Fonts; without the network the system fonts are used.

## Licence and credits

- The Cascade Atlas, its tables, figures, scripts and clips, and this site with its generator, are under the PolyForm Noncommercial License 1.0.0. Required Notice: Copyright (c) 2026 the Cascade Atlas authors.
- The study *Music on the labels* cites its sources by name; the Sources page lists them with their links.
- KaTeX (MIT licence) sets the formulas at build time; its stylesheet and fonts ship with the site. IBM Plex Sans and Newsreader are under the SIL Open Font License.
