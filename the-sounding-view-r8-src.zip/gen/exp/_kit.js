// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// _kit.js — the shared kit of the experiments of The Sounding View (release 4). Plain script, no modules.
// Every experiment module registers itself as SDV_EXP[slug] = { mount(root, data, S, kit) } and draws with this kit:
// canvases that follow the device pixel ratio and the panel's width, sliders and switches whose labels come from the
// string table through S(id), one AudioContext started on the first click, tones with 20 ms fades, the diverging colour
// map (blue − · white 0 · red +), arrows, the status chips and the grade marks as the site draws them.
(function () {
  'use strict';
  var SDV_EXP = (window.SDV_EXP = window.SDV_EXP || {});
  var kit = {};

  // ------------------------------------------------------------ numbers and colour
  kit.clamp = function (x, a, b) { return x < a ? a : x > b ? b : x; };
  kit.num = function (x, d) { return Number(x).toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d }); };
  kit.sci = function (x, d) { return Number(x).toExponential(d == null ? 2 : d).replace('e', ' × 10^').replace('+', ''); };
  // diverging map: v in [-1, 1] → css colour; blue for −, white at 0, red for +
  kit.cmap = function (v) {
    v = kit.clamp(v, -1, 1);
    var t = Math.abs(v), r, g, b;
    if (v >= 0) { r = 255; g = Math.round(255 - 158 * t); b = Math.round(255 - 175 * t); }
    else { r = Math.round(255 - 170 * t); g = Math.round(255 - 120 * t); b = Math.round(255 - 40 * t); }
    return 'rgb(' + r + ',' + g + ',' + b + ')';
  };
  kit.ink = function () { return getComputedStyle(document.documentElement).getPropertyValue('--ink').trim() || '#1d221f'; };
  kit.accent = function () { return getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#0e7368'; };
  kit.muted = function () { return getComputedStyle(document.documentElement).getPropertyValue('--muted').trim() || '#6b7470'; };
  kit.panel = function () { return getComputedStyle(document.documentElement).getPropertyValue('--panel').trim() || '#ffffff'; };
  kit.warm = function () { return getComputedStyle(document.documentElement).getPropertyValue('--warm').trim() || '#b4552b'; };
  kit.blue = '#2b5f9e'; kit.red = '#c24a3a'; kit.violet = '#6b4fa0';

  // ------------------------------------------------------------ DOM
  function el(tag, attrs, children) {
    var e = document.createElement(tag);
    if (attrs) for (var k in attrs) { if (k === 'class') e.className = attrs[k]; else if (k === 'text') e.textContent = attrs[k]; else if (k === 'html') e.innerHTML = attrs[k]; else e.setAttribute(k, attrs[k]); }
    if (children) children.forEach(function (c) { if (c) e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return e;
  }
  kit.el = el;
  // a panel with a heading (the heading is a traced string: pass the string id so the build can verify it)
  kit.panel_ = function (root, sid, S, cls) { var p = el('div', { class: 'exp-panel ' + (cls || '') }); if (sid) p.appendChild(el('h3', { 'data-s': sid, text: S(sid) })); root.appendChild(p); return p; };
  kit.line = function (parent, sid, S, cls) { var p = el('p', { class: 'exp-line ' + (cls || ''), 'data-s': sid, text: S(sid) }); parent.appendChild(p); return p; };
  // a read-out line whose text the experiment composes from numbers: not traced, class exp-read
  kit.readout = function (parent) { var p = el('p', { class: 'exp-read' }); parent.appendChild(p); return p; };

  // a canvas that fills its parent's width at a given aspect ratio and follows devicePixelRatio
  kit.canvas = function (parent, aspect, maxH) {
    var c = el('canvas', { class: 'exp-canvas' }); parent.appendChild(c);
    // the parent is often a grid cell: let it shrink below the canvas's pixel width (min-width: auto would not), and never let
    // the canvas spill over its neighbours while a re-size is pending
    parent.style.minWidth = '0'; c.style.maxWidth = '100%';
    var ctx = c.getContext('2d'), w = 0, h = 0;
    function size() {
      var W = Math.max(200, parent.clientWidth), H = Math.round(W * (aspect || 0.5));
      if (maxH && H > maxH) H = maxH;
      var r = window.devicePixelRatio || 1;
      if (W !== w || H !== h) { w = W; h = H; c.width = Math.round(W * r); c.height = Math.round(H * r); c.style.width = W + 'px'; c.style.height = H + 'px'; ctx.setTransform(r, 0, 0, r, 0, 0); return { w: w, h: h, changed: true }; }
      return { w: w, h: h, changed: false };
    }
    size();
    window.addEventListener('resize', size);
    // the cell's width changes when siblings are added or the grid re-flows, not only when the window resizes: follow it,
    // and tell the modules (which redraw on the window's resize event) when the canvas's size moved
    if (typeof ResizeObserver !== 'undefined') {
      var pending = false;
      new ResizeObserver(function () {
        if (pending) return; pending = true;
        requestAnimationFrame(function () { pending = false; if (size().changed) window.dispatchEvent(new Event('resize')); });
      }).observe(parent);
    }
    return { el: c, ctx: ctx, size: size, get w() { return w; }, get h() { return h; } };
  };

  // controls: label from S(id) (traced), value printed live
  kit.slider = function (parent, o) {
    // o: { id (string id of the label), min, max, step, value, fmt(v) → string, log: bool, onchange(v) }
    var wrap = el('label', { class: 'exp-slider' });
    var lab = el('span', { class: 'exp-lab', 'data-s': o.id, text: o.S(o.id) });
    var input = el('input', { type: 'range', min: o.log ? 0 : o.min, max: o.log ? 1000 : o.max, step: o.log ? 1 : o.step, value: o.log ? toLog(o.value) : o.value });
    var val = el('span', { class: 'exp-val' });
    function toLog(v) { return Math.round(1000 * (Math.log(v) - Math.log(o.min)) / (Math.log(o.max) - Math.log(o.min))); }
    function fromLog(p) { return Math.exp(Math.log(o.min) + (p / 1000) * (Math.log(o.max) - Math.log(o.min))); }
    function get() { return o.log ? fromLog(+input.value) : +input.value; }
    function show() { val.textContent = o.fmt ? o.fmt(get()) : kit.num(get(), 2); }
    input.addEventListener('input', function () { show(); if (o.onchange) o.onchange(get()); });
    wrap.appendChild(lab); wrap.appendChild(input); wrap.appendChild(val); parent.appendChild(wrap); show();
    return { get: get, set: function (v) { input.value = o.log ? toLog(v) : v; show(); }, el: wrap };
  };
  kit.seg = function (parent, o) {
    // o: { ids: [string ids], values: [values], value, S, onchange(v) } — a segmented switch
    var wrap = el('div', { class: 'seg exp-seg', role: 'radiogroup' }), cur = o.value;
    var btns = o.ids.map(function (sid, i) {
      var b = el('button', { type: 'button', role: 'radio', 'data-s': sid, text: o.S(sid), 'aria-checked': String(o.values[i] === cur) });
      b.addEventListener('click', function () { cur = o.values[i]; btns.forEach(function (x, j) { x.setAttribute('aria-checked', String(j === i)); }); if (o.onchange) o.onchange(cur); });
      wrap.appendChild(b); return b;
    });
    parent.appendChild(wrap);
    return { get: function () { return cur; }, el: wrap };
  };
  kit.button = function (parent, sid, S, onclick, cls) { var b = el('button', { type: 'button', class: 'btn exp-btn ' + (cls || ''), 'data-s': sid, text: S(sid) }); b.addEventListener('click', onclick); parent.appendChild(b); return b; };
  kit.check = function (parent, sid, S, value, onchange) {
    var wrap = el('label', { class: 'exp-check' }), input = el('input', { type: 'checkbox' }); input.checked = !!value;
    input.addEventListener('change', function () { onchange(input.checked); });
    wrap.appendChild(input); wrap.appendChild(el('span', { 'data-s': sid, text: S(sid) })); parent.appendChild(wrap);
    return { get: function () { return input.checked; }, el: wrap };
  };
  kit.controls = function (parent) { var d = el('div', { class: 'exp-controls' }); parent.appendChild(d); return d; };

  // ------------------------------------------------------------ marks
  // a status chip as the site draws it: computed · standard-recomputed · input · ours · open
  kit.chip = function (status, text) { return el('span', { class: 'chip chip--sm chip--' + status, text: text || status.replace('-', ', ') }); };
  // a grade mark of the lens: exact · partial · analogy · none (the word is a traced string: pass its id)
  kit.grade = function (parent, grade, sid, S) {
    var m = el('span', { class: 'exp-grade exp-grade--' + grade });
    var dot = el('span', { class: 'exp-grade-dot', 'aria-hidden': 'true' });
    m.appendChild(dot); m.appendChild(el('span', { 'data-s': sid, text: S(sid) }));
    parent.appendChild(m); return m;
  };

  // ------------------------------------------------------------ drawing helpers
  kit.arrow = function (ctx, x0, y0, x1, y1, color, width) {
    var dx = x1 - x0, dy = y1 - y0, L = Math.hypot(dx, dy); if (L < 0.5) return;
    var ux = dx / L, uy = dy / L, hl = Math.min(6, L * 0.5), hw = hl * 0.55;
    ctx.strokeStyle = color; ctx.fillStyle = color; ctx.lineWidth = width || 1.2;
    ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1 - ux * hl, y1 - uy * hl); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x1 - ux * hl - uy * hw, y1 - uy * hl + ux * hw); ctx.lineTo(x1 - ux * hl + uy * hw, y1 - uy * hl - ux * hw); ctx.closePath(); ctx.fill();
  };
  kit.disc = function (ctx, x, y, r, sense, color) { // an oriented disc (a bivector): a circle with a curved arrow, sense +1 anticlockwise
    ctx.strokeStyle = color; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.stroke();
    ctx.fillStyle = color; ctx.globalAlpha = 0.15; ctx.fill(); ctx.globalAlpha = 1;
    var a0 = -0.6, a1 = sense > 0 ? -2.4 : 1.2;
    ctx.beginPath(); ctx.arc(x, y, r * 0.65, a0, a1, sense > 0); ctx.stroke();
    var ax = x + r * 0.65 * Math.cos(a1), ay = y + r * 0.65 * Math.sin(a1), tx = -Math.sin(a1) * (sense > 0 ? -1 : 1), ty = Math.cos(a1) * (sense > 0 ? -1 : 1);
    kit.arrow(ctx, ax - tx * 0.01, ay - ty * 0.01, ax + tx * 3, ay + ty * 3, color, 1.2);
  };
  kit.axes = function (ctx, box, o) {
    // box {l, t, r, b}; o {xmin,xmax,ymin,ymax,xlog,ylog,xlabel,ylabel,xticks,yticks}; returns x(v), y(v)
    var X = function (v) { var t = o.xlog ? (Math.log(v) - Math.log(o.xmin)) / (Math.log(o.xmax) - Math.log(o.xmin)) : (v - o.xmin) / (o.xmax - o.xmin); return box.l + t * (box.r - box.l); };
    var Y = function (v) { var t = o.ylog ? (Math.log(v) - Math.log(o.ymin)) / (Math.log(o.ymax) - Math.log(o.ymin)) : (v - o.ymin) / (o.ymax - o.ymin); return box.b - t * (box.b - box.t); };
    ctx.strokeStyle = kit.muted(); ctx.lineWidth = 1; ctx.strokeRect(box.l, box.t, box.r - box.l, box.b - box.t);
    ctx.fillStyle = kit.muted(); ctx.font = '11px system-ui, sans-serif'; ctx.textAlign = 'center';
    (o.xticks || []).forEach(function (v) { var x = X(v); ctx.beginPath(); ctx.moveTo(x, box.b); ctx.lineTo(x, box.b + 4); ctx.stroke(); ctx.fillText(typeof v === 'number' ? String(v) : v, x, box.b + 15); });
    ctx.textAlign = 'right';
    (o.yticks || []).forEach(function (v) { var y = Y(v); ctx.beginPath(); ctx.moveTo(box.l - 4, y); ctx.lineTo(box.l, y); ctx.stroke(); ctx.fillText(String(v), box.l - 6, y + 4); });
    if (o.xlabel) { ctx.textAlign = 'center'; ctx.fillText(o.xlabel, (box.l + box.r) / 2, box.b + 28); }
    if (o.ylabel) { ctx.save(); ctx.translate(Math.max(10, box.l - 30), (box.t + box.b) / 2); ctx.rotate(-Math.PI / 2); ctx.textAlign = 'center'; ctx.fillText(o.ylabel, 0, 0); ctx.restore(); }
    return { x: X, y: Y };
  };
  kit.curve = function (ctx, pts, X, Y, color, width, dash) {
    ctx.strokeStyle = color; ctx.lineWidth = width || 1.5; ctx.setLineDash(dash || []);
    ctx.beginPath(); var on = false;
    pts.forEach(function (p) { var x = X(p[0]), y = Y(p[1]); if (!isFinite(x) || !isFinite(y)) { on = false; return; } if (!on) { ctx.moveTo(x, y); on = true; } else ctx.lineTo(x, y); });
    ctx.stroke(); ctx.setLineDash([]);
  };
  kit.interp = function (pts, x) { // linear interpolation on [x, y] pairs sorted by x; null outside
    if (!pts.length || x < pts[0][0] || x > pts[pts.length - 1][0]) return null;
    var lo = 0, hi = pts.length - 1; while (hi - lo > 1) { var m = (lo + hi) >> 1; if (pts[m][0] <= x) lo = m; else hi = m; }
    var a = pts[lo], b = pts[hi]; if (b[0] === a[0]) return a[1]; return a[1] + (b[1] - a[1]) * (x - a[0]) / (b[0] - a[0]);
  };

  // ------------------------------------------------------------ time
  kit.loop = function (fn) { // requestAnimationFrame loop with the page's visibility; fn(t seconds, dt)
    var last = null, run = true, id = null;
    function frame(ts) { if (!run) return; var t = ts / 1000, dt = last == null ? 0 : Math.min(0.1, t - last); last = t; try { fn(t, dt); } catch (e) { run = false; throw e; } id = requestAnimationFrame(frame); }
    id = requestAnimationFrame(frame);
    document.addEventListener('visibilitychange', function () { if (document.hidden) { run = false; if (id) cancelAnimationFrame(id); } else if (!run) { run = true; last = null; id = requestAnimationFrame(frame); } });
    return { stop: function () { run = false; if (id) cancelAnimationFrame(id); }, start: function () { if (!run) { run = true; last = null; id = requestAnimationFrame(frame); } } };
  };

  // ------------------------------------------------------------ audio (one context for the page, started on a click)
  var AC = null, master = null;
  kit.audio = function () {
    if (!AC) { var Ctx = window.AudioContext || window.webkitAudioContext; if (!Ctx) return null; AC = new Ctx(); master = AC.createGain(); master.gain.value = 0.5; master.connect(AC.destination); }
    if (AC.state === 'suspended') { try { AC.resume(); } catch (e) { } }
    return { ctx: AC, master: master };
  };
  kit.ready = function () { return !!AC && AC.state === 'running'; };
  // a tone: { f, gain (≤ 0.3), type, decay (time constant in s; 0 = held), dur (s, for held tones), at (delay s) } → { stop() }
  kit.tone = function (o) {
    var a = kit.audio(); if (!a) return { stop: function () { } };
    var t0 = a.ctx.currentTime + (o.at || 0.01), osc = a.ctx.createOscillator(), g = a.ctx.createGain();
    osc.type = o.type || 'sine'; osc.frequency.value = o.f;
    g.gain.setValueAtTime(0, t0); g.gain.linearRampToValueAtTime(o.gain == null ? 0.2 : o.gain, t0 + 0.02);
    var dur;
    if (o.decay) { g.gain.setTargetAtTime(0, t0 + 0.02, o.decay); dur = Math.min(o.maxDur || 6, 8 * o.decay + 0.02); }
    else { dur = o.dur || 2; g.gain.setValueAtTime(o.gain == null ? 0.2 : o.gain, t0 + dur - 0.02); g.gain.linearRampToValueAtTime(0, t0 + dur); }
    osc.connect(g); g.connect(a.master); osc.start(t0); osc.stop(t0 + dur + 0.05);
    return { osc: osc, gain: g, stop: function () { try { var t = a.ctx.currentTime; g.gain.cancelScheduledValues(t); g.gain.setTargetAtTime(0, t, 0.01); osc.stop(t + 0.08); } catch (e) { } } };
  };
  // a held tone whose frequency and gain can be changed live: { set(f, gain), stop() }
  kit.voice = function (o) {
    var a = kit.audio(); if (!a) return { set: function () { }, stop: function () { } };
    var osc = a.ctx.createOscillator(), g = a.ctx.createGain(); osc.type = o.type || 'sine'; osc.frequency.value = o.f || 220; g.gain.value = 0;
    osc.connect(g); g.connect(a.master); osc.start();
    g.gain.setTargetAtTime(o.gain == null ? 0.15 : o.gain, a.ctx.currentTime, 0.02);
    return { set: function (f, gain) { var t = a.ctx.currentTime; if (f != null) osc.frequency.setTargetAtTime(f, t, 0.02); if (gain != null) g.gain.setTargetAtTime(gain, t, 0.02); },
             stop: function () { try { var t = a.ctx.currentTime; g.gain.setTargetAtTime(0, t, 0.02); osc.stop(t + 0.1); } catch (e) { } } };
  };
  // a sum of partials struck once: parts = [{f, a, decay}] → stops itself
  kit.strike = function (parts, gain) { var G = gain == null ? 0.12 : gain; return parts.map(function (p) { return kit.tone({ f: p.f, gain: G * (p.a == null ? 1 : p.a), decay: p.decay || 0.8, type: p.type }); }); };
  // a stereo pair in quadrature (for the spin experiments): { set(f, phase), stop() }
  kit.pair = function (f) {
    var a = kit.audio(); if (!a) return { set: function () { }, stop: function () { } };
    var merger = a.ctx.createChannelMerger(2), oL = a.ctx.createOscillator(), oR = a.ctx.createOscillator(), gL = a.ctx.createGain(), gR = a.ctx.createGain();
    oL.frequency.value = f; oR.frequency.value = f; gL.gain.value = 0.12; gR.gain.value = 0.12;
    oL.connect(gL); oR.connect(gR); gL.connect(merger, 0, 0); gR.connect(merger, 0, 1); merger.connect(a.master);
    var t0 = a.ctx.currentTime + 0.02; oL.start(t0); oR.start(t0);
    return { set: function (ff) { oL.frequency.setTargetAtTime(ff, a.ctx.currentTime, 0.02); oR.frequency.setTargetAtTime(ff, a.ctx.currentTime, 0.02); }, stop: function () { var t = a.ctx.currentTime; gL.gain.setTargetAtTime(0, t, 0.02); gR.gain.setTargetAtTime(0, t, 0.02); oL.stop(t + 0.1); oR.stop(t + 0.1); } };
  };
  // a click (for slow gyrations): a short burst
  kit.click = function (f, amp) { var a = kit.audio(); if (!a) return; var t = a.ctx.currentTime, o = a.ctx.createOscillator(), g = a.ctx.createGain(); o.frequency.value = f || 800; g.gain.setValueAtTime(amp || 0.15, t); g.gain.exponentialRampToValueAtTime(0.0005, t + 0.03); o.connect(g); g.connect(a.master); o.start(t); o.stop(t + 0.04); };

  kit.mountAll = function (S) {
    // called by the page: mounts every <section class="exp" data-exp> whose module and data are present
    var secs = document.querySelectorAll('section.exp[data-exp]');
    Array.prototype.forEach.call(secs, function (sec) {
      var slug = sec.getAttribute('data-exp'), mod = SDV_EXP[slug], dataEl = document.getElementById('exp-data-' + slug), stage = sec.querySelector('.exp-stage');
      if (!mod || !stage) return;
      var data = dataEl ? JSON.parse(dataEl.textContent) : {};
      try { mod.mount(stage, data, S, kit); sec.setAttribute('data-mounted', '1'); } catch (e) { sec.setAttribute('data-mounted', 'error'); console.error('experiment ' + slug + ': ' + (e && e.message)); }
    });
  };
  SDV_EXP._kit = kit;
})();
