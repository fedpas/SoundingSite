# REVIEW_IT — the reviewer's pass over the Italian side (release 2)

The two merged tables, `gen/content/it/racconto.json` (122 narrations) and `gen/content/it/strings_it.json` (405 strings), read as the Italian owner will read them, against the records they stand on, and edited in place. Nothing outside `gen/content/it/` and this file was touched.

## Summary

**What was read.** `it/VOICE_IT.md` whole; `it/draft/NOTE_IT-1.md` and `NOTE_IT-2.md` (the two narrators' terminology and their doubts); `gen/content/it/MANIFEST.json` (every target's `tells`, `length`, `where`); `gen/lib/italian.mjs` (`bannedHits`, reimplemented in a check of my own and run before and after the edits). Every one of the 122 narrations and the 405 strings, each beside the English string whose job it does. The records: for release 1, `repo/content/rows.json` and `texts.json` (the claims, kinds, standard references, evidence and research texts of the 27 row blocks and the nine leads MUS-701, MUS-741 … MUS-748), `lenses.json` (the lens Music, 34 entries, grades counted), the study `docs/round36/music_on_the_labels.html` split into its units (the abstract, §2.2, §3.0 … §3.9, §4, §5.1 … §5.5, §6, §7, §8, §9), `checks/selfcheck/round36/audio/INDEX.md`, the English `out/checks.html` and `out/pictures.html`, `gen/assets/RELEASE_NOTES.md` for the synthesizer's figures; for release 2, the English `out/bridges.html` stripped to text (the head, the table of the eleven bridges, the eight items' records, every proposed row's claim, research text, controls, standard reference and bridge grades, the paper's dictionary with its counts and sixteen rows), the drill `the_bridges_drilled.html` split into units (the byline, the abstract, "In one line each", §9, §10, part 2's opening, §16), the pack's `audio/INDEX.md` (clips 13 … 21), the checks page's counts per script (53 + 52 + 24 + 16 + 30 + 28 + 29 + 17 + 62 = 311) and control names. The Italian pages as rendered: `out/it/index`, `tone` (whole, with every register of its rows), `bridges` (head, table, item 1), `sounds` (head, the nine instruments' controls, the clips), `dictionary`, `checks`, `pictures`, `sources`, `about`.

**Fidelity.** Every number, name, grade, status and claim I could trace was found in the record its narration tells, printed as the record prints it (decimal point, the record's digits). The statuses named in the narrations match the chips of all 63 row blocks (three proposed rows standard, recomputed; MUS-049 ours; the rest computed; the seven INP rows inputs; LAB-016b and MUS-003 standard, recomputed). The grade counts of the Dictionary narration (16 exact, 1 exact with an input, 7 partial, 2 analogy, 8 none) are the lens's. The item narrations' check counts, the clips' measured values, the instruments' numbers (which follow the Sounds page's own "where the numbers come from" lines) and the figure captions all check. Where a narration goes beyond a row's text (INP-127's 250 listeners and the years of playing, MUS-005's "23, non 19", MUS-010's meantone temperaments, MUS-009's ethnomusicological names as inputs, SPR-M16's property the spring step "computes but does not state", MUS-012's cheap check, MUS-043's "the brief expected the opposite"), the claim is in the study section the narration also tells. Analogies stay analogies, readings stay ours, proposed rows say so: no fidelity fault was found in the narrations. One string was wrong on the page it stands on (`about.notthere.p`: on the Italian pages Racconto is the narration, not the studies' words) and one narration placed the drill's opinion as closing the study (`bridges:opinion`); both fixed.

**Edits: 24 in all** — 12 of Italian (grammar, a calque, an ambiguous pronoun, a word that means timbre on a music site, a capital after a semicolon, the article before *Tsimane'*), 8 of consistency between the two narrators' halves (*commi* for the plural of *comma*, *i convergenti* masculine, *le schede* for the records in place of IT-2's *gli atti*, one wording for one English sentence, *sede* for a row's home), 2 of fidelity (above), 2 in place (the home's list of pages left out the Bridges page whose card sits under it; the About page's narration repeated the strings `method.1` and `method.3` nearly verbatim right above them). Every edited narration stays inside its range by whitespace tokens (counts given below); every placeholder in braces is kept; no banned word was introduced (my check and the site's checker both at 0).

**Judged good and left alone.** The terminology is one across the two halves: *il nucleo*, *verifica*, *controllo*, *guasto*, *il proprietario*, *capitolo* (IT-2's word for item, never used by IT-1), *scheda*, *registrazione* (run record), *collana / braccialetto*, *per toni interi*, *dato in ingresso*, *nostra lettura*, the grade words, *il grado di partenza / il grado proposto*, *il pacchetto*, *lo studio dei ponti*, *collegamento*, *clip* masculine, decimal points everywhere, «» as the only quotation marks (IT-1 uses none), straight apostrophes throughout, the notation as the records print it. The voice is one: first person singular, *voi*, present, unhurried; the past tenses of `page:bridges` ("aveva dato", "aveva chiesto") tell a sequence and were left. *The Shifted View* in MUS-019 stays the proper name of the sister site (the record says so); IT-1's *la vista spostata di Atiyah e Moore* is the paper's title and a different thing. The anglicisms left are the technical ones the contract and the notes allow (*clip, log, script, browser, abstract, gauge, chirp, boost, sandwich, forque, cluster, 5-limit*). Things I weighed and did not change: "Sezione che precede / che segue" (stiff but forced by the banned words, and clear); the chrome's "clip 7" beside the narrations' "clip 07" (the English chrome has the same split); `section:scales`'s long relative clause (it follows the lead's); the Dictionary narration's second paragraph, which overlaps `dict.readings.p` far down the page (not in place); the `blk.from.*` strings, not rendered on the Italian pages (one unified anyway, cheap); the English README quoted under "La parola del pacchetto su sé stesso" and the English "Nothing is merged …" under the bridges head, which are records and stay English.

**Not resolved.** Nothing blocking. Two notes for the builder: (1) the English chrome itself says "clip 7" where the clip labels say "Clip 07"; the Italian mirrors it and I left it. (2) The status value in the Atlas register prints the record's English word ("computed") under the Italian label "Stato" while the chip says "calcolato"; that is the site's rule (records stay English) and is consistent, but a reader may notice it.

**Build and check after the edits**: `node gen/build.mjs ../repo` — 16 pages and 16 in Italian, warnings 0; `node gen/check.mjs ../repo` — 0 errors, 0 warnings, 7659 traced blocks, 122 narrations. My own reimplementation of the checker's rules: 122 narrations, 405 strings, 0 errors, before and after.

## The edits (id or target, old → new, reason)

### 1. narration `page:home` — in-place

- old: Vi accompagno di pagina in pagina: otto sezioni, un dizionario, le verifiche, le figure, i suoni e le fonti.
- new: Vi accompagno di pagina in pagina: otto sezioni, i ponti sondati, un dizionario, le verifiche, le figure, i suoni e le fonti.
- why: the home's own card to the page The bridges drilled sits right under this narration, and the narrator's list of the pages left it out; 179 words, inside 120–180 (179 words after the edit)

### 2. narration `section:groups` — italian

- old: la dualità che Lewin ha nominato (MUS-006)
- new: la dualità che porta il nome di Lewin (MUS-006)
- why: 'nominare' reads as 'to mention' or 'to appoint' in Italian; the lens calls it Lewin duality (the lead: 'the duality Lewin named'); 158 words, inside 100–160 (157 words after the edit)

### 3. narration `row:INP-125` — italian

- old: i Tsimane', una società amazzonica
- new: gli Tsimane', una società amazzonica
- why: the article before the cluster ts- is lo/gli (as 'lo tsunami'), the Crusca's rule (121 words after the edit)

### 4. narration `row:INP-125` — italian

- old: riporta nei Tsimane' risposte
- new: riporta negli Tsimane' risposte
- why: same article rule (121 words after the edit)

### 5. narration `row:MUS-013` — italian

- old: i Tsimane' lo mostrano
- new: gli Tsimane' lo mostrano
- why: same article rule (136 words after the edit)

### 6. narration `page:sounds` — italian

- old: Un test in Chromium rende il motore della pagina fuori linea e lo misura per FFT
- new: Un test in Chromium esegue fuori linea il motore della pagina e lo misura per FFT
- why: 'rende il motore fuori linea' does not say what the test does (Chromium renders the engine into an OfflineAudioContext: it runs it offline); same length, 159 words (159 words after the edit)

### 7. narration `page:about` — in-place

- old: Ogni frase del sito viene da uno di quattro luoghi: una scheda dell'Atlante, un inventario, i file propri di uno studio o la tabella delle stringhe del sito, e il generatore verifica ciascuna contro la sua fonte. Gli enunciati con uno script vengono per primi, nulla è affermato oltre l'eseguito, i risultati negativi restano, i dati in ingresso restano dati in ingresso. Ogni riga si legge in quattro registri, Racconto, Ricerca, Atlas e Standard, e porta il bollino di stato dell'Atlante: calcolato, standard ricalcolato, dato in ingresso, nostra lettura, aperto.
- new: Ogni frase del sito ha una fonte, una scheda dell'Atlante, un inventario, i file propri di uno studio o la tabella delle stringhe, e il generatore la verifica contro quella fonte. Viene per primo ciò che uno script ha eseguito, e nulla si afferma oltre; i risultati negativi restano, un dato in ingresso resta tale. Ogni riga si legge in quattro registri, Racconto, Ricerca, Atlas e Standard, e porta il bollino di stato dell'Atlante: calcolato, standard ricalcolato, dato in ingresso, nostra lettura, aperto; una riga proposta porta anche il contorno che lo dice.
- why: as rendered, the narration stood directly above the strings method.1 and method.3 and repeated their first sentences almost verbatim (a note that repeats the lead); reworded in the narrator's voice, same facts (the proposed outline from chip.legend.proposed added); 139 words, inside 80–140 (139 words after the edit)

### 8. narration `bridges:table` — italian

- old: e l'ingresso della musica; La colonna finale nomina
- new: e l'ingresso della musica; la colonna finale nomina
- why: a capital after a semicolon (94 words after the edit)

### 9. narration `bridges:item:walk` — consistency

- old: quelli della scala che sono i comma, 23.460 cent
- new: quelli della scala che sono i commi, 23.460 cent
- why: the plural of comma (the musical comma) is commi, as IT-1 writes it (section:scales, MUS-010, the strings i6.h, home.play.p); IT-2 left it invariable (173 words after the edit)

### 10. narration `row:MUS-029` — italian

- old: Un sistema in moto attraverso l'aria la rompe: il mezzo ha un sistema di quiete.
- new: Un sistema in moto attraverso l'aria rompe l'equazione: il mezzo ha un sistema di quiete.
- why: 'la rompe' had no clear antecedent (the cell? the equation?); the record: a frame moving through the air breaks the first-order equation; 135 words (134 words after the edit)

### 11. narration `row:MUS-031` — italian

- old: L'anello a primi vicini manca i k di 60.0 fino a 762.0 cent.
- new: L'anello a primi vicini resta sotto ω_k = k da 60.0 a 762.0 cent.
- why: 'manca i k di' is not Italian for 'falls short of k by'; the record: the nearest-neighbour ring falls short of k by 60.0 to 762.0 cents; 137 words (136 words after the edit)

### 12. narration `row:MUS-034` — consistency

- old: Alle convergenti gli scarti sono i comma, alternati e decrescenti
- new: Ai convergenti gli scarti sono i commi, alternati e decrescenti
- why: 'convergente' is masculine in both halves (IT-1: i convergenti 7/12 …; IT-2 elsewhere: le convergenti only here), and the plural of comma is commi (133 words after the edit)

### 13. narration `pictures:round37` — consistency

- old: la spirale del cammino e i comma della scala
- new: la spirale del cammino e i commi della scala
- why: commi, as above (117 words after the edit)

### 14. narration `bridges:opinion` — fidelity

- old: Tre affermazioni oneste chiudono lo studio.
- new: L'opinione dello studio sta in tre affermazioni oneste.
- why: the three statements open the opinion, §9 ('Three honest statements, in the Atlas's words'); they do not close the study, whose part 2 follows; 136 words (136 words after the edit)

### 15. string `it.records` — consistency

- old: Gli atti restano nell'inglese dell'Atlante; il narratore racconta questa riga nel registro Racconto.
- new: Le schede restano nell'inglese dell'Atlante; questa riga la racconto io nel registro Racconto.
- why: the records are 'le schede' everywhere else (method.1, method.2, page:about, b.item.bridge); 'gli atti' was IT-2's word alone; and the first person, as reg.story.p ('la mia narrazione') and page:about ('le racconto io') speak

### 16. string `about.italian.p` — consistency

- old: gli atti dell'Atlante restano accanto in inglese
- new: le schede dell'Atlante restano accanto in inglese
- why: schede, as above

### 17. string `b.stamp.k` — italian

- old: Il timbro dello studio:
- new: L'intestazione dello studio:
- why: on a music site 'timbro' reads as timbre; the stamp is the study's byline line, its intestazione

### 18. string `i1.p` — italian

- old: sull'orologio delle dodici e suonatelo
- new: sull'orologio delle dodici classi e suonatelo
- why: 'l'orologio delle dodici' is the clock at twelve o'clock; the glossary's term is l'orologio delle dodici classi, as the narrations and aria.clock say

### 19. string `sec.chain.note` — consistency

- old: Il selettore di registro in alto decide che cosa mostra ogni riga.
- new: Il selettore di registro in alto sceglie che cosa mostra ogni riga.
- why: the same English sentence ('chooses what each row shows') is 'sceglie' in b.rows.note; one word for one sentence

### 20. string `method.4` — italian

- old: come file propri dello studio, lo studio stesso, i ROWS.md dei suoi capitoli, i suoi script, log, figure e clip, e segna proposta ogni riga di quel genere.
- new: come file propri dello studio (lo studio stesso, i ROWS.md dei suoi capitoli, i suoi script, log, figure e clip) e segna come proposta ogni riga che ne trae.
- why: the English's dashes became commas and the apposition read as a list of things the site reads; 'ogni riga di quel genere' is translationese for 'every such row'

### 21. string `about.notthere.p` — fidelity

- old: il registro Racconto dice quelle righe con le parole degli studi, e lo dichiara.
- new: nelle pagine inglesi il registro Racconto dice quelle righe con le parole degli studi, e lo dichiara; in queste le racconto io.
- why: on the Italian pages Racconto is the narration, not the studies' words (reg.story.p already says so); the sentence was false on the page it stands on

### 22. string `pics.r37.p` — italian

- old: Disegnate dagli script del pacchetto dai loro dati di figura;
- new: Disegnate dagli script del pacchetto dai dati delle figure;
- why: 'dai loro dati di figura' is a calque of 'from its figure data'; the site's phrase is 'i dati delle figure' (about.reads.p)

### 23. string `dict.paper.cand.p` — consistency

- old: che cosa calcolerebbe una verifica, dove vivrebbe e che cosa decide il proprietario
- new: che cosa calcolerebbe una verifica, dove avrebbe sede e che cosa decide il proprietario
- why: a row's home is 'la sede' in the chrome (atl.home.proposed: Sede proposta) and in page:acoustics; 'dove vivrebbe' calqued 'where it would live'

### 24. string `blk.from.research.p` — consistency

- old: Non c'è ancora un testo per il racconto: il testo di ricerca della riga
- new: Non c'è ancora un testo narrativo: il testo di ricerca della riga
- why: the same English opening ('No story text yet') is 'un testo narrativo' in blk.from.research (IT-1); one wording for one job (neither string is rendered on the Italian pages)
