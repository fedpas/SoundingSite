// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// rings — which rings can sound a string (MUS-031, MUS-039, MUS-040, MUS-041).
(function () {
  'use strict';
  window.SDV_EXP = window.SDV_EXP || {};
  var RM = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  function cents(r) { return 1200 * Math.log(r) / Math.LN2; }
  function rep(s, o) { for (var k in o) s = s.replace('{' + k + '}', o[k]); return s; }
  function cv(kit, parent, aspect, maxH) { var d = kit.el('div', { style: 'width:100%;min-width:0' }); parent.appendChild(d); return kit.canvas(d, aspect, maxH); }
  function txt(ctx, s, x, y, al, col, px) { ctx.fillStyle = col; ctx.font = (px || 11) + 'px system-ui, sans-serif'; ctx.textAlign = al || 'left'; ctx.fillText(s, x, y); }
  // one Play/Mute per panel (only one sounds at a time) and one Pause for the picture
  function transport(kit, S) {
    var st = { paused: RM }, cur = null, hasAudio = !!(window.AudioContext || window.webkitAudioContext), warned = false;
    st.pause = function (controls) {
      var p = kit.button(controls, 'exp.common.pause', S, function () { st.paused = !st.paused; show(); if (st.onpause) st.onpause(); });
      function show() { p.setAttribute('aria-pressed', String(st.paused)); p.style.background = st.paused ? 'var(--accent-tint)' : ''; }
      show(); return p;
    };
    st.player = function (controls, o) {
      var me = { on: false };
      var b = kit.button(controls, 'exp.common.play', S, function () {
        if (me.on) { me.stop(); return; }
        if (!hasAudio || !kit.audio()) { b.disabled = true; if (!warned) { warned = true; kit.line(controls.parentNode, 'exp.common.noaudio', S); } return; }
        if (cur && cur !== me) cur.stop();
        me.on = true; cur = me; label(); o.start();
      });
      function label() { var id = me.on ? 'exp.common.mute' : 'exp.common.play'; b.setAttribute('data-s', id); b.textContent = S(id); b.setAttribute('aria-pressed', String(me.on)); }
      me.stop = function () { if (!me.on) return; me.on = false; if (cur === me) cur = null; label(); o.stop(); };
      return me;
    };
    return st;
  }
  // the foot of every experiment: what you see, what you hear, the data line
  function foot(kit, S, root, slug) {
    var p = kit.panel_(root, 'exp.common.see', S, 'span');
    kit.line(p, 'exp.' + slug + '.see', S);
    p.appendChild(kit.el('h3', { 'data-s': 'exp.common.hear', text: S('exp.common.hear') }));
    kit.line(p, 'exp.' + slug + '.hear', S);
    p.appendChild(kit.el('p', { class: 'exp-source' }, [kit.el('b', { 'data-s': 'exp.common.data', text: S('exp.common.data') }), ' · ', kit.el('span', { 'data-s': 'exp.' + slug + '.data', text: S('exp.' + slug + '.data') })]));
  }

  // bars on a ruler of cents with the harmonic series behind them; items {c, h, sel}
  function rulerBars(kit, S, c, items, hmax, maxC0) {
    var ctx = c.ctx, w = c.w, h = c.h, l = 12, r = 10, t = 10, b = 26, maxC = 1, mut = kit.muted();
    ctx.clearRect(0, 0, w, h);
    items.forEach(function (it) { maxC = Math.max(maxC, it.c); }); maxC = Math.max(maxC * 1.06, maxC0 || 1300);
    var X = function (cc) { return l + cc / maxC * (w - l - r); };
    ctx.lineWidth = 1; ctx.strokeStyle = mut;
    for (var n = 1; n <= 24; n++) { var cc = cents(n); if (cc > maxC) break; ctx.globalAlpha = 0.5; ctx.setLineDash([3, 3]); ctx.beginPath(); ctx.moveTo(X(cc), t); ctx.lineTo(X(cc), h - b); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1; if (n < 10 || n % 2 === 0) txt(ctx, String(n), X(cc), h - b + 12, 'center', mut, 10); }
    ctx.beginPath(); ctx.moveTo(l, h - b); ctx.lineTo(w - r, h - b); ctx.stroke();
    items.forEach(function (it) { var bh = Math.max(2, it.h / hmax * (h - b - t)); ctx.fillStyle = it.col || (it.sel ? kit.accent() : kit.blue); ctx.fillRect(X(it.c) - 3.5, h - b - bh, 7, bh); });
    txt(ctx, S('exp.common.cents'), w - r, h - 4, 'right', mut, 10);
  }
  var TAU = Math.PI * 2;
  window.SDV_EXP.rings = { mount: function (root, data, S, kit) {
    root.classList.add('half');
    var accent = kit.accent(), ink = kit.ink(), mut = kit.muted(), noA = false, H = data.harmonic_ring, C = data.chain;
    function strike(parts) {
      if (!kit.audio()) { if (!noA) { noA = true; kit.line(root.lastChild, 'exp.common.noaudio', S); } return; }
      var tot = 0; parts.forEach(function (p) { tot += p.a; }); parts.forEach(function (p) { p.a /= tot; }); kit.strike(parts, 0.3);
    }
    function decays(arr) { return arr.map(function (p, i) { p.decay = 1.6 / (1 + 0.3 * i); return p; }); }
    // a ring of twelve with chords per distance d, coloured by sign; and the weights as bars
    function chords(c, ws) {
      var ctx = c.ctx, w = c.w, h = c.h, R = Math.min(w, h) * 0.38, cx = w / 2, cy = h / 2, mx = 0, d, i;
      ws.forEach(function (x) { mx = Math.max(mx, Math.abs(x)); }); ctx.clearRect(0, 0, w, h);
      for (d = 1; d <= ws.length; d++) {
        ctx.strokeStyle = ws[d - 1] >= 0 ? kit.blue : kit.red; ctx.lineWidth = 0.6 + 3 * Math.sqrt(Math.abs(ws[d - 1]) / mx); ctx.globalAlpha = 0.5; ctx.beginPath();
        for (i = 0; i < (d === 6 ? 6 : 12); i++) { var a = TAU * i / 12 - Math.PI / 2, b = TAU * (i + d) / 12 - Math.PI / 2; ctx.moveTo(cx + R * Math.cos(a), cy + R * Math.sin(a)); ctx.lineTo(cx + R * Math.cos(b), cy + R * Math.sin(b)); }
        ctx.stroke();
      }
      ctx.globalAlpha = 1; ctx.fillStyle = ink;
      for (i = 0; i < 12; i++) { var t = TAU * i / 12 - Math.PI / 2; ctx.beginPath(); ctx.arc(cx + R * Math.cos(t), cy + R * Math.sin(t), 5, 0, TAU); ctx.fill(); }
    }
    function wbars(c, ws) {
      var ctx = c.ctx, w = c.w, h = c.h, mx = 0, base = h - 22, top = 16, bw = Math.min(30, (w - 20) / ws.length * 0.6);
      ws.forEach(function (x) { mx = Math.max(mx, Math.abs(x)); }); ctx.clearRect(0, 0, w, h);
      var zero = ws.some(function (x) { return x < 0; }) ? (top + base) / 2 + 6 : base, sc = (zero === base ? base - top : (base - top) / 2 - 6) / mx;
      ctx.strokeStyle = mut; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(8, zero); ctx.lineTo(w - 8, zero); ctx.stroke();
      ws.forEach(function (x, i) {
        var X = 12 + (w - 24) * (i + 0.5) / ws.length; ctx.fillStyle = x >= 0 ? kit.blue : kit.red;
        ctx.fillRect(X - bw / 2, x >= 0 ? zero - x * sc : zero, bw, Math.max(1.5, Math.abs(x) * sc));
        txt(ctx, 'd = ' + (i + 1), X, h - 6, 'center', mut, 10); txt(ctx, kit.num(x, 2), X, x >= 0 ? zero - x * sc - 4 : zero - 4 + 0, 'center', ink, 10);
      });
    }
    function ringPanel(p) { return { ring: cv(kit, p, 0.62, 260), w: cv(kit, p, 0.34, 150), spec: cv(kit, p, 0.4, 190) }; }

    // ---- panel a
    var pa = kit.panel_(root, 'exp.rings.panel.a', S), A = ringPanel(pa), ctlA = kit.controls(pa), preset = 'harmonic';
    kit.seg(ctlA, { ids: ['exp.rings.a.harm', 'exp.rings.a.nn'], values: ['harmonic', 'nn'], value: 'harmonic', S: S, onchange: function (v) { preset = v; drawA(); } });
    kit.button(ctlA, 'exp.common.strike', S, function () {
      var c = data.clip15, f = preset === 'harmonic' ? c.harmonic_hz : c.nearest_neighbour_hz;
      strike(decays(f.map(function (x, i) { return { f: x, a: c.amps[i] }; })));
    });
    var rdA = kit.readout(pa), rdA2 = kit.readout(pa);
    kit.line(pa, 'exp.rings.line.nonneg', S);
    function drawA() {
      var ws = preset === 'harmonic' ? H.weights : [1, 0, 0, 0, 0, 0];
      chords(A.ring, ws); wbars(A.w, ws);
      var sp = preset === 'harmonic' ? H.cents_harmonic : H.cents_nearest_neighbour;
      rulerBars(kit, S, A.spec, sp.map(function (c, i) { return { c: c, h: 1 / (i + 1), sel: false }; }), 1, 3200);
      rdA.textContent = preset === 'harmonic' ? H.weights_exact.join(' · ') : '2 sin(πk/12) → ' + H.spectrum_nearest_neighbour.map(function (x) { return kit.num(x, 3); }).join(' : ');
      rdA2.textContent = sp.map(function (c) { return kit.num(c, 0); }).join(' · ') + ' ' + S('exp.common.cents');
    }

    // ---- panel b
    var pb = kit.panel_(root, 'exp.rings.panel.b', S), B = ringPanel(pb), ctlB = kit.controls(pb), st = data.sets;
    kit.button(ctlB, 'exp.common.strike', S, function () { strike(decays(st.clip20.measured_hz.map(function (f, i) { return { f: f, a: 1 / (i + 1) }; }))); });
    var rdB = kit.readout(pb), rdB2 = kit.readout(pb);
    kit.line(pb, 'exp.rings.line.positive', S);
    function drawB() {
      chords(B.ring, st.weights); wbars(B.w, st.weights);
      rulerBars(kit, S, B.spec, st.smallest.map(function (n, i) { return { c: cents(n), h: 1, sel: false }; }), 1, 4100);
      var pos = data.rings_N.filter(function (r) { return r.nonnegative; }).map(function (r) { return r.N; });
      var w0 = Object.keys(st.windows).filter(function (k) { return st.windows[k] > 0; })[0];
      rdB.textContent = '{' + st.smallest.join(', ') + '} · ' + st.weights_exact.join(' · ');
      rdB2.textContent = 'N = ' + pos.join(', ') + ': ≥ 0 · ' + w0 + ' → ' + st.windows[w0];
    }

    // ---- panel c
    var pc_ = kit.panel_(root, 'exp.rings.panel.c', S, 'span'), cC = cv(kit, pc_, 0.42, 240), cCs = cv(kit, pc_, 0.3, 170), ctlC = kit.controls(pc_), which = 'ff', uni = false;
    kit.seg(ctlC, { ids: ['exp.rings.c.ff', 'exp.rings.c.fr', 'exp.rings.c.A', 'exp.rings.c.B'], values: ['ff', 'fr', 'A', 'B'], value: 'ff', S: S, onchange: function (v) { which = v; uniChk.el.style.display = v === 'A' || v === 'B' ? 'none' : ''; drawC(); } });
    var uniChk = kit.check(ctlC, 'exp.rings.c.uniform', S, false, function (v) { uni = v; drawC(); });
    kit.button(ctlC, 'exp.common.strike', S, function () {
      var c19 = data.clip19, c21 = data.clip21, parts;
      if (which === 'A') parts = c21.ringA_hz.map(function (f, i) { return { f: f, a: Math.abs(c21.ringA_amps[i]) }; });
      else if (which === 'B') parts = c21.ringB_hz.map(function (f, i) { return { f: f, a: 1 / (i + 1) }; });
      else if (uni && which === 'fr') parts = c19.uniform_hz.map(function (f, i) { return { f: f, a: c19.uniform_amps[i] }; });
      else if (uni) parts = C.uniform_fixed_fixed_ratios.map(function (r, i) { return { f: 220 * r, a: 1 / (i + 1) }; });
      else parts = c19.harmonic_hz.map(function (f, i) { return { f: f, a: c19.harmonic_amps[i] }; });
      strike(decays(parts));
    });
    var rdC = kit.readout(pc_), rdC2 = kit.readout(pc_), lnC = kit.line(pc_, 'exp.rings.line.chain', S);
    function drawC() {
      var ctx = cC.ctx, w = cC.w, h = cC.h, i, items = [], ids = { ff: 'exp.rings.line.chain', fr: 'exp.rings.line.taper', A: 'exp.rings.line.ringA', B: 'exp.rings.line.ringB' };
      lnC.setAttribute('data-s', ids[which]); lnC.textContent = S(ids[which]); ctx.clearRect(0, 0, w, h);
      if (which === 'ff' || which === 'fr') {
        var D = which === 'ff' ? C.fixed_fixed : C.fixed_free, n = 12, ms = uni ? D.masses.map(function () { return 1; }) : D.masses, ks = uni ? D.springs.map(function () { return 1; }) : D.springs;
        var mM = Math.max.apply(null, ms), kM = Math.max.apply(null, ks), X = function (j) { return 18 + (w - 36) * j / (n + 1); }, y = h / 2;
        ctx.strokeStyle = ink; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(X(0), y - 16); ctx.lineTo(X(0), y + 16); if (which === 'ff') { ctx.moveTo(X(n + 1), y - 16); ctx.lineTo(X(n + 1), y + 16); } ctx.stroke();
        for (i = 0; i < ks.length; i++) { ctx.strokeStyle = mut; ctx.lineWidth = uni ? 2 : 0.8 + 4 * ks[i] / kM; ctx.beginPath(); ctx.moveTo(X(i), y); ctx.lineTo(X(i + 1), y); ctx.stroke(); }
        ctx.fillStyle = kit.blue; for (i = 0; i < n; i++) { ctx.beginPath(); ctx.arc(X(i + 1), y, uni ? 7 : 2.5 + 9 * Math.sqrt(ms[i] / mM), 0, TAU); ctx.fill(); }
        var hh = C.cents_harmonic, un = which === 'fr' ? C.cents_uniform_fixed_free : C.uniform_fixed_fixed_ratios.map(cents);
        items = (uni ? un : hh).map(function (c, j) { return { c: c, h: 1 / (j + 1), sel: false, col: uni ? kit.red : null }; });
        rdC.textContent = (which === 'ff' ? S('exp.rings.c.spread') + ' ' + kit.num(Math.max.apply(null, D.masses) / Math.min.apply(null, D.masses), 2) : S('exp.rings.c.taper') + ' 1 → ' + kit.num(D.masses[n - 1], 5)) + ' · ' + S('exp.rings.c.mrange') + ' ' + kit.num(Math.min.apply(null, ms), 5) + ' … ' + kit.num(mM, 1);
        rdC2.textContent = (uni ? un : hh).slice(0, 8).map(function (c) { return kit.num(c, 0); }).join(' · ') + ' ' + S('exp.common.cents');
      } else {
        var R = data.rings['ring_' + which], mR = Math.max.apply(null, R.masses), kR = Math.max.apply(null, R.springs), cx = w / 2, cy = h / 2, rr = Math.min(w, h) * 0.38, P = [];
        for (i = 0; i < 12; i++) { var a = TAU * i / 12 - Math.PI / 2; P.push([cx + rr * Math.cos(a), cy + rr * Math.sin(a)]); }
        for (i = 0; i < 12; i++) { ctx.strokeStyle = mut; ctx.lineWidth = 0.8 + 4 * R.springs[i] / kR; ctx.beginPath(); ctx.moveTo(P[i][0], P[i][1]); ctx.lineTo(P[(i + 1) % 12][0], P[(i + 1) % 12][1]); ctx.stroke(); }
        ctx.fillStyle = kit.blue; for (i = 0; i < 12; i++) { ctx.beginPath(); ctx.arc(P[i][0], P[i][1], 3 + 8 * Math.sqrt(R.masses[i] / mR), 0, TAU); ctx.fill(); }
        var sp = R.spectrum.slice(1).map(Math.sqrt), seen = [];
        sp.forEach(function (x) { var f = seen.filter(function (s) { return Math.abs(s.x - x) < 1e-6; })[0]; if (f) f.n++; else seen.push({ x: x, n: 1 }); });
        items = seen.map(function (s) { return { c: cents(s.x / sp[0]), h: s.n, sel: false }; });
        rdC.textContent = 'ω = ' + sp.map(function (x) { return kit.num(x, 3); }).join(', ');
        rdC2.textContent = seen.map(function (s) { return '×' + s.n; }).join(' ');
      }
      rulerBars(kit, S, cCs, items, Math.max.apply(null, items.map(function (x) { return x.h; })), 3400);
    }
    foot(kit, S, root, 'rings');
    window.addEventListener('resize', function () { drawA(); drawB(); drawC(); });
    drawA(); drawB(); drawC();
  } };
})();
