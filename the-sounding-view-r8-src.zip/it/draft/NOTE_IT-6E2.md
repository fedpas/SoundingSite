# NOTE IT-6 E2 — the strings of the experiments `layers` (68) and `spin` (60)

Written: `it/draft/r6_E2.json`, 128 strings, no narrations or titles. Checker: 0 errors, 0 warnings.
Changed strings (lead, see, hear, data of both experiments) start from `previousIt` and add only what the English added; new strings are written from the English and the spec's "Extended" section.

Terms: la lamina (the sheet); il taglio lontano (far cutoff); lo zero freddo (cold zero); il nodo (η_L = 2); la cavità migliore; lo spostamento (shift); i tripletti dilatati / più dolci (stretched, gentler); l'inviluppo freddo; la finestra O–X; l'onda O, l'onda X lenta, l'onda X rapida, la soglia dell'onda X rapida; la formula di Mjølhus; la confluenza; la fuga (leak); la catena fredda.
Spin: i luoghi speciali; il pilotaggio trifase (glossed once, in exp.spin.line.cube); la terna di funzioni (for "triplet" of functions, to keep "il tripletto" for the cutoff triplet); le particelle di fluido (parcels); il punto fermo; il galleggiante; la deriva di Stokes; il fondo termico (thermal floor); il limite pesante; il baricentro (centroid); la parte del mezzo (medium's share); Invia, Suona kept.

Doubts: (1) "once taken as a bound" (cap.rotor) is told as "che si potrebbe prendere per un limite" to avoid history wording. (2) rd.water: the English prints a Stokes drift {u} "at the still point, swirling around it" while line.water says it is zero there; told as the English has it. (3) release-5 Italian of exp.layers.cap.path still has the temporal "prima scende" (not my string, not touched).
