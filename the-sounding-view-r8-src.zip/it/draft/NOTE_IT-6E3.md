# NOTE_IT-6E3

Written: `it/draft/r6_E3.json` (narrator E3): nine narrations MUS-213, 220, 214, 215, 216, 217, 218, 221, 219 (86-100 words with the notation counted as words; 40-90 asked, the checker warns on none but one near the edge), the nine row titles, `chain:spin-probes`, `fig:fig_spin_probes`, `check:music_spin_probes`, and the re-reading of `section:spin`, `page:checks`, `page:pictures`, `page:about`. 0 errors.

Terms: "i volumetti" for the fluid parcels (the orbit), "elementi di volume" for a solid's rotating volume elements; "il pilotaggio trifase / come nella corrente trifase" said once in MUS-213; "il punto fermo"; "lo strato viscoso"; "il pavimento termico"; "la coppia"; "ponte di Barnett".

Rewritten (reword): section:spin (first part kept, second chain added in four sentences, the experiment named). Rewritten because the Italian contradicted the English counts: page:checks (ventisette -> trenta; sedici -> diciannove, four of them read from their own files), page:pictures (trenta -> trentatre, the three new figures named), page:about (the exception was one work, now four; says plainly where the rows come from, as the Method page may).

Doubts: (1) the O-X step is "il passo O-X" in page:checks, page:pictures and page:about; E1 may choose another word for "step" and the coordinator should align the three. (2) MUS-214 gives x* as 1.32385 and 0.37443 (the record's certified intervals rounded to five places). (3) MUS-218's absorber is told as "per l'argomento della riga", since the row reads it as an argument, not a computation. (4) MUS-214 says the medium's share is not computed and "not small", as the row's homePhys says.
