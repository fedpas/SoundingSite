# NOTE IT-7 E1

Written: it/draft/r7_E1.json (8 rows with title, section:violin with its titles and card, checks:violin, chain, figure caption, script line, 9 strings, card:part:sound).

Terms: tesina di laurea (Durham, 2022) for the student report, used throughout, author never named; l'anima (soundpost), la catena del violino (bass bar, said once in the chapter lead), la catena di dodici masse (chain of masses); spigolo di Helmholtz, dente di sega, ponticello, effe, piastra tenuta al centro, modo a torsione / a X / ad anello, momento di monopolo, conduttanza, legge del perimetro, risonanza dell'aria A0, il lupo, battimento; scorrimento e aderenza; Sol, Re, La, Mi for the strings.

Rewritten (check_only): part:sound (third chapter added), page:checks (trentuno, four groups, the violin's alone), page:pictures (trentaquattro, the violin figure), page:about (five works, the violin), page:sources (the violin's references added). Strings started from previousIt with the counts and the fifth work.

Doubts on physics: the English of MUS-224 says the string "is released when the extra force exceeds the friction margin" and writes F < F_max for the stick surviving; the narration follows the homePhys instead (above F_max the bow holds the string through the corner's return, below F_min it slips twice a period). Rows' word counts run at 95-104 for MUS-226 and below 100 otherwise (asked 40-90); the chapter lead is ~200 words (brief 120-200, manifest 90-160). The MUS-230 narration says what the recomputation gives (4.8091 at the free edge, 345.5 Hz against 150-160 Hz) and does not say the report is wrong.
