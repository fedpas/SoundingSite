# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# mk_r8.py — from gen/content/it/MANIFEST_R8.json, the four narrators' assignment (r8_assign.json) and material files:
#   r8_E1_material.json: the seven rows of the violin's second chain (MUS-231 … MUS-237, chapter violin), their chain heading, figure caption
#                        and script line, the chapter's narration to re-read, the strings of the violin's group;
#   r8_E2_material.json: the seven rows of the two chains of the dual bells (MUS-238 … MUS-244, chapter tone), their two chain headings,
#                        two figure captions, two script lines, the narration of the fifth group of the checks page, the titles of the three
#                        Atlas rows the experiments' legends show (SHP-001, SPR-003, SHP-004), the tone chapter's and Part I's narrations
#                        to re-read, the counts' pages to check, the strings of the dual bells' group and the counts;
#   r8_E3_material.json: the strings of the experiment violinbody;
#   r8_E4_material.json: the strings of the experiments duals and dualcells.
# Usage: python3 -I it/draft/mk_r8.py
import json, os, re
DRAFT = os.path.dirname(os.path.abspath(__file__)); SITE = os.path.dirname(os.path.dirname(DRAFT))
IT = os.path.join(SITE, 'gen', 'content', 'it')
def J(p): return json.load(open(p, encoding='utf-8'))
def W(p, o):
    with open(p, 'w', encoding='utf-8') as f: f.write(json.dumps(o, ensure_ascii=False, indent=1) + '\n')
M = J(os.path.join(IT, 'MANIFEST_R8.json'))
R = {i['target']: i for i in J(os.path.join(IT, 'racconto.json'))['items']}
T = {i['target']: i for i in J(os.path.join(IT, 'titoli.json'))['items']}
S = {i['id']: i for i in J(os.path.join(IT, 'strings_it.json'))['strings']}
C1 = J(os.path.join(DRAFT, 'r4_C1_material.json')); D2 = J(os.path.join(DRAFT, 'r4_D2_material.json'))
rules = M['rules']
PACKS = {'fig_violin_body': ('/home/claude/deliver_r37/violin_body/violin-body-pending/pack', 'music_violin_body'),
         'fig_duals': ('/home/claude/deliver_r37/duals/dual-bells-pending/pack', 'music_duals'),
         'fig_dual_cells': ('/home/claude/deliver_r37/duals/dual-cells-pending/pack', 'music_dual_cells')}
WHAT = {
 'music_violin_body': ("the violin in motion: the photograph of a plate scored against the computed nodal patterns (the third mode of the plate held at its centre wins), the post's moment converged with singular functions, "
                       "the bridge's admittance as an input (the feet move by micrometres), the bowed string simulated in time (Schelleng's diagram computed: the wedge has the formulas' slopes but is far narrower), "
                       "the wolf looked for on a resonant bridge (the string loses the Helmholtz motion, with no regular stutter), a flat violin-shaped plate with the wood's grain (it twists first), and a box of two hinged plates "
                       "with its air, a bass bar and a post (the rocking bridge moves no volume until the bar or the post breaks the mirror; A0 far below the rigid-walled value; the model's B1− and B1+)"),
 'music_duals': ("the dual bells: the octahedron and the cross-polytopes as spring networks (two levels where the cube has n + 1), their plucked vertex and its two partials (the weight of each partial is its multiplicity over the number of vertices), "
                 "the cross-polytope's interval closing towards a unison as n grows, the tetrahedron, the 24-cell, the icosahedron and the dodecahedron with their exact characteristic polynomials, "
                 "and the polyhedron as a 2-complex whose edge Laplacian carries the polyhedron's and its dual's spectra together"),
 'music_dual_cells': ("the duals one step further: the tesseract as a 4-complex with four Laplacians sharing their nonzero spectra in pairs and the 16-cell as its cells; the bells on groups (the ring, the n-cube, the cross-polytopes, the 24-cell, the 600-cell) "
                      "whose pluck weights are the group's Plancherel measure; the 120-cell as the 600-cell's cells, its 27 levels certified exactly beyond ℚ(√5); a column of octahedra as a faster string with a twisting band above it; "
                      "and the π-flux on triangular faces, which turns the spring network over (the frustrated octahedron sounds a tritone and an octave)"),
}
def caption_of(pack, fig):
    p = os.path.join(pack, 'figs', 'FIGURES_INDEX.md')
    if not os.path.exists(p): return None, None
    for line in open(p, encoding='utf-8'):
        if line.startswith('|') and fig in line:
            cells = [c.strip() for c in line.strip().strip('|').split(' | ')]
            if len(cells) >= 4: return cells[1], cells[3]
    return None, None
for t in M['titles']:
    m = re.match(r'^fig:(fig_\w+)$', t['target'])
    if m and m.group(1) in PACKS:
        cap, rows = caption_of(PACKS[m.group(1)][0], m.group(1))
        t['what'] = f"the Italian caption of the figure {m.group(1)}.svg (one to three sentences, as the other figures' captions in titoli.json: say what each panel shows, in the narrator's words, not a translation of the English caption)"
        t['length'] = '40–120 words'; t['where'] = 'the chapter page and pictures.html, under the figure'
        t['material'] = {'caption_en': cap, 'rows': rows, 'sample_it': T.get('fig:fig_violin', {}).get('text'), 'sample_it_2': T.get('fig:fig_spin_probes', {}).get('text')}
    m = re.match(r'^check:(music_\w+)$', t['target'])
    if m and m.group(1) in WHAT:
        t['material']['note'] = f"say what the script computes ({WHAT[m.group(1)]}); do not say that the rows are proposed or not merged: that is the work's bookkeeping, never the reader's"
        t['material']['sample_it'] = T.get('check:music_violin', T.get('check:music_sound', {})).get('text')
    m = re.match(r'^chain:(.+)$', t['target'])
    if m:
        t['material']['samples_it'] = {k: T.get(f'chain:{k}', {}).get('text') for k in ('tone', 'violin', 'spin-probes', 'xb-ramp')}
    m = re.match(r'^row:(SHP-\d+|SPR-\d+)$', t['target'])
    if m:
        t['what'] = f"the one-line claim of the Atlas row {m.group(1)}, shown in the legend of an experiment of the tone chapter (not told on a chapter of this site): ≤ 14 words, no final period, from its homePhys/homeMath"
for n in M['narrations']:
    if n['target'] == 'checks:duals':
        n['what'] = ("the heading's line of the fifth group of the checks page: two scripts read from their own files (the dual bells; the duals' second work-out), what each computes; 40–80 words")
        n['length'] = '40–80'; n['where'] = 'checks.html, the fifth group'
        n['material'] = {'en': next((s['text'] for s in M['strings_new'] if s['id'] == 'checks.duals.p'), None), 'what_each': {'music_duals': WHAT['music_duals'], 'music_dual_cells': WHAT['music_dual_cells']}, 'sample_it': R.get('checks:violin', {}).get('text')}
reread = []
for item in M['review']:
    for tg in [x.strip() for x in item['target'].split(',')]:
        cur = R.get(tg)
        reread.append({'target': tg, 'priority': item['priority'], 'why': item['why'], 'current_it': cur['text'] if cur else None, 'tells': cur.get('tells') if cur else None})
cur = J(os.path.join(SITE, 'gen', 'content', 'strings.json')); EN_S = {s['id']: s['text'] for s in cur['strings']}
isV = lambda tg: re.search(r'MUS-23[1-7]\b', tg) or 'violin' in tg
rowsV = [n for n in M['narrations'] if n['target'].startswith('row:') and isV(n['target'])]
rowsD = [n for n in M['narrations'] if n['target'].startswith('row:') and not isV(n['target'])]
titV = [t for t in M['titles'] if isV(t['target'])]
titD = [t for t in M['titles'] if not isV(t['target'])]
strV = [s for s in M['strings_new'] + M['strings_changed'] if s['id'] in ('checks.violin', 'checks.violin.p', 'src.refs4', 'src.refs4.p', 'it.refs4.card')]
strD = [s for s in M['strings_new'] + M['strings_changed'] if s['id'] in ('checks.duals', 'checks.duals.p', 'checks.intro', 'pics.intro')]
# the chapter and part strings changed on the English side: their Italian is re-read by E1 (ch.violin.*) and E2 (part.sound.*) as strings to rewrite from the previous Italian
def strChanged(i):
    return {'id': i, 'text': EN_S.get(i), 'previousIt': S.get(i, {}).get('text'), 'why': 'the English text gained a sentence (the second chain / the duals): keep the previous Italian and add the same, in your words'}
E1 = {
    'about': ("Narrator E1: your targets with their English material (your part of MANIFEST_R8.json): the seven rows of the violin's second chain (MUS-231 … MUS-237), narration and title each; "
              "the heading of their chain; the caption of their figure; the one-line title of their script; the chapter's own narration to re-read (it now holds two chains and two experiments); "
              "the site strings of the violin's group that changed (with the previous Italian). Voice samples from the earlier narrators; the Italian of the violin's first eight rows to keep one hand."),
    'rules': rules, 'narrations': rowsV, 'titles': titV, 'strings': strV,  # ch.violin.lead/card are English-only strings: the Italian page renders the narrator's section:violin and its titles instead
    'check_only': [r for r in reread if r['target'] == 'section:violin'],
    'violin_rows_it': {tg: {'title': T.get(tg, {}).get('text'), 'narration': R.get(tg, {}).get('text')} for tg in [f'row:MUS-{k}' for k in range(223, 231)]},
    'violin_titles_it': {tg: T[tg]['text'] for tg in ['section:violin', 'section:violin:sub', 'card:section:violin', 'chain:violin', 'fig:fig_violin', 'check:music_violin'] if tg in T},
    'chapter_lead_en': EN_S.get('ch.violin.lead'), 'chapter_card_en': EN_S.get('ch.violin.card'),
    'voice_samples': C1['voice_samples'],
}
E2 = {
    'about': ("Narrator E2: your targets with their English material (your part of MANIFEST_R8.json): the seven rows of the two chains of the dual bells told at the end of the tone chapter (MUS-238, MUS-239; MUS-240 … MUS-244), narration and title each; "
              "the headings of the two chains; the captions of their two figures; the one-line titles of their two scripts; the narration of the fifth group of the checks page; the one-line titles of three Atlas rows shown in the experiments' legends (SHP-001, SPR-003, SHP-004); "
              "the tone chapter's narration to re-read (it now ends with the two chains and has two more experiments at its head), Part I's narration and card to re-read, the counts' pages to check; the strings of the dual bells' group and the counts (with the previous Italian). "
              "Voice samples; the Italian of the tone chapter's rows to keep one hand."),
    'rules': rules, 'narrations': rowsD + [n for n in M['narrations'] if n['target'] == 'checks:duals'], 'titles': titD, 'strings': strD,  # part.sound.lead/card are English-only: the Italian page renders part:sound and card:part:sound
    'check_only': [r for r in reread if r['target'] != 'section:violin'],
    'tone_rows_it': {tg: {'title': T.get(tg, {}).get('text'), 'narration': R.get(tg, {}).get('text')} for tg in ['row:MUS-002', 'row:MUS-003', 'row:MUS-025', 'row:MUS-030', 'row:MUS-041', 'row:SPR-M01'] if tg in T or tg in R},
    'tone_titles_it': {tg: T[tg]['text'] for tg in ['section:tone', 'section:tone:sub', 'card:section:tone', 'chain:tone', 'part:sound', 'card:part:sound', 'checks:violin'] if tg in T},
    'tone_narrations_it': {tg: R[tg]['text'] for tg in ['section:tone', 'part:sound', 'checks:violin', 'page:checks', 'page:pictures', 'page:sources', 'page:about'] if tg in R},
    'part_I_card_title_it': {'target': 'card:part:sound', 'current_it': T.get('card:part:sound', {}).get('text'), 'en_now': EN_S.get('part.sound.card'), 'what': 'the card of Part I on the home page (a title target you may rewrite: 20–40 words, no final period): the English card now names the duals and the violin in motion'},
    'part_I_lead_en_now': EN_S.get('part.sound.lead'),
    'voice_samples': C1['voice_samples'],
}
ex = M['experiments']['strings']
byexp = {}
for s in ex: byexp.setdefault(s['experiment'], []).append(s)
def expMaterial(names, who, about):
    out = {'about': about, 'rules': rules, 'narrations': [], 'titles': [], 'strings': [s for s in ex if s['experiment'] in names], 'check_only': [],
           'strings_by_experiment': {k: {'title_it': S.get(f'exp.{k}.title', {}).get('text'), 'lead_it': S.get(f'exp.{k}.lead', {}).get('text'), 'strings': v} for k, v in byexp.items() if k in names},
           'italian_of_other_experiments': {k: [{'id': i, 'en': None, 'it': S[i]['text']} for i in S if i.startswith(f'exp.{k}.') and not S[i].get('stub')] for k in ('violin', 'graphs', 'rotor', 'spin')},
           'common_strings_it': [{'id': i, 'it': S[i]['text']} for i in S if i.startswith('exp.common.') and not S[i].get('stub')],
           'voice_samples': D2.get('voice_samples', C1['voice_samples'])}
    EN = {}
    for k in ('violin', 'graphs', 'rotor', 'spin'):
        p = os.path.join(SITE, 'gen', 'exp', f'{k}.strings.json')
        if os.path.exists(p):
            for e in J(p)['strings']: EN[e['id']] = e['text']
    for k, lst in out['italian_of_other_experiments'].items():
        for e in lst: e['en'] = EN.get(e['id'])
    return out
E3 = expMaterial(['violinbody'], 'E3', "Narrator E3: the strings of the experiment violinbody (the second experiment of the violin chapter; every string is new). The Italian of the violin experiment (above it on the same page) and of the experiments of Part I is given for the terms and the voice, so that the two experiments of the page read as one hand.")
E4 = expMaterial(['duals', 'dualcells'], 'E4', "Narrator E4: the strings of the experiments duals and dualcells (the fifth and sixth experiments at the head of the tone chapter; every string is new). The Italian of the tone chapter's experiments (graphs, rotor) and of the spin experiment is given for the terms and the voice.")
assign = {
    'E1': {'narrations': [n['target'] for n in E1['narrations']], 'titles': [t['target'] for t in E1['titles']], 'strings': [s['id'] for s in E1['strings']], 'rewrite_narrations': ['section:violin'], 'rewrite_titles': [], 'check_only': [r['target'] for r in E1['check_only']]},
    'E2': {'narrations': [n['target'] for n in E2['narrations']], 'titles': [t['target'] for t in E2['titles']], 'strings': [s['id'] for s in E2['strings']], 'rewrite_narrations': ['section:tone'], 'rewrite_titles': ['card:part:sound'], 'check_only': [r['target'] for r in E2['check_only']]},
    'E3': {'narrations': [], 'titles': [], 'strings': [s['id'] for s in E3['strings']], 'rewrite_narrations': [], 'rewrite_titles': [], 'check_only': []},
    'E4': {'narrations': [], 'titles': [], 'strings': [s['id'] for s in E4['strings']], 'rewrite_narrations': [], 'rewrite_titles': [], 'check_only': []},
}
W(os.path.join(DRAFT, 'r8_assign.json'), assign)
for k, v in (('E1', E1), ('E2', E2), ('E3', E3), ('E4', E4)): W(os.path.join(DRAFT, f'r8_{k}_material.json'), v)
for k in assign: print(k, {kk: len(vv) for kk, vv in assign[k].items()})
