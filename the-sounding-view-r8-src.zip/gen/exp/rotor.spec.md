# Builder B1 — Ladder I: one tone, many bodies (five experiments)

Read `CONTRACT.md` and `_common.strings.json` first; then `_kit.js` (the helpers), and `field.js` if it exists. The Atlas rows' claims are in `/tmp/claude-0/-home-claude/394118bf-a32c-5136-a011-44d634d15d21/scratchpad/plan4/atlas_sound.json` (`rows[id].homePhys`, `.status`, `.text`). ATLAS = `/tmp/claude-0/-home-claude/394118bf-a32c-5136-a011-44d634d15d21/scratchpad/in4414/one-rule-src-4.4.14`; its figure data for these five: `checks/selfcheck/round36/figdata/{chain_modes, partials, dissonance_curve, consonance, cents_table}.json`, `checks/selfcheck/round37/figdata/{bell, bell_levels, harmonic_ring, rings, chain, cut_ring, sets, clips, clips_rings}.json`. Read them with `python3 -I`, inspect the shapes (the `source` fields name the check groups), and copy what each experiment needs into `<slug>.data.json`. The Atlas's engine `ATLAS/engines/springEngine.js` (plain ES module: `walsh, verts, edges, omega2, mode, pluck, levelShare, signedLevels`) may be copied into your module as plain functions, with its SPDX header line kept; it needs `ATLAS/engines/bitrule.js` (`popcount`, `sign`): copy what you use.

Pitch mapping for every experiment here: the first partial (or the lowest mode) sounds at 220 Hz unless the spec says otherwise; print the mapping in the `hear` line.



---

## 1. `rotor` — A pure tone is a rotor (rows SPR-M01, MUS-001)

*Panels:* (a) **The rotor**: a point turning on a circle at frequency f, a radius line, and to the right its shadow traced as the sine against time (scrolling); under it the spring step's three motions as three small (x, ẋ) portraits — circle (harmonic, k > 0), hyperbola (inverted, k < 0), line (free, k = 0) — with a switch that picks which one the big picture shows (the sine becomes an exponential run-away for the inverted one, a straight drift for the free one; say in a line that only the circle is a tone). (b) **Two rotors**: two points on two circles at f₁ and f₂, their sum traced below with its envelope; a Δf slider (0 … 12 Hz) prints the beat frequency |f₁ − f₂|; a preset "tempered fifth" sets f₂ = f₁·2^(7/12) and prints the beat of the third partial of the lower against the second of the upper, |3f₁ − 2f₂| = 0.886 Hz at f₁ = 220 Hz — compute it, print it, and say that the just fifth (3/2) beats at 0; draw the two partials' phasors beating. *Hear:* Play holds the rotor's tone; the second panel plays the two tones (beats audible) and, with the preset, the fifth with its partials (two sines + their 3rd and 2nd partials at 1/3, 1/2 amplitude). *Legend rows:* SPR-M01, MUS-001. *Data:* none beyond constants; `source`: "the spring step, SPR-M01; MUS-001".

### As built

Mapping: lowest and only tone 220 Hz = f. Slow-down: panel (a) the picture turns 0.5 turn per second, so it runs f/0.5 = 440× slower than the sound at 220 Hz (printed, follows the frequency slider); panel (b) the picture runs 10× slower than the sound and the wiggle's carrier is drawn at 12 Hz instead of 220 Hz (printed), the beat at its true rate.
Deviations: the tempered fifth's beat of 3f₁ − 2f₂ is 0.745 Hz at f₁ = 220 Hz; the 0.886 Hz of the brief is the value at C4 = 261.6 Hz (`cents_table.json`, 3C:2G); both are printed. A third switch value (just fifth, beat 0) was added. In the fifth modes the picture draws the two partials in question (3f₁ at 1/3 and 2f₂ at 1/2), shifted down by a common amount. Only the circle sounds; the other two portraits are silent (said on the page). No data file beyond constants; no Atlas file read.
