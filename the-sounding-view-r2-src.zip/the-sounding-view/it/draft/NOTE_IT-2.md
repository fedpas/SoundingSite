# NOTE IT-2 — the narrator of the page *The bridges drilled* and of release 2's strings

Delivered, in this folder:

- `racconto_bridges.json` — 62 items, one per target of my share (`page:bridges`; `bridges:table`; the eight `bridges:item:*`; `row:MUS-014` … `row:MUS-049`; `instrument:crt|rings|rows`; `clip:13` … `clip:21`; `page:acoustics`; `checks:round37`; `pictures:round37`; `bridges:opinion`), each `{ id: "r:" + target, target, tells, text, why }`, the `tells` copied verbatim from `gen/content/it/MANIFEST.json` (duplicates included, as the manifest has them: `check:music_labels12.py` twice for MUS-023, and so on); 8,177 whitespace tokens of narration (7,920 tokens that carry a letter or a digit).
- `strings_it_new.json` — the 185 ids of the manifest's `strings_new`, each `{ id, text, why }`, the `why` copied from the manifest; 1,957 tokens. No other id, no id missing (checked against the manifest).
- `check_IT-2.py` — my check, run before delivery (see "The checks" below). It reads the two JSON files and the manifest, so the builder can rerun it from anywhere: `python3 -I site/it/draft/check_IT-2.py`.
- Both tables load: `python3 -c 'import json; json.load(open("racconto_bridges.json")); json.load(open("strings_it_new.json"))'` prints nothing and exits 0 (run from this folder).

Nothing was written outside `it/draft/`; the working files (the study and the pages stripped to text, the source parts of the two tables, the trimming scripts) were removed after the build, so this folder holds only the deliverables and the check.

## What I read

- `it/VOICE_IT.md`, whole; `gen/content/it/MANIFEST.json`, whole (the 62 targets of my share with their `tells`, `length` and `where`; the 185 `strings_new`; the `strings_changed`, which are IT-1's); `gen/lib/italian.mjs` and the Italian section of `gen/check.mjs`, to match the checker's banned-word rule exactly (whole words, case-insensitive; `ora` not after an apostrophe; `round N`; `prima` before di/che/del/…, before punctuation or at the end, and after come/di/da; the markup rule `<[a-z]`, `**`, a line starting with `#`); `gen/lib/study.mjs`, to resolve `drill:top.N`: the units of the study's head are `top.0` the kicker, `top.1` the h1, `top.2` the byline paragraph ("A research note written for the Atlas's owner …"), `top.3` the Abstract, `top.4` "In one line each".
- The study `docs/round37/the_bridges_drilled.html`, whole (the head, §1 … §10, Part 2, §11 … §16, the figure captions and the clip paragraphs; the References and the Appendix skimmed).
- `docs/round37/BRIDGES_DRILLED.md` (its summary table of the eleven bridges and its joined `BRIDGE.md`s), the eight items' `ROWS.md` and `BRIDGE.md`, whole; the eight `NOTE.md` by their headings and the sections that bear on terminology and on what was found wrong (clock §3, rings §7, acoustics §2–§3); `items/acoustics/DICTIONARY.md`, whole; `figs/FIGURES_INDEX.md`, whole; `checks/selfcheck/round37/audio/INDEX.md`, whole; `checks/selfcheck/round37/README.md`, whole.
- The pages as built, stripped to text: `out/bridges.html` (the head, the table, the eight items with their proposed rows, the dictionary, the opinion), `out/sounds.html` (instruments 7, 8, 9 and the clips 13 … 21), `out/checks.html` (the section of the nine scripts), `out/pictures.html` (the twelve figures), `out/dictionary.html` (the paper's dictionary).
- IT-1's `NOTE_IT-1.md` (its terminology table), after my first build, to keep the two voices on one vocabulary: *il nucleo*, *collana / braccialetto*, *per toni interi*, *dato in ingresso*, *il pizzico*, *esecuzione*, *preimpostazioni*, *il log*, *il passo della molla* are the same words on both sides.

Every number, name and claim in a narration is taken from the records its `tells` name and quoted as the record prints it (decimal point, the record's digits, its units, its spacing of large numbers: 9 985 920, 46 272; but 42934 and 2985984 as MUS-015's own text prints them). Where I shortened for length I dropped numbers the English record shows beside, never a claim's qualification (every "proposta", every "nostra", every "richiamato" stayed).

## Terminology beyond the glossary

| English (the records) | Italian used | note |
|---|---|---|
| the drill; drilled (a bridge) | sondare, i ponti sondati; "lo studio" for the drill as a whole | the study's title stays English; "lo studio" around it, as asked |
| item (the eight items of the round) | il capitolo (Capitolo 1 / 8, "la scheda del capitolo") | "voce" is kept for the dictionary's and the lens's entries; "item" would be an anglicism |
| the item's record (BRIDGE.md) | la scheda del capitolo | |
| the records (the Atlas's English blocks) | gli atti | "record" is an anglicism; "registro" would clash with the four registers |
| the kernel (checks/selfcheck) | il nucleo | as IT-1 |
| the owner; the brief | il proprietario; la consegna | |
| the paper (Burns, Daniel, Alexander and Dressel) | l'articolo | |
| the pack | il pacchetto | glossary |
| the chrome (navigation, labels) | la cornice del sito | |
| the study's stamp (its byline line) | il timbro dello studio | |
| grade in round 36 / grade round 37 proposes; before / after | il grado di partenza / il grado proposto; "Di partenza" / "Proposto" as the two columns | as asked; "round N" never appears |
| exact (arithmetic), none (meaning); exact with an input | esatto (aritmetica), nessuno (significato); esatto con un dato in ingresso | |
| ours (a reading) | nostra lettura; "è nostro/nostra" | |
| recalled (a theorem not proved here) | richiamato | |
| standard, recomputed; reduction (the kind) | standard, ricalcolato; (il tipo) riduzione | "kind" → tipo, as IT-1; the Clifford "type" is also "il tipo" (il tipo M₂(ℍ)) |
| the bit rule; the top label F; the top blade Ω | la regola dei bit; l'etichetta massima F; la lama massima | "blade" → lama, the Italian GA usage |
| mask; XOR; weight (popcount); Hamming distance | maschera; XOR; peso; distanza di Hamming | |
| the clock (of a cell, ℤ₈); the clock sum | l'orologio (orologio 6); la somma d'orologio | the glossary's "orologio" for the clock of twelve as well |
| 2-part, 3-part of ℤ₁₂ | la componente 2-primaria, 3-primaria | |
| fibre product; common quotient; coset | prodotto fibrato; quoziente comune; classe laterale | |
| the mirror (ζ₄⁻¹, the generators in the opposite order) | il fattore ℤ₄ rispecchiato; lo specchio x ↦ 7x | the Atlas's mirror Cl(p,q) → Cl(q,p) is the glossary's "lo specchio"; the item's "mirror" is told as "la radice ζ₄⁻¹" and never as "lo specchio dell'Atlante" (clock NOTE.md §3.2 asks the two not to share the word) |
| Walsh modes, vectors, characters | modi, vettori, caratteri di Walsh | |
| Weil's normaliser; Weil's index; the Heisenberg pair; Weyl operators; the chirp | il normalizzatore di Weil; l'indice di Weil; la coppia di Heisenberg; gli operatori di Weyl; il chirp | "chirp" kept, the signal-processing word Italian uses |
| Gauss sum; quadratic form; degenerate; radical; discriminant form | somma di Gauss; forma quadratica; degenere; radicale; forma discriminante | |
| signature word | parola di segnatura | |
| necklace; bracelet; Burnside's lemma; cycle index | collana; braccialetto; lemma di Burnside; indice dei cicli | |
| Johnson graph; 3-regular bipartite; hexagon face | grafo di Johnson; 3-regolare e bipartito; esagono | |
| neo-Riemannian moves; contextual; absolute | mosse neoriemanniane; contestuale; assoluto | |
| torsor; simply transitive; centralizer; commutator subgroup; central product; conjugate | torsore; semplicemente transitiva; centralizzante; sottogruppo dei commutatori; prodotto centrale; coniugato | |
| Azumaya property; group algebra; the bit rule's twist; the twisted L_a R′_b | la proprietà di Azumaya; l'algebra di gruppo; la torsione della regola dei bit; gli operatori ritorti | "twist" → torsione / ritorti, not the anglicism |
| the walk; cut; step word; octave word; letter frequency | il cammino; il taglio; la parola dei passi; la parola delle ottave; la frequenza di una lettera | |
| 2-automatic sequence; 2-kernel; substitution; block code; Cobham's theorem | successione 2-automatica; 2-nucleo; sostituzione; codice a blocchi; il teorema di Cobham | |
| Sturmian; Christoffel word; involution (Berthé–de Luca–Reutenauer); numeration; Ostrowski digits | sturmiana; parola di Christoffel; l'involuta; numerazione; le cifre di Ostrowski | |
| convergent; comma (Pythagorean, Mercator's) | convergente; comma pitagorico, di Mercator | "Mercator" as the record prints the name |
| all-interval row; sequencing (Gordon); Eimert's exchange; retrograde; inversion; combinatorial; all-combinatorial | serie panintervallare; sequenziazione; lo scambio di Eimert; retrogrado; inversione; combinatoriale; pancombinatoriale | |
| voicing rule | la regola di disposizione | |
| Berg's Lyric Suite row; Klein's Mutterakkord; Slonimsky's Grandmother chord; the wedge | la serie della Suite lirica di Berg; il Mutterakkord; l'accordo della Nonna di Slonimsky; il cuneo | "Suite lirica" is the Italian title in use; the English title stands in the records beside |
| middle C, C4; the note names | il Do centrale, C4; C, D, E♭, F♯, A♭ … as the records print them | letter names kept so the reader finds the same symbols in the English record |
| spring; stiffness; negative stiffness; nearest-neighbour ring; circulant | molla; rigidezza; rigidezza negativa; l'anello a primi vicini; circolante | |
| clamped–free; clamped at both ends; free chain | incastrata a un capo e libera all'altro; incastrata a entrambi gli estremi; catena libera | |
| interlacing spectra (strictly) | spettri (strettamente) interallacciati | the Italian of "interlacing eigenvalues" |
| Gladwell's theorem; dual Hahn polynomials; Krawczyk's test / theorem; rational interval arithmetic | il teorema di Gladwell; i polinomi di Hahn duali; il test / teorema di Krawczyk; aritmetica degli intervalli razionale | |
| realizable set; window a … a + 5; assignment (of partials to modes) | insieme realizzabile; finestra; assegnazione | |
| missing fundamental; band-limited pulse; clang; inharmonic | fondamentale mancante; impulso a banda limitata; clangore; inarmonico | |
| rigid body; space / body frame; motor; rotor; translator; sandwich; the motor group | corpo rigido; sistema fisso / solidale; motore; rotore; traslatore; sandwich; il gruppo dei motori | glossary for the frames |
| binary octahedral / tetrahedral group; Hurwitz units | gruppo ottaedrale / tetraedrale binario; le unità di Hurwitz | |
| momentum (the Atlas's bivector P = I[B]); momentum law; Euler term; tops; forque | il momento; la legge del momento; il termine di Eulero; le trottole; forque (the paper's name, kept) | |
| grade complements; measurable fields; potentials; sources; power fields W_e, W_m; Faraday bivector; Lorenz–FitzGerald condition | complementi di grado; campi misurabili; potenziali; sorgenti; campi di potenza; bivettore di Faraday; condizione di Lorenz–FitzGerald | |
| Hodge star; Hodge decomposition; pseudoscalar; spinor; null (vector, wave vector); boost | stella di Hodge; decomposizione di Hodge; pseudoscalare; spinore; nullo; boost | "boost" kept, Italian physics' usage |
| the time edge (z_acγ₀, the label's xor 0001) | lo spigolo temporale | |
| stress-energy (energy–momentum) tensor; adiabatic bulk modulus; acoustic impedance; vorticity | il tensore degli sforzi / energia-impulso; il modulo di compressibilità adiabatico; l'impedenza acustica; la vorticità | |
| the paper's corrections; the power-corrected equations; printed slips | le correzioni dell'articolo; le equazioni con i termini di potenza; le sviste di stampa | "corretto/a" is banned, so never "equazioni corrette" |
| candidates (for the Atlas) | i candidati | |
| the whole-tone set (instrument 7's preset) | Toni interi | "esatonale" is kept for the hexatonic cycle alone, as the glossary gives it, although Italian usage also calls the whole-tone scale "esatonale"; "Toni interi" avoids the collision, as IT-1's "per toni interi" does |
| the check's routes [bit] [std] [ref] [ctl] | le vie | the Checks page's "Its routes" → "Le sue vie" |
| control; fault; FAIL line; exit 1 | controllo; guasto; riga FAIL; "fa fallire lo script" / "esce con 1" | glossary |
| the docstring's first paragraph; Scope | "Che cos'è"; "Ambito" | |
| Stage and ptype; Proposed home; Evidence | Stadio e ptype; Sede proposta; Evidenza | "ptype" is the Atlas's field name |
| study (the home card's badge) | studio | |

## What was unclear in the sources, and how I told it

- **`drill:top.2`, `top.3`, `top.4`.** Not named in VOICE_IT.md; resolved from `gen/lib/study.mjs` (above): `page:bridges` stands on the byline paragraph and the abstract, `bridges:table` on "In one line each" and BRIDGES_DRILLED.md's table. The narrations quote those two units only (the three asks, the counts, "Nothing is merged", the eleven one-liners).
- **Before / after.** Told as "il grado di partenza" and "il grado proposto" everywhere (the table's lead, the two column strings, the Standard register's labels, the items). "Round 36" is told as "lo studio Music on the labels" where the grade of departure is meant, and "le tavole" where the Atlas's merged state is meant.
- **The word "item".** Chosen "capitolo" (see the table). All strings that render an item (`b.items`, `b.item.k`, `b.item.bridge`, `b.rows.note`, `std.bridge`, `dict.paper.p`, `blk.*`) use it; the eight headings keep the English's bridge numbers.
- **The clips' records vs the study's paragraphs.** Where the two print a number differently I quoted the clip's own `audio/INDEX.md`, the record the manifest's `tells` name: clip 16 "0.0490 %" (the study: 0.049 %), clip 18 "0.0270 %" (0.027 %), clip 19 "656.53, 1082.71, …, 3476.09 Hz" (the study rounds to one decimal), clip 21 "ogni picco un multiplo di 110 Hz entro lo 0.5 %" (the study says "within 1 %").
- **MUS-023 and MUS-030 tell one script twice** (the manifest lists `check:music_labels12.py` twice, `check:music_bell.py` twice): the tells are copied as they are; the narration names both groups (ml·COMP and ml·SIGN; mb·BELL and mb·AUDIO).
- **MUS-029's two inputs** (c = 343 m/s, ρ = 1.2041 kg/m³) are told as "dati in ingresso", as the row has them; the row's own status stays "calcolato".
- **MUS-049** has no check of its own: told as "una lettura nostra, proposta, senza una verifica propria", with the three caveats the row gives for the time edge, and never as a result.
- **The analogies** stay analogies in every row and item: the word "campana" (MUS-030, bridge 1), "forma PLR" (bridge 11), the time edge as a translation (MUS-049, bridge 2), the circle of fifths as the Atlas's twelve (opinion), a scale as a signature word (MUS-019), the symmetry that forbids (MUS-041) — each marked "nostra/nostro" or "analogia (nostra)".
- **Numbers the trimming removed.** Each narration is inside its length by the strictest count (every token, "=" and numbers included), so several lists of numbers that the English record shows beside were cut (the twelve cents of the 12-cube stayed; the per-cardinality class counts of MUS-021, the three XOR examples of MUS-022, the two sign counts of MUS-023, the second spectrum of the positive ring in MUS-031, the masses of the dual Hahn chain in MUS-041 went). No number was rounded or rewritten.
- **"prima".** The checker flags `prima` before a comma or a full stop whatever its sense, so "forma prima" never closes a clause in my texts (I wrote "le forme prime di Rahn e di Forte"), and "first … then" is told with "per primo … poi", never with "prima … poi". "Di nuovo" is banned ("nuovo"): "daccapo" / "anche" instead. "Ultimo" is banned: "la colonna finale", "le sei note finali". "Corretto" is banned: "le correzioni dell'articolo" for the paper's corrections, "con i termini di potenza" for the power-corrected equations.
- **The strings' names.** The Sounding View, The Shifted View, Music on the labels, The bridges drilled, the file names, the ids, the check tags, run_all.sh, ptype, the arXiv number and the DOI stay as they are; `b.title` is the study's title in English; `src.refs2` is "The bridges drilled — riferimenti"; `lang.en` / `lang.it` stay "EN" / "IT".
- **`i9.yes`, `i9.no`, the notes under instrument 8** are told as the readouts the page prints after a number (the English's shape kept: a lower-case sentence that continues a readout).
- **`i8.note.solved`**: "no spring pulls two masses together as they part" → "nessuna molla tira due masse l'una verso l'altra mentre si allontanano".

## Word counts

Two counts per narration: whitespace tokens (the strictest, every number and symbol a token) and tokens that carry a letter or a digit. Both lie inside the manifest's range for all 62.

| target | range | tokens | letters/digits |
|---|---|---|---|
| `page:bridges` | 150–220 | 215 | 215 |
| `bridges:table` | 60–100 | 94 | 94 |
| `bridges:item:clock` | 120–180 | 176 | 173 |
| `bridges:item:labels` | 120–180 | 162 | 162 |
| `bridges:item:duality` | 120–180 | 176 | 173 |
| `bridges:item:walk` | 120–180 | 173 | 170 |
| `bridges:item:rows` | 120–180 | 171 | 170 |
| `bridges:item:rings` | 120–180 | 178 | 174 |
| `bridges:item:body` | 120–180 | 164 | 162 |
| `bridges:item:acoustics` | 120–180 | 170 | 168 |
| `row:MUS-014` | 60–140 | 134 | 130 |
| `row:MUS-015` | 60–140 | 133 | 124 |
| `row:MUS-016` | 60–140 | 135 | 128 |
| `row:MUS-017` | 60–140 | 129 | 117 |
| `row:MUS-018` | 60–140 | 135 | 125 |
| `row:MUS-019` | 60–140 | 131 | 125 |
| `row:MUS-020` | 60–140 | 133 | 133 |
| `row:MUS-021` | 60–140 | 134 | 127 |
| `row:MUS-022` | 60–140 | 128 | 124 |
| `row:MUS-023` | 60–140 | 133 | 129 |
| `row:MUS-024` | 60–140 | 136 | 130 |
| `row:MUS-025` | 60–140 | 137 | 136 |
| `row:MUS-026` | 60–140 | 129 | 123 |
| `row:MUS-027` | 60–140 | 133 | 128 |
| `row:MUS-028` | 60–140 | 137 | 135 |
| `row:MUS-029` | 60–140 | 134 | 121 |
| `row:MUS-030` | 60–140 | 137 | 130 |
| `row:MUS-031` | 60–140 | 135 | 125 |
| `row:MUS-032` | 60–140 | 128 | 128 |
| `row:MUS-033` | 60–140 | 130 | 121 |
| `row:MUS-034` | 60–140 | 133 | 127 |
| `row:MUS-035` | 60–140 | 133 | 131 |
| `row:MUS-036` | 60–140 | 133 | 127 |
| `row:MUS-037` | 60–140 | 131 | 130 |
| `row:MUS-038` | 60–140 | 133 | 131 |
| `row:MUS-039` | 60–140 | 136 | 129 |
| `row:MUS-040` | 60–140 | 135 | 131 |
| `row:MUS-041` | 60–140 | 131 | 127 |
| `row:MUS-042` | 60–140 | 133 | 126 |
| `row:MUS-043` | 60–140 | 130 | 126 |
| `row:MUS-044` | 60–140 | 133 | 127 |
| `row:MUS-045` | 60–140 | 132 | 129 |
| `row:MUS-046` | 60–140 | 134 | 122 |
| `row:MUS-047` | 60–140 | 130 | 120 |
| `row:MUS-048` | 60–140 | 127 | 118 |
| `row:MUS-049` | 60–140 | 129 | 127 |
| `instrument:crt` | 80–140 | 131 | 125 |
| `instrument:rings` | 80–140 | 135 | 131 |
| `instrument:rows` | 80–140 | 132 | 131 |
| `clip:13` | 40–90 | 87 | 87 |
| `clip:14` | 40–90 | 77 | 73 |
| `clip:15` | 40–90 | 87 | 85 |
| `clip:16` | 40–90 | 84 | 82 |
| `clip:17` | 40–90 | 86 | 85 |
| `clip:18` | 40–90 | 82 | 80 |
| `clip:19` | 40–90 | 71 | 68 |
| `clip:20` | 40–90 | 84 | 81 |
| `clip:21` | 40–90 | 87 | 84 |
| `page:acoustics` | 120–180 | 176 | 176 |
| `checks:round37` | 100–160 | 154 | 154 |
| `pictures:round37` | 60–120 | 117 | 116 |
| `bridges:opinion` | 80–140 | 134 | 134 |

Totals: 8,177 tokens (7,920 with a letter or a digit) of narration; 1,957 tokens of strings.

## The checks

`check_IT-2.py` reimplements the matcher of `gen/lib/italian.mjs` (the same word list; `ora` not after an apostrophe; `round\s*\d+`; `prima` before di/che/del/della/dei/delle/dello/degli/d', before `, . ; : ! ?` or at the end, and after come/di/da; whole words, case-insensitive, Unicode letters) with a self-test against the rule's own examples, and then:

- greps every narration and every string for the banned forms — **0 hits** in the 62 narrations and in the 185 strings (no string of mine is `release.stamp`, so no exception was needed);
- counts each narration against the manifest's `length`, both ways — **all 62 inside their range**;
- refuses markup (`<[a-z]`, `**`, a line starting with `#`) — none;
- checks that every `id` is `r:` + target, no target twice, every `tells` equal to the manifest's, a `why` on each — ok;
- checks that the 185 string ids are exactly the manifest's `strings_new` and that no brace placeholder of the English was lost — ok (none of the 185 has a placeholder).

Its last run printed: `narrations 62, strings 185, narration words 8177, string words 1957, errors 0`.

## Not resolved, for the builder

- The stub tables in `gen/content/it/` (`racconto.json`, `strings_it.json`) were not touched: the builder merges IT-1's `racconto_r1.json` + `strings_it_r1.json` with my `racconto_bridges.json` + `strings_it_new.json` (together 122 targets and 405 ids, as the manifest counts).
- The `optional: true` flag of some `strings_new` entries was not carried into `strings_it_new.json` (the asked shape is `{ id, text, why }`); every optional id is filled.
- The `about` field of each table is in English (for the builder), the `voice` field in Italian (the narrator's own description); both are the same `voice` text in the two files.
