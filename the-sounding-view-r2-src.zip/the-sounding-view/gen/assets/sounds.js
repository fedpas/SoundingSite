// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// The Sounding View — sounds.js: a Web Audio synthesizer in plain JavaScript (no library) that plays the Atlas's numbers.
// Every number comes from window.SDV_DATA (sounds-data.js, copied by the generator from the checks' figdata/ of round 36
// and of round 37's pack) or is computed here from them; the page says beneath each instrument which file and which row.
// Every word the script writes into the page is read from the page (the hidden labels data-s=… the build filled from the
// string table of the page's language, or the select's options), so the Italian page plays the same engine.
// The engine works on any BaseAudioContext, so the test (gen/test_sounds.mjs) renders the same calls into an
// OfflineAudioContext and measures them. Sound: sine oscillators summed as partials (no sawtooth node), 20 ms
// raised-cosine fades on every tone, a master gain at −6 dBFS; the AudioContext is created on the first click.
(function () {
  'use strict';
  var DATA = window.SDV_DATA || null;
  var SVGNS = 'http://www.w3.org/2000/svg';
  var FADE = 0.02;
  var MASTER_DB = -6;
  var NAMES = ['C', 'C♯', 'D', 'E♭', 'E', 'F', 'F♯', 'G', 'A♭', 'A', 'B♭', 'B'];

  // ------------------------------------------------------------------ the engine
  function rc(n, up, level) { var a = new Float32Array(n); for (var i = 0; i < n; i++) { var v = 0.5 - 0.5 * Math.cos(Math.PI * i / (n - 1)); a[i] = (up ? v : 1 - v) * level; } return a; }
  function ratio(s) { s = String(s); var p = s.split('/'); return p.length === 2 ? (+p[0]) / (+p[1]) : +s; }
  function master(ac) { var g = ac.createGain(); g.gain.value = Math.pow(10, MASTER_DB / 20); g.connect(ac.destination); return g; }
  // one tone: sine partials f·ratios[k] with amplitudes amps[k]·level, from t for dur seconds, faded in and out (raised
  // cosine, 20 ms); glide (optional): {from, to, t1, t2} multiplies every partial's frequency, exponentially
  function tone(ac, dest, t, dur, f, ratios, amps, level, glide, track) {
    var g = ac.createGain();
    g.gain.value = 0;
    g.connect(dest);
    var fade = Math.min(FADE, dur / 2.01);
    g.gain.setValueCurveAtTime(rc(64, true, level), t, fade);
    g.gain.setValueCurveAtTime(rc(64, false, level), t + dur - fade, fade);
    for (var k = 0; k < ratios.length; k++) {
      var o = ac.createOscillator();
      o.type = 'sine';
      var fk = f * ratios[k];
      if (glide) {
        o.frequency.setValueAtTime(fk * glide.from, t);
        o.frequency.setValueAtTime(fk * glide.from, glide.t1);
        o.frequency.exponentialRampToValueAtTime(fk * glide.to, glide.t2);
      } else o.frequency.setValueAtTime(fk, t);
      var pg = ac.createGain();
      pg.gain.value = amps[k];
      o.connect(pg); pg.connect(g);
      o.start(t); o.stop(t + dur + 0.005);
      if (track) track.push(o);
    }
    return g;
  }
  // a percussive sound of the rhythms (clip 8's: a click, a tick, a thump): a 2 ms raised-cosine attack, an exponential decay
  function hit(ac, dest, t, f, decay, level, track) {
    var g = ac.createGain();
    g.gain.value = 0;
    g.connect(dest);
    g.gain.setValueCurveAtTime(rc(16, true, level), t, 0.002);
    g.gain.setTargetAtTime(0, t + 0.002, decay);
    var o = ac.createOscillator();
    o.type = 'sine';
    o.frequency.setValueAtTime(f, t);
    o.connect(g);
    o.start(t); o.stop(t + 0.002 + decay * 7);
    if (track) track.push(o);
  }
  function sumOf(a) { var s = 0; for (var i = 0; i < a.length; i++) s += a[i]; return s; }
  var HARM6 = [1, 2, 3, 4, 5, 6];
  function amps6() { return DATA.amps.slice(0, 6); }

  // ------------------------------------------------------------------ the numbers
  function freqOf(pc, tuning, octave) {
    var f = DATA.C4 * Math.pow(2, pc / 12);
    if (tuning === 'just' && DATA.just[pc] != null) f = DATA.C4 * ratio(DATA.just[pc]);
    return f * Math.pow(2, octave || 0);
  }
  function intervalVector(pcs) {
    var iv = [0, 0, 0, 0, 0, 0];
    for (var i = 0; i < pcs.length; i++) for (var j = i + 1; j < pcs.length; j++) { var d = ((pcs[j] - pcs[i]) % 12 + 12) % 12; var ic = Math.min(d, 12 - d); if (ic > 0) iv[ic - 1]++; }
    return iv;
  }
  // f̂(k) = Σ_{x∈S} e^(−2πikx/12), dft.json's convention; returns |f̂(k)| for k = 0 … 6
  function dftAbs(pcs) {
    var out = [];
    for (var k = 0; k <= 6; k++) { var re = 0, im = 0; for (var i = 0; i < pcs.length; i++) { var a = 2 * Math.PI * k * pcs[i] / 12; re += Math.cos(a); im -= Math.sin(a); } out.push(Math.sqrt(re * re + im * im)); }
    return out;
  }
  // Bjorklund's algorithm as Toussaint describes it: k sequences [x] and n − k sequences [.], the remainders appended
  // to the leaders until at most one remainder is left
  function bjorklund(k, n) {
    if (k <= 0) return new Array(n + 1).join('.');
    if (k >= n) return new Array(n + 1).join('x');
    var a = [], b = [], i;
    for (i = 0; i < k; i++) a.push(['x']);
    for (i = 0; i < n - k; i++) b.push(['.']);
    while (b.length > 1) {
      var m = Math.min(a.length, b.length), na = [];
      for (i = 0; i < m; i++) na.push(a[i].concat(b[i]));
      var rest = a.length > m ? a.slice(m) : b.slice(m);
      a = na; b = rest;
    }
    return a.concat(b).map(function (s) { return s.join(''); }).join('');
  }
  function chainOmegas(N) { var w = []; for (var k = 1; k <= N; k++) w.push(2 * Math.sin(k * Math.PI / (2 * (N + 1)))); return w; }
  function chainFreqs(N, f1) { var w = chainOmegas(N); return w.map(function (x) { return (f1 || 220) * x / w[0]; }); }

  // the triads of plr_dual.json: root, quality, the edges by label
  var TRI = null;
  function triads() {
    if (TRI) return TRI;
    var byName = {}, list = DATA.plr.nodes.map(function (n) {
      var third = n.type === 'major' ? 4 : 3, root = null;
      for (var i = 0; i < 3; i++) { var x = n.pcs[i]; if (n.pcs.indexOf((x + third) % 12) >= 0 && n.pcs.indexOf((x + 7) % 12) >= 0) root = x; }
      var t = { id: n.id, name: n.name, type: n.type, pcs: n.pcs, root: root, third: (root + third) % 12, fifth: (root + 7) % 12, x: n.xy_centroid_in_domain[0], y: n.xy_centroid_in_domain[1], nb: {} };
      byName[n.name] = t;
      return t;
    });
    DATA.plr.edges.forEach(function (e) { byName[e.a].nb[e.label] = byName[e.b]; byName[e.b].nb[e.label] = byName[e.a]; });
    TRI = { list: list, byName: byName };
    return TRI;
  }
  // the role of a pitch class in a triad, and its just ratio over the root (4:5:6 major, 10:12:15 minor)
  function roleRatio(t, pc, tuning) {
    var r = pc === t.root ? 0 : pc === t.third ? 1 : 2;
    if (tuning === 'just') return [1, t.type === 'major' ? 5 / 4 : 6 / 5, 3 / 2][r];
    return Math.pow(2, [0, t.type === 'major' ? 4 : 3, 7][r] / 12);
  }
  // a walk's voices: three frequencies; a move keeps the two common tones and moves the third voice to the new pitch
  // class, tuned (just) on the held tones or (12-TET) on the semitone grid, by the octave nearest to where it was
  function startVoices(t, tuning) {
    var R = DATA.C4 * Math.pow(2, t.root / 12) * (t.root >= 7 ? 0.5 : 1);
    return [t.root, t.third, t.fifth].map(function (pc) { return { pc: pc, f: R * roleRatio(t, pc, tuning) }; });
  }
  function moveVoices(voices, t, tuning) {
    var held = voices.filter(function (v) { return t.pcs.indexOf(v.pc) >= 0; });
    var mover = voices.filter(function (v) { return t.pcs.indexOf(v.pc) < 0; })[0];
    if (held.length !== 2 || !mover) return startVoices(t, tuning);
    var newPc = t.pcs.filter(function (pc) { return pc !== held[0].pc && pc !== held[1].pc; })[0];
    var R = held[0].f / roleRatio(t, held[0].pc, tuning); // the new root, from a held tone (the other agrees)
    var f = R * roleRatio(t, newPc, tuning);
    while (f > mover.f * Math.SQRT2) f /= 2;
    while (f < mover.f / Math.SQRT2) f *= 2;
    return voices.map(function (v) { return v === mover ? { pc: newPc, f: f } : v; });
  }
  // the drift of a just walk: the root's frequency against the 12-TET frequency of its pitch class, in cents
  function driftCents(voices, t) {
    var root = voices.filter(function (v) { return v.pc === t.root; })[0];
    var tet = DATA.C4 * Math.pow(2, t.root / 12);
    var c = 1200 * Math.log2(root.f / tet);
    return c - 1200 * Math.round(c / 1200);
  }

  // ------------------------------------------------------------------ the instruments' scores (engine level)
  function playChord(ac, dest, t, pcs, tuning, dur, arpeggio, track) {
    var a = amps6(), lev = 0.95 / (Math.max(1, arpeggio ? 1 : pcs.length) * sumOf(a));
    var sorted = pcs.slice().sort(function (x, y) { return x - y; });
    var step = 0.38;
    sorted.forEach(function (pc, i) {
      var f = freqOf(pc, tuning);
      if (arpeggio) tone(ac, dest, t + i * step, step + 0.06, f, HARM6, a, lev, null, track);
      else tone(ac, dest, t, dur, f, HARM6, a, lev, null, track);
    });
    return arpeggio ? sorted.length * step + 0.06 : dur;
  }
  function playVoices(ac, dest, t, voices, dur, track) {
    var a = amps6(), lev = 0.95 / (voices.length * sumOf(a));
    voices.forEach(function (v) { tone(ac, dest, t, dur, v.f, HARM6, a, lev, null, track); });
  }
  // a rhythm: bars × n pulses at ppm pulses per minute; an onset a 1200 Hz click, another pulse a soft 3.5 kHz tick,
  // each downbeat (pulse 0) also a 180 Hz thump
  function scheduleRhythm(ac, dest, t, str, ppm, bars, track) {
    var dt = 60 / ppm, n = str.length;
    for (var b = 0; b < bars; b++) for (var i = 0; i < n; i++) {
      var ti = t + (b * n + i) * dt;
      if (str[i] === 'x') hit(ac, dest, ti, 1200, 0.018, 0.55, track); else hit(ac, dest, ti, 3500, 0.006, 0.08, track);
      if (i === 0) hit(ac, dest, ti, 180, 0.05, 0.4, track);
    }
    return bars * n * dt;
  }
  function chainModes(ac, dest, t, N, track) {
    var fs = chainFreqs(N, 220), step = 0.55;
    fs.forEach(function (f, i) { tone(ac, dest, t + i * step, step - 0.05, f, [1], [1], 0.9, null, track); });
    return fs.length * step;
  }
  function ringModes(ac, dest, t, track) {
    var step = 0.5;
    DATA.chain.C12.omega2_float.forEach(function (w2, k) { if (w2 > 0) tone(ac, dest, t + k * step, step - 0.04, 440 * Math.sqrt(w2), [1], [1], 0.9, null, track); });
    return 12 * step;
  }
  function bodyPartials(body) {
    var P = DATA.partials;
    if (body === 'stiff') return P.stiff.ratio_to_first.slice();
    if (body === 'bar') return P.bar.slice();
    if (body === 'membrane') return P.membrane.slice(0, 6);
    return P.string.slice();
  }
  function playPartials(ac, dest, t, body, track) {
    var r = bodyPartials(body), a = r.map(function (x, i) { return 1 / (i + 1); }), lev = 0.95 / sumOf(a), step = 0.36;
    r.forEach(function (x, i) { tone(ac, dest, t + i * step, step + 0.04, 220 * x, [1], [1], 0.9 / Math.sqrt(i + 1), null, track); });
    var t2 = t + r.length * step + 0.1;
    tone(ac, dest, t2, 1.6, 220, r, a, lev, null, track);
    return t2 + 1.6 - t;
  }
  function playGliss(ac, dest, t, timbre, track) {
    var C = DATA.curve, a = amps6(), r = timbre === 'bar' ? C.partials_bar.slice(0, 6) : HARM6, lev = 0.95 / (2 * sumOf(a));
    tone(ac, dest, t, 8.0, C.f1, r, a, lev, null, track);
    tone(ac, dest, t, 8.0, C.f1, r, a, lev, { from: 1, to: 2, t1: t + 0.5, t2: t + 7.0 }, track);
    return 8.0;
  }

  // ------------------------------------------------------------------ round 37: the CRT grid, the rings and the bell, the rows
  var HARM4 = [1, 2, 3, 4], AMP4 = [1, 1 / 2, 1 / 3, 1 / 4];
  var midiHz = function (m) { return 440 * Math.pow(2, (m - 69) / 12); };
  // the rule of x ↦ 7x on the CRT grid, computed from crt_tonnetz.json's cells: (a, b) ↦ (a, −b) or (−a, b)
  function crtMirror() {
    var cells = DATA.crt.cells, byPc = {}, ab = true, ba = true;
    cells.forEach(function (c) { byPc[c.pc] = c; });
    cells.forEach(function (c) {
      var img = byPc[(7 * c.pc) % 12];
      if (!(img.a_major_thirds === c.a_major_thirds && img.b_minor_thirds === (4 - c.b_minor_thirds) % 4)) ab = false;
      if (!(img.a_major_thirds === (3 - c.a_major_thirds) % 3 && img.b_minor_thirds === c.b_minor_thirds)) ba = false;
    });
    return ab ? '(a, b) -> (a, -b)' : ba ? '(a, b) -> (-a, b)' : null;
  }
  function mirror7(pcs) { return pcs.map(function (pc) { return (7 * pc) % 12; }).sort(function (x, y) { return x - y; }); }
  function crtCoords(pc) { var c = DATA.crt.cells.filter(function (x) { return x.pc === pc; })[0]; return [c.a_major_thirds, c.b_minor_thirds]; }
  // a sequence of pitch classes, each a tone (or the major triad on it) of 12-TET in the octave of middle C
  function playSeq(ac, dest, t, pcs, step, triad, track) {
    var a = amps6(), lev = 0.95 / ((triad ? 3 : 1) * sumOf(a));
    pcs.forEach(function (pc, i) {
      var f = freqOf(pc, 'tet');
      tone(ac, dest, t + i * step, step + 0.06, f, HARM6, a, lev, null, track);
      if (triad) { tone(ac, dest, t + i * step, step + 0.06, f * Math.pow(2, 4 / 12), HARM6, a, lev, null, track); tone(ac, dest, t + i * step, step + 0.06, f * Math.pow(2, 7 / 12), HARM6, a, lev, null, track); }
    });
    return pcs.length * step + 0.06;
  }
  // a struck sound: partials freqs[k] with amplitudes amps[k], each decaying exponentially with its own τ (taus[k]),
  // a 4 ms raised-cosine attack, stopped at t + dur
  function bellTone(ac, dest, t, freqs, amps, taus, dur, level, track) {
    var g = ac.createGain();
    g.gain.value = level / Math.max(1e-9, sumOf(amps));
    g.connect(dest);
    for (var k = 0; k < freqs.length; k++) {
      var o = ac.createOscillator();
      o.type = 'sine';
      o.frequency.setValueAtTime(freqs[k], t);
      var pg = ac.createGain();
      pg.gain.value = 0;
      pg.gain.setValueCurveAtTime(rc(16, true, amps[k]), t, 0.004);
      pg.gain.setTargetAtTime(0, t + 0.004, taus[k]);
      o.connect(pg); pg.connect(g);
      o.start(t); o.stop(t + dur);
      if (track) track.push(o);
    }
    return g;
  }
  var tauBell = function (f, f1, tau1) { return tau1 * f1 / f; }; // clips 13 … 15: τ = 1.8 s × 220/f
  var tauRing = function (f, fLow) { return 1.5 * Math.sqrt(fLow / f); }; // clips 19 … 21: τ = 1.5 s × (f_low/f)^½
  // the sounds of instrument 8, from the data: partials in Hz, amplitudes, decays, and the stiffnesses (exact) where the data has them
  function ringSound(kind) {
    var R = DATA.rings, out;
    var pluck = R.solved.pluck.map(ratio); // the character expansion: 2/12 for the pairs k, −k and 1/12 for k = 6
    if (kind === 'solved' || kind === 'nn') {
      var sp = kind === 'solved' ? R.solved.spectrum : R.nn.spectrum, f1 = R.solved.f1;
      out = { freqs: sp.map(function (k) { return f1 * k; }), amps: pluck.slice(), weights: kind === 'solved' ? R.solved.weights_exact : null, negative: kind === 'solved' ? R.solved.weights.filter(function (w) { return w < 0; }).length : 0 };
      out.taus = out.freqs.map(function (f) { return tauBell(f, f1, R.bell12.tau1); });
    } else if (kind === 'pos7' || kind === 'pos4') {
      var set = R[kind].set, unit = R[kind].unit;
      out = { freqs: set.assignment.map(function (k) { return unit * k; }), amps: pluck.slice(), weights: set.weights_exact, negative: set.weights.filter(function (w) { return w < 0; }).length };
      out.taus = out.freqs.map(function (f) { return tauRing(f, Math.min.apply(null, out.freqs)); });
    } else if (kind === 'ringA') {
      out = { freqs: R.ringA.hz.slice(), amps: R.ringA.amps.map(function (x) { return Math.abs(x); }), weights: null, negative: 0 };
      out.taus = out.freqs.map(function (f) { return tauRing(f, Math.min.apply(null, out.freqs)); });
    } else if (kind === 'ringB') {
      out = { freqs: R.ringB.hz.slice(), amps: R.ringB.hz.map(function () { return 1 / R.ringB.hz.length; }), weights: null, negative: 0 };
      out.taus = out.freqs.map(function (f) { return tauRing(f, Math.min.apply(null, out.freqs)); });
    } else {
      var B = kind === 'bell12' ? R.bell12 : R.bell3, lv = B.levels.filter(function (l) { return l.j > 0; });
      out = { freqs: lv.map(function (l) { return B.f1 * l.ratio; }), amps: lv.map(function (l) { return l.weight; }), weights: lv.map(function (l) { return l.weight_exact; }), negative: 0 };
      out.taus = out.freqs.map(function (f) { return tauBell(f, B.f1, B.tau1); });
    }
    return out;
  }
  function playRing(ac, dest, t, kind, dur, track) { var r = ringSound(kind); bellTone(ac, dest, t, r.freqs, r.amps, r.taus, dur, 0.9, track); return dur; }
  // the rows: a row from its interval sequence (one character per interval, T = 10, E = 11), its intervals, the voicing
  // rule of audio/INDEX.md, its retrograde and inversion, and R = T₆
  function rowPcs(seq) { var pcs = [0], x = 0; for (var i = 0; i < seq.length; i++) { var c = seq[i], d = c === 'T' ? 10 : c === 'E' ? 11 : +c; x = (x + d) % 12; pcs.push(x); } return pcs; }
  function rowIntervals(pcs) { var out = []; for (var j = 0; j + 1 < pcs.length; j++) out.push(((pcs[j + 1] - pcs[j]) % 12 + 12) % 12); return out; }
  function rowSeq(pcs) { return rowIntervals(pcs).map(function (d) { return d === 10 ? 'T' : d === 11 ? 'E' : String(d); }).join(''); }
  function voicing(pcs) { var m = [60 + pcs[0]], iv = rowIntervals(pcs); for (var j = 0; j < iv.length; j++) { var i = iv[j]; m.push(m[j] + (i <= 5 ? i : i >= 7 ? i - 12 : 6)); } return m; }
  function retrograde(pcs) { return pcs.slice().reverse(); }
  function inversion(pcs) { return pcs.map(function (p) { return (12 - p) % 12; }); }
  function isRT6(pcs) { var r = retrograde(pcs); return r.every(function (p, j) { return p === (pcs[j] + 6) % 12; }); }
  function playRow(ac, dest, t, midis, noteDur, track) {
    var lev = 0.95 / sumOf(AMP4);
    midis.forEach(function (m, j) { tone(ac, dest, t + j * noteDur, noteDur, midiHz(m), HARM4, AMP4, lev, null, track); });
    return midis.length * noteDur;
  }

  window.SDV_ENGINE = { master: master, tone: tone, hit: hit, freqOf: freqOf, intervalVector: intervalVector, dftAbs: dftAbs, bjorklund: bjorklund, chainFreqs: chainFreqs, triads: triads, startVoices: startVoices, moveVoices: moveVoices, driftCents: driftCents, playChord: playChord, playVoices: playVoices, scheduleRhythm: scheduleRhythm, chainModes: chainModes, ringModes: ringModes, playPartials: playPartials, playGliss: playGliss, ratio: ratio,
    crtMirror: crtMirror, mirror7: mirror7, crtCoords: crtCoords, playSeq: playSeq, bellTone: bellTone, ringSound: ringSound, playRing: playRing, rowPcs: rowPcs, rowIntervals: rowIntervals, rowSeq: rowSeq, voicing: voicing, retrograde: retrograde, inversion: inversion, isRT6: isRT6, playRow: playRow, midiHz: midiHz };
  if (!DATA || typeof document === 'undefined') return;

  // ------------------------------------------------------------------ the page: one AudioContext, made on the first click
  var AC = null, OUT = null, ACTIVE = [], TIMERS = [], RAF = [];
  function ac() {
    if (!AC) { var C = window.AudioContext || window.webkitAudioContext; if (!C) return null; AC = new C(); OUT = master(AC); }
    if (AC.state === 'suspended') AC.resume();
    return AC;
  }
  function stopAll() {
    ACTIVE.forEach(function (o) { try { o.stop(); } catch (e) { /* already stopped */ } });
    ACTIVE = [];
    TIMERS.forEach(clearTimeout); TIMERS = [];
    RAF.forEach(function (f) { f.stop = true; }); RAF = [];
    document.querySelectorAll('.tz .tri.on').forEach(function (n) { n.classList.remove('on'); });
  }
  function later(ms, fn) { TIMERS.push(setTimeout(fn, ms)); }
  function el(tag, attrs, parent) { var e = document.createElementNS(SVGNS, tag); for (var k in attrs) e.setAttribute(k, attrs[k]); if (parent) parent.appendChild(e); return e; }
  function q(root, sel) { return root.querySelector(sel); }
  function fmt(x, d) { return (Math.round(x * Math.pow(10, d)) / Math.pow(10, d)).toFixed(d); }
  function segValue(seg) { var b = seg.querySelector('[aria-checked="true"]'); return b ? b.getAttribute('data-v') : null; }
  function bindSeg(seg, on) {
    seg.addEventListener('click', function (e) { var b = e.target.closest('button[data-v]'); if (!b) return; seg.querySelectorAll('button').forEach(function (x) { x.setAttribute('aria-checked', x === b ? 'true' : 'false'); }); if (on) on(b.getAttribute('data-v')); });
  }
  // a label of the page's language: the hidden span data-s=<id> the build filled from the string table
  function Lb(root, id) { var e = root.querySelector('[data-s="' + id + '"]'); return e ? e.textContent : ''; }
  function ariaOf(box) { return box.getAttribute('aria-label') || ''; }
  function presetBtn(label, title, fn) { var b = document.createElement('button'); b.type = 'button'; b.className = 'btn'; b.textContent = label; if (title) b.title = title; b.addEventListener('click', fn); return b; }

  // ---------------------------------------------------------------- 1. the clock
  function initClock(root) {
    var set = [], tuningSeg = q(root, '[data-tuning]');
    var pcsBox = q(root, '[data-pcs]'), dial = q(root, '[data-dial]');
    var buttons = NAMES.map(function (nm, pc) {
      var b = document.createElement('button'); b.type = 'button'; b.textContent = nm; b.setAttribute('aria-pressed', 'false'); b.setAttribute('aria-label', nm);
      b.addEventListener('click', function () { toggle(pc); });
      pcsBox.appendChild(b); return b;
    });
    var svg = el('svg', { viewBox: '0 0 300 300', role: 'img', 'aria-label': ariaOf(dial) }, dial);
    el('circle', { cx: 150, cy: 150, r: 112, fill: 'none', class: 'svg-rule', 'stroke-width': 1.5 }, svg);
    var poly = el('polygon', { points: '', fill: 'none', class: 'svg-accent', 'stroke-width': 2.2, 'stroke-linejoin': 'round' }, svg);
    var dots = NAMES.map(function (nm, pc) {
      var a = 2 * Math.PI * pc / 12, x = 150 + 112 * Math.sin(a), y = 150 - 112 * Math.cos(a);
      var g = el('g', { class: 'pc-dot', tabindex: '-1', style: 'cursor:pointer' }, svg);
      var c = el('circle', { cx: x, cy: y, r: 15, fill: 'var(--panel)', stroke: 'var(--ink-2)', 'stroke-width': 1.3 }, g);
      var t = el('text', { x: x, y: y + 0.5, 'text-anchor': 'middle', 'dominant-baseline': 'central', class: 'lbl-ink' }, g); t.textContent = nm;
      g.addEventListener('click', function () { toggle(pc); });
      return { c: c, t: t, x: x, y: y };
    });
    function toggle(pc) { var i = set.indexOf(pc); if (i >= 0) set.splice(i, 1); else set.push(pc); set.sort(function (a, b) { return a - b; }); draw(); }
    function draw() {
      buttons.forEach(function (b, pc) { b.setAttribute('aria-pressed', set.indexOf(pc) >= 0 ? 'true' : 'false'); });
      dots.forEach(function (d, pc) { var on = set.indexOf(pc) >= 0; d.c.setAttribute('fill', on ? 'var(--accent)' : 'var(--panel)'); d.c.setAttribute('stroke', on ? 'var(--accent)' : 'var(--ink-2)'); d.t.setAttribute('style', on ? 'fill:var(--panel)' : ''); });
      poly.setAttribute('points', set.map(function (pc) { return dots[pc].x + ',' + dots[pc].y; }).join(' '));
      q(root, '[data-out="card"]').textContent = String(set.length);
      q(root, '[data-out="iv"]').textContent = set.length > 1 ? '⟨' + intervalVector(set).join(' ') + '⟩' : '—';
      var abs = dftAbs(set), named = null;
      DATA.dft.sets.forEach(function (s) { if (s.pcs.length === set.length && s.pcs.every(function (x, i) { return set[i] === x; })) named = s; });
      var max = Math.max(1, set.length), html = '<table><thead><tr><th>k</th><th>|f̂(k)|</th><th></th>' + (named ? '<th>|f̂(k)|²</th>' : '') + '</tr></thead><tbody>';
      for (var k = 1; k <= 6; k++) html += '<tr><td>' + k + '</td><td>' + fmt(abs[k], 4) + '</td><td class="bar-c"><span style="width:' + (100 * abs[k] / max).toFixed(1) + '%"></span></td>' + (named ? '<td>' + named.abs2[String(k)] + '</td>' : '') + '</tr>';
      q(root, '[data-out="dft"]').innerHTML = html + '</tbody></table>';
      var note = q(root, '[data-out="exactnote"]');
      note.hidden = !named;
      q(root, '[data-out="setname"]').textContent = named ? named.name : '';
    }
    function play(arp) {
      if (!set.length) return;
      var A = ac(); if (!A) return; stopAll();
      playChord(A, OUT, A.currentTime + 0.05, set, segValue(tuningSeg), 2.2, arp, ACTIVE);
    }
    root.querySelector('[data-act="chord"]').addEventListener('click', function () { play(false); });
    root.querySelector('[data-act="arp"]').addEventListener('click', function () { play(true); });
    root.querySelector('[data-act="clear"]').addEventListener('click', function () { set = []; draw(); });
    root.querySelector('[data-act="stop"]').addEventListener('click', stopAll);
    bindSeg(tuningSeg, null);
    var pb = q(root, '[data-presets]');
    DATA.dft.sets.forEach(function (s) { pb.appendChild(presetBtn(s.name, null, function () { set = s.pcs.slice(); draw(); play(false); })); });
    set = DATA.dft.sets[1].pcs.slice(); // the diatonic, as the page opens
    draw();
  }

  // ---------------------------------------------------------------- 2. the Tonnetz walk
  function initTonnetz(root) {
    var T = triads(), box = q(root, '[data-tz]'), tuningSeg = q(root, '[data-tuning]');
    var S = 92, ox = 30, oy = 24, W = 5.6 * S + 2 * ox, H = 2.7 * S + 2 * oy;
    var X = function (x) { return ox + x * S; }, Y = function (y) { return H - oy - y * S; };
    var svg = el('svg', { viewBox: '0 0 ' + W.toFixed(0) + ' ' + H.toFixed(0), role: 'img', 'aria-label': ariaOf(box) }, box);
    // the periods of the domain, (4, −1) and (0, 3) in the lattice (i, j), drawn at (i + j/2, j·√3/2)
    var P1 = [4 - 0.5, -Math.sqrt(3) / 2], P2 = [1.5, 3 * Math.sqrt(3) / 2], maxLen = 0;
    var gE = el('g', {}, svg);
    DATA.plr.edges.forEach(function (e) {
      var a = T.byName[e.a], b = T.byName[e.b], best = null;
      for (var m = -1; m <= 1; m++) for (var n = -1; n <= 1; n++) { var bx = b.x + m * P1[0] + n * P2[0], by = b.y + m * P1[1] + n * P2[1], d = Math.hypot(bx - a.x, by - a.y); if (!best || d < best.d) best = { d: d, x: bx, y: by, m: m, n: n }; }
      maxLen = Math.max(maxLen, best.d);
      var wrap = best.m !== 0 || best.n !== 0;
      el('line', { x1: X(a.x), y1: Y(a.y), x2: X(best.x), y2: Y(best.y), class: e.label + (wrap ? ' wrap' : '') }, gE);
      if (wrap) el('line', { x1: X(b.x), y1: Y(b.y), x2: X(a.x - best.x + b.x), y2: Y(a.y - best.y + b.y), class: e.label + ' wrap' }, gE);
    });
    svg.setAttribute('data-maxedge', maxLen.toFixed(4));
    var nodes = {};
    T.list.forEach(function (t) {
      var g = el('g', { class: 'tri ' + t.type, tabindex: '0', role: 'button', 'aria-label': t.name + ' ' + t.type }, svg);
      el('circle', { cx: X(t.x), cy: Y(t.y), r: 17 }, g);
      var tx = el('text', { x: X(t.x), y: Y(t.y) }, g); tx.textContent = t.name;
      g.addEventListener('click', function () { jump(t); });
      g.addEventListener('keydown', function (ev) { if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); jump(t); } });
      nodes[t.name] = g;
    });
    var cur = T.byName.C, voices = null, word = '', drift = 0;
    function show(t) {
      Object.keys(nodes).forEach(function (k) { nodes[k].classList.toggle('on', k === t.name); });
      q(root, '[data-out="word"]').textContent = word || '—';
      q(root, '[data-out="drift"]').textContent = (segValue(tuningSeg) === 'just' ? (drift >= 0 ? '+' : '') + fmt(drift, 2) : '0.00') + ' ' + Lb(root, 'i2.cents');
      q(root, '[data-out="chord"]').textContent = t.name + ' (' + t.type + '): ' + voices.map(function (v) { return NAMES[v.pc] + ' ' + fmt(v.f, 2) + ' ' + Lb(root, 'ui.hz'); }).join(' · ');
    }
    function sound(dur) { var A = ac(); if (!A) return; playVoices(A, OUT, A.currentTime + 0.03, voices, dur || 0.9, ACTIVE); }
    function jump(t) { stopAll(); cur = t; word = ''; voices = startVoices(t, segValue(tuningSeg)); drift = segValue(tuningSeg) === 'just' ? driftCents(voices, t) : 0; show(t); sound(); }
    function move(letter) {
      var t = cur.nb[letter]; if (!t) return;
      if (!voices) voices = startVoices(cur, segValue(tuningSeg));
      voices = moveVoices(voices, t, segValue(tuningSeg));
      cur = t; word += letter;
      drift = segValue(tuningSeg) === 'just' ? driftCents(voices, t) : 0;
      show(t); sound(0.8);
    }
    ['P', 'L', 'R'].forEach(function (x) { root.querySelector('[data-act="' + x + '"]').addEventListener('click', function () { stopAll(); move(x); }); });
    function walk(names, closed) {
      stopAll();
      var tuning = segValue(tuningSeg), seq = names.slice();
      if (closed) seq.push(names[0]);
      var t0 = T.byName[seq[0]];
      cur = t0; word = ''; voices = startVoices(t0, tuning); drift = tuning === 'just' ? driftCents(voices, t0) : 0;
      var steps = [{ t: t0, v: voices, w: '', d: drift }];
      for (var i = 1; i < seq.length; i++) {
        var a = T.byName[seq[i - 1]], b = T.byName[seq[i]], letter = null;
        ['P', 'L', 'R'].forEach(function (x) { if (a.nb[x] === b) letter = x; });
        var v = moveVoices(steps[i - 1].v, b, tuning);
        steps.push({ t: b, v: v, w: steps[i - 1].w + letter, d: tuning === 'just' ? driftCents(v, b) : 0 });
      }
      if (closed && tuning === 'just') steps.push({ t: t0, v: startVoices(t0, tuning), w: steps[steps.length - 1].w, d: 0, ref: true });
      var A = ac(); if (!A) return;
      var step = 0.62, start = A.currentTime + 0.05;
      steps.forEach(function (s, i) {
        playVoices(A, OUT, start + i * step + (s.ref ? 0.25 : 0), s.v, s.ref ? 1.1 : step - 0.04, ACTIVE);
        later(1000 * (start - A.currentTime + i * step), function () { cur = s.t; voices = s.v; word = s.w; drift = s.d; show(s.t); });
      });
    }
    root.querySelector('[data-act="hex"]').addEventListener('click', function () { walk(DATA.plr.hexatonic[0], true); });
    root.querySelector('[data-act="oct"]').addEventListener('click', function () { walk(DATA.plr.octatonic[0], true); });
    root.querySelector('[data-act="beet"]').addEventListener('click', function () { walk(DATA.plr.beethoven, false); });
    root.querySelector('[data-act="lr"]').addEventListener('click', function () { walk(DATA.plr.LR_cycle, true); });
    root.querySelector('[data-act="stop"]').addEventListener('click', stopAll);
    bindSeg(tuningSeg, function () { voices = startVoices(cur, segValue(tuningSeg)); word = ''; drift = 0; show(cur); });
    voices = startVoices(cur, 'tet');
    show(cur);
  }

  // ---------------------------------------------------------------- 3. Euclidean rhythms
  function initRhythm(root) {
    var kIn = q(root, '[data-in="k"]'), nIn = q(root, '[data-in="n"]'), tIn = q(root, '[data-in="tempo"]'), neck = q(root, '[data-neck]');
    var svg = el('svg', { viewBox: '0 0 300 300', role: 'img', 'aria-label': ariaOf(neck) }, neck), dots = [];
    function clamp() { var n = Math.max(1, Math.min(16, Math.round(+nIn.value || 8))), k = Math.max(1, Math.min(n, Math.round(+kIn.value || 3))); nIn.value = n; kIn.value = k; return { k: k, n: n }; }
    function draw() {
      var p = clamp(), s = bjorklund(p.k, p.n);
      while (svg.firstChild) svg.removeChild(svg.firstChild);
      el('circle', { cx: 150, cy: 150, r: 110, fill: 'none', class: 'svg-rule', 'stroke-width': 1.5 }, svg);
      var pts = [];
      dots = [];
      for (var i = 0; i < p.n; i++) {
        var a = 2 * Math.PI * i / p.n, x = 150 + 110 * Math.sin(a), y = 150 - 110 * Math.cos(a);
        if (s[i] === 'x') pts.push(x + ',' + y);
        dots.push({ x: x, y: y, on: s[i] === 'x' });
      }
      if (pts.length > 1) el('polygon', { points: pts.join(' '), fill: 'none', class: 'svg-accent', 'stroke-width': 2 }, svg);
      dots.forEach(function (d, i) { d.c = el('circle', { cx: d.x, cy: d.y, r: d.on ? 11 : 6, fill: d.on ? 'var(--accent)' : 'var(--panel)', stroke: d.on ? 'var(--accent)' : 'var(--ink-2)', 'stroke-width': 1.4 }, svg); if (i === 0) el('text', { x: d.x, y: d.y - 20, 'text-anchor': 'middle', class: 'lbl' }, svg).textContent = '0'; });
      var t = el('text', { x: 150, y: 156, 'text-anchor': 'middle', class: 'lbl-ink' }, svg); t.textContent = 'E(' + p.k + ', ' + p.n + ')';
      q(root, '[data-out="str"]').textContent = s;
      var m = null; DATA.even.rhythms.forEach(function (r) { if (r.k === p.k && r.n === p.n) m = r; });
      var box = q(root, '[data-out="match"]');
      box.hidden = !(m && m.bjorklund === s);
      q(root, '[data-out="mname"]').textContent = m ? m.name + ' (' + m.bjorklund + ')' : '';
      return s;
    }
    [kIn, nIn].forEach(function (x) { x.addEventListener('input', draw); });
    root.querySelector('[data-act="play"]').addEventListener('click', function () {
      var s = draw(), A = ac(); if (!A) return; stopAll();
      var ppm = Math.max(60, Math.min(600, +tIn.value || 240)), start = A.currentTime + 0.06, dt = 60 / ppm, bars = 4;
      scheduleRhythm(A, OUT, start, s, ppm, bars, ACTIVE);
      for (var i = 0; i < bars * s.length; i++) (function (i) { later(1000 * (start - A.currentTime + i * dt), function () { dots.forEach(function (d, j) { d.c.setAttribute('stroke', j === i % s.length ? 'var(--warm)' : d.on ? 'var(--accent)' : 'var(--ink-2)'); d.c.setAttribute('stroke-width', j === i % s.length ? 4 : 1.4); }); }); })(i);
    });
    root.querySelector('[data-act="stop"]').addEventListener('click', stopAll);
    var pb = q(root, '[data-presets]');
    var tempo = { 8: 240, 12: 360, 16: 480 };
    DATA.even.rhythms.forEach(function (r) { pb.appendChild(presetBtn('E(' + r.k + ', ' + r.n + ')', r.name, function () { kIn.value = r.k; nIn.value = r.n; tIn.value = tempo[r.n] || 240; draw(); root.querySelector('[data-act="play"]').click(); })); });
    draw();
  }

  // ---------------------------------------------------------------- 4. the chain and the ring
  function initChain(root) {
    var nIn = q(root, '[data-in="N"]'), sel = q(root, '[data-in="body"]'), box = q(root, '[data-modes]');
    // the bodies are the page's options (strings of the page's language); the stiff string's B is the data's
    var stiffOpt = sel.querySelector('option[value="stiff"]'); if (stiffOpt) stiffOpt.textContent = stiffOpt.textContent + ' (B = ' + DATA.partials.stiff.B + ')';
    var svg = el('svg', { viewBox: '0 0 300 300', role: 'img', 'aria-label': ariaOf(box) }, box), rows = [];
    function N() { var n = Math.max(1, Math.min(8, Math.round(+nIn.value || 5))); nIn.value = n; return n; }
    function draw(hi) {
      var n = N();
      while (svg.firstChild) svg.removeChild(svg.firstChild);
      rows = [];
      var h = 280 / n;
      for (var k = 1; k <= n; k++) {
        var y0 = 10 + (k - 0.5) * h, pts = [];
        for (var j = 0; j <= n + 1; j++) { var x = 20 + 260 * j / (n + 1), y = y0 - 0.38 * h * Math.sin(k * Math.PI * j / (n + 1)); pts.push(x.toFixed(1) + ',' + y.toFixed(1)); }
        el('line', { x1: 20, y1: y0, x2: 280, y2: y0, class: 'svg-rule', 'stroke-width': 1 }, svg);
        var pl = el('polyline', { points: pts.join(' '), fill: 'none', stroke: k === hi ? 'var(--warm)' : 'var(--accent)', 'stroke-width': k === hi ? 3 : 1.8 }, svg);
        for (var jj = 1; jj <= n; jj++) el('circle', { cx: 20 + 260 * jj / (n + 1), cy: y0 - 0.38 * h * Math.sin(k * Math.PI * jj / (n + 1)), r: 3.4, class: 'svg-fill-ink' }, svg);
        rows.push(pl);
      }
      var P = DATA.chain.P[String(n)];
      q(root, '[data-out="exact"]').textContent = P ? P.omega2.join(', ') : chainOmegas(n).map(function (w) { return fmt(w * w, 6); }).join(', ');
      q(root, '[data-out="freqs"]').textContent = chainFreqs(n, 220).map(function (f) { return fmt(f, 2); }).join(' · ') + ' ' + Lb(root, 'ui.hz');
    }
    nIn.addEventListener('input', function () { draw(0); });
    root.querySelector('[data-act="chain"]').addEventListener('click', function () {
      var A = ac(); if (!A) return; stopAll(); var n = N(), start = A.currentTime + 0.05;
      chainModes(A, OUT, start, n, ACTIVE); draw(0);
      for (var k = 1; k <= n; k++) (function (k) { later(1000 * (start - A.currentTime + (k - 1) * 0.55), function () { draw(k); }); })(k);
      later(1000 * (start - A.currentTime + n * 0.55), function () { draw(0); });
    });
    root.querySelector('[data-act="ring"]').addEventListener('click', function () {
      var A = ac(); if (!A) return; stopAll(); ringModes(A, OUT, A.currentTime + 0.05, ACTIVE);
      q(root, '[data-out="exact"]').textContent = DATA.chain.C12.omega2.join(', ');
      q(root, '[data-out="freqs"]').textContent = DATA.chain.C12.omega2_float.map(function (w2) { return fmt(440 * Math.sqrt(w2), 2); }).join(' · ') + ' ' + Lb(root, 'ui.hz');
    });
    root.querySelector('[data-act="tone"]').addEventListener('click', function () {
      var A = ac(); if (!A) return; stopAll(); playPartials(A, OUT, A.currentTime + 0.05, sel.value, ACTIVE);
      q(root, '[data-out="freqs"]').textContent = bodyPartials(sel.value).map(function (r) { return fmt(220 * r, 2); }).join(' · ') + ' ' + Lb(root, 'ui.hz');
    });
    root.querySelector('[data-act="stop"]').addEventListener('click', stopAll);
    draw(0);
  }

  // ---------------------------------------------------------------- 5. the dissonance glissando
  function initGliss(root) {
    var C = DATA.curve, box = q(root, '[data-curve]'), seg = q(root, '[data-timbre]');
    var W = 640, H = 230, L = 40, Rm = 14, T = 26, B = 34;
    var svg = el('svg', { viewBox: '0 0 ' + W + ' ' + H, role: 'img', 'aria-label': ariaOf(box) }, box), marker = null, path = null, gMin = null;
    var rx = function (r) { return L + (W - L - Rm) * (r - 1) / 1.3; };
    function draw() {
      while (svg.firstChild) svg.removeChild(svg.firstChild);
      var bar = segValue(seg) === 'bar', D = bar ? C.D_bar : C.D_harmonic, max = 0;
      D.forEach(function (d) { if (d > max) max = d; });
      var ry = function (d) { return T + (H - T - B) * (1 - d / max); };
      el('line', { x1: L, y1: H - B, x2: W - Rm, y2: H - B, class: 'svg-rule', 'stroke-width': 1 }, svg);
      [1, 1.25, 1.5, 1.75, 2, 2.25].forEach(function (r) { el('line', { x1: rx(r), y1: H - B, x2: rx(r), y2: H - B + 5, class: 'svg-rule' }, svg); el('text', { x: rx(r), y: H - B + 18, 'text-anchor': 'middle', class: 'lbl' }, svg).textContent = String(r); });
      var d = '';
      for (var i = 0; i < C.r.length; i += 2) d += (i ? 'L' : 'M') + rx(C.r[i]).toFixed(1) + ' ' + ry(D[i]).toFixed(1);
      path = el('path', { d: d, fill: 'none', class: 'svg-accent', 'stroke-width': 2 }, svg);
      gMin = el('g', {}, svg);
      (bar ? C.minima_bar.filter(function (m) { return m.kind === 'corner'; }) : C.minima_harmonic).forEach(function (m) {
        el('line', { x1: rx(m.r), y1: T - 4, x2: rx(m.r), y2: H - B, class: 'svg-rule', 'stroke-dasharray': '2 3' }, gMin);
        el('text', { x: rx(m.r), y: T - 8, 'text-anchor': 'middle', class: 'lbl' }, gMin).textContent = m.just || m.r.toFixed(4);
      });
      marker = el('circle', { cx: rx(1), cy: ry(D[0]), r: 6, class: 'svg-warm' }, svg);
      marker.dataset.max = max;
    }
    function at(r) {
      var bar = segValue(seg) === 'bar', D = bar ? C.D_bar : C.D_harmonic, i = Math.max(0, Math.min(C.r.length - 1, Math.round((r - 1) / 1.3 * (C.r.length - 1))));
      var max = +marker.dataset.max;
      marker.setAttribute('cx', rx(r)); marker.setAttribute('cy', T + (H - T - B) * (1 - D[i] / max));
      q(root, '[data-out="r"]').textContent = 'r = ' + fmt(r, 4) + ' · ' + fmt(r * C.f1, 2) + ' ' + Lb(root, 'ui.hz');
    }
    bindSeg(seg, draw);
    root.querySelector('[data-act="play"]').addEventListener('click', function () {
      var A = ac(); if (!A) return; stopAll(); draw();
      var start = A.currentTime + 0.05, job = { stop: false };
      playGliss(A, OUT, start, segValue(seg), ACTIVE);
      RAF.push(job);
      (function tick() {
        if (job.stop) return;
        var t = A.currentTime - start, r = t < 0.5 ? 1 : t < 7 ? Math.pow(2, (t - 0.5) / 6.5) : 2;
        at(r);
        if (t < 8.05) requestAnimationFrame(tick);
      })();
    });
    root.querySelector('[data-act="stop"]').addEventListener('click', stopAll);
    draw(); at(1);
  }

  // ---------------------------------------------------------------- 6. the commas
  function initCommas(root) {
    var a = amps6();
    function go(kind) {
      var A = ac(); if (!A) return; stopAll(); var t = A.currentTime + 0.05, f1 = 220, f2, beat, txt;
      if (kind === 'just' || kind === 'tet') {
        f2 = kind === 'just' ? 330 : 220 * Math.pow(2, 7 / 12);
        var lev = 0.95 / (2 * sumOf(a));
        tone(A, OUT, t, 3.2, f1, HARM6, a, lev, null, ACTIVE); tone(A, OUT, t, 3.2, f2, HARM6, a, lev, null, ACTIVE);
        beat = Math.abs(3 * f1 - 2 * f2); txt = fmt(f1, 2) + ' + ' + fmt(f2, 4) + ' ' + Lb(root, 'ui.hz') + ' · |3f₁ − 2f₂|';
      } else if (kind === 'comma') {
        f2 = f1 * ratio(DATA.commas.Pythagorean);
        tone(A, OUT, t, 3.2, f1, [1], [1], 0.45, null, ACTIVE); tone(A, OUT, t, 3.2, f2, [1], [1], 0.45, null, ACTIVE);
        beat = Math.abs(f2 - f1); txt = fmt(f1, 2) + ' + ' + fmt(f2, 4) + ' ' + Lb(root, 'ui.hz') + ' · ' + DATA.commas.Pythagorean + ' · |f₂ − f₁|';
      } else {
        var just = kind === 'chordj', fs = just ? [1, 5 / 4, 3 / 2].map(function (r) { return DATA.C4 * r; }) : [0, 4, 7].map(function (s) { return DATA.C4 * Math.pow(2, s / 12); });
        playVoices(A, OUT, t, fs.map(function (f) { return { f: f }; }), 3.4, ACTIVE);
        beat = Math.abs(5 * fs[0] - 4 * fs[1]); txt = fs.map(function (f) { return fmt(f, 2); }).join(' · ') + ' ' + Lb(root, 'ui.hz') + ' · |5C − 4E|' + (just ? '' : ' (cents_table.json: ' + fmt(DATA.chordBeats['5C:4E'], 4) + ')');
      }
      q(root, '[data-out="beat"]').textContent = fmt(beat, 6) + ' ' + Lb(root, 'ui.hz');
      q(root, '[data-out="freqs"]').textContent = txt;
    }
    ['just', 'tet', 'comma', 'chordj', 'chordt'].forEach(function (k) { root.querySelector('[data-act="' + k + '"]').addEventListener('click', function () { go(k); }); });
    root.querySelector('[data-act="stop"]').addEventListener('click', stopAll);
  }

  // ---------------------------------------------------------------- 7. the Tonnetz as the CRT grid
  function initCrt(root) {
    var box = q(root, '[data-crt]'), soundSeg = q(root, '[data-sound]'), cells = DATA.crt.cells;
    var CW = 86, CH = 70, ox = 34, oy = 22, W = ox + 4 * CW + 10, H = oy + 3 * CH + 10;
    var svg = el('svg', { viewBox: '0 0 ' + W + ' ' + H, role: 'img', 'aria-label': ariaOf(box) }, box);
    var X = function (b) { return ox + b * CW; }, Y = function (a) { return oy + a * CH; };
    // the axes: a (the major thirds, ℤ₃) down the rows, b (the minor thirds, ℤ₄) along the columns
    for (var b = 0; b < 4; b++) el('text', { x: X(b) + CW / 2, y: oy - 8, 'text-anchor': 'middle', class: 'axis' }, svg).textContent = 'b = ' + b;
    for (var a = 0; a < 3; a++) el('text', { x: ox - 6, y: Y(a) + CH / 2, 'text-anchor': 'end', 'dominant-baseline': 'central', class: 'axis' }, svg).textContent = 'a = ' + a;
    var gLines = el('g', {}, svg), gArrows = el('g', {}, svg), nodes = {};
    cells.forEach(function (c) {
      var g = el('g', { class: 'cell', tabindex: '0', role: 'button', 'aria-label': c.name + ' (' + c.a_major_thirds + ', ' + c.b_minor_thirds + ')' }, svg);
      el('rect', { x: X(c.b_minor_thirds) + 3, y: Y(c.a_major_thirds) + 3, width: CW - 6, height: CH - 6, rx: 8 }, g);
      el('text', { x: X(c.b_minor_thirds) + CW / 2, y: Y(c.a_major_thirds) + CH / 2 - 4 }, g).textContent = c.name;
      el('text', { x: X(c.b_minor_thirds) + CW / 2, y: Y(c.a_major_thirds) + CH - 12, class: 'ab' }, g).textContent = '(' + c.a_major_thirds + ', ' + c.b_minor_thirds + ') · ' + c.pc;
      g.addEventListener('click', function () { toggle(c.pc, true); });
      g.addEventListener('keydown', function (ev) { if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); toggle(c.pc, true); } });
      nodes[c.pc] = g;
    });
    var centre = function (pc) { var ab = crtCoords(pc); return [X(ab[1]) + CW / 2, Y(ab[0]) + CH / 2]; };
    var set = [], image = [];
    function sorted(a) { return a.slice().sort(function (x, y) { return x - y; }); }
    function draw() {
      cells.forEach(function (c) { nodes[c.pc].classList.toggle('on', set.indexOf(c.pc) >= 0); nodes[c.pc].classList.toggle('img', image.indexOf(c.pc) >= 0); });
      q(root, '[data-out="set"]').textContent = set.length ? sorted(set).map(function (pc) { return NAMES[pc]; }).join(' ') + ' · {' + sorted(set).join(', ') + '}' : '—';
      q(root, '[data-out="coords"]').textContent = set.length ? sorted(set).map(function (pc) { var ab = crtCoords(pc); return '(' + ab[0] + ', ' + ab[1] + ')'; }).join(' ') : '—';
      q(root, '[data-out="image"]').textContent = image.length ? image.map(function (pc) { return NAMES[pc]; }).join(' ') + ' · {' + image.join(', ') + '}' : '—';
      var rule = crtMirror();
      q(root, '[data-out="rule"]').textContent = rule ? rule.replace('->', '↦').replace(/-([ab])/g, '−$1') + (rule === DATA.crt.mirror_x7 ? ' = crt_tonnetz.json' : ' ≠ crt_tonnetz.json') : '?';
    }
    function clearLines() { while (gLines.firstChild) gLines.removeChild(gLines.firstChild); while (gArrows.firstChild) gArrows.removeChild(gArrows.firstChild); }
    function toggle(pc, play) {
      var i = set.indexOf(pc); if (i >= 0) set.splice(i, 1); else set.push(pc);
      image = []; clearLines(); draw();
      if (play) { var A = ac(); if (!A) return; stopAll(); playSeq(A, OUT, A.currentTime + 0.03, [pc], 0.5, segValue(soundSeg) === 'triad', ACTIVE); }
    }
    function light(seq, step, start, A) { seq.forEach(function (pc, i) { later(1000 * (start - A.currentTime + i * step), function () { cells.forEach(function (c) { nodes[c.pc].classList.toggle('on', c.pc === pc); }); }); }); later(1000 * (start - A.currentTime + seq.length * step), draw); }
    root.querySelector('[data-act="fifths"]').addEventListener('click', function () {
      var A = ac(); if (!A) return; stopAll(); image = []; clearLines();
      var path = DATA.crt.fifths_path_ab, pcs = DATA.crt.fifths_pcs, step = 0.32, start = A.currentTime + 0.05;
      for (var i = 0; i + 1 < path.length; i++) { var p = path[i], n = path[i + 1]; if (Math.abs(n[0] - p[0]) <= 1 && Math.abs(n[1] - p[1]) <= 1) el('line', { x1: X(p[1]) + CW / 2, y1: Y(p[0]) + CH / 2, x2: X(n[1]) + CW / 2, y2: Y(n[0]) + CH / 2, class: 'path' }, gLines); }
      playSeq(A, OUT, start, pcs, step, false, ACTIVE);
      light(pcs, step, start, A);
    });
    root.querySelector('[data-act="cycles"]').addEventListener('click', function () {
      var A = ac(); if (!A) return; stopAll(); image = []; clearLines();
      var z4 = DATA.crt.H1.minor_thirds_Z4.pcs, z3 = DATA.crt.H1.augmented_Z3.pcs, t = A.currentTime + 0.05, a = amps6();
      var chord = function (pcs, t0, dur) { var lev = 0.95 / (pcs.length * sumOf(a)); pcs.forEach(function (pc) { tone(A, OUT, t0, dur, freqOf(pc, 'tet'), HARM6, a, lev, null, ACTIVE); }); };
      chord(z4, t, 1.1); later(1000 * (t - A.currentTime), function () { set = z4.slice(); draw(); });
      playSeq(A, OUT, t + 1.25, z4, 0.3, false, ACTIVE); light(z4, 0.3, t + 1.25, A);
      var t2 = t + 1.25 + 4 * 0.3 + 0.4;
      chord(z3, t2, 1.1); later(1000 * (t2 - A.currentTime), function () { set = z3.slice(); draw(); });
      playSeq(A, OUT, t2 + 1.25, z3, 0.3, false, ACTIVE); light(z3, 0.3, t2 + 1.25, A);
    });
    root.querySelector('[data-act="mirror"]').addEventListener('click', function () {
      if (!set.length) return;
      var A = ac(); if (!A) return; stopAll(); clearLines();
      var img = mirror7(set), t = A.currentTime + 0.05, a = amps6(), lev = 0.95 / (set.length * sumOf(a));
      set.forEach(function (pc) { tone(A, OUT, t, 1.2, freqOf(pc, 'tet'), HARM6, a, lev, null, ACTIVE); });
      img.forEach(function (pc) { tone(A, OUT, t + 1.4, 1.2, freqOf(pc, 'tet'), HARM6, a, lev, null, ACTIVE); });
      set.forEach(function (pc) { var p = centre(pc), n = centre((7 * pc) % 12); if (p[0] !== n[0] || p[1] !== n[1]) el('line', { x1: p[0], y1: p[1], x2: n[0], y2: n[1], class: 'arrow', 'marker-end': 'url(#crt-arrow)' }, gArrows); });
      image = img; draw();
    });
    var defs = el('defs', {}, svg), marker = el('marker', { id: 'crt-arrow', viewBox: '0 0 10 10', refX: '9', refY: '5', markerWidth: '7', markerHeight: '7', orient: 'auto-start-reverse' }, defs);
    el('path', { d: 'M 0 0 L 10 5 L 0 10 z', class: 'svg-fill-accent' }, marker);
    root.querySelector('[data-act="clear"]').addEventListener('click', function () { set = []; image = []; clearLines(); draw(); });
    root.querySelector('[data-act="stop"]').addEventListener('click', stopAll);
    var presets = { diatonic: [0, 2, 4, 5, 7, 9, 11], aug: DATA.crt.H1.augmented_Z3.pcs, dim: DATA.crt.H1.minor_thirds_Z4.pcs, whole: [0, 2, 4, 6, 8, 10] };
    Object.keys(presets).forEach(function (k) { root.querySelector('[data-act="' + k + '"]').addEventListener('click', function () { set = presets[k].slice(); image = []; clearLines(); draw(); var A = ac(); if (!A) return; stopAll(); playChord(A, OUT, A.currentTime + 0.05, set, 'tet', 1.6, false, ACTIVE); }); });
    bindSeg(soundSeg, null);
    draw();
  }

  // ---------------------------------------------------------------- 8. the two rings and the bell
  function initRings(root) {
    var box = q(root, '[data-strip]'), W = 640, H = 200, Lm = 36, Rm = 12, T = 14, B = 30, FMAX = 1400;
    var svg = el('svg', { viewBox: '0 0 ' + W + ' ' + H, role: 'img', 'aria-label': ariaOf(box) }, box);
    var fx = function (f) { return Lm + (W - Lm - Rm) * f / FMAX; };
    function draw(kind) {
      while (svg.firstChild) svg.removeChild(svg.firstChild);
      el('line', { x1: Lm, y1: H - B, x2: W - Rm, y2: H - B, class: 'svg-rule', 'stroke-width': 1 }, svg);
      for (var f = 0; f <= FMAX; f += 220) { el('line', { x1: fx(f), y1: H - B, x2: fx(f), y2: H - B + 5, class: 'svg-rule' }, svg); el('text', { x: fx(f), y: H - B + 18, 'text-anchor': 'middle', class: 'lbl' }, svg).textContent = String(f); }
      if (!kind) return;
      var r = ringSound(kind), max = Math.max.apply(null, r.amps), loud = r.amps.indexOf(max);
      r.freqs.forEach(function (f, k) { var h = (H - T - B) * r.amps[k] / max; el('line', { x1: fx(f), y1: H - B, x2: fx(f), y2: H - B - h, class: 'stem' + (k === loud ? ' loud' : '') }, svg); });
      el('text', { x: fx(r.freqs[loud]), y: H - B - (H - T - B) - 2, 'text-anchor': 'middle', class: 'lbl' }, svg).textContent = fmt(r.freqs[loud], 2);
      q(root, '[data-out="partials"]').textContent = r.freqs.map(function (f) { return fmt(f, 2); }).join(' · ') + ' ' + Lb(root, 'ui.hz');
      q(root, '[data-out="weights"]').textContent = r.weights ? r.weights.join(', ') : '—';
      q(root, '[data-out="loudest"]').textContent = fmt(r.freqs[loud], 2) + ' ' + Lb(root, 'ui.hz') + ' (' + fmt(r.amps[loud] / sumOf(r.amps), 3) + ')';
      var note = { solved: 'i8.note.solved', nn: 'i8.note.nn', pos7: 'i8.note.pos', pos4: 'i8.note.pos', ringA: 'i8.note.ab', ringB: 'i8.note.ab', bell12: 'i8.note.bell', bell3: 'i8.note.bell3' }[kind], txt = Lb(root, note);
      if (kind === 'nn') { // the page's ω_k = 2 sin(πk/12), as ratios to ω₁, against the data
        var diff = 0; DATA.rings.nn.spectrum.forEach(function (x, i) { var w = Math.sin((i + 1) * Math.PI / 12) / Math.sin(Math.PI / 12); diff = Math.max(diff, Math.abs(w - x)); });
        txt += ' ' + diff.toExponential(2);
      }
      q(root, '[data-out="note"]').textContent = txt;
    }
    ['solved', 'nn', 'pos7', 'pos4', 'ringA', 'ringB', 'bell12', 'bell3'].forEach(function (k) {
      root.querySelector('[data-act="' + k + '"]').addEventListener('click', function () { var A = ac(); if (!A) return; stopAll(); draw(k); playRing(A, OUT, A.currentTime + 0.05, k, 3.3, ACTIVE); });
    });
    root.querySelector('[data-act="stop"]').addEventListener('click', stopAll);
    draw('solved');
  }

  // ---------------------------------------------------------------- 9. the all-interval rows
  function initRows(root) {
    var R = DATA.rows, box = q(root, '[data-staff]'), idxIn = q(root, '[data-in="index"]'), lenSeg = q(root, '[data-len]');
    var W = 640, H = 220, Lm = 30, Rm = 12, T = 14, B = 24;
    var svg = el('svg', { viewBox: '0 0 ' + W + ' ' + H, role: 'img', 'aria-label': ariaOf(box) }, box);
    var state = { pcs: rowPcs(R.rows[0]), idx: 0 };
    var findIdx = function (pcs) { return R.rows.indexOf(rowSeq(pcs)); };
    function noteDur() { return +segValue(lenSeg) || 0.3; }
    function drawStaff(melody, melody2) {
      while (svg.firstChild) svg.removeChild(svg.firstChild);
      var all = melody.concat(melody2 || []), lo = Math.min.apply(null, all) - 1, hi = Math.max.apply(null, all) + 1, n = all.length;
      var x = function (j) { return Lm + (W - Lm - Rm) * (j + 0.5) / n; }, y = function (m) { return T + (H - T - B) * (hi - m) / (hi - lo); };
      for (var m = lo; m <= hi; m++) if (m % 12 === 0) { el('line', { x1: Lm, y1: y(m), x2: W - Rm, y2: y(m), class: 'svg-rule', 'stroke-dasharray': '2 3' }, svg); el('text', { x: Lm - 4, y: y(m) + 3, 'text-anchor': 'end', class: 'lbl' }, svg).textContent = 'C' + (m / 12 - 1); }
      var seg = function (mel, off, cls) {
        var d = ''; mel.forEach(function (m, j) { d += (j ? 'L' : 'M') + x(off + j).toFixed(1) + ' ' + y(m).toFixed(1); });
        el('path', { d: d, class: cls }, svg);
        mel.forEach(function (m, j) { el('circle', { cx: x(off + j), cy: y(m), r: 4.5, class: 'note' + (cls ? ' ' + cls : '') }, svg); });
      };
      seg(melody, 0, '');
      if (melody2) seg(melody2, melody.length, 'retro');
    }
    function show() {
      var pcs = state.pcs, iv = rowIntervals(pcs), midis = voicing(pcs), idx = state.idx;
      q(root, '[data-out="pcs"]').textContent = pcs.map(function (p) { return NAMES[p]; }).join(' ') + ' · ' + pcs.map(function (p) { return p === 10 ? 'T' : p === 11 ? 'E' : String(p); }).join(' ');
      q(root, '[data-out="ints"]').textContent = iv.join(' ') + ' · ' + rowSeq(pcs);
      q(root, '[data-out="melody"]').textContent = midis.map(function (m) { return NAMES[((m % 12) + 12) % 12] + (Math.floor(m / 12) - 1); }).join(' ') + ' · ' + midis.map(function (m) { return fmt(midiHz(m), 2); }).join(' · ') + ' ' + Lb(root, 'ui.hz');
      q(root, '[data-out="class"]').textContent = idx >= 0 ? Lb(root, 'i9.class.tir') + ' ' + R.class_TIR[idx] + ' / ' + R.counts.T_I_R + ' · ' + Lb(root, 'i9.class.g3') + ' ' + R.class_G3[idx] + ' / ' + R.counts.G3 : '—';
      if (idx >= 0) { var hn = R.hexachord_names[R.first_hexachord[idx]], hc = R.hexachords.filter(function (h) { return h.name === hn; })[0]; q(root, '[data-out="hex"]').textContent = hn + (hc ? ' ' + hc.prime_form + ' · ' + (R.types[hc.type] || hc.type) : '') + ' · ' + R.combinatoriality[idx]; } else q(root, '[data-out="hex"]').textContent = '—';
      q(root, '[data-out="sym"]').textContent = isRT6(pcs) ? Lb(root, 'i9.yes') : Lb(root, 'i9.no');
      drawStaff(midis);
    }
    function setRow(pcs) { state.pcs = pcs; state.idx = findIdx(pcs); if (state.idx >= 0) idxIn.value = state.idx + 1; show(); }
    function play(midis, midis2) {
      var A = ac(); if (!A) return; stopAll();
      var d = noteDur(), start = A.currentTime + 0.05;
      playRow(A, OUT, start, midis, d, ACTIVE);
      if (midis2) playRow(A, OUT, start + midis.length * d + 0.3, midis2, d, ACTIVE);
      drawStaff(midis, midis2);
    }
    idxIn.addEventListener('change', function () { var i = Math.max(1, Math.min(R.rows.length, Math.round(+idxIn.value || 1))); idxIn.value = i; setRow(rowPcs(R.rows[i - 1])); });
    root.querySelector('[data-act="row"]').addEventListener('click', function () { play(voicing(state.pcs)); });
    root.querySelector('[data-act="retro"]').addEventListener('click', function () { play(voicing(retrograde(state.pcs))); });
    root.querySelector('[data-act="inv"]').addEventListener('click', function () { play(voicing(inversion(state.pcs))); });
    root.querySelector('[data-act="rt6"]').addEventListener('click', function () { play(voicing(state.pcs), voicing(retrograde(state.pcs))); });
    root.querySelector('[data-act="berg"]').addEventListener('click', function () { setRow(R.berg.pcs.slice()); play(voicing(state.pcs)); });
    root.querySelector('[data-act="least"]').addEventListener('click', function () { setRow(rowPcs(R.rows[0])); play(voicing(state.pcs)); });
    root.querySelector('[data-act="greatest"]').addEventListener('click', function () { setRow(rowPcs(R.rows[R.rows.length - 1])); play(voicing(state.pcs)); });
    root.querySelector('[data-act="wedge"]').addEventListener('click', function () { setRow(R.wedge.pcs.slice()); play(voicing(state.pcs)); });
    root.querySelector('[data-act="stop"]').addEventListener('click', stopAll);
    bindSeg(lenSeg, null);
    setRow(R.berg.pcs.slice());
  }

  function init() {
    var map = { clock: initClock, tonnetz: initTonnetz, rhythm: initRhythm, chain: initChain, gliss: initGliss, commas: initCommas, crt: initCrt, rings: initRings, rows: initRows };
    document.querySelectorAll('[data-inst]').forEach(function (s) { var f = map[s.getAttribute('data-inst')]; if (f) f(s); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
