# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# mk_r6.py — from gen/content/it/MANIFEST_R6.json, the three narrators' assignment (r6_assign.json) and material files:
#   r6_E1_material.json: the rows of the kinetic triplet's cavity phase and of the O–X step (chapter layers), their chain headings,
#                        figure captions and script lines, the site strings that changed, and the targets of the layers chapter to re-read;
#   r6_E2_material.json: the strings of the two experiments extended (layers, spin);
#   r6_E3_material.json: the rows of the spin of sound on its probes (chapter spin), their chain heading, figure caption and script line,
#                        and the targets of the spin chapter and of the pages whose counts changed to re-read.
# Usage: python3 -I it/draft/mk_r6.py   (the packs' figure indexes are read for the captions: SDV_PACK_T, SDV_PACK_O, SDV_PACK_S or the delivered folders)
import json, os, re
DRAFT = os.path.dirname(os.path.abspath(__file__)); SITE = os.path.dirname(os.path.dirname(DRAFT))
IT = os.path.join(SITE, 'gen', 'content', 'it')
def J(p): return json.load(open(p, encoding='utf-8'))
def W(p, o):
    with open(p, 'w', encoding='utf-8') as f: f.write(json.dumps(o, ensure_ascii=False, indent=1) + '\n')
M = J(os.path.join(IT, 'MANIFEST_R6.json'))
R = {i['target']: i for i in J(os.path.join(IT, 'racconto.json'))['items']}
T = {i['target']: i for i in J(os.path.join(IT, 'titoli.json'))['items']}
S = {i['id']: i for i in J(os.path.join(IT, 'strings_it.json'))['strings']}
C1 = J(os.path.join(DRAFT, 'r4_C1_material.json')); D2 = J(os.path.join(DRAFT, 'r4_D2_material.json'))
rules = M['rules']
PACKS = {
    'fig_xb_triplet': (os.environ.get('SDV_PACK_T') or '/home/claude/deliver_r37/packs/xb-triplet-pending/pack', 'music_xb_triplet', "the kinetic triplet's cavity phase: the conversion of the X wave on the cutoff–resonance–cutoff triplet against the position of its L cutoff, with the hot electrons' layers in three forms and the warm fluid's, the maximum's shift and shortfall as the plasma cools, the minimum that stays a zero, the triplet stretched two and four times"),
    'fig_ox_step': (os.environ.get('SDV_PACK_O') or '/home/claude/deliver_r37/packs/ox-step-pending/pack', 'music_ox_step', "the O–X step: the cold plasma at oblique incidence on a density ramp, the 4 × 4 system of the tangential fields and its cutoffs, the ordinary wave turned into the slow extraordinary wave at X = 1 on MUS-161's ramp and its stretches against Mjølhus's formula, the whole cold chain to the upper hybrid layer"),
    'fig_spin_probes': (os.environ.get('SDV_PACK_S') or '/home/claude/deliver_r37/packs/spin-probes-pending/pack', 'music_spin_probes', "the spin of sound on its probes: the three-phase cube and its nodal diagonal, the triangle and the tetrahedron, the small sphere's entrainment and the thermal floor, the two spins of a Rayleigh wave, the deep-water wave's orbit and drift, the still point of the water tank, the Barnett bridge from the rotation of a surface wave to a spin"),
}
def caption_of(pack, fig):
    p = os.path.join(pack, 'figs', 'FIGURES_INDEX.md')
    if not os.path.exists(p): return None, None
    for line in open(p, encoding='utf-8'):
        if line.startswith('|') and fig in line:
            cells = [c.strip() for c in line.strip().strip('|').split(' | ')]
            if len(cells) >= 4: return cells[1], cells[3]
    return None, None
# the figures' titles: their captions, as release 3's narrators wrote the figures' lines (one or two sentences)
for t in M['titles']:
    m = re.match(r'^fig:(fig_\w+)$', t['target'])
    if m and m.group(1) in PACKS:
        pack, script, what = PACKS[m.group(1)]
        cap, rows = caption_of(pack, m.group(1))
        t['what'] = f"the Italian caption of the figure {m.group(1)}.svg (one to three sentences, as the other figures' captions in titoli.json: say what each panel shows, in the narrator's words, not a translation of the English caption)"
        t['length'] = '40–110 words'; t['where'] = 'its chapter page and pictures.html, under the figure'
        t['material'] = {'caption_en': cap, 'rows': rows, 'sample_it': T['fig:fig_two_fluid']['text'] if 'fig:fig_two_fluid' in T else None, 'sample_it_2': T.get('fig:fig_xb_ramp', {}).get('text')}
    m = re.match(r'^check:(music_\w+)$', t['target'])
    if m:
        for fig, (pack, script, what) in PACKS.items():
            if script == m.group(1):
                t['material']['note'] = f"say what the script computes ({what}); do not say that the rows are proposed or not merged: that is the work's bookkeeping, never the reader's"
                t['material']['sample_it'] = T.get('check:music_xb_ramp', T.get('check:music_layers', {})).get('text')
# the targets to re-read, with their current Italian
reread = []
for item in M['review']:
    for tg in [x.strip() for x in item['target'].split(',')]:
        cur = R.get(tg)
        reread.append({'target': tg, 'priority': item['priority'], 'why': item['why'], 'current_it': cur['text'] if cur else None, 'tells': cur.get('tells') if cur else None})
def is_spin(target):
    m = re.search(r'(MUS-\d{3})', target)
    if m: return int(m.group(1)[4:]) >= 213
    return any(k in target for k in ('spin-probes', 'fig_spin_probes', 'music_spin_probes', 'section:spin'))
narr_E1 = [n for n in M['narrations'] if not is_spin(n['target'])]
narr_E3 = [n for n in M['narrations'] if is_spin(n['target'])]
tit_E1 = [t for t in M['titles'] if not is_spin(t['target'])]
tit_E3 = [t for t in M['titles'] if is_spin(t['target'])]
re_E1 = [r for r in reread if r['target'] in ('section:layers', 'checks:light')]
re_E3 = [r for r in reread if r['target'] not in ('section:layers', 'checks:light')]
E1 = {
    'about': "Narrator E1: your targets with their English material (your part of MANIFEST_R6.json): the three rows of the kinetic triplet's cavity phase (MUS-200 … MUS-202) and the six of the O–X step (MUS-203 … MUS-208), narration and title each; the headings of their two chains; the captions of their two figures; the one-line titles of their two scripts; the site strings that are new or changed (with the previous Italian); and the narrations of the layers chapter and of the checks page to re-read (with their current Italian). Voice samples from the earlier narrators follow.",
    'rules': rules, 'narrations': narr_E1, 'titles': tit_E1, 'strings': M['strings_new'] + M['strings_changed'], 'check_only': re_E1,
    'chapter_layers_rows_it': {tg: T[tg]['text'] for tg in ['row:MUS-151', 'row:MUS-152', 'row:MUS-158', 'row:MUS-159', 'row:MUS-160', 'row:MUS-161', 'row:MUS-190', 'row:MUS-192', 'row:MUS-195', 'row:MUS-197'] if tg in T},
    'chapter_layers_narrations_it': {tg: R[tg]['text'] for tg in ['row:MUS-161', 'row:MUS-195', 'row:MUS-197', 'row:MUS-199'] if tg in R},
    'chapter_layers_narration_it': R['section:layers']['text'], 'chapter_layers_title_it': T['section:layers']['text'], 'chain_xb_ramp_title_it': T.get('chain:xb-ramp', {}).get('text'),
    'voice_samples': C1['voice_samples'],
}
ex = M['experiments']['strings']
byexp = {}
for s in ex: byexp.setdefault(s['experiment'], []).append(s)
E2 = {
    'about': "Narrator E2: the strings of the two experiments extended (your part of MANIFEST_R6.json, group \"experiments\"): the strings each experiment added, and those whose English changed (with the previous Italian in previousIt). The release-5 Italian of every other string of these two experiments is given for the terms and the voice, so that the pages read as one hand.",
    'rules': rules, 'narrations': [], 'titles': [], 'strings': ex, 'check_only': [],
    'strings_by_experiment': {k: {'title_it': S.get(f'exp.{k}.title', {}).get('text'), 'lead_it': S.get(f'exp.{k}.lead', {}).get('text'), 'strings': v} for k, v in byexp.items()},
    'release5_italian_of_these_experiments': {k: [{'id': i, 'en': None, 'it': S[i]['text']} for i in S if i.startswith(f'exp.{k}.') and not S[i].get('stub')] for k in byexp},
    'voice_samples': D2.get('voice_samples', C1['voice_samples']),
}
EN = {}
for k in byexp:
    for e in J(os.path.join(SITE, 'gen', 'exp', f'{k}.strings.json'))['strings']: EN[e['id']] = e['text']
for k, lst in E2['release5_italian_of_these_experiments'].items():
    for e in lst: e['en'] = EN.get(e['id'])
E3 = {
    'about': "Narrator E3: your targets with their English material (your part of MANIFEST_R6.json): the rows of the spin of sound on its probes (MUS-213 …), narration and title each; the heading of their chain; the caption of their figure; the one-line title of their script; and the narrations of the spin chapter and of the pages whose counts changed to re-read (with their current Italian). Voice samples from the earlier narrators follow.",
    'rules': rules, 'narrations': narr_E3, 'titles': tit_E3, 'strings': [], 'check_only': re_E3,
    'chapter_spin_rows_it': {tg: T[tg]['text'] for tg in ['row:MUS-060', 'row:MUS-062', 'row:MUS-063', 'row:MUS-065', 'row:MUS-066', 'row:MUS-068', 'row:MUS-087'] if tg in T},
    'chapter_spin_narrations_it': {tg: R[tg]['text'] for tg in ['row:MUS-063', 'row:MUS-066', 'row:MUS-087'] if tg in R},
    'chapter_spin_narration_it': R['section:spin']['text'], 'chapter_spin_title_it': T['section:spin']['text'], 'chain_spin_title_it': T.get('chain:spin', {}).get('text'),
    'page_experiment_narration_it': R.get('page:experiment', {}).get('text'),
    'voice_samples': C1['voice_samples'],
}
assign = {
    'E1': {'narrations': [n['target'] for n in narr_E1], 'titles': [t['target'] for t in tit_E1], 'strings': [s['id'] for s in E1['strings']], 'rewrite_narrations': [], 'rewrite_titles': [], 'check_only': [r['target'] for r in re_E1]},
    'E2': {'narrations': [], 'titles': [], 'strings': [s['id'] for s in ex], 'rewrite_narrations': [], 'rewrite_titles': [], 'check_only': []},
    'E3': {'narrations': [n['target'] for n in narr_E3], 'titles': [t['target'] for t in tit_E3], 'strings': [], 'rewrite_narrations': [], 'rewrite_titles': [], 'check_only': [r['target'] for r in re_E3]},
}
W(os.path.join(DRAFT, 'r6_assign.json'), assign); W(os.path.join(DRAFT, 'r6_E1_material.json'), E1); W(os.path.join(DRAFT, 'r6_E2_material.json'), E2); W(os.path.join(DRAFT, 'r6_E3_material.json'), E3)
print('E1', {k: len(v) for k, v in assign['E1'].items()}, 'E2', {k: len(v) for k, v in assign['E2'].items()}, 'E3', {k: len(v) for k, v in assign['E3'].items()})
