# The Sounding View, release 10 — deploying `out/`

`out/` is the whole site, static: English at the root (`index.html`), Italian under `it/`, the clips under `audio/` (Ogg and MP3), `site.css`, `site.js`, `experiments.js`, `sounds.js`, `sounds-data.js`, `version.json`, `404.html`. Nothing to build, nothing to install. Every link inside the site is relative, so it works at a domain's root or under a path; only `404.html` assumes the root.

## Vercel

The Vercel website does not take a zip; the command-line tool does, in one command, and a Git repository does it on every push.

**With the command line** (Node is needed once):

```
npm i -g vercel
vercel login
cd sounding-view-r10          # the folder that holds vercel.json and out/
vercel --prod
```

Answer the questions with the defaults (set up and deploy: yes; scope: yours; link to an existing project: no; project name: as you like; directory: `./`). `vercel.json` tells Vercel there is no framework and no build, and that `out/` is the site. The first run prints the public address; later runs of `vercel --prod` from the same folder update the same site.

**With a Git repository**: push this folder (with `vercel.json` and `out/`) to GitHub, import the repository at vercel.com → Add New → Project, change nothing (the framework is "Other", the build command empty, the output directory `out`), Deploy. Every later push redeploys.

## Netlify (if ever preferred)

Drag the `out/` folder onto app.netlify.com → Sites, or connect the repository; `netlify.toml` carries the same settings.

## After Monday's Atlas

The site reads the Atlas release pinned in `gen/content/atlas-4.4.15/` and links into `https://toy-model-v0.vercel.app/` with that release's routes. When the new release is deployed there: replace the pinned export, run `node gen/check.mjs` (it names every row that moved), fix what it names, `node gen/build.mjs`, and deploy `out/` again with the same command. The pages do not change otherwise; the links start resolving the moment the Atlas at that address carries the release.
