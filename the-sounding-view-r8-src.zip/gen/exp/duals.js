// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// duals — the dual bells: ten solids struck at a corner, the plucked corner, the cross-polytope's interval, the springs on the edges (MUS-238, MUS-239)
// The page draws the data's spectra, weights, cents and curves; it computes only the corners' coordinates and their turning, the fractions as numbers, and f = 220 Hz x sqrt(lambda)/sqrt(2).
(function () {
  'use strict';
  window.SDV_EXP = window.SDV_EXP || {};
  window.SDV_EXP['duals'] = { mount: function (root, data, S, kit) {
    var P = 'exp.duals.', el = kit.el, TAU = Math.PI * 2, F0 = 220 / Math.SQRT2, DECAY = 1.5, SWEEP = 6, TMAX = 12;
    var reduce = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    var SOL = data.solids, BY = {}, GREEN = '#3a8a5a', EDGES = data.edges;
    SOL.forEach(function (s) { BY[s.name] = s; });
    var st = { sol: 'cube', t: 0, paused: reduce, pl: { cube: true, octahedron: true, tetrahedron: true, 'cell24': true }, n: 6, ev: 'cube' };
    // ------------------------------------------------------------ helpers
    function grid(parent) { var d = el('div'); d.style.cssText = 'display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:12px;align-items:start'; parent.appendChild(d); return d; }
    function cv(parent, a, m) { var d = el('div'); d.style.minWidth = '0'; parent.appendChild(d); return kit.canvas(d, a, m); }
    function txt(c, s, x, y, color, align, size, bold) { c.fillStyle = color || kit.muted(); c.textAlign = align || 'left'; c.font = (bold ? '600 ' : '') + (size || 11) + 'px system-ui, sans-serif'; c.fillText(s, x, y); }
    function R(id, o) { var s = S(P + id); for (var k in (o || {})) s = s.split('{' + k + '}').join(o[k]); return s; }
    function frac(s) { var p = String(s).split('/'); return p.length === 2 ? +p[0] / +p[1] : +p[0]; }
    function gcd(a, b) { return b ? gcd(b, a % b) : a; }
    function pretty(s) { return String(s).replace(/sqrt\((\d+)\)/g, '√$1').replace(/sqrt\(([^()]+)\)/g, '√($1)').replace(/-/g, '−'); }
    function hz(lam) { return F0 * Math.sqrt(lam); }                 // one mapping for every solid: f = 220 Hz x sqrt(lambda) / sqrt(2)
    function sname(n) { return S(P + 'sol.' + n); }
    function foot() {
      var p = kit.panel_(root, 'exp.common.see', S, 'span');
      kit.line(p, P + 'see', S);
      p.appendChild(el('h3', { 'data-s': 'exp.common.hear', text: S('exp.common.hear') })); kit.line(p, P + 'hear', S);
      p.appendChild(el('p', { class: 'exp-source' }, [el('b', { 'data-s': 'exp.common.data', text: S('exp.common.data') }), ' · ', el('span', { 'data-s': P + 'data', text: S(P + 'data') })]));
    }
    // the partials of a solid (the zero mode does not sound): spectrum, weights, partials, cents are the data's
    function levels(s) {
      var L = [];
      for (var i = 1; i < s.spectrum.length; i++) L.push({ lam: s.spectrum_float[i][0], lamS: s.spectrum[i][0], m: s.spectrum[i][1], wS: s.weights[i][0], w: frac(s.weights[i][0]), pS: s.partials[i], c: s.cents[i] });
      return L;
    }
    // ------------------------------------------------------------ sound: one at a time, one Play/Mute per panel's button
    var SND = null, noAudio = null, timer = 0;
    function setBtn(b, on) { var id = on ? 'exp.common.mute' : b._sid; b.textContent = S(id); b.setAttribute('data-s', id); b.setAttribute('aria-pressed', String(on)); }
    function stopSnd() { if (SND) { SND.tones.forEach(function (t) { t.stop(); }); setBtn(SND.btn, false); clearTimeout(timer); SND = null; } }
    function start(btn, kind, groups, norm) {   // groups: [{at, parts: [{f, a}]}] ; loudness = weight, scaled so that the sum is at most 0.28
      stopSnd(); var a = kit.audio(); if (!a) { if (!noAudio) noAudio = kit.line(root, 'exp.common.noaudio', S); return; }
      var tones = [], end = 0;
      groups.forEach(function (g) {
        var tot = norm || g.parts.reduce(function (s, p) { return s + p.a; }, 0); end = Math.max(end, g.at);
        g.parts.forEach(function (p) { tones.push(kit.tone({ f: p.f, gain: 0.28 * p.a / tot, decay: DECAY, maxDur: 7, at: 0.01 + g.at })); });
      });
      SND = { btn: btn, kind: kind, groups: groups, norm: norm, tones: tones, t0: performance.now() }; setBtn(btn, true);
      timer = setTimeout(function () { if (SND && SND.btn === btn) stopSnd(); }, (end + 7.1) * 1000);
    }
    function toggle(btn, kind, build, norm) { if (SND && SND.btn === btn) { stopSnd(); return; } start(btn, kind, build(), norm); }
    function again(btn, build) { if (SND && SND.btn === btn) start(btn, SND.kind, build(), SND.norm); }   // a control that moves the picture re-strikes
    function btn(parent, id, kind, build, norm) { var b = kit.button(parent, id, S, function () { toggle(b, kind, build, norm); }); b._sid = id; return b; }
    function parts(L) { return L.map(function (l) { return { f: hz(l.lam), a: l.w }; }); }

    // ------------------------------------------------------------ geometry: the corners are written here, the edges are the pairs at the minimal distance
    var GEO = {};
    function geo(name) {
      if (GEO[name]) return GEO[name];
      var V = [], phi = (1 + Math.sqrt(5)) / 2, n = 3, i, j, e = [], dm = 1e9;
      function signs(d, f) { for (var m = 0; m < (1 << d); m++) { var v = [], neg = 0; for (var b = 0; b < d; b++) { var s = (m >> b & 1) ? -1 : 1; if (s < 0) neg++; v.push(s); } if (!f || f(neg)) V.push(v); } }
      function axes(d) { for (var a = 0; a < d; a++) for (var s = -1; s <= 1; s += 2) { var v = []; for (var b = 0; b < d; b++) v.push(b === a ? s : 0); V.push(v); } }
      function cyc(f) { [-1, 1].forEach(function (sy) { [-1, 1].forEach(function (sz) { var p = f(sy, sz); V.push(p, [p[1], p[2], p[0]], [p[2], p[0], p[1]]); }); }); }
      if (name === 'tetrahedron') signs(3, function (k) { return k % 2 === 0; });
      else if (name === 'cube') signs(3);
      else if (name === 'octahedron') axes(3);
      else if (name === 'icosahedron') cyc(function (y, z) { return [0, y, z * phi]; });
      else if (name === 'dodecahedron') { signs(3); cyc(function (y, z) { return [0, y / phi, z * phi]; }); }
      else if (name === 'tesseract') { n = 4; signs(4); }
      else if (name === '16-cell') { n = 4; axes(4); }
      else if (name === '24-cell') { n = 4; axes(4); signs(4); for (i = V.length - 16; i < V.length; i++) V[i] = V[i].map(function (x) { return x / 2; }); }
      else if (name === '5-cube') { n = 5; signs(5); } else { n = 5; axes(5); }
      function d2(a, b) { var s = 0; for (var k = 0; k < a.length; k++) s += (a[k] - b[k]) * (a[k] - b[k]); return s; }
      for (i = 0; i < V.length; i++) for (j = i + 1; j < V.length; j++) dm = Math.min(dm, d2(V[i], V[j]));
      for (i = 0; i < V.length; i++) for (j = i + 1; j < V.length; j++) if (Math.abs(d2(V[i], V[j]) - dm) < 1e-6) e.push([i, j]);
      var Rm = Math.sqrt(Math.max.apply(null, V.map(function (v) { return d2(v, v.map(function () { return 0; })); })));
      return (GEO[name] = { n: n, V: V, E: e, R: Rm });
    }
    function rot(x, i, j, a) { var c = Math.cos(a), s = Math.sin(a), xi = x[i], xj = x[j]; x[i] = c * xi - s * xj; x[j] = s * xi + c * xj; }
    function project(g, a) {
      var ops = [[0, 2, a], [1, 2, 0.5]];
      if (g.n >= 4) ops.push([0, 3, 0.8 * a], [1, 3, 0.35 * a + 0.6]);
      if (g.n === 5) ops.push([2, 4, 0.6 * a], [0, 4, 0.5 * a + 0.3]);
      return g.V.map(function (v) { var x = v.slice(); ops.forEach(function (o) { rot(x, o[0], o[1], o[2]); }); return x; });   // the first three coordinates: an orthogonal projection
    }

    // ================================================================ (i) the bells
    var p1 = kit.panel_(root, P + 'panel.bells', S), g1 = grid(p1);
    var cA = cv(g1, 0.9, 360), cB = cv(g1, 0.9, 360);
    var k1 = kit.controls(p1);
    function build1() { var s = BY[st.sol]; return [{ at: 0, parts: parts(levels(s)) }]; }
    function buildDual() { var s = BY[st.sol], d = BY[s.dual]; return [{ at: 0, parts: parts(levels(s)) }, { at: 1.2, parts: parts(levels(d)) }]; }
    var play1 = btn(k1, 'exp.common.play', 'bells', build1), dualB = btn(k1, P + 'b.dual', 'bells', buildDual);
    var pauseB = kit.button(k1, 'exp.common.pause', S, function () { st.paused = !st.paused; pauseB.setAttribute('aria-pressed', String(st.paused)); }); pauseB.setAttribute('aria-pressed', String(st.paused));
    var NAMES = SOL.map(function (s) { return s.name; }), segs = [];
    [NAMES.slice(0, 5), NAMES.slice(5)].forEach(function (grp, gi) {
      var kc = kit.controls(p1);
      var sg = kit.seg(kc, { S: S, ids: grp.map(function (n) { return P + 'sol.' + n; }), values: grp, value: gi === 0 ? st.sol : null, onchange: function (v) {
        st.sol = v; segs.forEach(function (o, oi) { if (oi !== gi) Array.prototype.forEach.call(o.el.querySelectorAll('button'), function (b) { b.setAttribute('aria-checked', 'false'); }); });
        readA(); again(play1, build1); again(dualB, buildDual); } });
      segs.push(sg);
    });
    var rA = [kit.readout(p1), kit.readout(p1), kit.readout(p1), kit.readout(p1)];
    kit.line(p1, P + 'cap.bells', S);
    function readA() {
      var s = BY[st.sol], L = levels(s);
      rA[0].textContent = R('rd.counts', { V: s.V, E: s.E, k: s.degree });
      rA[1].textContent = R('rd.spec', { s: s.spectrum.map(function (p) { return pretty(p[0]) + ' × ' + p[1]; }).join(', ') });
      rA[2].textContent = L.length > 1 ? R('rd.parts', { n: L.length, a: kit.num(hz(L[0].lam), 1), b: kit.num(hz(L[1].lam), 1), c: kit.num(L[1].c, 3) }) : R('rd.part1', { a: kit.num(hz(L[0].lam), 1) });
      rA[3].textContent = s.dual === s.name ? sname(s.name) + ' · ' + S(P + 'owndual') : R('dualis', { d: sname(s.dual) });
    }
    function drawWire() {
      var c = cA.ctx, w = cA.w, h = cA.h, g = geo(st.sol), X = project(g, st.t * 0.35), sc = 0.4 * Math.min(w, h) / g.R, i;
      c.clearRect(0, 0, w, h);
      var ink = kit.ink();
      g.E.forEach(function (e) {
        var a = X[e[0]], b = X[e[1]], d = (a[2] + b[2]) / 2 / g.R;
        c.globalAlpha = 0.3 + 0.6 * (d + 1) / 2; c.strokeStyle = ink; c.lineWidth = 1.2;
        c.beginPath(); c.moveTo(w / 2 + a[0] * sc, h / 2 - a[1] * sc); c.lineTo(w / 2 + b[0] * sc, h / 2 - b[1] * sc); c.stroke();
      });
      c.globalAlpha = 1;
      for (i = X.length - 1; i >= 0; i--) { c.fillStyle = i === 0 ? kit.warm() : ink; c.beginPath(); c.arc(w / 2 + X[i][0] * sc, h / 2 - X[i][1] * sc, i === 0 ? 5.5 : 2.3, 0, TAU); c.fill(); }
      txt(c, sname(st.sol), 8, 16, ink, 'left', 13, true);
      if (g.n > 3) txt(c, S(P + 'cv.proj') + ' (' + g.n + 'D)', 8, h - 8, kit.muted(), 'left', 10);
    }
    // overlapping labels are pushed apart (top to bottom)
    function spread(ys, gap, lo, hi) {
      var o = ys.map(function (y, i) { return i; }).sort(function (a, b) { return ys[a] - ys[b]; }), out = ys.slice(), k;
      for (k = 0; k < o.length; k++) out[o[k]] = Math.max(ys[o[k]], k ? out[o[k - 1]] + gap : lo);
      for (k = o.length - 1; k >= 0; k--) if (out[o[k]] > hi - (o.length - 1 - k) * gap) out[o[k]] = hi - (o.length - 1 - k) * gap;
      return out;
    }
    function drawLadder() {
      var c = cB.ctx, w = cB.w, h = cB.h, s = BY[st.sol], d = BY[s.dual], two = d.name !== s.name, top = 26, bot = h - 26, x0 = 38, cw = (w - x0 - 4) / (two ? 2 : 1), CM = 1750;
      var Y = function (v) { return bot - v / CM * (bot - top); };
      c.clearRect(0, 0, w, h);
      c.strokeStyle = kit.muted(); c.lineWidth = 1; c.fillStyle = kit.muted(); c.font = '10px system-ui, sans-serif'; c.textAlign = 'right';
      [0, 400, 800, 1200, 1600].forEach(function (v) { c.globalAlpha = 0.25; c.beginPath(); c.moveTo(x0, Y(v)); c.lineTo(w - 4, Y(v)); c.stroke(); c.globalAlpha = 1; c.fillText(String(v), x0 - 4, Y(v) + 3); });
      txt(c, S(P + 'cv.cents'), 4, 12, kit.muted(), 'left', 10);
      [s].concat(two ? [d] : []).forEach(function (q, ci) {
        var L = levels(q), xa = x0 + ci * cw + 4, barMax = Math.min(0.3 * cw, 60), faint = ci === 1, col = faint ? kit.muted() : kit.accent();
        var ly = spread(L.map(function (l) { return Y(l.c) - 4; }), faint ? 12 : 22, top, bot);
        c.globalAlpha = faint ? 0.5 : 1;
        c.strokeStyle = kit.ink(); c.beginPath(); c.moveTo(xa, top); c.lineTo(xa, bot); c.stroke();
        L.forEach(function (l, i) {
          var len = l.w / 0.6 * barMax, y = Y(l.c);
          c.fillStyle = col; c.fillRect(xa, y - 3.5, len, 7);
          c.strokeStyle = kit.muted(); c.lineWidth = 0.7; c.beginPath(); c.moveTo(xa + len, y); c.lineTo(xa + len + 4, ly[i] + 1); c.stroke(); c.lineWidth = 1;
          txt(c, l.wS + ' · ' + kit.num(l.c, 0), xa + len + 6, ly[i] + 1, kit.ink(), 'left', 10, !faint);
          if (!faint) txt(c, 'λ ' + pretty(l.lamS) + ' · ' + pretty(l.pS), xa + len + 6, ly[i] + 12, kit.muted(), 'left', 9);
        });
        c.globalAlpha = 1;
        txt(c, sname(q.name), xa, h - 8, faint ? kit.muted() : kit.ink(), 'left', 11, !faint);
      });
    }

    // ================================================================ (ii) the plucked vertex
    var p2 = kit.panel_(root, P + 'panel.pluck', S), cP = cv(p2, 0.5, 300), k2 = kit.controls(p2);
    var PK = [['cube', 'cube', kit.accent()], ['octahedron', 'octahedron', kit.red], ['tetrahedron', 'tetrahedron', kit.blue], ['cell24', '24-cell', kit.violet]], rP = {};
    PK.forEach(function (q) {
      var ck = kit.check(k2, P + 'sol.' + q[1], S, true, function (on) { st.pl[q[0]] = on; rP[q[0]].style.display = on ? '' : 'none'; });
      ck.el.style.borderBottom = '3px solid ' + q[2]; ck.el.style.paddingBottom = '2px';
      var s = BY[q[1]];
      rP[q[0]] = kit.readout(p2);
      rP[q[0]].textContent = S(P + 'pk.' + q[1]) + ' · ' + R('pk.w', { w: s.weights.map(function (x) { return x[0]; }).join(', '), l: s.weights.map(function (x) { return pretty(x[1]); }).join(', ') });
    });
    var rCur = kit.readout(p2), rSlow = kit.readout(p2);
    rSlow.textContent = S('exp.common.slowed').replace('{n}', kit.num(Math.round(SWEEP * TAU * F0 / TMAX), 0));
    kit.line(p2, P + 'cap.pluck', S);
    function cursor() {
      if (!SND || SND.kind !== 'bells') return null;
      return ((performance.now() - SND.t0) / 1000 / SWEEP * TMAX) % TMAX;
    }
    function drawPluck() {
      var c = cP.ctx, w = cP.w, h = cP.h, box = { l: 44, r: w - 10, t: 10, b: h - 34 }; c.clearRect(0, 0, w, h);
      var ax = kit.axes(c, box, { xmin: 0, xmax: TMAX, ymin: -0.9, ymax: 1.05, xticks: [0, 2, 4, 6, 8, 10, 12], yticks: [-0.5, 0, 0.5, 1], xlabel: S(P + 'cv.t'), ylabel: S(P + 'cv.x') });
      c.save(); c.beginPath(); c.rect(box.l, box.t, box.r - box.l, box.b - box.t); c.clip();
      PK.forEach(function (q) { if (st.pl[q[0]]) { var pk = data.pluck[q[0]]; kit.curve(c, pk.t.map(function (t, i) { return [t, pk.x[i]]; }), ax.x, ax.y, q[2], 1.8); } });
      c.restore();
      var tc = cursor(), vals = [];
      if (tc != null) {
        c.strokeStyle = kit.warm(); c.lineWidth = 1.2; c.beginPath(); c.moveTo(ax.x(tc), box.t); c.lineTo(ax.x(tc), box.b); c.stroke();
        PK.forEach(function (q) { if (st.pl[q[0]]) { var pk = data.pluck[q[0]], v = kit.interp(pk.t.map(function (t, i) { return [t, pk.x[i]]; }), tc); c.fillStyle = q[2]; c.beginPath(); c.arc(ax.x(tc), ax.y(v), 3.5, 0, TAU); c.fill(); vals.push(sname(q[1]) + ' ' + kit.num(v, 3)); } });
      }
      rCur.textContent = tc == null ? '' : R('pk.cur', { t: kit.num(tc, 2), v: vals.join(' · ') }); rCur.style.display = tc == null ? 'none' : '';
    }

    // ================================================================ (iii) the interval against n
    var p3 = kit.panel_(root, P + 'panel.interval', S), cI = cv(p3, 0.5, 300), k3 = kit.controls(p3);
    var CI = data.cross_interval, CL = data.cube_ladder, CROSS = { 3: 'octahedron', 4: '16-cell', 5: '5-cross' };
    function pair(n) {   // the two partials of the n-cross-polytope: the data's solid for n = 3, 4, 5, the rule beyond
      var s = BY[CROSS[n]], r;
      if (s) { var L = levels(s); return { la: L[0].lam, lb: L[1].lam, wa: L[0].wS, wb: L[1].wS, a: L[0].w, b: L[1].w, src: R('iii.src.data', { name: sname(s.name) }) }; }
      r = gcd(n - 1, 2 * n);
      return { la: 2 * n - 2, lb: 2 * n, wa: '1/2', wb: ((n - 1) / r) + '/' + (2 * n / r), a: 0.5, b: (n - 1) / (2 * n), src: S(P + 'iii.src.rule') };
    }
    function build3() { var q = pair(st.n); return [{ at: 0, parts: [{ f: hz(q.la), a: q.a }, { f: hz(q.lb), a: q.b }] }]; }
    var play3 = btn(k3, 'exp.common.play', 'interval', build3);
    kit.slider(k3, { S: S, id: P + 'iii.n', min: 2, max: 12, step: 1, value: st.n, fmt: function (v) { return String(v); }, onchange: function (v) { st.n = v; readI(); again(play3, build3); } });
    var rI = [kit.readout(p3), kit.readout(p3), kit.readout(p3)];
    kit.line(p3, P + 'cap.interval', S);
    function readI() {
      var n = st.n, q = pair(n), f1 = hz(q.la), f2 = hz(q.lb);
      rI[0].textContent = R('iii.rd.eig', { a: q.la, b: q.lb, wa: q.wa, wb: q.wb, src: q.src });
      rI[1].textContent = R('iii.rd.int', { c: kit.num(CI.cents[CI.n.indexOf(n)], 3), l: kit.num(CL.cents[n - 1], 3), n: n, k: kit.num(CL.cents[n - 2], 3), m: n - 1 });
      rI[2].textContent = R('iii.rd.hz', { f1: kit.num(f1, 1), f2: kit.num(f2, 1), b: kit.num(f2 - f1, 1) });
    }
    function drawInterval() {
      var c = cI.ctx, w = cI.w, h = cI.h, box = { l: 48, r: w - 12, t: 12, b: h - 34 }, n = st.n; c.clearRect(0, 0, w, h);
      var ax = kit.axes(c, box, { xmin: 1, xmax: 12, ymin: 0, ymax: 2200, xticks: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], yticks: [0, 600, 1200, 1800], xlabel: S(P + 'cv.nj'), ylabel: S('exp.common.cents') });
      var fall = CI.n.map(function (v, i) { return [v, CI.cents[i]]; }), rise = CL.j.map(function (v, i) { return [v, CL.cents[i]]; });
      kit.curve(c, rise, ax.x, ax.y, kit.blue, 1.8); kit.curve(c, fall, ax.x, ax.y, kit.red, 1.8);
      [[rise, kit.blue], [fall, kit.red]].forEach(function (q) { q[0].forEach(function (p) { c.fillStyle = q[1]; c.beginPath(); c.arc(ax.x(p[0]), ax.y(p[1]), 2.2, 0, TAU); c.fill(); }); });
      c.setLineDash([3, 3]); c.strokeStyle = kit.muted(); c.beginPath(); c.moveTo(ax.x(n), box.t); c.lineTo(ax.x(n), box.b); c.stroke(); c.setLineDash([]);
      c.strokeStyle = kit.warm(); c.lineWidth = 4; c.beginPath(); c.moveTo(ax.x(n - 1), ax.y(CL.cents[n - 2])); c.lineTo(ax.x(n), ax.y(CL.cents[n - 1])); c.stroke(); c.lineWidth = 1;
      c.fillStyle = kit.warm(); c.beginPath(); c.arc(ax.x(n), ax.y(CL.cents[n - 1]), 4.5, 0, TAU); c.fill(); c.beginPath(); c.arc(ax.x(n), ax.y(CI.cents[CI.n.indexOf(n)]), 4.5, 0, TAU); c.fill();
      txt(c, S(P + 'cv.rise'), box.l + 12, ax.y(2000), kit.blue, 'left', 11); txt(c, S(P + 'cv.fall'), ax.x(4.2), ax.y(780), kit.red, 'left', 11);
    }

    // ================================================================ (iv) the edges
    var p4 = kit.panel_(root, P + 'panel.edges', S), cE = cv(p4, 0.5, 300), k4 = kit.controls(p4);
    function key(v) { return JSON.stringify(v); }
    function lamF(e, i) { var f = e.L1_spectrum_float ? e.L1_spectrum_float[i][0] : e.L1_spectrum[i][0]; return f; }
    function cubeBell(list) { return function () { var E = EDGES.cube.euler[1]; return [{ at: 0, parts: list.map(function (q) { return { f: hz(q[0]), a: q[1] / E }; }) }]; }; }
    btn(k4, 'exp.duals.iv.b.springs', 'edges', cubeBell(EDGES.cube.L1_spectrum), 1);
    btn(k4, 'exp.duals.iv.b.cube', 'edges', cubeBell(EDGES.cube.from_vertices), 1);
    btn(k4, 'exp.duals.iv.b.octa', 'edges', cubeBell(EDGES.cube.from_faces), 1);
    kit.seg(k4, { S: S, ids: ['tetrahedron', 'cube', 'icosahedron'].map(function (n) { return P + 'sol.' + n; }), values: ['tetrahedron', 'cube', 'icosahedron'], value: st.ev, onchange: function (v) { st.ev = v; readE(); } });
    var rE = [kit.readout(p4), kit.readout(p4)]; kit.line(p4, P + 'iv.ident', S); kit.line(p4, P + 'cap.edges', S);
    function readE() {
      var e = EDGES[st.ev], u = e.euler, k = e.ranks;
      rE[0].textContent = R('iv.rd.eu', { V: u[0], E: u[1], F: u[2], x: u[0] - u[1] + u[2], r1: k[0], r2: k[1], n: e.L1_spectrum.length });
      rE[1].textContent = R('iv.rd.count', { E: u[1], V: u[0], F: u[2], r1: k[0], r2: k[1] });
    }
    function drawEdges() {
      var c = cE.ctx, w = cE.w, h = cE.h, e = EDGES[st.ev], N = e.L1_spectrum.length, box = { l: 40, r: w - 10, t: 24, b: h - 40 }; c.clearRect(0, 0, w, h);
      var idx = e.L1_spectrum.map(function (q, i) { return i; }).sort(function (a, b) { return lamF(e, a) - lamF(e, b); }), mx = Math.max.apply(null, e.L1_spectrum.map(function (q) { return q[1]; })) + 1;
      var Y = function (v) { return box.b - v / mx * (box.b - box.t); }, slot = (box.r - box.l) / N, bw = Math.min(46, slot * 0.7);
      c.strokeStyle = kit.muted(); c.lineWidth = 1; c.beginPath(); c.moveTo(box.l, box.t); c.lineTo(box.l, box.b); c.lineTo(box.r, box.b); c.stroke();
      c.fillStyle = kit.muted(); c.font = '10px system-ui, sans-serif'; c.textAlign = 'right'; for (var v = 0; v <= mx; v += (mx > 8 ? 2 : 1)) c.fillText(String(v), box.l - 4, Y(v) + 3);
      txt(c, S(P + 'cv.mult'), 4, 12, kit.muted(), 'left', 10);
      idx.forEach(function (i, k) {
        var q = e.L1_spectrum[i], kq = key(q[0]), find = function (a) { var r = 0; a.forEach(function (z) { if (key(z[0]) === kq) r = z[1]; }); return r; };
        var nv = find(e.from_vertices), nf = find(e.from_faces), x = box.l + slot * (k + 0.5) - bw / 2;
        c.fillStyle = kit.blue; c.fillRect(x, Y(nv), bw, Y(0) - Y(nv)); c.fillStyle = GREEN; c.fillRect(x, Y(nv + nf), bw, Y(nv) - Y(nv + nf));
        txt(c, String(q[1]), x + bw / 2, Y(nv + nf) - 4, kit.ink(), 'center', 11, true);
        txt(c, pretty(q[0]), x + bw / 2, box.b + 14, kit.ink(), 'center', 10);
      });
      txt(c, S(P + 'cv.lam'), box.r, h - 6, kit.muted(), 'right', 10);
      c.fillStyle = kit.blue; c.fillRect(box.l + 10, 8, 10, 10); txt(c, S(P + 'cv.v'), box.l + 24, 17, kit.ink(), 'left', 10);
      c.fillStyle = GREEN; c.fillRect(box.l + 24 + c.measureText(S(P + 'cv.v')).width + 20, 8, 10, 10); txt(c, S(P + 'cv.f'), box.l + 24 + c.measureText(S(P + 'cv.v')).width + 34, 17, kit.ink(), 'left', 10);
    }

    foot();
    readA(); readI(); readE();
    kit.loop(function (t, dt) {
      if (!st.paused) st.t += dt;
      drawWire(); drawLadder(); drawPluck(); drawInterval(); drawEdges();
    });
  } };
})();
