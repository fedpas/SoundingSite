# B8a note: `duals`, four panels for the Tone chapter

Built: `duals.js` (see line count in the report), `duals.strings.json` (59 strings, rows MUS-238, 239, 002, 025, 030, SHP-001, SPR-003), `duals.data.json` (28 kB, `duals.json` whole), `duals.spec.md`, `_harness_duals.html` and two screenshots; console clean at both widths and after striking every button, switching all ten solids and moving the slider to its end.

## What the page draws
- The bells: ten solids as turning wireframes (4D and 5D projected), the struck corner orange; the ladder of partials (cents as height, weight as length and label, eigenvalue and partial beside), the dual's ladder faint; V, E, degree, spectrum, number of partials and the lowest interval.
- The plucked corner: four curves, toggles, closed forms with the data's weights, a cursor with the values under it, the slow-down factor.
- The interval against n: falling and rising curves, slider, the ladder's step marked, partials, weights, cents, pitches and beat.
- The edges: stacked counts (vertices blue, faces green), the identity, the ranks and Euler; three buttons for the cube's springs and its two shares.

## Mapping
f = 220 Hz x sqrt(lambda)/sqrt(2); decay 1.5 s.

## Could not place, or with a caveat
- n = 2 (the square) and n > 5 are not solids in the data: eigenvalues and weights by the stated rule, said on the page.
- `charpoly` is carried, not drawn. The zero mode is neither drawn nor sounded.
- The cursor is an illustration (489 times slower than the sound).

## String ids (all `exp.duals.*`)
title, lead, see, hear, data; panel.bells/pluck/interval/edges; sol.<ten names>; b.dual, dualis, owndual, cv.cents, cv.proj, rd.counts, rd.spec, rd.parts, rd.part1, cap.bells; pk.cube/octahedron/tetrahedron/24-cell, pk.w, pk.cur, cv.t, cv.x, cap.pluck; iii.n, cv.fall, cv.rise, cv.nj, iii.rd.eig, iii.src.data, iii.src.rule, iii.rd.int, iii.rd.hz, cap.interval; cv.v, cv.f, cv.lam, cv.mult, iv.ident, iv.rd.count, iv.rd.eu, iv.b.springs, iv.b.cube, iv.b.octa, cap.edges.
