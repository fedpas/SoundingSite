# Experiment "The field made visible — sound beside light" (`field.html`)

Read `COMMON.md` first. Title on the page: *The field made visible: pressure and velocity as one field, beside E and B*.

## What it shows

Two canvases, one above the other (side by side at 1280 px): **Sound** and **Light**, the same plane wave in both, travelling along x, in a strip of two wavelengths.

**Sound** (air: c = 343 m/s, ρ = 1.2041 kg/m³; the acoustic impedance ρc = 413.0063 Pa·s/m is *forced* by the equation, MUS-029):
- the pressure p(x, t) as a diverging colour map (red +, blue −) over the strip;
- the velocity v as thin arrows along x on a coarser grid, length ∝ |v|;
- the parcels: a row of dots at rest positions x₀ that move by the displacement ξ(x₀, t) = ∫v dt (longitudinal motion, visibly compressing where p is red);
- an "energy flux" overlay (toggle): arrows of the intensity I = p·v; in a travelling wave they always point +x; in a standing wave they oscillate with zero mean — print the time-averaged I beside the toggle;
- a microphone marker draggable along x; its p(t) is drawn as a small trace and, when sound is on, heard.
- Modes: *travelling* p = P cos(kx − ωt), v = p/(ρc); *standing* p = 2P cos(kx) cos(ωt), v = (2P/ρc) sin(kx) sin(ωt) (quadrature in space and time: say so in a line). P = 1 Pa (94 dB SPL); f = 220 Hz, so λ = c/f = 1.5595 m. The picture runs 400× slower than the sound (say so).
- A small panel "one equation, three grades": the first-order equation D(p/ρc + v) = 0 with D = (1/c)∂_t + ∇ in Cl(3,0) has a scalar part (continuity), a vector part (Euler) and a bivector part (curl v = 0) — show three gauges (small meters) reading the residual of each grade on the drawn field, all at zero (they are, for the exact plane wave; compute them numerically on the grid and print the max residual as a number so the reader sees "0.00"). This is MUS-029: the two linear equations of sound and the absence of vorticity are one first-order equation.

**Light** (vacuum, same picture): E along y as arrows (red/blue colour under them for its sign), B as the **bivector** e_x∧e_y drawn as small oriented discs lying in the picture plane with a curved arrow for the sense (the vector B along z would come out of the screen; the Atlas writes B as a plane). E and B in phase for the travelling wave; standing wave in quadrature. The Poynting flux E×B as the same overlay. Below the light strip, the **Hodge-dual toggle**: "B as a vector along z" ⇄ "B as the plane e_x∧e_y" — draw the switch as the Atlas's bit labels: the generator e_z is the label 100, its dual (complement) is 011 = e_x e_y: "the Hodge dual of a label is its complement" (MUS-045). When the toggle is on the vector side, draw B as ⊙ / ⊗ marks sized by |B|.

**The grades of the analogy** (a row of three marks under both strips, words written out):
- *exact*: the same operator on every grade — sound's D on Cl(3,0) and Maxwell's ∇ on Cl(1,3) (MUS-029, MUS-047);
- *partial*: the two first-order equations stand one grade apart: scalar + vector against vector + bivector (the lens reading of PAG-008);
- *none*: the acoustic boost is exact algebra but not an observer's frame: the air's rest frame is preferred (MUS-029, MUS-045; INP-011). Show this as a dead switch "boost the observer" that, when pressed, prints the sentence instead of acting.

## Sound
On Play: the microphone's p(t) as a 220 Hz sine, amplitude following the marker's position in a standing wave (silent at a node, loudest at an antinode) and constant in a travelling wave. A second button "hear E at the marker" plays the same for light with a different timbre (a triangle wave) so the ear tells them apart. Gain 0.2, 20 ms fades.

## Controls
travelling / standing · flux overlay · dual toggle · Play/Mute · a slider for the phase speed read-out? No: keep it to those. Print λ, ρc, k and ω.

## Rows for the strip
MUS-029 (computed), MUS-045, MUS-046, MUS-047, MUS-048, MUS-049 (computed), INP-131, INP-132 (input). Take the claim lines from atlas_sound.json.

## As built (release 4, contract module `field.js`)

Converted from the prototype `plan4/proto/field.html`: every picture and the sound kept (two canvases, the marker you drag or move with the arrow keys, the flux overlay, travelling and standing, the three residual meters computed on the drawn field, the Hodge-dual toggle, the three grade cards, the dead boost button). Words moved to `field.strings.json` (82 strings, ids `exp.field.*`; text drawn inside the canvases is S() too); the numbers (c, ρ, f, P, the 400× slow-down) to `field.data.json`; the legend is the generator's. Colours: `kit.cmap` for p and E and the B discs, `kit.blue`/`kit.red` for the signs, `kit.accent()` for the flux. The sound is `kit.voice` (sine for p, triangle for E at the marker, gain 0.2 times the local amplitude, silent at a node in the standing wave); it starts on a click. The picture runs 400× slower than the sound (`exp.common.slowed`). Pause is added (reduced motion starts paused). The wave is analytic; the data file names the constants' rows and the identities' checks (no table is drawn).
