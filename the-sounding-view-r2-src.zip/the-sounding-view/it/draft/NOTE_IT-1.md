# NOTE_IT-1 — the narrator IT-1's delivery (racconto_r1.json, strings_it_r1.json)

Delivered, in `site/it/draft/`:

- `racconto_r1.json` — 60 items, one per target of my share (`page:home`; the eight `section:*`; the 27 `row:*` blocks; `page:dictionary`, `page:checks`, `page:pictures`, `page:sounds`; the six instruments `clock|tonnetz|rhythm|chain|gliss|commas`; `clip:01` … `clip:10` with `08a`, `08b`, `08c`; `page:sources`, `page:about`), each `{ id: "r:" + target, target, tells, text, why }`, the `tells` copied verbatim from `content/it/MANIFEST.json`; 7,496 words of narration in all.
- `strings_it_r1.json` — exactly the 220 ids of `content/strings.json` that the manifest does not list under `strings_new` (the set was computed by script, not by hand); for the 14 ids under `strings_changed` the Italian does the job of the manifest's new English text; 2,384 words.
- `check_IT-1.py` — the check I ran before delivering (banned words as the checker matches them, lengths against the manifest, placeholders, ids, no HTML/markdown/TeX). Run: `python3 -I check_IT-1.py ../../gen/content/it/MANIFEST.json racconto_r1.json strings_it_r1.json ../../gen/content/strings.json`.

Both files load: `python3 -c 'import json; json.load(open("racconto_r1.json")); json.load(open("strings_it_r1.json"))'` prints nothing and exits 0 (verified on 2 November 2026).

I did not write anything of IT-2's share (`page:bridges`, `bridges:*`, `row:MUS-014` … `MUS-049`, `instrument:crt|rings|rows`, `clip:13` … `clip:21`, `page:acoustics`, `checks:round37`, `pictures:round37`, the 185 `strings_new`), and I did not touch the `_tmp/` folder in `it/draft/`, which is not mine.

## What I read

- `it/VOICE_IT.md` whole; `gen/content/it/MANIFEST.json` (the targets with their `tells`, `length`, `where`; `strings_new`; `strings_changed`); `gen/content/strings.json`.
- The English site as built, `out/*.html`, stripped to text: `index`, the eight sections (`tone`, `consonance`, `clock`, `scales`, `groups`, `shapes`, `fourier`, `question`), `dictionary`, `checks` (the two scripts' heads, groups, controls and run records; the nine scripts of the pack only glanced at), `pictures`, `sounds`, `sources`, `about`.
- The Atlas's tables: `repo/content/rows.json` and `texts.json` for MUS-701 (the lead the home is composed from) and the rows' texts as the pages print them; `lenses.json` for the lens `mus` (34 entries, grades, evidence, rows).
- The study `repo/docs/round36/music_on_the_labels.html`: the abstract (`study:top.3`), §1, §2.2, §3.0–3.9, §4 (the table of the scripts), §5.3, §7 (the clips), §8, §9.1.
- `repo/checks/selfcheck/round36/audio/INDEX.md` (every clip's "what is heard" and "built from").
- `site/gen/assets/RELEASE_NOTES.md` and `site/record/SITE_NOTES.md` for the method (page:about) and the synthesizer (page:sounds).

Every number, name and claim in a narration is taken from the record its `tells` name, quoted as the record prints it (decimal point, the record's digits and units). Where I shortened a list of numbers for length I kept the record's first values and never rounded.

## Terminology beyond the glossary (my choices)

| English (the records) | Italian used | note |
|---|---|---|
| the spring step (the Atlas's page `steps/spring`) | il passo della molla | "passo" for the Atlas's step page; the id stays |
| the kernel (`spring_selfcheck.py`) | il nucleo (spring_selfcheck.py) | named with its file the first time on each row |
| multivector; the kernel's `matmul` | multivettore; "esatto con il nucleo" | the helper's name dropped in prose |
| mask (twelve-bit mask) | maschera di dodici bit | |
| maximally even (set, scale) | massimamente uniforme | the usual Italian of Clough–Douthett's term |
| necklace; bracelet | collana; braccialetto | Burnside's counts |
| convergent; semiconvergent | convergente; semiconvergente | (ridotta would also do; I kept the cognate the records use) |
| well-formed scale | scala ben formata | glossary |
| beats; roughness; harmonicity; gradus suavitatis | battimenti; asprezza; armonicità; gradus (suavitatis), left in Latin | |
| dyad; triad; hexachord; interval class | diade; triade; esacordo; classe intervallare | |
| chromatic cluster | cluster cromatico | kept as the Italian music term (tone cluster); the only anglicism in a narration besides clip, log, script, browser, abstract |
| whole-tone (scale/hexagon) | per toni interi | to keep "esatonale" for the hexatonic cycle alone |
| contextual inversion; simply transitive; torsor | inversione contestuale; semplicemente transitivo; torsore | |
| voice leading; Möbius band; projective plane; cell complex; clique complex | condotta delle voci; nastro di Möbius; piano proiettivo; complesso cellulare; complesso delle cricche | |
| homometry; Wiener–Khinchin; Gauss sum | omometria; Wiener–Khinchin; somma di Gauss | |
| Z-relation, Z-pairs | relazione Z, coppie Z | |
| onset; pulse; downbeat; bar | attacco; pulsazione; primo tempo (battere); battuta | the rhythm clips |
| click / tick / thump (the clips' sounds) | colpo secco / lieve tic / colpo sordo | |
| sawtooth-like tone | timbro simile a un dente di sega | |
| Shepard tones | toni di Shepard | |
| stiff string; free bar; membrane; drum; bell; pluck | corda rigida; barra libera; membrana; tamburo; campana; pizzico | glossary |
| just intonation / just fifth / tempered fifth | intonazione naturale / quinta naturale / quinta temperata | "naturale" throughout, never "giusta" |
| cents; comma; schisma; diesis | cent (invariable); comma; scisma; diesis (il diesis 128/125, the record's word) | |
| the shifted view (Atiyah–Moore) | la vista spostata di Atiyah e Moore | the sister site's name The Shifted View is not used here |
| frames (the four frames of ATY-040) | quattro riferimenti | |
| "input" as a status | dato in ingresso | glossary |
| log; run; last run | il log (kept: Italian computing uses it; "registro" would clash with the four registers); esecuzione; **Esecuzione registrata** (since "ultima" is banned) | |
| Since (the row's release) | Nelle tavole da | the value stays "v4.4.9"; "versione" is banned |
| Previous / Next section | Sezione che precede / Sezione che segue | "precedente" and "prima" are banned |
| Presets | Preimpostazioni | |
| Tuning: Just / 12-TET | Intonazione: Naturale / 12-TET | |
| Play / Stop / Clear | Suona / Ferma / Azzera | |
| Kind (the Atlas's kind) | Tipo | |
| About (the page) | Il metodo (nav), heading "Da dove viene ogni frase" | the glossary's choice for the page; the heading reworded so the page does not say "Il metodo" twice |
| Also here (heading) | Le altre pagine | |
| the drill, the pack | lo studio The bridges drilled / lo studio dei ponti; il pacchetto | in the strings that mention it |
| the Atlas's "release" / "round N" in strings | dropped: "con lo studio Music on the labels integrato", "il pacchetto dello studio The bridges drilled, proposto e non ancora integrato" | see "release.stamp" below |
| Required Notice | kept in English inside `about.licence.p` | it is the licence's required line, a record |

Names kept as they are: The Sounding View, The Shifted View, the Cascade Atlas (l'Atlante in prose), Atlas, Standard, Tonnetz, ONE RULE (la regola unica), every row id, check tag, file name, data-file key (`hexatonic`, `LR_cycle`, `beethoven_first_19`, `partials_bar`, `chord_beats_hz_12tet`, `C4_hz`), the study titles, the journal names and the authors.

## What was unclear, and how I told it

- **`release.stamp`.** The English stamp says "(round 36)" and "the pack of round 37". The manifest allows *release* and *versione* in this one string, but not "round N"; so the stamp names the studies instead of the rounds: "costruito dalle tavole del Cascade Atlas {atlas}, con lo studio Music on the labels integrato, e dal pacchetto dello studio The bridges drilled, proposto e non ancora integrato". The same move in `checks.intro`, `about.reads.p`, `method.2` ("gli indici delle figure e dei clip dei due studi"). If the checker does allow "round N" in the stamp, the builder may put "(round 36)" back; I preferred the safe form.
- **`reg.story.p`** describes what Story shows; on the Italian pages Racconto shows my narration, on the English ones the study's prose. The string says both ("nelle pagine italiane è la mia narrazione della riga; in quelle inglesi …"), so it is true on either side.
- **`blk.from.*`** (Story's source lines) are presumably not rendered on the Italian pages, where Racconto is mine; they are filled anyway, as the manifest asks.
- **`nav.about`** is "Il metodo" per the glossary; since the About page's first heading is also "The method", I reworded that heading (`about.method`) as "Da dove viene ogni frase" so the page does not print the same words twice.
- **The clips' narrations** stand on `audio/INDEX.md`'s "what is heard" and "built from" only, as the manifest's `tells` say; the study's own "what to hear" lines (§7) are not among the tells, so I kept my listening advice to what the clip's record states or what follows from its string (e.g. the cinquillo's "uno isolato e poi due coppie" reads x.xx.xx.; the tresillo's "a distanza 3, 3 e 2" reads x..x..x.). I did not carry over "the complement of the tresillo" (§7, clip 10) or "the chain's five notes make no scale" (§7, clip 1).
- **`page:sounds`** tells `clip:01`, `clip:21`, `instrument:clock`, `instrument:rows`; I name clip 01 and clip 21 ("due anelli su 110 Hz", from the Sounds page's own line for clip 21) and the first and ninth instruments in passing, without telling the drill's rows, which are IT-2's. The synthesizer's figures (20 ms raised-cosine fades, −6 dBFS, one JavaScript file without libraries, the test's 37 assertions in Chromium) are RELEASE_NOTES.md's and the Sounds page's.
- **`page:home`** tells `study:top.3` and `MUS-701`: the first paragraph follows the abstract's sentences and MUS-701's "what listeners report … between the two stands a reading of ours", as the home's English paragraph is composed; the second paragraph is the narrator's.
- **`row:LAB-046`, `row:LAB-047`, `row:LNS-137`, `row:LAB-016b`, `row:SPR-M01`, `row:SPR-M16`, `row:ATY-040`** are the Atlas's own rows; each narration says so ("è dell'Atlante") and ends on the lens entry that reads it, with its grade and the grade's reason, taken from `lenses.json`.
- **Status words.** Every row narration names its status in the glossary's words: "calcolato" with its check tag and script; "ha stato standard, ricalcolato" (MUS-003, LAB-016b); "è un dato in ingresso … nessun calcolo sulle etichette lo fornisce; la riga non ha verifiche" (the seven INP rows); "è una lettura nostra" (MUS-013), with the open questions named as "aperte".
- **The pager's "prev"/"next"**: "Sezione che precede / che segue", since both "precedente" and the temporal "prima" are banned.
- **"Ultimo"/"ora"/"nuovo"/"prima"** forced some rewordings: "Esecuzione registrata" for Last run; "il C maggiore di arrivo" for "the last C major" (clip 07); "dapprima" never needed; "prima" appears only as the ordinal before a noun ("il primo tempo", "la prima … nota" never, "in prima persona" in `about.notthere.p`, "vengono per primi" in `method.3`), which the checker allows.
- **Lengths.** I counted whitespace-separated tokens, which counts every "=", number and symbol as a word, so this is the strictest count; every narration is inside its range by that count and also by a letters-only count (see the table). Several rows and the sections were trimmed from longer drafts to fit; where I cut, I cut numbers that the English record beside already shows, never a claim's qualification (e.g. "B è un'impostazione della verifica", "come suonino non è calcolato", "non un gusto universale" stayed).

## Checks run

`check_IT-1.py` (the matcher follows the manifest's rule: whole words, any form, case-insensitive — adesso, nuov-, recent-, ultim-, aggiornat-, precedent-, corrett-, sostituit-, superat-, version-, release, new; "round N"; "ora" not after an apostrophe; "prima" before di/che/del…, after come/di/da, or closing a clause before , . ; : ) or the end):

- racconto_r1.json: 60 items, no target twice, every `tells` equal to the manifest's, every text in range, **0 banned words**, no HTML, no markdown, no TeX, a `why` on each.
- strings_it_r1.json: exactly the 220 ids, every placeholder `{release}`, `{atlas}`, `{date}` kept, **0 banned words** (release/versione only in `release.stamp`, where the manifest allows them), a `why` on each.
- Both files `json.load` cleanly.

Two things I had flagged and fixed before delivery: "superate" (banned) in page:sounds became "tutte riuscite"; "per prima," in MUS-005 was reworded. Counts after the final run: 7,496 narration words (whitespace tokens), 2,384 string words.

## Word counts (whitespace tokens; the manifest's range beside)

| target | parole | intervallo |
|---|---|---|
| `page:home` | 176 | 120–180 |
| `section:tone` | 156 | 100–160 |
| `section:consonance` | 156 | 100–160 |
| `section:clock` | 156 | 100–160 |
| `section:scales` | 156 | 100–160 |
| `section:groups` | 155 | 100–160 |
| `section:shapes` | 150 | 100–160 |
| `section:fourier` | 152 | 100–160 |
| `section:question` | 153 | 100–160 |
| `row:SPR-M01` | 135 | 60–140 |
| `row:MUS-001` | 136 | 60–140 |
| `row:MUS-002` | 137 | 60–140 |
| `row:MUS-003` | 136 | 60–140 |
| `row:SPR-M16` | 136 | 60–140 |
| `row:ATY-040` | 135 | 60–140 |
| `row:INP-128` | 139 | 60–140 |
| `row:MUS-004` | 133 | 60–140 |
| `row:INP-124` | 124 | 60–140 |
| `row:INP-125` | 121 | 60–140 |
| `row:INP-126` | 130 | 60–140 |
| `row:INP-127` | 124 | 60–140 |
| `row:LAB-046` | 137 | 60–140 |
| `row:MUS-005` | 136 | 60–140 |
| `row:MUS-010` | 131 | 60–140 |
| `row:MUS-009` | 137 | 60–140 |
| `row:LNS-137` | 136 | 60–140 |
| `row:MUS-006` | 134 | 60–140 |
| `row:MUS-012` | 133 | 60–140 |
| `row:LAB-016b` | 131 | 60–140 |
| `row:MUS-007` | 135 | 60–140 |
| `row:MUS-008` | 138 | 60–140 |
| `row:LAB-047` | 131 | 60–140 |
| `row:MUS-011` | 137 | 60–140 |
| `row:INP-129` | 136 | 60–140 |
| `row:INP-130` | 137 | 60–140 |
| `row:MUS-013` | 136 | 60–140 |
| `page:dictionary` | 157 | 100–160 |
| `page:checks` | 159 | 100–160 |
| `page:pictures` | 113 | 60–120 |
| `page:sounds` | 159 | 100–160 |
| `instrument:clock` | 115 | 60–120 |
| `instrument:tonnetz` | 118 | 60–120 |
| `instrument:rhythm` | 113 | 60–120 |
| `instrument:chain` | 119 | 60–120 |
| `instrument:gliss` | 111 | 60–120 |
| `instrument:commas` | 112 | 60–120 |
| `clip:01` | 81 | 40–90 |
| `clip:02` | 73 | 40–90 |
| `clip:03` | 88 | 40–90 |
| `clip:04` | 86 | 40–90 |
| `clip:05` | 86 | 40–90 |
| `clip:06` | 88 | 40–90 |
| `clip:07` | 85 | 40–90 |
| `clip:08a` | 69 | 40–90 |
| `clip:08b` | 62 | 40–90 |
| `clip:08c` | 47 | 40–90 |
| `clip:09` | 82 | 40–90 |
| `clip:10` | 78 | 40–90 |
| `page:sources` | 135 | 80–140 |
| `page:about` | 136 | 80–140 |
