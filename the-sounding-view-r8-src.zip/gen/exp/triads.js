// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// triads — two groups on the triads, each the other's centralizer (MUS-006, 012, 018, 026 … 028, 032, 042 … 044, LNS-137)
(function () {
  'use strict';
  window.SDV_EXP = window.SDV_EXP || {};
  window.SDV_EXP['triads'] = {
    mount: function (root, data, S, kit) {
      var TAU = Math.PI * 2, el = kit.el, NS = 'exp.triads.', snd = false, live = [], timers = [], names = data.names, TR = data.triads;
      var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      var moving = !reduce, T = 0, mode = 'ti', kind = 'T', nn = 4, cur = 0, anim = null, tri = null, sel = 0, wm = 0, wsel = [1, 3];
      var byKey = {}; TR.forEach(function (t, i) { byKey[t.pcs.slice().sort(function (a, b) { return a - b; }).join(',')] = i; });
      var byName = {}; TR.forEach(function (t, i) { byName[t.name] = i; });
      function hz(pc) { return 261.6256 * Math.pow(2, pc / 12); }
      function cell(p) { var c = el('div', { style: 'min-width:0;overflow:hidden' }); p.appendChild(c); return c; }
      function silence() { live.forEach(function (t) { t.stop(); }); live = []; timers.forEach(clearTimeout); timers = []; }
      function chordAt(p, at, dur) { p.forEach(function (x) { live.push(kit.tone({ f: hz(x), gain: 0.14, dur: dur || 0.6, at: at || 0.02 })); }); }
      function playBtn(parent) {
        var b = kit.button(parent, 'exp.common.play', S, function () {
          snd = !snd; b.textContent = S(snd ? 'exp.common.mute' : 'exp.common.play'); b.setAttribute('data-s', snd ? 'exp.common.mute' : 'exp.common.play');
          if (snd) { if (!kit.audio()) kit.line(root, 'exp.common.noaudio', S); chordAt(TR[cur].pcs); } else silence();
        }); return b;
      }
      function idxTi(i, kd, n) { // image of triad i under T_n or I_n
        var t = TR[i], major = t.type === 'major', root = i % 12;
        if (kd === 'T') return major ? (root + n) % 12 : 12 + (root + n) % 12;
        return major ? 12 + (((n - root - 7) % 12) + 12) % 12 : (((n - root - 7) % 12) + 12) % 12;
      }
      function nbr(i) { var o = {}; data.edges.forEach(function (e) { if (e.a === TR[i].name) o[e.label] = byName[e.b]; else if (e.b === TR[i].name) o[e.label] = byName[e.a]; }); return o; }
      function invN(i, j) { for (var n = 0; n < 12; n++) if (idxTi(i, 'I', n) === j) return n; return -1; }
      function setCur(i) { cur = i; var t = data.tri.filter(function (x) { return x.triad === TR[i].name; })[0]; tri = t.ij.map(function (v) { return v.slice(); }); anim = null; }
      setCur(0);

      root.classList.add('half');
      // ---------------------------------------------- (a) the 24 triads
      var pa = kit.panel_(root, NS + 'panel.a', S), da = kit.canvas(cell(pa), 1, 380), ca = kit.controls(pa);
      playBtn(ca);
      kit.seg(ca, { ids: [NS + 'mode.ti', NS + 'mode.plr'], values: ['ti', 'plr'], value: mode, S: S, onchange: function (v) { mode = v; } });
      kit.seg(ca, { ids: [NS + 'kind.T', NS + 'kind.I'], values: ['T', 'I'], value: kind, S: S, onchange: function (v) { kind = v; } });
      kit.slider(ca, { id: NS + 'n', S: S, min: 0, max: 11, step: 1, value: nn, fmt: function (v) { return String(v); }, onchange: function (v) { nn = v; if (snd) { silence(); chordAt(TR[idxTi(cur, kind, nn)].pcs); } } });
      var ra = kit.readout(pa), rk = kit.readout(pa); kit.line(pa, NS + 'a.note', S);
      var g1 = el('p', { class: 'exp-line' }); pa.appendChild(g1); kit.grade(g1, 'exact', 'exp.common.grade.exact', S);
      rk.textContent = data.K_order + '   ' + data.orbital_sizes.join(' ') + '   ' + Object.keys(data.context_classes).map(function (k) { return k + '×' + data.context_classes[k]; }).join(' ');
      function P(i, cx, cy, R) { var t = TR[i]; return [cx + R * t.xy[0], cy - R * t.xy[1]]; }
      function drawA() {
        var s = da.size(), c = da.ctx, W = s.w, H = s.h, cx = W / 2, cy = H / 2, R = Math.min(W, H) * 0.4, i, p, q;
        c.clearRect(0, 0, W, H); c.strokeStyle = kit.muted(); c.globalAlpha = 0.3; c.beginPath(); c.arc(cx, cy, R, 0, TAU); c.stroke(); c.beginPath(); c.arc(cx, cy, R * 0.62, 0, TAU); c.stroke(); c.globalAlpha = 1;
        var imgs = [];
        if (mode === 'ti') { for (i = 0; i < 24; i++) { p = P(i, cx, cy, R); q = P(idxTi(i, kind, nn), cx, cy, R); if (i !== cur) { c.globalAlpha = 0.25; kit.arrow(c, p[0], p[1], p[0] + (q[0] - p[0]) * 0.85, p[1] + (q[1] - p[1]) * 0.85, kind === 'T' ? kit.blue : kit.red, 1); c.globalAlpha = 1; } } p = P(cur, cx, cy, R); q = P(idxTi(cur, kind, nn), cx, cy, R); if (p[0] !== q[0] || p[1] !== q[1]) kit.arrow(c, p[0], p[1], p[0] + (q[0] - p[0]) * 0.9, p[1] + (q[1] - p[1]) * 0.9, kit.warm(), 2.6); }
        else { var nb = nbr(cur); p = P(cur, cx, cy, R); ['P', 'L', 'R'].forEach(function (l) { var j = nb[l]; q = P(j, cx, cy, R); kit.arrow(c, p[0], p[1], p[0] + (q[0] - p[0]) * 0.9, p[1] + (q[1] - p[1]) * 0.9, kit.warm(), 2.4); c.fillStyle = kit.warm(); c.font = 'bold 13px system-ui, sans-serif'; c.textAlign = 'center'; c.fillText(l, (p[0] + q[0]) / 2 + 8, (p[1] + q[1]) / 2 - 4); imgs.push(j); }); }
        for (i = 0; i < 24; i++) {
          p = P(i, cx, cy, R); var maj = TR[i].type === 'major';
          c.fillStyle = maj ? kit.ink() : kit.panel(); c.strokeStyle = i === cur ? kit.warm() : kit.ink(); c.lineWidth = i === cur ? 3 : 1.4; c.beginPath(); c.arc(p[0], p[1], maj ? 7 : 5.5, 0, TAU); c.fill(); c.stroke();
          c.fillStyle = kit.muted(); c.font = '11px system-ui, sans-serif'; c.textAlign = 'center'; var o = maj ? 20 : -14; c.fillText(TR[i].name, cx + (R + o * 0 + (maj ? 18 : -17)) * TR[i].xy[0] / (maj ? 1 : 0.62), cy - (R + (maj ? 18 : -17)) * TR[i].xy[1] / (maj ? 1 : 0.62) * 1 + 4);
        }
        var j2 = idxTi(cur, kind, nn);
        ra.textContent = TR[cur].name + (mode === 'ti' ? '  ' + kind + (kind === 'T' ? '' : '') + nn + ' → ' + TR[j2].name : '  P → ' + TR[nbr(cur).P].name + '   L → ' + TR[nbr(cur).L].name + '   R → ' + TR[nbr(cur).R].name);
      }
      da.el.addEventListener('click', function (e) {
        var r = da.el.getBoundingClientRect(), s = da.size(), R = Math.min(s.w, s.h) * 0.4, x = e.clientX - r.left - s.w / 2, y = -(e.clientY - r.top - s.h / 2), best = 0, bd = 1e9;
        TR.forEach(function (t, i) { var d = Math.hypot(x - R * t.xy[0], y - R * t.xy[1]); if (d < bd) { bd = d; best = i; } }); setCur(best); if (snd) { silence(); chordAt(TR[best].pcs); }
      });

      // ---------------------------------------------- (b) contextuality as conjugation: the move on the Tonnetz
      var pb = kit.panel_(root, NS + 'panel.b', S), db = kit.canvas(cell(pb), 1, 380), cb = kit.controls(pb);
      ['P', 'L', 'R'].forEach(function (l) { kit.button(cb, NS + 'move.' + l, S, function () { doMove(l); }); });
      var lr = false;
      function runLR() { if (!snd || !lr) return; silence(); data.LR_cycle.forEach(function (n, i) { chordAt(TR[byName[n]].pcs, 0.02 + i * 0.4, 0.38); timers.push(setTimeout(function () { setCur(byName[n]); }, i * 400)); }); timers.push(setTimeout(runLR, 24 * 400)); }
      kit.button(cb, NS + 'cycle', S, function () { lr = !lr; if (lr) runLR(); else silence(); });
      kit.check(cb, NS + 'motion', S, moving, function (v) { moving = v; });
      var rb = kit.readout(pb); kit.line(pb, NS + 'b.note', S);
      function pcOf(v) { return ((7 * v[0] + 4 * v[1]) % 12 + 12) % 12; }
      function xyOf(v) { return [v[0] + v[1] / 2, v[1] * Math.sqrt(3) / 2]; }
      function triIndex(t) { return byKey[t.map(pcOf).sort(function (a, b) { return a - b; }).join(',')]; }
      function doMove(l) {
        var nb = nbr(cur), j = nb[l], pj = TR[j].pcs, k, old = -1;
        for (k = 0; k < 3; k++) if (pj.indexOf(pcOf(tri[k])) < 0) old = k;
        var a = tri[(old + 1) % 3], b = tri[(old + 2) % 3], nv = [a[0] + b[0] - tri[old][0], a[1] + b[1] - tri[old][1]];
        anim = { t0: T, old: old, from: tri[old].slice(), to: nv, tri: tri.map(function (v) { return v.slice(); }), j: j, l: l };
        if (snd) { silence(); chordAt(TR[cur].pcs, 0.02, 0.5); chordAt(pj, 0.55, 0.6); }
        var h = invN(cur, j); rb.textContent = l + ': ' + TR[cur].name + ' → ' + TR[j].name + '   I' + h + (cur === 0 ? '   (' + data.h[l] + ')' : '');
      }
      function drawB() {
        var s = db.size(), c = db.ctx, W = s.w, H = s.h, u = Math.min(W, H) / 5, i, j, v;
        if (anim && T - anim.t0 > 0.9 + 0.0) { tri = anim.tri.map(function (q, k) { return k === anim.old ? anim.to.slice() : q; }); cur = anim.j; anim = null; }
        var shown = tri.map(function (q) { return q.slice(); });
        if (anim) { var f = Math.min(1, (T - anim.t0) / 0.8); f = f * f * (3 - 2 * f); shown[anim.old] = [anim.from[0] + (anim.to[0] - anim.from[0]) * f, anim.from[1] + (anim.to[1] - anim.from[1]) * f]; }
        var cen = xyOf([(tri[0][0] + tri[1][0] + tri[2][0]) / 3, (tri[0][1] + tri[1][1] + tri[2][1]) / 3]);
        function X(q) { var p = xyOf(q); return [W / 2 + (p[0] - cen[0]) * u, H / 2 - (p[1] - cen[1]) * u]; }
        c.clearRect(0, 0, W, H);
        var ci = Math.round(tri[0][0]), cj = Math.round(tri[0][1]);
        for (i = ci - 5; i <= ci + 5; i++) for (j = cj - 5; j <= cj + 5; j++) {
          v = X([i, j]); if (v[0] < 6 || v[0] > W - 6 || v[1] < 6 || v[1] > H - 6) continue;
          c.fillStyle = kit.muted(); c.globalAlpha = 0.5; c.beginPath(); c.arc(v[0], v[1], 2.5, 0, TAU); c.fill(); c.globalAlpha = 1; c.font = '10px system-ui, sans-serif'; c.textAlign = 'center'; c.fillText(names[pcOf([i, j])], v[0], v[1] - 6);
        }
        // the three neighbours, dashed
        var nb = nbr(cur);
        ['P', 'L', 'R'].forEach(function (l) {
          var pj = TR[nb[l]].pcs, old = -1, k; for (k = 0; k < 3; k++) if (pj.indexOf(pcOf(tri[k])) < 0) old = k;
          var a = tri[(old + 1) % 3], b = tri[(old + 2) % 3], nv = [a[0] + b[0] - tri[old][0], a[1] + b[1] - tri[old][1]], m = X(nv), A = X(a), B = X(b);
          c.setLineDash([4, 3]); c.strokeStyle = kit.warm(); c.lineWidth = 1; c.beginPath(); c.moveTo(A[0], A[1]); c.lineTo(m[0], m[1]); c.lineTo(B[0], B[1]); c.stroke(); c.setLineDash([]);
          c.fillStyle = kit.warm(); c.font = 'bold 12px system-ui, sans-serif'; c.fillText(l, m[0] + 8, m[1] + 12);
        });
        var pts = shown.map(X), maj = TR[triIndex(tri)].type === 'major';
        c.beginPath(); pts.forEach(function (p, k) { if (k) c.lineTo(p[0], p[1]); else c.moveTo(p[0], p[1]); }); c.closePath(); c.fillStyle = maj ? kit.red : kit.blue; c.globalAlpha = 0.25; c.fill(); c.globalAlpha = 1; c.strokeStyle = maj ? kit.red : kit.blue; c.lineWidth = 2; c.stroke();
        pts.forEach(function (p, k) { c.fillStyle = anim && k === anim.old ? kit.warm() : kit.ink(); c.beginPath(); c.arc(p[0], p[1], anim && k === anim.old ? 7 : 5, 0, TAU); c.fill(); });
        if (!rb.textContent) rb.textContent = TR[triIndex(tri)].name;
      }

      // ---------------------------------------------- (c) the rigid body's two frames
      var pc = kit.panel_(root, NS + 'panel.c', S, 'span'), dc = kit.canvas(cell(pc), 0.5, 320), cc = kit.controls(pc);
      kit.slider(cc, { id: 'exp.common.time', S: S, min: 0, max: 0.75, step: 0.01, value: 0, fmt: function (v) { return kit.num(v, 2); }, onchange: function (v) { tsl = v; moving = false; } });
      var tsl = 0, rc = kit.readout(pc), g2 = el('p', { class: 'exp-line' }); pc.appendChild(g2);
      kit.grade(g2, 'analogy', 'exp.common.grade.analogy', S); g2.appendChild(document.createTextNode(' ')); g2.appendChild(el('span', { 'data-s': NS + 'c.analogy', text: S(NS + 'c.analogy') }));
      var F = data.frames, fr = { t: [], cx: [], cy: [], psi: [] }, pu = 0;
      F.forEach(function (f, k) { var psi = Math.atan2(f.corners[1][1] - f.corners[0][1], f.corners[1][0] - f.corners[0][0]); if (k) while (psi - pu > Math.PI) psi -= TAU; while (k && psi - pu < -Math.PI) psi += TAU; pu = psi; fr.t.push(f.t); fr.cx.push(f.centre[0]); fr.cy.push(f.centre[1]); fr.psi.push(psi); });
      function at(arr, t) { return kit.interp(fr.t.map(function (x, i) { return [x, arr[i]]; }), t); }
      function drawC() {
        var s = dc.size(), c = dc.ctx, W = s.w, H = s.h, t = moving ? (T * 0.12) % 0.75 : tsl; c.clearRect(0, 0, W, H);
        var cx = at(fr.cx, t), cy = at(fr.cy, t), psi = at(fr.psi, t), k = fr.t.length - 1, rate = (fr.psi[k] - fr.psi[0]) / (fr.t[k] - fr.t[0]);
        var vx = (fr.cx[k] - fr.cx[0]) / (fr.t[k] - fr.t[0]), vy = (fr.cy[k] - fr.cy[0]) / (fr.t[k] - fr.t[0]);
        var hw = W / 2, u = Math.min(hw / 4.6, H / 3.4), i, a;
        function sq(ox, oy, ang, sc, ccx, ccy) { var pts = []; for (var q = 0; q < 4; q++) { a = ang + q * Math.PI / 2 - Math.PI / 4; pts.push([ox + (ccx + 0.7071 * Math.cos(a) * 0) * sc + 0, oy]); } return pts; }
        void sq; void i;
        function square(ox, oy, scx, scy, ang) { c.beginPath(); for (var q = 0; q < 4; q++) { var b = ang - Math.PI / 4 + q * Math.PI / 2 - 0, x = ox + scx + 0.7071 * u * Math.cos(b) * 1, y = oy + scy - 0.7071 * u * Math.sin(b); if (q) c.lineTo(x, y); else c.moveTo(x, y); } c.closePath(); }
        // left: the space frame (axes fixed), the body turns and moves
        var lx = hw * 0.25, ly = H * 0.32;
        c.strokeStyle = kit.muted(); c.lineWidth = 1; c.strokeRect(2, 2, hw - 6, H - 4); c.strokeRect(hw + 2, 2, hw - 6, H - 4);
        kit.arrow(c, lx, ly + 0 * u, lx + u * 0.9, ly, kit.muted(), 1.4); kit.arrow(c, lx, ly, lx, ly - u * 0.9, kit.muted(), 1.4);
        var px = lx + cx * u * 0.8, py = ly - cy * u * 0.8;
        square(px, py, 0, 0, psi); c.fillStyle = kit.accent(); c.globalAlpha = 0.18; c.fill(); c.globalAlpha = 1; c.strokeStyle = kit.accent(); c.lineWidth = 1.8; c.stroke();
        kit.arrow(c, px, py, px + u * 0.8 * Math.cos(psi), py - u * 0.8 * Math.sin(psi), kit.red, 2); kit.arrow(c, px, py, px - u * 0.8 * Math.sin(psi), py - u * 0.8 * Math.cos(psi), kit.blue, 2);
        kit.arrow(c, px, py, px + vx * u * 0.35, py - vy * u * 0.35, kit.warm(), 2.4);
        // right: the body frame (the body is still), the space turns the other way
        var bx = hw + hw / 2, by = H / 2; square(bx, by, 0, 0, 0); c.fillStyle = kit.accent(); c.globalAlpha = 0.18; c.fill(); c.globalAlpha = 1; c.strokeStyle = kit.accent(); c.lineWidth = 1.8; c.stroke();
        kit.arrow(c, bx, by, bx + u * 0.8, by, kit.red, 2); kit.arrow(c, bx, by, bx, by - u * 0.8, kit.blue, 2);
        c.setLineDash([4, 3]); kit.arrow(c, bx, by, bx + u * 1.5 * Math.cos(-psi), by - u * 1.5 * Math.sin(-psi), kit.muted(), 1.4); kit.arrow(c, bx, by, bx - u * 1.5 * Math.sin(-psi), by - u * 1.5 * Math.cos(-psi), kit.muted(), 1.4); c.setLineDash([]);
        var bvx = vx * Math.cos(psi) + vy * Math.sin(psi), bvy = -vx * Math.sin(psi) + vy * Math.cos(psi);
        kit.arrow(c, bx, by, bx + bvx * u * 0.35, by - bvy * u * 0.35, kit.warm(), 2.4);
        rc.textContent = 't = ' + kit.num(t, 2) + '   dψ/dt = ' + kit.num(rate, 2) + '   v(space) = (' + kit.num(vx, 2) + ', ' + kit.num(vy, 2) + ')   v(body) = (' + kit.num(bvx, 2) + ', ' + kit.num(bvy, 2) + ')   ' + data.rate;
      }

      // ---------------------------------------------- (d) Weil's normaliser
      var pd = kit.panel_(root, NS + 'panel.d', S, 'span'), wd = el('div', { style: 'display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:10px' }); pd.appendChild(wd);
      var dg = kit.canvas(cell(wd), 0.4, 200), dw = kit.canvas(cell(wd), 0.8, 300), cd = kit.controls(pd);
      var SETS = [[0, 4, 7], [0, 2, 4, 5, 7, 9, 11], [0, 2, 4, 7, 9]];
      kit.seg(cd, { ids: [NS + 'set.triad', NS + 'set.diatonic', NS + 'set.pentatonic'], values: [0, 1, 2], value: wm, S: S, onchange: function (v) { wm = v; wplay(); } });
      var rd = kit.readout(pd); kit.line(pd, NS + 'd.note', S);
      var U = [1, 5, 7, 11];
      function wmap(x) { return (U[wsel[0]] * x + wsel[1]) % 12; }
      function wplay() { if (!snd) return; silence(); chordAt(SETS[wm], 0.02, 0.6); chordAt(SETS[wm].map(wmap), 0.7, 0.8); }
      dg.el.addEventListener('click', function (e) { var r = dg.el.getBoundingClientRect(), s = dg.size(), gx = (e.clientX - r.left - 30) / ((s.w - 36) / 12), gy = (e.clientY - r.top - 6) / ((s.h - 12) / 4); var b = Math.floor(gx), uu = Math.floor(gy); if (b >= 0 && b < 12 && uu >= 0 && uu < 4) { wsel = [uu, b]; wplay(); } });
      function drawD() {
        var s = dg.size(), c = dg.ctx, W = s.w, H = s.h, cw = (W - 36) / 12, ch = (H - 12) / 4, u, b; c.clearRect(0, 0, W, H); c.font = '10px system-ui, sans-serif';
        for (u = 0; u < 4; u++) { c.fillStyle = kit.muted(); c.textAlign = 'right'; c.fillText(String(U[u]), 26, 6 + u * ch + ch * 0.62); for (b = 0; b < 12; b++) { var on = wsel[0] === u && wsel[1] === b; c.fillStyle = on ? kit.accent() : kit.panel(); c.strokeStyle = kit.muted(); c.fillRect(30 + b * cw, 6 + u * ch, cw - 1.5, ch - 1.5); c.strokeRect(30 + b * cw, 6 + u * ch, cw - 1.5, ch - 1.5); if (on) { c.fillStyle = kit.panel(); c.textAlign = 'center'; c.fillText(String(b), 30 + b * cw + cw / 2, 6 + u * ch + ch * 0.6); } } }
        var s2 = dw.size(), c2 = dw.ctx, W2 = s2.w, H2 = s2.h, cx = W2 / 2, cy = H2 / 2, R = Math.min(W2, H2) * 0.36, k, p, set = SETS[wm], img = set.map(wmap); c2.clearRect(0, 0, W2, H2);
        c2.strokeStyle = kit.muted(); c2.globalAlpha = 0.4; c2.beginPath(); c2.arc(cx, cy, R, 0, TAU); c2.stroke(); c2.globalAlpha = 1;
        function pp(x, r) { var a = TAU * x / 12 - Math.PI / 2; return [cx + r * Math.cos(a), cy + r * Math.sin(a)]; }
        for (k = 0; k < 12; k++) { p = pp(k, R); var o = set.indexOf(k) >= 0, m = img.indexOf(k) >= 0; c2.fillStyle = m ? kit.accent() : kit.panel(); c2.strokeStyle = o ? kit.warm() : kit.muted(); c2.lineWidth = o ? 2.5 : 1.2; c2.beginPath(); c2.arc(p[0], p[1], m || o ? 7 : 4, 0, TAU); c2.fill(); c2.stroke(); var q = pp(k, R + 17); c2.fillStyle = kit.muted(); c2.font = '11px system-ui, sans-serif'; c2.textAlign = 'center'; c2.fillText(names[k], q[0], q[1] + 4); }
        set.forEach(function (x) { var A = pp(x, R), B = pp(wmap(x), R); c2.globalAlpha = 0.5; kit.arrow(c2, A[0], A[1], A[0] + (B[0] - A[0]) * 0.85, A[1] + (B[1] - A[1]) * 0.85, kit.violet, 1); c2.globalAlpha = 1; });
        rd.textContent = 'x ↦ ' + U[wsel[0]] + 'x + ' + wsel[1] + '   {' + set.join(', ') + '} ↦ {' + img.join(', ') + '}   48 = 4 × 12';
      }

      var pz = kit.panel_(root, 'exp.common.see', S); kit.line(pz, NS + 'see', S);
      var ph = kit.panel_(root, 'exp.common.hear', S); kit.line(ph, NS + 'hear', S);
      var pdt = el('p', { class: 'exp-line' }); pdt.appendChild(el('strong', { 'data-s': 'exp.common.data', text: S('exp.common.data') })); pdt.appendChild(document.createTextNode(' ')); pdt.appendChild(el('span', { 'data-s': NS + 'data', text: S(NS + 'data') }));
      root.appendChild(el('div', { class: 'exp-panel span' }, [pdt]));
      kit.loop(function (t, dt) { if (moving) T += dt; else if (anim) T += dt; drawA(); drawB(); drawC(); drawD(); });
    }
  };
})();
