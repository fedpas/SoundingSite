// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// clockring — the clock is the ring's spectrum (MUS-005, MUS-014, MUS-015, LAB-046)
(function () {
  'use strict';
  window.SDV_EXP = window.SDV_EXP || {};
  window.SDV_EXP['clockring'] = {
    mount: function (root, data, S, kit) {
      var TAU = Math.PI * 2, el = kit.el, snd = false, live = [], timers = [];
      var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      var moving = !reduce, T = 0, k = 1, edges = 'chromatic', dir = 0, gi = 1, swaps = 1, voice = null;
      var V = data.vertices, om = data.omega2.map(function (w) { return Math.sqrt(w); }), w1 = om[1];
      var NS = 'exp.clockring.';
      function hz(pc) { return 261.6256 * Math.pow(2, pc / 12); }
      function wrapper(parent) { var w = el('div', { style: 'display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:10px' }); parent.appendChild(w); return w; }
      function cell(w) { var c = el('div', { style: 'min-width:0;overflow:hidden' }); w.appendChild(c); return c; }
      function silence() { live.forEach(function (t) { t.stop(); }); live = []; timers.forEach(clearTimeout); timers = []; if (voice) { voice.stop(); voice = null; } }
      function modeF() { return k === 0 ? 0 : 220 * om[k] / w1; }
      function startVoice() { if (!snd) return; if (voice) voice.stop(); voice = kit.voice({ f: Math.max(20, modeF()), gain: k === 0 ? 0 : 0.14 }); }
      function scale(pcs) { if (!snd) return; silence(); pcs.forEach(function (p, i) { live.push(kit.tone({ f: hz(p), gain: 0.16, dur: 0.3, at: 0.02 + i * 0.25 })); }); timers.push(setTimeout(startVoice, 12 * 250 + 300)); }

      root.classList.add('half');
      // ---------------------------------------------------------- (a) one dial, two readings
      var pa = kit.panel_(root, NS + 'panel.a', S, 'span');
      var wa = wrapper(pa), ca = cell(wa), cb = cell(wa);
      var dial = kit.canvas(ca, 1, 380), spec = kit.canvas(cb, 1, 380);
      var ctl = kit.controls(pa);
      var pbtn = kit.button(ctl, 'exp.common.play', S, function () {
        snd = !snd; pbtn.textContent = S(snd ? 'exp.common.mute' : 'exp.common.play'); pbtn.setAttribute('data-s', snd ? 'exp.common.mute' : 'exp.common.play');
        if (snd) { if (!kit.audio()) kit.line(pa, 'exp.common.noaudio', S); startVoice(); } else silence();
      });
      kit.slider(ctl, { id: 'exp.common.mode', S: S, min: 0, max: 6, step: 1, value: 1, fmt: function (v) { return String(v); }, onchange: function (v) { k = v; if (voice) voice.set(Math.max(20, modeF()), k === 0 ? 0 : 0.14); } });
      kit.seg(ctl, { ids: [NS + 'edges.chromatic', NS + 'edges.fifths'], values: ['chromatic', 'fifths'], value: edges, S: S, onchange: function (v) { edges = v; } });
      kit.check(ctl, NS + 'motion', S, moving, function (v) { moving = v; });
      kit.button(ctl, NS + 'scale.chromatic', S, function () { scale([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]); });
      kit.button(ctl, NS + 'scale.fifths', S, function () { scale(data.fifths_order); });
      var rd = kit.readout(pa);
      kit.line(pa, NS + 'sentence', S);
      var gl = el('p', { class: 'exp-line' }); pa.appendChild(gl); kit.grade(gl, 'exact', 'exp.common.grade.exact', S);
      pa.appendChild(el('p', { class: 'exp-line', 'data-s': 'exp.common.slowed', text: S('exp.common.slowed').replace('{n}', '440') }));

      function pos(i, cx, cy, R) { return [cx + R * V[i].x, cy - R * V[i].y]; }
      function drawDial() {
        var s = dial.size(), c = dial.ctx, W = s.w, H = s.h, cx = W / 2, cy = H / 2, R = Math.min(W, H) * 0.31, i, p, q;
        c.clearRect(0, 0, W, H);
        var ec = edges === 'chromatic' ? data.chromatic_edges : data.fifths_edges;
        c.lineWidth = 1; c.strokeStyle = edges === 'chromatic' ? kit.muted() : kit.accent(); c.globalAlpha = 0.55;
        ec.forEach(function (e) { p = pos(e[0], cx, cy, R); q = pos(e[1], cx, cy, R); c.beginPath(); c.moveTo(p[0], p[1]); c.lineTo(q[0], q[1]); c.stroke(); });
        c.globalAlpha = 1;
        // the fifth as x7: the hour hand jumps; the chromatic edge {j, j+1} lands on the fifths edge {7j, 7j+7}
        var step = Math.floor(T / 1.6) % 12, half = (T % 1.6) > 0.8, j = step, a = half ? data.x7[j] : j, b = half ? data.x7[(j + 1) % 12] : (j + 1) % 12;
        p = pos(a, cx, cy, R); q = pos(b, cx, cy, R); c.strokeStyle = kit.warm(); c.lineWidth = 3.2; c.beginPath(); c.moveTo(p[0], p[1]); c.lineTo(q[0], q[1]); c.stroke();
        kit.arrow(c, cx, cy, cx + (p[0] - cx) * 0.62, cy + (p[1] - cy) * 0.62, kit.warm(), 2.2);
        // the mode k: a hand at each hour (the phase of the character) and the mass pulsing radially
        var ph = TAU * 0.5 * (om[k] / w1) * T;
        for (i = 0; i < 12; i++) {
          var th = TAU * i * k / 12 + ph, d = Math.cos(th), u = V[i], px = cx + R * u.x, py = cy - R * u.y;
          var L = 0.2 * R, mx = px + u.x * L * d, my = py - u.y * L * d;
          c.strokeStyle = d >= 0 ? kit.red : kit.blue; c.fillStyle = c.strokeStyle; c.lineWidth = 4; c.globalAlpha = 0.5;
          c.beginPath(); c.moveTo(px, py); c.lineTo(mx, my); c.stroke(); c.globalAlpha = 1;
          c.beginPath(); c.arc(mx, my, 5, 0, TAU); c.fill();
          var bx = px + u.x * R * 0.3, by = py - u.y * R * 0.3;
          kit.arrow(c, bx, by, bx + Math.cos(th) * 11, by - Math.sin(th) * 11, kit.ink(), 1.1);
          c.fillStyle = kit.muted(); c.font = '11px system-ui, sans-serif'; c.textAlign = 'center';
          c.fillText(V[i].name, cx + (R + 0.5 * R) * u.x, cy - (R + 0.5 * R) * u.y + 4);
        }
        c.fillStyle = kit.ink(); c.font = '13px system-ui, sans-serif'; c.textAlign = 'center'; c.fillText('ℤ₁₂', cx, cy + 4);
        rd.textContent = 'k = ' + k + '   ω² = ' + kit.num(data.omega2[k], 4) + '   f = ' + (k === 0 ? '—' : kit.num(modeF(), 1) + ' ' + S('exp.common.hz')) + '   ×7: ' + a + ' → ' + data.x7[a];
      }
      function drawSpec() {
        var s = spec.size(), c = spec.ctx, W = s.w, H = s.h, box = { l: 40, t: 18, r: W - 12, b: H - 36 };
        c.clearRect(0, 0, W, H);
        var ax = kit.axes(c, box, { xmin: -0.5, xmax: 6.5, ymin: 0, ymax: 1.05 * om[6] / w1, xticks: [0, 1, 2, 3, 4, 5, 6], yticks: [0, 1, 2, 3], xlabel: S('exp.common.mode'), ylabel: 'ω/ω₁' });
        for (var i = 0; i <= 6; i++) {
          var x0 = ax.x(i - 0.34), x1 = ax.x(i + 0.34), y = ax.y(om[i] / w1);
          c.fillStyle = i === k ? kit.accent() : kit.muted(); c.globalAlpha = i === k ? 0.9 : 0.35; c.fillRect(x0, y, x1 - x0, box.b - y); c.globalAlpha = 1;
        }
        spec._ax = ax; spec._box = box;
      }
      spec.el.addEventListener('click', function (e) {
        var r = spec.el.getBoundingClientRect(), x = e.clientX - r.left, ax = spec._ax; if (!ax) return;
        var i = Math.round(6 * (x - ax.x(0)) / (ax.x(6) - ax.x(0))); if (i < 0 || i > 6) return;
        k = i; sliderK.set(i); if (voice) voice.set(Math.max(20, modeF()), k === 0 ? 0 : 0.14);
      });
      var sliderK = { set: function (v) { var inp = pa.querySelector('input[type=range]'); inp.value = v; inp.dispatchEvent(new Event('input')); } };

      // ---------------------------------------------------------- (b) two clocks
      var pb = kit.panel_(root, NS + 'panel.b', S);
      var two = kit.canvas(cell(pb), 0.62, 300), cb2 = kit.controls(pb);
      kit.seg(cb2, { ids: [NS + 'hom.8to12', NS + 'hom.12to8'], values: [0, 1], value: 0, S: S, onchange: function (v) { dir = v; gi = Math.min(gi, 3); } });
      var gs = kit.slider(cb2, { id: NS + 'hom.image', S: S, min: 0, max: 3, step: 1, value: 1, fmt: function (v) { return String(keys()[v]); }, onchange: function (v) { gi = v; } });
      function keys() { return dir === 0 ? [0, 3, 6, 9] : [0, 2, 4, 6]; }
      var g1 = el('p', { class: 'exp-line' }), g2 = el('p', { class: 'exp-line' }); pb.appendChild(g1); pb.appendChild(g2);
      kit.grade(g1, 'exact', 'exp.common.grade.exact', S); g1.appendChild(document.createTextNode(' ')); g1.appendChild(el('span', { 'data-s': NS + 'b.exact', text: S(NS + 'b.exact') }));
      kit.grade(g2, 'none', 'exp.common.grade.none', S); g2.appendChild(document.createTextNode(' ')); g2.appendChild(el('span', { 'data-s': NS + 'b.none', text: S(NS + 'b.none') }));
      var rb = kit.readout(pb);
      function dot8(i, cx, cy, R) { var a = TAU * i / 8 - Math.PI / 2; return [cx + R * Math.cos(a), cy + R * Math.sin(a)]; }
      function drawTwo() {
        var s = two.size(), c = two.ctx, W = s.w, H = s.h, R = Math.min(W / 4.4, H * 0.36), c1 = [W * 0.25, H * 0.5], c2 = [W * 0.75, H * 0.5], i, p;
        c.clearRect(0, 0, W, H);
        var even8 = data.Z8.even_half, dim = data.dim7_Z4, aug = data.aug_Z3, g = keys()[gi];
        for (i = 0; i < 8; i++) {
          p = dot8(i, c1[0], c1[1], R); var sh = even8.indexOf(i) >= 0;
          c.fillStyle = sh ? kit.accent() : kit.panel(); c.strokeStyle = sh ? kit.accent() : kit.muted(); c.lineWidth = 1.5; c.beginPath(); c.arc(p[0], p[1], 6, 0, TAU); c.fill(); c.stroke();
          c.fillStyle = kit.muted(); c.font = '11px system-ui, sans-serif'; c.textAlign = 'center'; c.fillText(String(i), c1[0] + (R + 17) * Math.cos(TAU * i / 8 - Math.PI / 2), c1[1] + (R + 17) * Math.sin(TAU * i / 8 - Math.PI / 2) + 4);
        }
        for (i = 0; i < 12; i++) {
          p = [c2[0] + R * V[i].x, c2[1] - R * V[i].y]; var sh2 = dim.indexOf(i) >= 0, au = aug.indexOf(i) >= 0;
          c.fillStyle = sh2 ? kit.accent() : kit.panel(); c.strokeStyle = sh2 ? kit.accent() : (au ? kit.warm() : kit.muted()); c.lineWidth = au ? 2 : 1.5; c.beginPath(); c.arc(p[0], p[1], 6, 0, TAU); c.fill(); c.stroke();
          c.fillStyle = kit.muted(); c.font = '11px system-ui, sans-serif'; c.textAlign = 'center'; c.fillText(String(i), c2[0] + (R + 17) * V[i].x, c2[1] - (R + 17) * V[i].y + 4);
        }
        // the homomorphism x → g·x as arrows between the dials (reading from the chosen side)
        c.globalAlpha = 0.6;
        if (dir === 0) for (i = 0; i < 8; i++) { var a = dot8(i, c1[0], c1[1], R), j = (g * i) % 12; kit.arrow(c, a[0] + 7, a[1], c2[0] + R * V[j].x - 7, c2[1] - R * V[j].y, kit.violet, 1); }
        else for (i = 0; i < 12; i++) { var b = [c2[0] + R * V[i].x, c2[1] - R * V[i].y], jj = (g * i) % 8, d = dot8(jj, c1[0], c1[1], R); kit.arrow(c, b[0] - 7, b[1], d[0] + 7, d[1], kit.violet, 1); }
        c.globalAlpha = 1;
        c.fillStyle = kit.ink(); c.font = '13px system-ui, sans-serif'; c.textAlign = 'center'; c.fillText('ℤ₈', c1[0], c1[1] + 4); c.fillText('ℤ₁₂', c2[0], c2[1] + 4);
        var im = (dir === 0 ? data.Hom_Z8_Z12 : data.Hom_Z12_Z8)[String(g)];
        rb.textContent = '1 ↦ ' + g + '   ' + (dir === 0 ? 'ℤ₈ → ℤ₁₂' : 'ℤ₁₂ → ℤ₈') + '   {' + im.join(', ') + '}';
      }

      // ---------------------------------------------------------- (c) the rule with modulus 12
      var pc = kit.panel_(root, NS + 'panel.c', S);
      var rc = kit.canvas(cell(pc), 0.8, 280), cc = kit.controls(pc);
      kit.slider(cc, { id: NS + 'swaps', S: S, min: 0, max: 12, step: 1, value: swaps, fmt: function (v) { return String(v); }, onchange: function (v) { swaps = v; if (snd) live.push(kit.tone({ f: hz(v % 12), gain: 0.16, dur: 0.5 })); } });
      kit.line(pc, NS + 'rule', S);
      var tb = el('table', { class: 'exp-table' }), th = el('tr'); [NS + 'tbl.swaps', NS + 'tbl.sign', NS + 'tbl.turn'].forEach(function (id) { th.appendChild(el('th', { 'data-s': id, text: S(id) })); }); tb.appendChild(th);
      [[0, '1'], [1, 'ω'], [3, 'i'], [6, '−1'], [12, '1']].forEach(function (r) { var tr = el('tr'); tr.appendChild(el('td', { text: String(r[0]) })); tr.appendChild(el('td', { text: r[1] === '1' && r[0] ? 'ω¹² = 1' : (r[0] === 1 ? 'ω' : r[1]) })); tr.appendChild(el('td', { text: (30 * r[0]) + '°' })); tb.appendChild(tr); });
      pc.appendChild(tb);
      var rr = kit.readout(pc);
      function drawRoots() {
        var s = rc.size(), c = rc.ctx, W = s.w, H = s.h, cx = W / 2, cy = H / 2, R = Math.min(W, H) * 0.36, i;
        c.clearRect(0, 0, W, H); c.strokeStyle = kit.muted(); c.lineWidth = 1; c.beginPath(); c.arc(cx, cy, R, 0, TAU); c.stroke();
        c.beginPath(); c.moveTo(cx - R - 8, cy); c.lineTo(cx + R + 8, cy); c.moveTo(cx, cy - R - 8); c.lineTo(cx, cy + R + 8); c.globalAlpha = 0.3; c.stroke(); c.globalAlpha = 1;
        for (i = 0; i < 12; i++) {
          var a = -TAU * i / 12, x = cx + R * Math.cos(a), y = cy + R * Math.sin(a), on = i === swaps % 12;
          c.fillStyle = on ? kit.accent() : kit.panel(); c.strokeStyle = on ? kit.accent() : kit.muted(); c.lineWidth = 1.5; c.beginPath(); c.arc(x, y, on ? 7 : 4.5, 0, TAU); c.fill(); c.stroke();
          if (i < swaps) { var b = -TAU * (i + 1) / 12; c.strokeStyle = kit.warm(); c.lineWidth = 2; c.beginPath(); c.arc(cx, cy, R, a, b, true); c.stroke(); }
        }
        kit.arrow(c, cx, cy, cx + R * Math.cos(-TAU * swaps / 12) * 0.94, cy + R * Math.sin(-TAU * swaps / 12) * 0.94, kit.accent(), 2);
        c.fillStyle = kit.ink(); c.font = '12px system-ui, sans-serif'; c.textAlign = 'left'; c.fillText('1', cx + R + 10, cy - 4); c.fillText('i', cx + 4, cy - R - 10);
        var ang = TAU * swaps / 12; rr.textContent = 'ω^' + swaps + ' = ' + kit.num(Math.cos(ang), 3) + (Math.sin(ang) < -1e-9 ? ' − ' : ' + ') + kit.num(Math.abs(Math.sin(ang)), 3) + ' i';
      }

      var pz = kit.panel_(root, 'exp.common.see', S); kit.line(pz, NS + 'see', S);
      var ph2 = kit.panel_(root, 'exp.common.hear', S); kit.line(ph2, NS + 'hear', S);
      var pd = el('p', { class: 'exp-line' }); pd.appendChild(el('strong', { 'data-s': 'exp.common.data', text: S('exp.common.data') })); pd.appendChild(document.createTextNode(' ')); pd.appendChild(el('span', { 'data-s': NS + 'data', text: S(NS + 'data') })); ph2.parentNode.appendChild(el('div', { class: 'exp-panel span' }, [pd]));
      kit.loop(function (t, dt) { if (moving) T += dt; drawDial(); drawSpec(); drawTwo(); drawRoots(); });
      void gs;
    }
  };
})();
