# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# mk_r5.py — from gen/content/it/MANIFEST_R5.json, the two narrators' assignment (r5_assign.json) and material files
# (r5_E1_material.json: the rows of the kinetic X–B ramp, the titles, the site strings, the targets to re-read;
#  r5_E2_material.json: the strings of the three experiments corrected). Usage: python3 -I it/draft/mk_r5.py
import json, os
DRAFT = os.path.dirname(os.path.abspath(__file__)); SITE = os.path.dirname(os.path.dirname(DRAFT))
IT = os.path.join(SITE, 'gen', 'content', 'it')
def J(p): return json.load(open(p, encoding='utf-8'))
def W(p, o):
    with open(p, 'w', encoding='utf-8') as f: f.write(json.dumps(o, ensure_ascii=False, indent=1) + '\n')
M = J(os.path.join(IT, 'MANIFEST_R5.json'))
R = {i['target']: i for i in J(os.path.join(IT, 'racconto.json'))['items']}
T = {i['target']: i for i in J(os.path.join(IT, 'titoli.json'))['items']}
S = {i['id']: i for i in J(os.path.join(IT, 'strings_it.json'))['strings']}
C1 = J(os.path.join(DRAFT, 'r4_C1_material.json')); D2 = J(os.path.join(DRAFT, 'r4_D2_material.json'))
rules = M['rules']
# the figure's title: its caption, as release 3's narrators wrote the figures' lines (one or two sentences)
for t in M['titles']:
    if t['target'] == 'fig:fig_xb_ramp':
        t['what'] = "the Italian caption of the figure fig_xb_ramp.svg (one to three sentences, as the other figures' captions in titoli.json: say what each panel shows, in the narrator's words, not a translation of the English caption)"
        t['length'] = '40–110 words'; t['where'] = 'layers.html and pictures.html, under the figure'
        t['material'] = {'caption_en': "The kinetic X–B ramp. (a) The local waves on MUS-161's Budden ramp at Y = 9/10 about the upper hybrid layer: the running wavenumbers of the kinetic layers in the full first order (v_t/c = 1/40, solid) and of MUS-152's fluid layers (c_s/c = 1/40, dashed); the X wave on both sides, the Bernstein wave on the dense side, backward, the fluid's pressure wave on the low-density side; shaded, the layers about the upper hybrid density where the two kinetic waves form a complex pair. (b) Re E_x, the field along the wave, on the same two ramps: the kinetic converted wave on the dense side of the layer, the fluid's on the low-density side. (c) The conversion C on the Budden ramp against v_t/c (c_s/c for the fluid) at Y = 3/5, 3/4, 9/10, 2/5 and 2/7: the full first order, Ram and Schultz's form, the momentum form and the fluid; Budden's 1/4 dotted. (d) The triplet ramp at Y = 9/10 (η_L = 0.60153): 1 − C of the kinetic layers in the three forms at v_t/c = 1/20, 1/40, 1/80, 1/160, and of the fluid's layers at the same values of c_s/c. (e) Budden's ramp stretched s = 1, 2, 4 times at Y = 9/10: the departure of C from Budden's T(1 − T) in the three forms at v_t/c = 1/20 and 1/40. (f) Y = 11/20 and 13/25, near the band edge Y = 1/2: C of the three forms at v_t/c = 1/40 and 1/80. (g) The full relation's density root X*/X_UH (MUS-180) against λ = k⊥²v_t²/Ω² at Y = 9/10, 2/5 and 2/7, the certified points as open circles, the equation's first-order root dashed; the dense ends of the ramps marked.", 'rows': 'MUS-192 (a), MUS-194 (a, b, c), MUS-196 (c, e, f), MUS-197 (d), MUS-198 (g), MUS-199 (a)', 'sample_it': T['fig:fig_two_fluid']['text']}
    if t['target'] == 'check:music_xb_ramp':
        t['material']['note'] = "say what the script computes (the kinetic X–B ramp: the hot electrons' first-order response across the field carried into layered density ramps in three forms, the shares reflected, passed and converted, where the converted wave goes); do not say that the rows are proposed or not merged: that is the work's bookkeeping, never the reader's"
        t['material']['sample_it'] = T['check:music_layers']['text']
# the targets to re-read, with their current Italian
reread = []
for item in M['review']:
    for tg in [x.strip() for x in item['target'].split(',')]:
        cur = R.get(tg)
        reread.append({'target': tg, 'priority': item['priority'], 'why': item['why'], 'current_it': cur['text'] if cur else None, 'tells': cur.get('tells') if cur else None})
E1 = {
    'about': 'Narrator E1: your targets with their English material (your part of MANIFEST_R5.json): the ten rows of the kinetic X–B ramp (narration and title each), the heading of their chain, the caption of their figure, the one-line title of their script, two new site strings and five changed ones (with the previous Italian), and the narrations to re-read (with their current Italian). Voice samples from the earlier narrators follow.',
    'rules': rules, 'narrations': M['narrations'], 'titles': M['titles'], 'strings': M['strings_new'] + M['strings_changed'], 'check_only': reread,
    'chapter_layers_rows_it': {tg: T[tg]['text'] for tg in ['row:MUS-151', 'row:MUS-152', 'row:MUS-158', 'row:MUS-159', 'row:MUS-160', 'row:MUS-161'] if tg in T},
    'chapter_layers_narration_it': R['section:layers']['text'], 'chapter_layers_title_it': T['section:layers']['text'],
    'voice_samples': C1['voice_samples'],
}
ex = M['experiments']['strings']
byexp = {}
for s in ex: byexp.setdefault(s['experiment'], []).append(s)
E2 = {
    'about': 'Narrator E2: the strings of the three experiments corrected (your part of MANIFEST_R5.json, group "experiments"): the strings each experiment added, and four of each whose English changed (with the previous Italian in previousIt). The release-4 Italian of every other string of these three experiments is given for the terms and the voice, so that the pages read as one hand.',
    'rules': rules, 'narrations': [], 'titles': [], 'strings': ex, 'check_only': [],
    'strings_by_experiment': {k: {'title_it': S.get(f'exp.{k}.title', {}).get('text'), 'lead_it': S.get(f'exp.{k}.lead', {}).get('text'), 'strings': v} for k, v in byexp.items()},
    'release4_italian_of_these_experiments': {k: [{'id': i, 'en': None, 'it': S[i]['text']} for i in S if i.startswith(f'exp.{k}.') and not S[i].get('stub')] for k in byexp},
    'voice_samples': D2.get('voice_samples', C1['voice_samples']),
}
# the English of the release-4 strings beside their Italian, for the terms
EN = {}
for k in byexp:
    for e in J(os.path.join(SITE, 'gen', 'exp', f'{k}.strings.json'))['strings']: EN[e['id']] = e['text']
for k, lst in E2['release4_italian_of_these_experiments'].items():
    for e in lst: e['en'] = EN.get(e['id'])
assign = {
    'E1': {'narrations': [n['target'] for n in M['narrations']], 'titles': [t['target'] for t in M['titles']], 'strings': [s['id'] for s in E1['strings']], 'rewrite_narrations': [], 'rewrite_titles': [], 'check_only': [r['target'] for r in reread]},
    'E2': {'narrations': [], 'titles': [], 'strings': [s['id'] for s in ex], 'rewrite_narrations': [], 'rewrite_titles': [], 'check_only': []},
}
W(os.path.join(DRAFT, 'r5_assign.json'), assign); W(os.path.join(DRAFT, 'r5_E1_material.json'), E1); W(os.path.join(DRAFT, 'r5_E2_material.json'), E2)
print('E1', {k: len(v) for k, v in assign['E1'].items()}, 'E2', {k: len(v) for k, v in assign['E2'].items()})
