# xb_ramp.json: the field profiles are not per unit incident E_y (a note for the merge of the kinetic X–B ramp)

**What the site's builder saw.** In `figdata/xb_ramp.json ramps`, both for Y = 9/10, the fluid ramp's |E_y| runs 0.07–0.21 and the kinetic ramp's 0.39–1.16, while the `units` line says "fields for a unit incident E_y".

**The cause, in the writer** (`music_xb_ramp.py`). `scatter_solve` sets the incident wave as a unit coefficient of the incidence half-space's *normalized mode vector*: `f[iX] = 1.0 + 0j`, and `wave_vec` divides each wave's vector by its norm `nr`. So the stored fields are per unit amplitude of the normalized vector of each form, not per unit E_y. The two forms normalize differently:

- the full first order's vector is (E_x, E_y, Π_x, Π_y) with |E_x/E_y| = |D/S| ≈ 0.49 and Π_y ≈ kE_y (k ≈ 0.70) at the entry density X = 0.0666, Y = 9/10: norm² ≈ 1.7 |E_y|², so the incident |E_y| ≈ 0.76;
- the momentum form's vector is (E_y, H_z, P, v_x) with v_x = E_x/(iX): |v_x| ≈ 0.49 |E_y|/0.0666 ≈ 7.3 |E_y|, norm² ≈ 55 |E_y|², so the incident |E_y| ≈ 0.13.

With the reflected wave (|r| ≈ 0.49) added, that gives exactly the two ranges seen: 0.39–1.16 and 0.07–0.21. The ratio is the normalization, not the physics; `R`, `T`, `C` are unaffected (they are fluxes per unit incident flux).

**The fix** (three lines, if the fields are meant per unit incident E_y, as the units line says):

1. in `scatter_solve`, after `iX` is found, keep the incident wave's normalized vector: `out['inc'] = wave_vec(layers[0][0], iX)`;
2. in `g_fig`, after `o = ramp(...)`, divide by its E_y component — index 0 of (E_y, H_z, P, v_x) for the fluid run, index 1 of (E_x, E_y, Π_x, Π_y) for the kinetic one:
   `Ey0 = o['inc'][0 if fl else 1]; Ey = [v / Ey0 for v in Ey]; Ex = [v / Ey0 for v in Ex]`;
3. rerun `sx·FIG` (the group takes a second) and the figure script; the log line of `sx·FIG` #1 and `FIGURES_INDEX.md` (panel (b) says "for a unit incident E_y") then say what the file holds.

Or, leaving the numbers as they are, change the `units` line to "fields for a unit amplitude of the incident wave's normalized vector in each form" and the figure's panel (b) caption likewise.

**On the site** (release 5, the layers experiment, panel *The hot electrons' wave on the ramp*): each trace is scaled to its own largest, which is printed, and the caption says the two forms normalize the incident wave differently; nothing else depends on it.
