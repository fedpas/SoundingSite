// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// harmonics.js — the gyration's harmonics: Bernstein bands across B0, a small tilt, damping along B0, the thresholds and the firehose.
(function () {
  'use strict';
  window.SDV_EXP = window.SDV_EXP || {};
  var SL = 'harmonics', P = 'exp.harmonics.';
  window.SDV_EXP[SL] = { mount: function (root, data, S, kit) {
    var D = data, reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
    root.classList.add('half');
    var HZ = 1000;                                   // Omega <-> 1000 Hz in every panel
    var st = { lam: 1, q: '1', kp: 1.0, tan: 0.025, dist: 'maxwell', mode: 'whistler', k: 0.6, ratio: 0.8, snd: false, paused: reduce, t: 0, fhT: 0, fhWas: null };
    function cvs(panel, a, m) { var b = kit.el('div'); panel.appendChild(b); return kit.canvas(b, a, m); }
    function pairs(arr, i) { return arr.map(function (p) { return [p[0], p[i]]; }); }
    function sound() { if (!st.snd) return false; return true; }
    var nf;
    function playBtn(ctl) {
      var b = kit.button(ctl, 'exp.common.play', S, function () {
        if (!st.snd) { if (!kit.audio()) { nf.style.display = ''; return; } st.snd = true; } else st.snd = false;
        b.textContent = S(st.snd ? 'exp.common.mute' : 'exp.common.play'); b.setAttribute('data-s', st.snd ? 'exp.common.mute' : 'exp.common.play');
      });
    }
    var BAND = { 1: '1', 2: '2', 3: '3', 4: '4' };
    function bandW(q, b, kp) { var br = D.branches[q]; var pts = br.kperp.map(function (k, i) { return [k, br.bands[b][i]]; }); return kit.interp(pts, kp); }

    // ------------------------------------------------------------ (a) the gyration
    var pa = kit.panel_(root, P + 'panel.gyr', S);
    var ca = kit.controls(pa); playBtn(ca);
    kit.button(ca, 'exp.common.strike', S, strikeChord);
    var bP = kit.button(ca, 'exp.common.pause', S, function () { st.paused = !st.paused; bP.setAttribute('aria-pressed', String(st.paused)); }); bP.setAttribute('aria-pressed', String(st.paused));
    kit.slider(ca, { id: P + 'kp', S: S, min: 0.05, max: 3, step: 0.05, value: st.kp, fmt: function (v) { return kit.num(v, 2); }, onchange: function (v) { st.kp = v; draw(); } });
    nf = kit.line(pa, 'exp.common.noaudio', S, 'exp-note'); nf.style.display = 'none';
    var cvG = cvs(pa, 0.5, 280);
    kit.line(pa, P + 'cap.gyr', S);
    var rdG = kit.readout(pa);
    var cl = kit.controls(pa);
    kit.slider(cl, { id: P + 'lam', S: S, min: 0.01, max: 10, log: true, value: st.lam, fmt: function (v) { return kit.num(v, v < 0.1 ? 3 : 2); }, onchange: function (v) { st.lam = v; drawW(); } });
    var cvW = cvs(pa, 0.5, 260);
    kit.line(pa, P + 'cap.bars', S);
    var rdW1 = kit.readout(pa), rdW2 = kit.readout(pa), rdW3 = kit.readout(pa);

    // ------------------------------------------------------------ (b) the bands
    var pb = kit.panel_(root, P + 'panel.bands', S);
    var cb = kit.controls(pb);
    kit.seg(cb, { ids: [P + 'q.1', P + 'q.4'], values: ['1', '4'], value: '1', S: S, onchange: function (v) { st.q = v; draw(); } });
    var cvB = cvs(pb, 0.62, 300);
    kit.line(pb, P + 'cap.bands', S);
    var rdB = kit.readout(pb);
    var cvS = cvs(pb, 0.4, 190);
    kit.line(pb, P + 'cap.side', S);
    var rdS = kit.readout(pb);

    // ------------------------------------------------------------ (c) tilt
    var pc = kit.panel_(root, P + 'panel.tilt', S);
    var cc = kit.controls(pc);
    kit.seg(cc, { ids: [P + 'd.maxwell', P + 'd.k6', P + 'd.k2'], values: ['maxwell', 'k6', 'k2'], value: 'maxwell', S: S, onchange: function (v) { st.dist = v; draw(); } });
    kit.slider(cc, { id: P + 'tan', S: S, min: 0.01, max: 1 / 12, step: 0.0005, value: st.tan, fmt: function (v) { return kit.num(v, 4) + ' · ' + kit.num(Math.atan(v) * 180 / Math.PI, 2) + '°'; }, onchange: function (v) { st.tan = v; draw(); } });
    kit.button(cc, P + 'send', S, soundTilt);
    var cvT = cvs(pc, 0.6, 300);
    kit.line(pc, P + 'cap.tilt', S);
    var rdT = kit.readout(pc), rdT2 = kit.readout(pc);
    var cvPl = cvs(pc, 0.5, 220);
    kit.line(pc, P + 'cap.plane', S);

    // ------------------------------------------------------------ (d) along the field
    var pd = kit.panel_(root, P + 'panel.along', S);
    var cd = kit.controls(pd);
    kit.seg(cd, { ids: [P + 'm.whistler', P + 'm.icw'], values: ['whistler', 'icw'], value: 'whistler', S: S, onchange: function (v) { st.mode = v; kS.set(Math.min(st.k, v === 'icw' ? 1.5 : 1.3)); st.k = kS.get(); draw(); } });
    var kS = kit.slider(cd, { id: 'exp.common.wavenumber', S: S, min: 0.2, max: 1.3, step: 0.02, value: st.k, fmt: function (v) { return kit.num(v, 2); }, onchange: function (v) { st.k = v; draw(); } });
    kit.button(cd, P + 'send.along', S, soundAlong);
    var cvA = cvs(pd, 0.6, 300);
    kit.line(pd, P + 'cap.along', S);
    var rdA = kit.readout(pd);

    // ------------------------------------------------------------ (e) thresholds and the firehose
    var pe = kit.panel_(root, P + 'panel.thr', S);
    var tbl = kit.el('table', { class: 'exp-table' });
    var th = kit.el('tr'); th.appendChild(kit.el('th', { 'data-s': P + 'thr.instab', text: S(P + 'thr.instab') }));
    ['maxwell', 'k2', 'k6'].forEach(function (d) { th.appendChild(kit.el('th', { 'data-s': P + 'd.' + d, text: S(P + 'd.' + d) })); }); tbl.appendChild(th);
    var rowsT = [['thr.wai', 'WAI/max/2', 'WAI/bi/2/2', 'WAI/bi/6/2'], ['thr.emic', 'EMIC/max/2/0.01', 'EMIC/bi/2/2/1/100', 'EMIC/bi/6/2/1/100'], ['thr.fire', 'FIRE/max/2', 'FIRE/bi/2/2', 'FIRE/bi/6/2']];
    rowsT.forEach(function (r) { var tr = kit.el('tr'); tr.appendChild(kit.el('td', { 'data-s': P + r[0], text: S(P + r[0]) })); for (var i = 1; i < 4; i++) tr.appendChild(kit.el('td', { text: kit.num(D.thr[r[i]][0], 3) })); tbl.appendChild(tr); });
    pe.appendChild(tbl);
    kit.line(pe, P + 'cap.thr', S);
    var ce = kit.controls(pe);
    kit.slider(ce, { id: P + 'ratio', S: S, min: 0.3, max: 1.3, step: 0.01, value: st.ratio, fmt: function (v) { return kit.num(v, 2); }, onchange: function (v) { st.ratio = v; } });
    var cvF = cvs(pe, 0.36, 200);
    kit.line(pe, P + 'cap.fire', S);
    var rdF = kit.readout(pe), stat = kit.line(pe, P + 'stable', S, 'exp-note');

    // ------------------------------------------------------------ sound
    function strikeChord() {
      if (!st.snd) return;
      var parts = [], w = weights(st.lam, 8), mx = 0, n; for (n = 1; n <= 8; n++) mx = Math.max(mx, w[n]);
      for (n = 1; n <= 8; n++) parts.push({ f: HZ * n, a: w[n] / mx, decay: 1.1 });
      kit.strike(parts, 0.14);
      for (var b = 1; b <= 4; b++) { var w = bandW(st.q, b, st.kp); if (w) kit.tone({ f: w * HZ, gain: 0.05, dur: 1.6, at: 1.0 + 0.0 * b }); }
    }
    function tiltPt() { return kit.interp(pairs(D.damping.tan.map(function (t, i) { return [t, D.damping[st.dist][i][0]]; }), 1), st.tan); }
    function tiltIm() { return kit.interp(D.damping.tan.map(function (t, i) { return [t, D.damping[st.dist][i][1]]; }), st.tan); }
    function soundTilt() {
      if (!st.snd) return; var re = tiltPt(), im = tiltIm(); if (re == null) return;
      var g = Math.abs(im) * 2 * Math.PI * HZ; kit.tone({ f: re * HZ, gain: 0.16, decay: Math.min(8, 1 / Math.max(g, 1e-3)), maxDur: 4 });
    }
    function alongPt() { var a = D[st.mode].maxwell === undefined ? null : null; return a; }
    function curveAt(key) { var c = D[st.mode][key]; var re = kit.interp(c.map(function (p) { return [p[0], p[1]]; }), st.k); var pts = c.filter(function (p) { return p[2] != null; }); return { re: re, im: kit.interp(pts.map(function (p) { return [p[0], p[2]]; }), st.k) }; }
    function soundAlong() {
      if (!st.snd) return; var m = curveAt('2'); if (m.re == null || m.im == null) return;
      var g = Math.abs(m.im) * 2 * Math.PI * HZ; kit.tone({ f: m.re * HZ, gain: 0.16, decay: Math.min(8, 1 / Math.max(g, 1e-3)), maxDur: 4 });
    }

    // ------------------------------------------------------------ drawing
    // the harmonic weights Lambda_n(lambda) = I_n(lambda) e^(-lambda): Miller's backward recurrence I_(n-1) = (2n/lambda) I_n + I_(n+1) from sixty orders above,
    // normalised by Neumann's identity Lambda_0 + 2 sum Lambda_n = 1 (the method the Atlas certifies against its enclosures, sb·BESSEL)
    function weights(lam, nmax) {
      var M = nmax + D.bessel.orders_above, I = new Array(M + 2), n, s;
      I[M + 1] = 0; I[M] = 1e-30;
      for (n = M; n >= 1; n--) { I[n - 1] = (2 * n / lam) * I[n] + I[n + 1]; if (I[n - 1] > 1e100) { for (var j = n - 1; j <= M + 1; j++) I[j] *= 1e-100; } }
      s = I[0]; for (n = 1; n <= M; n++) s += 2 * I[n];
      var L = []; for (n = 0; n <= M; n++) L.push(I[n] / s);
      return L;
    }
    function fmtW(v) { return v < 1e-3 ? kit.sci(v, 2) : kit.num(v, 5); }
    function drawW() {
      var c = cvW.ctx, W = cvW.size().w, H = cvW.h; c.clearRect(0, 0, W, H);
      var box = { l: 46, r: W - 10, t: 12, b: H - 56 }, w = weights(st.lam, 8), cert = D.bessel.certified;
      var ax = kit.axes(c, box, { xmin: -0.5, xmax: 8.5, ymin: 0, ymax: 1, xticks: [], yticks: [0, 0.5, 1], ylabel: S(P + 'cv.w') });
      c.font = '11px system-ui, sans-serif'; c.textAlign = 'center';
      for (var n = 0; n <= 8; n++) {
        var x0 = ax.x(n - 0.35), x1 = ax.x(n + 0.35); c.fillStyle = n === 0 ? kit.muted() : kit.accent(); c.fillRect(x0, ax.y(w[n]), x1 - x0, box.b - ax.y(w[n]));
        c.fillStyle = kit.muted(); c.fillText('n = ' + n, ax.x(n), box.b + 14);
      }
      // the lambda axis, log, with the seven certified values marked and the slider's value
      var y0 = H - 18, lx = function (l) { return box.l + (Math.log(l) - Math.log(0.01)) / (Math.log(10) - Math.log(0.01)) * (box.r - box.l); };
      c.strokeStyle = kit.muted(); c.lineWidth = 1; c.beginPath(); c.moveTo(box.l, y0); c.lineTo(box.r, y0); c.stroke();
      cert.forEach(function (p) { c.fillStyle = kit.ink(); c.beginPath(); c.arc(lx(p[0]), y0, 3.5, 0, 6.2832); c.fill(); c.fillStyle = kit.muted(); c.textAlign = 'center'; c.fillText(String(p[0]), lx(p[0]), y0 + 14); });
      c.fillStyle = kit.warm(); c.beginPath(); c.moveTo(lx(st.lam), y0 - 2); c.lineTo(lx(st.lam) - 5, y0 - 11); c.lineTo(lx(st.lam) + 5, y0 - 11); c.closePath(); c.fill();
      c.fillStyle = kit.muted(); c.textAlign = 'right'; c.fillText('λ', box.l - 8, y0 + 4);
      var sum = w[0], M = w.length - 1, k; for (k = 1; k <= M; k++) sum += 2 * w[k];
      var N = 8, lam = st.lam, T = w[0] * Math.pow(lam / 2, N + 1); for (k = 2; k <= N + 1; k++) T /= k; T /= (1 - lam / (2 * (N + 2)));
      var hit = cert.filter(function (p) { return Math.abs(Math.log(p[0] / lam)) < 0.03; })[0];
      rdW1.textContent = S(P + 'rd.w').replace('{l}', kit.num(lam, lam < 0.1 ? 3 : 2)) + ' ' + w.slice(0, 9).map(fmtW).join(', ');
      rdW2.textContent = S(P + 'rd.sum').replace('{s}', sum.toFixed(12)).replace('{t}', kit.sci(2 * T, 2)) + (hit ? ' ' + S(P + 'rd.cert').replace('{n}', hit[1]) : '');
      rdW3.textContent = S(P + 'rd.method').replace('{e}', kit.sci(D.bessel.max_rel_error, 1));
    }
    function drawGyr(t) {
      var c = cvG.ctx, W = cvG.size().w, H = cvG.h; c.clearRect(0, 0, W, H);
      var hw = W * 0.45, cx = hw / 2 + 4, cy = H / 2, ppr = Math.min(hw / 2.6, H / 2.6), k = st.kp;
      c.save(); c.beginPath(); c.rect(4, 4, hw, H - 8); c.clip();
      for (var j = -40; j <= 40; j++) { var xr = (j * 2 * Math.PI) / k; var x0 = cx + xr * ppr, w = Math.PI / k * ppr; if (x0 > 4 + hw || x0 + w < 4) continue; c.fillStyle = 'rgba(194,74,58,0.13)'; c.fillRect(x0 - w / 2, 4, w, H - 8); }
      c.restore();
      c.strokeStyle = kit.muted(); c.lineWidth = 1; c.beginPath(); c.arc(cx, cy, ppr, 0, 6.2832); c.stroke();
      var ph = 2 * Math.PI * t / 4, ex = cx + ppr * Math.cos(ph), ey = cy - ppr * Math.sin(ph);
      c.fillStyle = kit.blue; c.beginPath(); c.arc(ex, ey, 5, 0, 6.2832); c.fill();
      c.fillStyle = kit.muted(); c.font = '11px system-ui, sans-serif'; c.textAlign = 'center'; c.fillText('⊙ B₀', cx, cy + 4);
      // the phase the electron meets, against time over three gyrations
      var box = { l: hw + 24, r: W - 8, t: 14, b: H - 14 };
      c.strokeStyle = kit.muted(); c.strokeRect(box.l, box.t, box.r - box.l, box.b - box.t);
      c.strokeStyle = kit.accent(); c.lineWidth = 1.8; c.beginPath();
      for (var i = 0; i <= 240; i++) { var tt = 3 * i / 240, y = box.b - (box.b - box.t) * (0.5 + 0.5 * Math.cos(k * Math.cos(2 * Math.PI * tt))); var x = box.l + (box.r - box.l) * tt / 3; if (i === 0) c.moveTo(x, y); else c.lineTo(x, y); }
      c.stroke();
      var tm = (t / 4) % 3; c.fillStyle = kit.warm(); c.beginPath(); c.arc(box.l + (box.r - box.l) * tm / 3, box.b - (box.b - box.t) * (0.5 + 0.5 * Math.cos(k * Math.cos(2 * Math.PI * tm))), 4.5, 0, 6.2832); c.fill();
      rdG.textContent = 'k⊥ρ = ' + kit.num(k, 2) + ';  ' + S('exp.common.slowed').replace('{n}', kit.num(Math.round(4 * HZ), 0));
    }
    function drawBands() {
      var c = cvB.ctx, W = cvB.size().w, H = cvB.h; c.clearRect(0, 0, W, H);
      var br = D.branches[st.q], box = { l: 40, r: W - 10, t: 12, b: H - 34 }, ymax = 5;
      var ax = kit.axes(c, box, { xmin: 0, xmax: 3, ymin: 0, ymax: ymax, xticks: [0, 1, 2, 3], yticks: [0, 1, 2, 3, 4, 5], xlabel: 'k⊥ρ', ylabel: 'ω / Ω' });
      c.strokeStyle = kit.muted(); c.lineWidth = 1; c.setLineDash([2, 3]); for (var n = 1; n <= 5; n++) { c.beginPath(); c.moveTo(box.l, ax.y(n)); c.lineTo(box.r, ax.y(n)); c.stroke(); } c.setLineDash([]);
      c.strokeStyle = kit.warm(); c.setLineDash([5, 3]); c.beginPath(); c.moveTo(box.l, ax.y(br.wUH)); c.lineTo(box.r, ax.y(br.wUH)); c.stroke(); c.setLineDash([]);
      c.fillStyle = kit.warm(); c.font = '11px system-ui, sans-serif'; c.textAlign = 'left'; c.fillText(S(P + 'cv.uh') + ' ' + kit.num(br.wUH, 3), box.l + 4, ax.y(br.wUH) - 4);
      for (var b = 1; b <= 4; b++) kit.curve(c, br.kperp.map(function (k, i) { return [k, br.bands[b][i]]; }), ax.x, ax.y, kit.blue, 1.6);
      c.strokeStyle = kit.accent(); c.lineWidth = 1; c.beginPath(); c.moveTo(ax.x(st.kp), box.t); c.lineTo(ax.x(st.kp), box.b); c.stroke();
      var txt = [];
      for (b = 1; b <= 4; b++) { var w = bandW(st.q, b, st.kp); if (w != null) { c.fillStyle = kit.accent(); c.beginPath(); c.arc(ax.x(st.kp), ax.y(w), 4, 0, 6.2832); c.fill(); txt.push(kit.num(w, 3)); } }
      rdB.textContent = 'ω/Ω at k⊥ρ = ' + kit.num(st.kp, 2) + ':  ' + txt.join(', ');
    }
    function drawSide() {
      var c = cvS.ctx, W = cvS.size().w, H = cvS.h; c.clearRect(0, 0, W, H);
      var box = { l: 40, r: W - 10, t: 10, b: H - 32 }, sd = D.side, ys = [], key = Object.keys(sd.curves);
      key.forEach(function (k) { sd.curves[k].forEach(function (v) { if (v != null) ys.push(v); }); });
      var ymin = -2, ymax = 4;
      var ax = kit.axes(c, box, { xmin: 0.001, xmax: 5, xlog: true, ymin: ymin, ymax: ymax, xticks: [0.001, 0.01, 0.1, 1], yticks: [0], xlabel: 'λ = (k⊥ρ)²', ylabel: S(P + 'cv.side') });
      var cols = [kit.blue, kit.accent(), kit.warm(), kit.red];
      c.save(); c.beginPath(); c.rect(box.l, box.t, box.r - box.l, box.b - box.t); c.clip();
      key.forEach(function (k, j) { kit.curve(c, sd.lam.map(function (l, i) { return sd.curves[k][i] == null ? [NaN, NaN] : [l, sd.curves[k][i]]; }), ax.x, ax.y, cols[j % 4], 1.5); });
      c.restore();
      c.strokeStyle = kit.muted(); c.lineWidth = 1; c.beginPath(); c.moveTo(box.l, ax.y(0)); c.lineTo(box.r, ax.y(0)); c.stroke();
      var tx = []; Object.keys(sd.cross).forEach(function (k) { var l = sd.cross[k][0]; c.fillStyle = kit.ink(); c.beginPath(); c.arc(ax.x(l), ax.y(0), 4.5, 0, 6.2832); c.fill(); tx.push('Y = ' + kit.num(parseFloat(k), 3) + ' → λ = ' + kit.num(l, 3)); });
      c.font = '11px system-ui, sans-serif'; c.textAlign = 'left'; key.forEach(function (k, j) { c.fillStyle = cols[j % 4]; c.fillText('Y = ' + kit.num(parseFloat(k), 3), box.l + 6 + j * 70, box.t + 12); });
      rdS.textContent = tx.join(';  ');
    }
    function drawTilt() {
      var c = cvT.ctx, W = cvT.size().w, H = cvT.h; c.clearRect(0, 0, W, H);
      var box = { l: 52, r: W - 10, t: 10, b: H - 34 };
      var ax = kit.axes(c, box, { xmin: 0.01, xmax: 1 / 12, ymin: 1e-7, ymax: 0.3, ylog: true, xticks: [0.01, 0.025, 0.05, 0.08], yticks: [1e-6, 1e-4, 1e-2], xlabel: 'tan θ = k∥/k⊥', ylabel: S(P + 'cv.rate') });
      c.save(); c.beginPath(); c.rect(box.l, box.t, box.r - box.l, box.b - box.t); c.clip();
      var cols = { maxwell: kit.ink(), k6: kit.blue, k2: kit.red };
      ['maxwell', 'k6', 'k2'].forEach(function (d) { kit.curve(c, D.damping.tan.map(function (t, i) { return [t, -D.damping[d][i][1]]; }), ax.x, ax.y, cols[d], d === st.dist ? 2.4 : 1.2); });
      c.restore();
      // the certified points and the Lorentzian
      var cm = D.damping.certified_maxwell, ck = D.damping.certified_kappa;
      [['1/40', 0.025], ['1/20', 0.05]].forEach(function (p) { c.fillStyle = kit.ink(); c.beginPath(); c.arc(ax.x(p[1]), ax.y(-cm[p[0]][1]), 3.5, 0, 6.2832); c.fill(); c.fillStyle = kit.blue; c.beginPath(); c.arc(ax.x(p[1]), ax.y(-ck['6/1/' + p[0].split('/')[1]][1]), 3.5, 0, 6.2832); c.fill(); c.fillStyle = kit.red; c.beginPath(); c.arc(ax.x(p[1]), ax.y(-ck['2/1/' + p[0].split('/')[1]][1]), 3.5, 0, 6.2832); c.fill(); });
      c.fillStyle = kit.violet; c.beginPath(); c.arc(ax.x(0.025), ax.y(-D.plane.lor[1]), 4, 0, 6.2832); c.fill();
      c.strokeStyle = kit.accent(); c.lineWidth = 1; c.beginPath(); c.moveTo(ax.x(st.tan), box.t); c.lineTo(ax.x(st.tan), box.b); c.stroke();
      c.font = '11px system-ui, sans-serif'; c.textAlign = 'left'; [['maxwell', S(P + 'd.maxwell')], ['k6', S(P + 'd.k6')], ['k2', S(P + 'd.k2')]].forEach(function (p, j) { c.fillStyle = cols[p[0]]; c.fillText(p[1], box.l + 6 + j * 80, box.t + 12); });
      c.fillStyle = kit.violet; c.fillText(S(P + 'd.lor'), box.l + 6 + 240, box.t + 12);
      var im = tiltIm();
      rdT.textContent = 'tan θ = ' + kit.num(st.tan, 4) + ':  Im ω/Ω = ' + (im == null ? S('exp.common.outside') : kit.sci(im, 2));
      var m40 = cm['1/40'][1], k6 = ck['6/1/40'][1], k2 = ck['2/1/40'][1], m20 = cm['1/20'][1];
      rdT2.textContent = 'tan θ = 1/40:  κ = 6 ' + kit.num(k6 / m40, 1) + '× and κ = 2 ' + kit.num(k2 / m40, 1) + '× the Maxwellian;  tan θ = 1/20 against 1/40, Maxwellian: ' + kit.num(m20 / m40, 0) + '×';
    }
    function drawPlane() {
      var c = cvPl.ctx, W = cvPl.size().w, H = cvPl.h; c.clearRect(0, 0, W, H);
      var box = { l: 48, r: W - 10, t: 10, b: H - 32 };
      var ax = kit.axes(c, box, { xmin: 1.85, xmax: 2.2, ymin: -0.13, ymax: 0.01, xticks: [1.9, 2.0, 2.1, 2.2], yticks: [-0.1, -0.05, 0], xlabel: 'Re ω / Ω', ylabel: 'Im ω / Ω' });
      function dot(p, col, r) { if (!p) return; c.fillStyle = col; c.beginPath(); c.arc(ax.x(p[0]), ax.y(p[1]), r || 4, 0, 6.2832); c.fill(); }
      D.plane.maxwell.forEach(function (p) { dot(p, kit.muted(), 3.5); });
      dot(D.plane.certified, kit.ink(), 5); dot(D.plane.cold, kit.accent(), 4.5); dot(D.plane.k2, kit.red, 4.5); dot(D.plane.k6, kit.blue, 4.5); dot(D.plane.lor, kit.violet, 4.5);
    }
    function drawAlong() {
      var c = cvA.ctx, W = cvA.size().w, H = cvA.h; c.clearRect(0, 0, W, H);
      var box = { l: 52, r: W - 10, t: 10, b: H - 34 }, kmax = st.mode === 'icw' ? 1.5 : 1.3;
      var ax = kit.axes(c, box, { xmin: 0.1, xmax: kmax, ymin: 1e-12, ymax: 0.3, ylog: true, xticks: [0.2, 0.5, 1.0].concat(st.mode === 'icw' ? [1.5] : [1.3]), yticks: [1e-10, 1e-6, 1e-2], xlabel: S(st.mode === 'icw' ? P + 'cv.kdi' : P + 'cv.kde'), ylabel: S(P + 'cv.rate') });
      var keys = [['1', kit.red], ['2', kit.warm()], ['6', kit.blue], ['14', kit.violet], ['maxwell', kit.ink()]];
      c.save(); c.beginPath(); c.rect(box.l, box.t, box.r - box.l, box.b - box.t); c.clip();
      keys.forEach(function (kc) { kit.curve(c, D[st.mode][kc[0]].filter(function (p) { return p[2] != null; }).map(function (p) { return [p[0], -p[2]]; }), ax.x, ax.y, kc[1], kc[0] === 'maxwell' ? 2.2 : 1.5); });
      c.restore();
      c.font = '11px system-ui, sans-serif'; c.textAlign = 'left'; keys.forEach(function (kc, j) { c.fillStyle = kc[1]; c.fillText(kc[0] === 'maxwell' ? S(P + 'd.maxwell') : 'κ = ' + kc[0], box.l + 6 + j * 62, box.t + 12); });
      c.strokeStyle = kit.accent(); c.beginPath(); c.moveTo(ax.x(st.k), box.t); c.lineTo(ax.x(st.k), box.b); c.stroke();
      var m = curveAt('2'), mw = curveAt('maxwell');
      rdA.textContent = 'k = ' + kit.num(st.k, 2) + ':  κ = 2: ω = ' + (m.re == null ? '—' : kit.num(m.re, 4)) + (m.im == null ? '' : ',  Im ω = ' + kit.sci(m.im, 2)) + (mw.im == null ? '' : ';  ' + S(P + 'd.maxwell') + ': Im ω = ' + kit.sci(mw.im, 2));
    }
    function drawFire(dt) {
      var c = cvF.ctx, W = cvF.size().w, H = cvF.h; c.clearRect(0, 0, W, H);
      var key = { maxwell: 'FIRE/max/2', k2: 'FIRE/bi/2/2', k6: 'FIRE/bi/6/2' }[st.dist === 'k6' ? 'k6' : st.dist === 'k2' ? 'k2' : 'maxwell'];
      var thr = D.thr[key][0], unst = st.ratio < thr;
      if (st.fhWas !== unst) { st.fhT = 0; st.fhWas = unst; stat.textContent = S(unst ? P + 'unstable' : P + 'stable'); stat.setAttribute('data-s', unst ? P + 'unstable' : P + 'stable'); }
      if (!st.paused) st.fhT += dt;
      var a = unst ? Math.min(1, 0.04 * Math.exp(st.fhT / 1.1)) : 0;
      for (var r = 0; r < 3; r++) {
        var y0 = H * (0.25 + 0.25 * r); c.strokeStyle = r === 1 ? kit.accent() : kit.muted(); c.lineWidth = r === 1 ? 2.2 : 1.2; c.beginPath();
        for (var i = 0; i <= 160; i++) { var x = i / 160, y = y0 - a * H * 0.12 * Math.sin(2 * Math.PI * 3 * x + r * 0.5); if (i === 0) c.moveTo(x * W, y); else c.lineTo(x * W, y); }
        c.stroke();
      }
      // the ions: arrows along B0, longer the hotter along the field
      var L = 14 + 28 * (1 - Math.min(1, st.ratio)); for (var j = 0; j < 8; j++) { var xx = (j + 0.5) / 8 * W; kit.arrow(c, xx - L / 2, H - 14, xx + L / 2, H - 14, kit.blue, 1.4); }
      rdF.textContent = 'T⊥/T∥ = ' + kit.num(st.ratio, 2) + ';  ' + S(P + 'thr.fire') + ' (β∥ = 2, ' + S(P + 'd.' + (st.dist)) + '): ' + kit.num(thr, 3);
    }
    function draw() { drawW(); drawBands(); drawSide(); drawTilt(); drawPlane(); drawAlong(); drawGyr(st.t); }
    var tt = 0; draw();
    kit.loop(function (t, dt) { if (!st.paused) tt += dt; st.t = tt; drawGyr(tt); drawFire(dt); });
    window.addEventListener('resize', draw);
    explain(root, SL, S, kit);
  } };
  function explain(root, slug, S, kit) {
    var p = kit.panel_(root, null, S, 'span');
    var a = kit.panel_(p, 'exp.common.see', S); kit.line(a, 'exp.' + slug + '.see', S);
    var h = kit.panel_(p, 'exp.common.hear', S); kit.line(h, 'exp.' + slug + '.hear', S);
    p.appendChild(kit.el('p', { class: 'exp-source' }, [kit.el('b', { 'data-s': 'exp.common.data', text: S('exp.common.data') }), ' ', kit.el('span', { 'data-s': 'exp.' + slug + '.data', text: S('exp.' + slug + '.data') })]));
  }
})();
