# The Sounding View, release 3 — the Italian narrators (A and B)

The owner's words for the Italian side: *"un agente professionista della musica, della matematica e della fisica che racconta il nostro sito"*. You are that narrator: you **tell** the site in Italian, you do not translate it. Release 2's voice is the model (read `it/VOICE_IT.md` §"voice" and the rules, and the `voice_samples` in your material file); keep it: present tense, precise, warm, "voi" for the reader where you address them, the narrator's "io" rarely.

The site (`SITE = /tmp/claude-0/-home-claude/394118bf-a32c-5136-a011-44d634d15d21/scratchpad/work/music/site_r3`) is now told as a story in four parts — **Sound** (tone, consonance), **Twelve** (clock, scales, groups, shapes, Fourier), **Sound beside light** (four chapters: sound and light side by side, the medium with two stiffnesses, a charged fluid, the spin of sound), **The question** — with a map of the bridges (five chapters, twelve lines, each graded before and after), a Sounds page (22 clips, 10 instruments, grouped by part) and a Reference menu (Dictionary, Checks, Pictures, Sources, Method).

## What you read (only this)

1. `it/draft/r3_<you>_material.json` — your targets with their English material, lengths and where they render; the release-2 Italian of what you rewrite or check; voice samples. **This is your main source.**
2. `it/draft/r3_assign.json` — your exact list of ids.
3. `it/VOICE_IT.md` — the voice and the rules (skim the tables of targets: they describe release 2).
4. For a row's detail, when the material is not enough: the row in `/tmp/claude-0/-home-claude/394118bf-a32c-5136-a011-44d634d15d21/scratchpad/pack38/round38_sound_light_pack/docs/round38/items/{aether,plasma,chirality,spin}/ROWS.md` (grep the id). For a page's context: `it/draft/en_r3/<page>.txt`, the English page as text — large; grep it, do not read it whole.

## What you write

One file, `it/draft/r3_<you>.json` (you are `A` or `B`):

```json
{ "narrator": "A",
  "racconto": [ { "id": "r:row:MUS-050", "target": "row:MUS-050", "tells": ["MUS-050"], "text": "…", "why": "one English line: what this narration tells" } ],
  "titoli":   [ { "id": "t:row:MUS-050", "target": "row:MUS-050", "text": "…", "why": "…" } ],
  "strings":  [ { "id": "i10.h", "text": "…" } ] }
```

- Every id of your assignment exactly once: `narrations` and `rewrite_narrations` → `racconto`; `titles` and `rewrite_titles` → `titoli`; `strings` → `strings`. A `check_only` target goes into `racconto` **only if** you rewrite it (because its release-2 Italian contradicts the English material or tells something that moved); say in your note which you checked and kept.
- `tells`: start from the `tells` the material gives; you may add ids the narration draws on, of the forms already in use (row ids such as `MUS-047`, `clip:22`, `fig:two_stiffnesses`, `check:music_aether.py`).
- Plain text: no HTML, no markdown, no TeX. Write the notation as the records print it (ω², ℤ₁₂, √3, c_P, κ/μ, Cl(1,3), 12-TET) and the numbers as the records print them (decimal point, same digits, same units), so a reader finds the same figure in the English record.
- Lengths: as the material asks (`length`, in words). Titles: one line, at most the words asked, no final period.
- Strings: the Italian for the job the string does (a label stays a label, a button stays a button); keep every `{placeholder}` exactly; where `previousIt` exists, start from it and change only what the English changed.

## The rules that the checker enforces (and the owner cares about)

- **No bookkeeping in the reading flow.** Never: round, pacchetto, proposto/a (as "proposed"), integrato/a (as "merged"), proprietario, nota di ricerca, versione, release, trivellato/perforato/drill, "non ancora nelle tavole". A reader of music, mathematics and physics does not care how the work was organized; tell what is computed, measured, read or open. (That the part *Sound beside light* reads a study whose rows are not yet the Atlas's is said once, on the Method page, by a text that is not yours: never say it.)
- **No history words** (they date the text): adesso, ora (as "now"), nuovo/a/i/e, recente, ultimo, aggiornato, precedente, corretto, sostituito, superato, "prima" in its temporal uses. The ordinal "la prima nota" is fine.
- **Names stay as they are**: record ids, file names, check tags, Atlas, Standard, The Sounding View, study titles (*Music on the labels*, *The bridges* — the site no longer calls it "The bridges drilled": never write "drilled" — *Sound beside light* as a study). Refer to the **parts and chapters by their Italian titles** (the titles you or the other narrator write; agree with the other narrator's file if it exists when you finish, else use a plain Italian description).
- Status words as release 2 says them: calcolato, standard ricalcolato, dato in ingresso, nostra lettura, aperto.
- Italian only: no English sentence in your texts (an English term of art in italics is not available — say it in Italian, or keep the proper name).

## Your share

**A** — Part III, the first three chapters: *sound and light side by side* (MUS-080, and the rewrite of MUS-049: in the site it is the computed shear-sector correspondence plus the pressure obstruction, no longer a reading; the word "translation" is MUS-080's, ours), *the medium with two stiffnesses* (MUS-050 … 055, 075, 070 … 074, INP-133 … 135), *a charged fluid* (MUS-056 … 058, 076 … 079, 081 … 086); the part's own narration (`part:light`), its title and card; the instrument "two stiffnesses" (`instrument:stiff` and its strings `i10.*`), clip 22, the two figures of these chapters.

**B** — the fourth chapter of Part III, *the spin of sound* (MUS-060 … 069, 087, INP-136 … 139; MUS-066 is open: tell both readings, the half and the full, their sources, and the experiment that would decide); the parts *Sound* and *Twelve* (`part:sound`, `part:twelve`) and the titles and cards of all parts but III; the map of the bridges (its five chapters `bridgech:*`, the title of line P and what decided it, the rewrite of the map's own narration `page:bridges` and titles, and `bridge:2:why`: bridge 2 now reads exact on the shear sector, none for the pressure, "translation" ours); the lens entries 35 … 47; the six scripts' one-line titles and `checks:light`; INP-131 and INP-132; every remaining string; and the rewrites of the page narrations whose counts and structure changed (`page:home`: four parts and two doors; `page:dictionary`: 47 entries; `page:sounds`: 22 clips, 10 instruments grouped by part, 43 assertions of the audio test; `page:sources`: three studies; `page:checks`: seventeen scripts in three groups, the first of which the narration tells; `page:pictures`: 29 figures grouped by part). Check the `check_only` targets and rewrite only what contradicts.

## Before you finish

Run `node it/draft/check_r3.mjs it/draft/r3_<you>.json` from `SITE` (NODE_PATH=/opt/npm-tools/node_modules not needed): 0 errors. Read its warnings (lengths, English left) and fix what is real. Then write `it/draft/NOTE_IT-3<you>.md` (short: what you wrote, the Italian titles you gave the parts and chapters, what you checked and kept, any doubt about a row's physics) and report in a few lines. Do not edit anything else: the coordinator merges your file into the tables and builds. Work economically.
