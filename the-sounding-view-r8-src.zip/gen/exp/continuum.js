// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// continuum — the beaded string becomes a string; bars and drums (MUS-002, MUS-003).
(function () {
  'use strict';
  window.SDV_EXP = window.SDV_EXP || {};
  var RM = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  function cents(r) { return 1200 * Math.log(r) / Math.LN2; }
  function rep(s, o) { for (var k in o) s = s.replace('{' + k + '}', o[k]); return s; }
  function cv(kit, parent, aspect, maxH) { var d = kit.el('div', { style: 'width:100%;min-width:0' }); parent.appendChild(d); return kit.canvas(d, aspect, maxH); }
  function txt(ctx, s, x, y, al, col, px) { ctx.fillStyle = col; ctx.font = (px || 11) + 'px system-ui, sans-serif'; ctx.textAlign = al || 'left'; ctx.fillText(s, x, y); }
  // one Play/Mute per panel (only one sounds at a time) and one Pause for the picture
  function transport(kit, S) {
    var st = { paused: RM }, cur = null, hasAudio = !!(window.AudioContext || window.webkitAudioContext), warned = false;
    st.pause = function (controls) {
      var p = kit.button(controls, 'exp.common.pause', S, function () { st.paused = !st.paused; show(); if (st.onpause) st.onpause(); });
      function show() { p.setAttribute('aria-pressed', String(st.paused)); p.style.background = st.paused ? 'var(--accent-tint)' : ''; }
      show(); return p;
    };
    st.player = function (controls, o) {
      var me = { on: false };
      var b = kit.button(controls, 'exp.common.play', S, function () {
        if (me.on) { me.stop(); return; }
        if (!hasAudio || !kit.audio()) { b.disabled = true; if (!warned) { warned = true; kit.line(controls.parentNode, 'exp.common.noaudio', S); } return; }
        if (cur && cur !== me) cur.stop();
        me.on = true; cur = me; label(); o.start();
      });
      function label() { var id = me.on ? 'exp.common.mute' : 'exp.common.play'; b.setAttribute('data-s', id); b.textContent = S(id); b.setAttribute('aria-pressed', String(me.on)); }
      me.stop = function () { if (!me.on) return; me.on = false; if (cur === me) cur = null; label(); o.stop(); };
      return me;
    };
    return st;
  }
  // the foot of every experiment: what you see, what you hear, the data line
  function foot(kit, S, root, slug) {
    var p = kit.panel_(root, 'exp.common.see', S, 'span');
    kit.line(p, 'exp.' + slug + '.see', S);
    p.appendChild(kit.el('h3', { 'data-s': 'exp.common.hear', text: S('exp.common.hear') }));
    kit.line(p, 'exp.' + slug + '.hear', S);
    p.appendChild(kit.el('p', { class: 'exp-source' }, [kit.el('b', { 'data-s': 'exp.common.data', text: S('exp.common.data') }), ' · ', kit.el('span', { 'data-s': 'exp.' + slug + '.data', text: S('exp.' + slug + '.data') })]));
  }

  // bars on a ruler of cents with the harmonic series behind them; items {c, h, sel}
  function rulerBars(kit, S, c, items, hmax, maxC0) {
    var ctx = c.ctx, w = c.w, h = c.h, l = 12, r = 10, t = 10, b = 26, maxC = 1, mut = kit.muted();
    ctx.clearRect(0, 0, w, h);
    items.forEach(function (it) { maxC = Math.max(maxC, it.c); }); maxC = Math.max(maxC * 1.06, maxC0 || 1300);
    var X = function (cc) { return l + cc / maxC * (w - l - r); };
    ctx.lineWidth = 1; ctx.strokeStyle = mut;
    for (var n = 1; n <= 24; n++) { var cc = cents(n); if (cc > maxC) break; ctx.globalAlpha = 0.5; ctx.setLineDash([3, 3]); ctx.beginPath(); ctx.moveTo(X(cc), t); ctx.lineTo(X(cc), h - b); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1; if (n < 10 || n % 2 === 0) txt(ctx, String(n), X(cc), h - b + 12, 'center', mut, 10); }
    ctx.beginPath(); ctx.moveTo(l, h - b); ctx.lineTo(w - r, h - b); ctx.stroke();
    items.forEach(function (it) { var bh = Math.max(2, it.h / hmax * (h - b - t)); ctx.fillStyle = it.sel ? kit.accent() : kit.blue; ctx.fillRect(X(it.c) - 3.5, h - b - bh, 7, bh); });
    txt(ctx, S('exp.common.cents'), w - r, h - 4, 'right', mut, 10);
  }
  var TAU = Math.PI * 2, F1 = 220, FPIC = 0.3;
  function bessel(m, x) { var s = 0, t = Math.pow(x / 2, m), i, f = 1; for (i = 2; i <= m; i++) f *= i; t /= f; for (i = 0; i < 30; i++) { s += t; t *= -(x / 2) * (x / 2) / ((i + 1) * (i + 1 + m)); } return s; }
  window.SDV_EXP.continuum = { mount: function (root, data, S, kit) {
    root.classList.add('half');
    var T = transport(kit, S), accent = kit.accent(), ink = kit.ink(), mut = kit.muted(), P = data.partials;
    var tau = 0, N = 12, ka = 1, body = 'string', kb = 1, noA = false;
    // the colour map as a table (kit.cmap gives css strings: read each once)
    var LUT = []; for (var li = 0; li <= 200; li++) { var mm = kit.cmap((li - 100) / 100).match(/\d+/g); LUT.push([+mm[0], +mm[1], +mm[2]]); }

    function chainOm(n, k) { return data.chain[n] ? Math.sqrt(data.chain[n][k - 1]) : 2 * Math.sin(Math.PI * k / (2 * (n + 1))); }
    function bodies() { // the partial ratios of each body, from the data
      return {
        string: P.string.slice(), stiff: P.stiff_string.ratio_to_first.slice(), bar: P.bar_free_free.ratio.slice(), membrane: P.membrane.ratio.slice()
      };
    }
    var R = bodies();

    // ---- panel a
    var pa = kit.panel_(root, 'exp.continuum.panel.a', S);
    var cA = cv(kit, pa, 0.4, 200), cAb = cv(kit, pa, 0.5, 220), ctlA = kit.controls(pa);
    kit.slider(ctlA, { id: 'exp.continuum.beads', S: S, min: 2, max: 48, step: 1, value: 12, fmt: function (v) { return String(v); }, onchange: function (v) { N = v; kaS.el.querySelector('input').max = Math.min(N, 8); ka = Math.min(ka, Math.min(N, 8)); kaS.set(ka); draw(); } });
    var kaS = kit.slider(ctlA, { id: 'exp.common.mode', S: S, min: 1, max: 8, step: 1, value: 1, fmt: function (v) { return String(v); }, onchange: function (v) { ka = v; draw(); } });
    kit.button(ctlA, 'exp.common.strike', S, function () { strike(partsA()); });
    T.pause(ctlA);
    var rdA = kit.readout(pa), rdA2 = kit.readout(pa);
    kit.line(pa, 'exp.continuum.line.limit', S);

    // ---- panel b
    var pb = kit.panel_(root, 'exp.continuum.panel.b', S);
    var cB = cv(kit, pb, 0.62, 300), cBb = cv(kit, pb, 0.42, 200), ctlB = kit.controls(pb);
    kit.seg(ctlB, { ids: ['exp.continuum.b.string', 'exp.continuum.b.stiff', 'exp.continuum.b.bar', 'exp.continuum.b.membrane'], values: ['string', 'stiff', 'bar', 'membrane'], value: 'string', S: S, onchange: function (v) { body = v; kb = 1; kbS.el.querySelector('input').max = R[body].length; kbS.set(1); noteB(); draw(); } });
    var kbS = kit.slider(ctlB, { id: 'exp.common.mode', S: S, min: 1, max: 8, step: 1, value: 1, fmt: function (v) { return String(v); }, onchange: function (v) { kb = v; draw(); } });
    kit.button(ctlB, 'exp.common.strike', S, function () { strike(R[body].map(function (r, i) { return { f: F1 * r, a: 1 / (i + 1), decay: 1.6 / (1 + 0.35 * i) }; })); });
    var rdB = kit.readout(pb), rdB2 = kit.readout(pb), rdB3 = kit.readout(pb);
    var lnB = kit.line(pb, 'exp.continuum.line.string', S);
    function noteB() { var id = 'exp.continuum.line.' + body; lnB.setAttribute('data-s', id); lnB.textContent = S(id); }
    foot(kit, S, root, 'continuum');

    function strike(parts) {
      if (!kit.audio()) { if (!noA) { noA = true; kit.line(pa, 'exp.common.noaudio', S); } return; }
      var tot = 0; parts.forEach(function (p) { tot += p.a; }); parts.forEach(function (p) { p.a /= tot; }); kit.strike(parts, 0.3);
    }
    function partsA() { var n = Math.min(N, 12); return Array.apply(null, Array(n)).map(function (_, i) { return { f: F1 * chainOm(N, i + 1) / chainOm(N, 1), a: 1 / (i + 1), decay: 1.6 / (1 + 0.35 * i) }; }); }

    // the membrane's mode: values on a polar grid, scaled to ±1
    var memo = {};
    function field(m, j, n) {
      var key = m + ',' + j, M = 90, i, k, arr, mx = 1e-9;
      if (memo[key]) return memo[key];
      arr = new Float32Array(M * M);
      for (i = 0; i < M; i++) for (k = 0; k < M; k++) { var x = (k + 0.5) / M * 2 - 1, y = (i + 0.5) / M * 2 - 1, r = Math.hypot(x, y); if (r > 1) { arr[i * M + k] = NaN; continue; } var v = bessel(m, j * r) * Math.cos(m * Math.atan2(y, x)); arr[i * M + k] = v; mx = Math.max(mx, Math.abs(v)); }
      for (i = 0; i < arr.length; i++) arr[i] /= mx;
      var zeros = [], prev = bessel(m, 0.0001 * j);
      for (i = 1; i <= 400; i++) { var cur = bessel(m, j * i / 400); if (prev * cur < 0) zeros.push(i / 400); prev = cur; }
      return (memo[key] = { arr: arr, M: M, zeros: zeros.filter(function (z) { return z < 0.99; }) });
    }
    var off = document.createElement('canvas');

    function draw() {
      var ctx, w, h, i, k;
      // -- a: beads
      ctx = cA.ctx; w = cA.w; h = cA.h; ctx.clearRect(0, 0, w, h);
      var wk = chainOm(N, ka) / chainOm(N, 1), ph = TAU * FPIC * wk * tau, cy = h / 2, A = h * 0.32;
      ctx.strokeStyle = mut; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(12, cy);
      var rad = Math.max(1.8, Math.min(5, (w - 24) / (N + 1) * 0.35));
      for (i = 1; i <= N; i++) ctx.lineTo(12 + (w - 24) * i / (N + 1), cy - A * Math.sin(Math.PI * ka * i / (N + 1)) * Math.cos(ph));
      ctx.lineTo(w - 12, cy); ctx.stroke();
      [12, w - 12].forEach(function (x) { ctx.strokeStyle = ink; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(x, cy - 12); ctx.lineTo(x, cy + 12); ctx.stroke(); });
      ctx.fillStyle = ink; for (i = 1; i <= N; i++) { ctx.beginPath(); ctx.arc(12 + (w - 24) * i / (N + 1), cy - A * Math.sin(Math.PI * ka * i / (N + 1)) * Math.cos(ph), rad, 0, TAU); ctx.fill(); }
      var items = [], errs = [], K = Math.min(N, 14);
      for (k = 1; k <= K; k++) { var c = cents(chainOm(N, k) / chainOm(N, 1)); items.push({ c: c, h: 1 / k, sel: k === ka }); if (k >= 2 && k <= 6) errs.push(k + ': ' + kit.num(c - cents(k), 1)); }
      rulerBars(kit, S, cAb, items, 1);
      rdA.textContent = 'N = ' + N + ' · ' + (data.chain[N] ? 'data' : 'ω_k = 2 sin(πk/(2(N+1)))') + ' · ' + S('exp.common.mode') + ' 2…6, ' + S('exp.common.cents') + ': ' + (errs.length ? errs.join(' · ') : '—');
      rdA2.textContent = S('exp.common.slowed').replace('{n}', kit.num(F1 / FPIC, 0)) + ' · ' + kit.num(F1 * wk, 1) + ' ' + S('exp.common.hz');
      // -- b: the body
      var r = R[body], K2 = r.length; kb = Math.min(kb, K2);
      var pb_ = TAU * FPIC * r[kb - 1] * tau;
      ctx = cB.ctx; w = cB.w; h = cB.h; ctx.clearRect(0, 0, w, h);
      if (body === 'membrane') {
        var mn = P.membrane.modes_mn[kb - 1], jm = P.membrane.j_mn[kb - 1], F = field(mn[0], jm, mn[1]), M = F.M, Rr = Math.min(w, h) / 2 - 6;
        off.width = M; off.height = M; var oc = off.getContext('2d'), im = oc.createImageData(M, M), cs = Math.cos(pb_);
        for (i = 0; i < M * M; i++) { var v = F.arr[i]; if (v !== v) { im.data[i * 4 + 3] = 0; continue; } var cc = LUT[Math.round(Math.max(-1, Math.min(1, v * cs)) * 100) + 100]; im.data[i * 4] = cc[0]; im.data[i * 4 + 1] = cc[1]; im.data[i * 4 + 2] = cc[2]; im.data[i * 4 + 3] = 255; }
        oc.putImageData(im, 0, 0);
        ctx.save(); ctx.beginPath(); ctx.arc(w / 2, h / 2, Rr, 0, TAU); ctx.clip(); ctx.imageSmoothingEnabled = true; ctx.drawImage(off, w / 2 - Rr, h / 2 - Rr, 2 * Rr, 2 * Rr); ctx.restore();
        ctx.strokeStyle = ink; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(w / 2, h / 2, Rr, 0, TAU); ctx.stroke();
        ctx.strokeStyle = mut; ctx.setLineDash([4, 3]);
        F.zeros.forEach(function (z) { ctx.beginPath(); ctx.arc(w / 2, h / 2, z * Rr, 0, TAU); ctx.stroke(); });
        for (i = 0; i < mn[0]; i++) { var th = Math.PI * (2 * i + 1) / (2 * mn[0]); ctx.beginPath(); ctx.moveTo(w / 2 - Rr * Math.cos(th), h / 2 - Rr * Math.sin(th)); ctx.lineTo(w / 2 + Rr * Math.cos(th), h / 2 + Rr * Math.sin(th)); ctx.stroke(); }
        ctx.setLineDash([]);
        rdB2.textContent = '(m, n) = (' + mn[0] + ', ' + mn[1] + ') · j_mn = ' + kit.num(jm, 4) + ' · J_' + mn[0] + '(j_mn) = ' + kit.num(bessel(mn[0], jm), 6);
        rdB3.textContent = 'J₀, J₁, J₂: ' + [[0, 1], [1, 1], [2, 1]].map(function (q) { var j = P.membrane.j_mn[P.membrane.modes_mn.findIndex(function (z) { return z[0] === q[0] && z[1] === q[1]; })]; return 'J_' + q[0] + '(' + kit.num(j, 4) + ') = ' + kit.num(bessel(q[0], j), 6); }).join(' · ');
      } else {
        var L = w - 24;
        ctx.strokeStyle = ink; ctx.lineWidth = 1.8; ctx.beginPath();
        for (i = 0; i <= 120; i++) { var x = i / 120, y = Math.sin(kb * Math.PI * x) * Math.cos(pb_); var X = 12 + L * x, Y = h / 2 - y * (h * 0.38); if (i) ctx.lineTo(X, Y); else ctx.moveTo(X, Y); }
        ctx.stroke();
        ctx.strokeStyle = mut; ctx.lineWidth = 0.6; ctx.setLineDash([2, 3]); ctx.beginPath(); ctx.moveTo(12, h / 2); ctx.lineTo(w - 12, h / 2); ctx.stroke(); ctx.setLineDash([]);
        if (body === 'bar') txt(ctx, S('exp.continuum.c.barshape'), w / 2, 14, 'center', mut, 10);
        if (body === 'bar') rdB2.textContent = 'x_k = ' + P.bar_free_free.x_k.map(function (x) { return kit.num(x, 4); }).slice(0, 4).join(', ') + ' …'; else if (body === 'stiff') rdB2.textContent = 'B = ' + P.stiff_string.B + ' · ' + S('exp.common.cents') + ' > k·f₁: ' + P.stiff_string.cents_above_k_f1.map(function (x) { return kit.num(x, 1); }).join(', '); else rdB2.textContent = 'f_k = k·f₁';
        rdB3.textContent = '';
      }
      var it2 = r.map(function (q, i) { return { c: cents(q), h: 1 / (i + 1), sel: i === kb - 1 }; });
      rulerBars(kit, S, cBb, it2, 1, 1300);
      rdB.textContent = r.map(function (q) { return kit.num(q, 3); }).join(' : ') + ' · ' + S('exp.common.slowed').replace('{n}', kit.num(F1 / FPIC, 0));
    }
    kbS.el.querySelector('input').max = 8; kaS.el.querySelector('input').max = 8; noteB();
    T.onpause = draw; window.addEventListener('resize', draw);
    kit.loop(function (t, dt) { if (!T.paused) tau += dt; draw(); });
    draw();
  } };
})();
