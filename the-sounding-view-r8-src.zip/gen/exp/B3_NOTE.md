# B3 note — light ladders (stiffness, noimage, spin, plasmawaves, coupling)

All five modules, strings, data, specs and harness pages are in gen/exp/; each passes the harness at 1280 and 390 px with no console errors and no horizontal overflow (screenshots `_harness_<slug>_1280.png` and `_390.png`).

Deviations (details in each spec's "as built"):
- The modules are 98 to 194 dense lines, below the 250 to 600 guide; spin is not 600.
- Canvases are wrapped in a `div.exp-cvwrap` because kit.canvas sizes to the parent's clientWidth (padding included) and overflowed the panel by its padding; no CSS rule for `.exp-cvwrap` is needed. Suggest fixing the kit to use the content width.
- kit.pair cannot set a phase: spin builds its own two-channel pair with a delay.
- Slider interpolation in stiffness scales the data's lambda_k (checked against the five data ratios, error 4e-16); noimage and coupling draw the grades.json fields, not a 3-D cube; plasmawaves draws electrons and ions in phase.
- spin.js has no `S` string for the code names A3 ... S8 beyond the four switch labels; the probe codes and numbers appear in untraced read-outs.
- Strings contain a few symbols (E, B, H, ρ, J) as their own ids; the exp.spin.analysis line needs the generator's link.
- Sound: all sound starts on a click; none of the modules plays on load; reduced motion starts the picture paused (Pause button present).
