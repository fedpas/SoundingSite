## 17. `coupling` — The coupling by grade (MUS-078, MUS-079, MUS-081, MUS-084, MUS-094, MUS-095, MUS-107)

*Panels:* (a) **The cube of grades**: two columns of five layers each (grades 0 … 4 of the fluid's completed field on the left: p, v, the pseudovector row with the vorticity, …; of Maxwell's field on the right: ρ, J, E, B, …), drawn as the Atlas's cube-of-grades picture (layers as rows of label boxes with their masks from `grades.json labels`); the coupling arrows: the fluid's grade-1 part (the current, with its time part scaled by c_L/c_s) → Maxwell's sources, 1 → 1; Maxwell's electric half → the fluid's force density, 2 → 2 (MUS-078); a switch "background field B₀" that adds the arrows of MUS-081/084 (the background acts only through the fluid's own velocity; it sources the fluid's vorticity in the pseudovector row); a switch "two fluids" (MUS-095: the background turns each fluid on itself, the electric field stays the only link — draw two fluid columns and one Maxwell column); a switch "a stream" (MUS-107: the stream's pressure carried along is a current). (b) **Not by the time edge** (MUS-079): the time edge (the right product by γ₀) drawn as a dashed arrow between the two columns with the grade mark *none* and the row's sentence. *Hear:* nothing moves here; a single confirming click on each switch (`kit.click`) is enough; say so in `hear`. *Legend rows:* MUS-078, MUS-079, MUS-081, MUS-084, MUS-094, MUS-095, MUS-107.

---

Deliver for each slug: `<slug>.js`, `<slug>.strings.json` (with `rows`), `<slug>.data.json`, `<slug>.spec.md` (this section plus "as built"), `_harness_<slug>.html` and the two screenshots, zero console errors; then `B3_NOTE.md`. The `spin` experiment is the largest (≈ 600 lines); build it last and carefully: every number from the JSON files, the formulas from FINAL.md §2 (eqs 5, 6, 10, 11, 15). Work economically elsewhere.

### As built

- The two columns list the Atlas's fields by grade (grades.json) with short names; layer masks are a read-out below. Arrows: p (grade 1) -> j_e (grade 1) and F (grade 2) -> N (grade 2); B0 adds elbow arrows p -> N and N -> wI inside the fluid; two fluids draws two fluid columns and a crossed, dashed 'no link'; a stream adds a second, accent arrow p -> j_e.
- The 'cube' is a table of rows, not a 3-D cube; the time edge panel is a separate small picture with grade none.
- Sound: Play enables one click per switch (kit.click, higher on, lower off); nothing else sounds. No animation (the canvas redraws, nothing moves).
- Module is 98 dense lines.
