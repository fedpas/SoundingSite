<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors -->

# The Sounding View — site notes (release 4, 5 November 2026)

What release 4 changed in the generator. The notes of releases 3, 2 and 1 follow below the rules and stay true wherever this section does not say otherwise.

## What changed

- **The Atlas 4.4.14 source** is read in its own layout (`gen/lib/sources.mjs`): `content/derived/status.json`, `package.json` for the version, `analyses.json`; no `records/music.json`, no `version.json`. Round 36's logs, figure data and audio come from the source; the archive (`SDV_ARCHIVE`, default `../repo`) still gives the round-36 study, `FIGURES_INDEX.md`, `lit/SOURCES.md` and the SVGs of rounds 36 and 37; round 38's SVGs, the notes' sources and the three `BRIDGE.md` come from the study's folder (`SDV_PACK38`); round 37's study and bridge table from `SDV_PACK`.
- **The pack row reader is gone** (`loadPack38`, `parseRows38`, `pack.row38`, `packRowBlock`). `gen/lib/pack.mjs` has `loadLight`: the fifteen scripts of `checks/selfcheck/sound_light/` with their logs, figure data and clip 22's index, the bridges of the study. Every row is `rowBlock` (evidence from `checks.json`, log lines of the group from the scripts' logs); a row the study's `BRIDGE.md` grades shows its bridges in Standard.
- **Structure** (`gen/content/structure.json`): Part III is nine chapters in four movements (`movements`); a chapter of Part III names one or two chains (`chains`), the second chain's rows after the first under its own title (a traced sub-heading); inputs stand before their first user (`depends`); each chapter names its experiments (`experiments`). The part page groups the chapters under the movements.
- **Experiments** (`gen/exp/`, `gen/lib/exp.mjs`): the generator reads every `<slug>.js` that has `<slug>.strings.json`, adds `_common.strings.json` and the modules' strings to the table (ids `exp.*`, flagged `exp`), mounts each chapter's experiments between its lead and its rows as `<section class="exp">` (header, empty stage, legend with a traced claim and a chip per row, the data line, the JSON data block), inlines the page's `exp.*` strings as a JSON block (`exp-strings`, in the page's language) and writes `out/experiments.js` (the SPDX line once, the kit, the modules in chapter order) and the experiments' styles after `site.css`. `site.js` calls `SDV_EXP._kit.mountAll(S)`. A module that is missing is a warning. The legend's claim is the part `claim` of `rows.homePhys` (cut at the first `:` or `;` outside brackets, capital first letter), else the research text's first sentence.
- **Pages**: `experiment.html` (and `it/`): the `<main>` of the report of `acoustic-spin-torque`, scripts and handlers removed, its figures shipped as `figures/analysis/`; linked from the spin chapter's lead and from the spin experiment's line (`exp.spin.analysis`). Sounds gets a third group, the experiments, by part. Method has a paragraph on what an experiment is. The tone chapter's ring row (MUS-002) is followed by a pointer to the clock ring experiment.
- **NASA recordings**: if `audio/nasa/whistler.mp3`, `chorus.mp3` and `hiss.wav` stand in the parent of `SDV_OGG`, the whistler section gets three `<audio controls>` and the credit "Source: NASA", the files copied to `out/audio/nasa/`; else the module's link stands.
- **Checker** (`gen/check.mjs`): the chapter model of release 4; the experiments: the sections of each chapter are its modules' in order and between lead and rows, the strings resolve (rule 2), the legend rows are the module's and exist in the Atlas, the data block parses and its `source` names an existing file under `checks/selfcheck/`, the five required strings, no bookkeeping word in a module's strings, the module's text is in `experiments.js` once, the licence line once, no network call, every `S('exp.…')` it asks for exists; the analysis page. `version.json` names the Atlas 4.4.14, release 4, no pack. `shoot.cjs` waits for the experiments and fails a page whose `section.exp` lacks `data-mounted="1"` or that logs a console error; `--light` shoots the light scheme only.
- **Italian**: `gen/manifest_r4.mjs` (from `manifest_r3.mjs`) keeps the finished tables of release 3 and writes the stubs and `content/it/MANIFEST_R4.json`.

## Rebuild

```
export NODE_PATH=/opt/npm-tools/node_modules
ATLAS=<the Atlas 4.4.14 source>
SDV_IT=off node gen/build.mjs $ATLAS && SDV_IT=off node gen/check.mjs $ATLAS        # English: 0 errors, 0 warnings
SDV_IT=partial node gen/build.mjs $ATLAS && node gen/manifest_r4.mjs $ATLAS         # the Italian stubs and MANIFEST_R4.json
SDV_IT=partial node gen/build.mjs $ATLAS && SDV_IT=partial node gen/check.mjs $ATLAS  # 0 errors, the stubs as warnings
node gen/test_sounds.mjs; node gen/shoot.cjs [--light]
node gen/exp/_harness.mjs <slug>                                                    # one experiment alone
```

## Open

The Italian tables: 84 narrations, 136 titles, 10 new and 11 changed strings, 787 experiment strings (MANIFEST_R4.json); the full build (`SDV_IT=full`) refuses the stubs.

---
# The Sounding View — site notes (release 3, 3 November 2026)

What release 3 changed in the generator. Release 2's notes follow below the rule and stay true wherever this section does not say otherwise.

## Layout changes

- `gen/content/structure.json` is the story: the four parts, the twelve chapters (an Atlas chapter names its section, `drop` and clips; a chapter of the study lists its rows and inputs), `soundsGroups` (the instruments by part) and `bridgeChapters` (the five chapters of the map).
- `gen/build.mjs`: chapter pages (`CHAPTERS`, `ROW_CH`, `rowHref`), part pages, the home (four part cards, two doors), the bridges map, Sounds by part, Reference menu (a `<details>`, no script), breadcrumbs, previous / next across the story. `packRowBlock` renders a row of the study from `pack.row38` (the former `proposedRowBlock`).
- `gen/lib/sources.mjs` reads 4.4.10's release layout (`rows.json`, `texts.json`, `chains.json` filtered to the page music, `derived_status.json`, `records/music.json`, `version.json`) and takes round 36's study, figures, logs and clips from the archive (`SDV_ARCHIVE`, default `../repo`); `lib/pack.mjs` reads the round-38 pack as a study's own files (`parseRows38`, `parseBridge38`, `loadPack38`; `SDV_PACK38`); `logGroup` reads both log layouts (`(n) [tag]` and `[tag]` headings).
- `gen/check.mjs`: the chapter model is read again from `structure.json` and the sources; rows once and in order, breadcrumbs, previous / next, the menu's links, no section number in the nav, the map's twelve lines and five chapters, 17 scripts with the log lines recounted from the logs (89 + 599 ok lines, 12 + 101 controls), 47 lens entries, 13 + 12 + 4 figures, 12 + 9 + 1 clips, `version.json` naming 4.4.10 and the round-38 pack.
- `gen/manifest_r3.mjs`: migrates the Italian tables, writes the stubs and `content/it/MANIFEST_R3.json`.
- Outputs are named for the studies, not the rounds: `figures/bridges/`, `figures/light/`, `audio/bridges/`, `audio/light/`, `checks/bridges/`, `checks/light/`.

## Rebuild

```
export NODE_PATH=/opt/npm-tools/node_modules
SDV_IT=off node gen/build.mjs <4.4.10 release dir> && SDV_IT=off node gen/check.mjs <same>   # English: 0 errors, 0 warnings
SDV_IT=partial node gen/build.mjs <dir> && SDV_IT=partial node gen/check.mjs <dir>          # with the Italian stubs: 0 errors, the stubs as warnings
node gen/test_sounds.mjs; node gen/shoot.cjs
```

The full build (`SDV_IT=full`, the default) refuses the stubs: it finishes when the narrators' entries replace them.

## Open

The Italian tables: 62 narrations, 101 titles, 66 new and 32 changed strings (MANIFEST_R3.json).

---
# The Sounding View — site notes (release 2, 2 November 2026)

How the generator works, its readers and string tables, how to rebuild and check, and what is not done. Release 1's notes are kept below the rule at the end. The second pass of release 2 (the owner's rejection of the Italian site: the English records stood in the reading flow and the pages carried the work's bookkeeping) is folded into these notes where it changed something; its own account is `NOTE_R2b.md`.

## Layout

```
site/
  gen/                    the generator (Node 22, KaTeX 0.16.47 and Playwright from NODE_PATH=/opt/npm-tools/node_modules)
    build.mjs             reads the Atlas, the pack and the tables below, writes out/ (and out/it/) and gen/build/trace.json
    check.mjs             verifies out/ against the sources (exit 0 when clean); the Italian pages too
    manifest_it.mjs       writes content/it/MANIFEST.json for the narrators (every target, strings_new, strings_changed)
    manifest_titoli.mjs   writes content/it/MANIFEST_TITOLI.json (second pass): the 237 targets of the titles table with their
                          English material, strings_new / strings_changed / strings_removed against the first pass's table
                          (../scratch/strings_r2a.json), and the first-pass Italian items that still carry a process word
    shoot.cjs             screenshots of every page, English and Italian (it_<page>), 1280 and 390 px, light and dark, from file://
    test_sounds.mjs       the synthesizer's test: Chromium renders sounds.js into an OfflineAudioContext and measures it (37 assertions)
    lib/sources.mjs       loads the Atlas's tables and round 36's files, attaches the pack; resolve(source) → text; applyPart
    lib/pack.mjs          the pack of round 37 as a source: the study, the ROWS.md reader, BRIDGE.md, BRIDGES_DRILLED.md, the
                          indexes, the scripts' docstrings, the logs, the figure data, DICTIONARY.md; resolvePack('pack.*')
    lib/italian.mjs       the narrator's three tables (content/it/), SDV_IT, the banned-word matcher, the process-word
                          matchers of both languages (PROCESS_EN, PROCESS_IT, processHits), the proper names the Italian flow
                          may keep (PROPER_NAMES, stripNames), dateWords (the stamp's date in words)
    lib/study.mjs         reads a study's HTML into units and sentences (both studies)
    lib/tex.mjs, lib/scripts.mjs, lib/md.mjs   as in release 1 (md.mjs now holds the table reader mdTables)
    content/strings.json  the site's own strings (455: 220 of release 1, 185 of release 2's first pass, 59 added and 9 removed
                          in its second pass): id, text, why; `optional` for the ones shown only on some data, used as
                          attributes, or shown on the Italian pages alone
    content/story_map.json   the Story register of the Atlas's rows (release 1)
    content/bridges_map.json the Story maps of the page of the drill: the head, the question, the eight items' sections, clips and
                          instruments, each proposed row's units or sentence ranges, the opinion
    content/placements.json  the section order and slugs, the clips of each section, each section's instrument, the home's figure
    content/it/strings_it.json, racconto.json, titoli.json   the narrator's three tables (see below); MANIFEST.json and
                          MANIFEST_TITOLI.json for the narrators
    figures/mark.svg      the site's mark
    assets/               site.css, site.js (the register switch), sounds.js (the synthesizer, 9 instruments), RELEASE_NOTES.md
    build/                trace.json (every traced block), build_log.json, check_log.json
  out/                    the site: 16 pages, it/ (16 Italian pages), site.css, site.js, sounds.js, sounds-data.js, katex/, figures/
                          (figures/round37/), audio/ (21 clips), checks/ (checks/round37/), content/version.json, RELEASE_NOTES.md, LICENSE
  record/                 these notes, shots/ (128 screenshots), shots_report.json, test_sounds.json, build_log.json, check_log.json
  NOTE_R2.md, NOTE_R2b.md   the builder's notes for the orchestrator, first and second pass (not shipped)
```

## How to rebuild

```
cd site
NODE_PATH=/opt/npm-tools/node_modules node gen/build.mjs REPO     # REPO: the Atlas's repository (default ../repo); SDV_PACK: the pack
                                                                  # (default ../../../r37/pack/round37_bridges_pack); about 1 s
NODE_PATH=/opt/npm-tools/node_modules node gen/check.mjs REPO     # 0 errors required; about 2 s
NODE_PATH=/opt/npm-tools/node_modules node gen/test_sounds.mjs    # 37 of 37 PASS required; about 20 s
NODE_PATH=/opt/npm-tools/node_modules node gen/shoot.cjs [--full] [--pages a,b,it_c] [--reg atlas]   # 0 problems; about 90 s
NODE_PATH=/opt/npm-tools/node_modules node gen/manifest_it.mjs    # rewrites content/it/MANIFEST.json after a string changes
NODE_PATH=/opt/npm-tools/node_modules node gen/manifest_titoli.mjs # rewrites content/it/MANIFEST_TITOLI.json (second pass)
```

`SDV_IT` chooses the Italian build: `full` (the default) refuses to finish, exit 1 naming the ids, when `strings_it.json` lacks a string, `racconto.json` lacks a narration or `titoli.json` lacks a title for a target the pages render, or when a table holds a stub (`"stub": true`); `partial` renders a missing narration or title as a visible placeholder (`data-r-missing`, `data-t-missing`) and the checker reports it, and the stubs, as warnings; `off` builds and checks the English site alone (and removes `out/it/`). `SDV_DATE` and `SDV_RELEASE` set the stamp; `SDV_OUT` builds elsewhere; `SDV_OGG` names the folder of round 36's Ogg clips (default `../audio_ogg`; the pack's own Ogg copies are read from its `audio/`). Every step reads the repository and the pack only.

## How the generator works

- **Trace.** `traced(ctx, base, source, {part, render})` resolves a source — `{table, key, field}` on the Atlas's tables (`rows`, `texts`, `status`, `checks`, `check_runs`, `log`, `logfile`, `lens`, `lens_readings`, `pages`, `page`, `chains`), on round 36's files (`study`, `study.heading`, `figures`, `clips`, `clips.outro`, `sources_md`), on the pack (`pack.study`, `pack.study.heading`, `pack.row`, `pack.item`, `pack.bridges`, `pack.bridge`, `pack.figures`, `pack.clips`, `pack.clips.rule`, `pack.clips.outro`, `pack.script`, `pack.log`, `pack.logfile`, `pack.seconds`, `pack.ogg`, `pack.dict`, `pack.dict.counts`, `pack.dict.slips`, `pack.dict.top`, `pack.dict.cand`, `pack.readme`), or a site string — applies the declared part (`first-sentence`, `md-plain`, `sentences:a-b`, `grade-word`), records the block in `build/trace.json` and gives the element its `data-b`. A site string is an element with `data-s`; a narration an element with `data-r`; a title of the Italian table `titoli.json` an element with `data-t` (second pass: `tt(target)`; a title may render more than once, a narration once).
- **Renderings.** `text`, `script`, `md`, `mdlinks`, `links`, `study` as in release 1; `lines` (the lines of a ROWS.md field, nested bullets as lines, scripts drawn), `ids` (scripts drawn, the row ids linked where the row is on the site), `refs` (arXiv numbers and DOIs as links).
- **The pack as a source** (`lib/pack.mjs`). The study `docs/round37/the_bridges_drilled.html` is read by `lib/study.mjs` like the first study (170 units, 29 formulas; its figures and embedded clips are dropped, the site shows its own copies). `ROWS.md` is read by `parseRows`: chunks between horizontal rules, the head `**MUS-0NN** · kind · **status** · tags · controls`, the stage line, the bold fields (`homeMath`, `homePhys`, `depends`, `standardRef`, `home` or `proposed home`, `what the control(s) break(s)`, `chain note`, `reason`, `the web claims`), nested bullets and indented lines as further lines of the field, the blockquote as the research text. `BRIDGE.md` gives its first table (the last column the grade proposed) and, per numbered section (`## n.` or `**n. …**`), the row ids and the check tags its text names (a row touches the bridges whose sections name it or one of its tags). `BRIDGES_DRILLED.md`'s summary table, `FIGURES_INDEX.md` (the eight items' tables joined) and `audio/INDEX.md` (the three items' tables joined, the voicing-rule paragraph, the three "the clips illustrate" lines) are read with `mdTables`. The nine scripts' docstrings give the first paragraph, the Statements section (one statement per check tag, continued on indented lines), the legend lines and the Scope line; the logs, the faults logs, `.log.seconds` and `ogg.log` are read as lines. `DICTIONARY.md` gives its three tables (the dictionary, the counts, the printed slips), its prose before the table and the ten candidates with their bullets.
- **Rows.** `rowBlock` as in release 1 for the Atlas's rows. `proposedRowBlock` for the pack's (the name is the generator's; the pages say nothing of it): the chip of the status ROWS.md gives, the same chip any row carries (the second pass removed the outline *proposed*: a reader of music, mathematics or physics has no use for the work's bookkeeping, which About alone tells); the article carries `data-proposed="<item>"` for the checker; Story from `bridges_map.json` (else the research text, and the block says so); Research the research text; Atlas the fields of ROWS.md, each traced, the depends text verbatim with the ids linked, the evidence tags each with the docstring's statement, the ok lines of the log's group, the log's ALL OK line and the run's seconds, what the controls break; Standard the standard reference and the bridge grade of the item's BRIDGE.md (the sections naming the row or its tags; for an item with one bridge, that bridge), before and after. On the Italian pages the head is the Italian claim `t:row:<id>` (the block's title, as the English claim is on the English page) over a small line with the id and the chip; the Story register (*Racconto*) holds the narration `r:row:<id>` as plain paragraphs; the three record registers open with a small Italian label each (`it.reg.research`, `it.reg.atlas`, `it.reg.standard`) and keep the records in English, and one note per page with row blocks (`it.registers.note`, under the rows' intro line, where the registers matter) says so once.
- **The page of the bridges** (`bridges.html`, "The bridges" / "I ponti"; the first pass called it by the study's title and carried its stamp and standing line, which the second pass removed with every other process word of the reading flow: the provenance is About's). English: h1, sub-title and lead (strings), the question and the method in the study's words (§1 and part 2's opening) in a collapsed disclosure, the table of the eleven bridges, the eight items (heading string, the BRIDGE.md title, the sections' prose units, the rows, the figures whose first row the item gives, the clips, the instrument), the paper's dictionary (also the second part of `dictionary.html`), the opinion and what part 2 changes, the pointer to the references on Sources. Italian: `t:page:bridges`, `:sub`, `:head` (the study's byline sentence is on no page since the owner's second reading: the source is Sources' and About's), the narration `r:page:bridges` with the study's §1 in a disclosure, the Italian table (`t:bridge:<n>`, the grade words as strings, `t:bridge:<n>:why`) with the English table in a disclosure, the items as `t:item:<item>` + `r:bridges:item:<item>` with the study's prose in a disclosure, the paper's dictionary as an Italian column table (# · `t:paper:<row>`) with the paper's table and the candidates in disclosures, the opinion as `r:bridges:opinion` with §9 and §16 in a disclosure.
- **Languages.** `buildPages()` runs once per language with `L` (the string table, the folder, the prefix `../` of the shared files, the narrations, the titles). The Italian pages are the same pages, with the same stylesheet, chips and layout, told in the narrator's words: the reading flow (titles, claims, leads, captions, the clips' lines, the instruments' words, the tables' Italian columns) comes from the three Italian tables — `data-s` strings, `data-r` narrations at their targets (`racc(target)`, plain paragraphs, no quote bar), `data-t` titles (`tt(target)`) — and the English records stand only inside the three record registers (each opening with a small Italian label) and inside collapsed `<details class="more card-en">` disclosures whose summaries are Italian strings (`card(summaryId, inner)`: the Atlas's lead of a section, the study's prose of an item, the figure's English caption with its data and rows, the clip's "what is heard", the lens record and the 124 readings, the paper's table and candidates, a script's statements and log, the two studies' references and the fetched links, the pack's README). The switch EN · IT and `lang="it"` as before.
- **Sounds.** `sounds-data.js` is written by the build from both rounds' `figdata/` (release 1's keys and `crt`, `rings`, `rows`); `sounds.js` exposes its engine as `window.SDV_ENGINE`; every word it writes into the page is read from the page (hidden spans `data-s`, the select's options, the containers' aria-labels), so the Italian page plays the same engine with Italian controls. Second pass: the names the data gives its twelve sets (`dft.json`: cluster, diatonic … octatonic; the Forte names 4-Z15 and 4-Z29 are ids and stay) and its five rhythms (`even.json`) are read from hidden spans `data-s="set.<word>"` / `data-s="rhy.<key>"` with `data-name="<the data's name>"` (`Ln`, `setName` in `sounds.js`); the build refuses an English string that does not read as the data names it, so the English page shows the data's names unchanged.
- **The stamp.** One human line per language, `release.stamp` = `Release {release} · {dateWords}` / `Edizione {release} · {dateWords}`, with `{dateWords}` the date of `version.json` in words (`dateWords(iso, lang)`: "2 November 2026" / "2 novembre 2026"); the Atlas's version, the study's date and the standing of its rows are said on About alone (`about.provenance`, `about.bridges.rows`) and kept whole in `version.json`, `RELEASE_NOTES.md` and these notes.

## What the checker verifies (`gen/check.mjs`)

Everything of release 1, on the English and the Italian pages (the English records keep their `data-b` on the Italian pages and are resolved again), and: the rows of the bridges carry the status their ROWS.md gives as their chip and nothing else (any `chip--proposed` is an error since the second pass; the articles carry `data-proposed="<item>"` for the checker alone); the page of the bridges shows every such row once, in the items' order, with its clips; the 12 figures of the pack on Pictures and on the page of the drill and shipped under `figures/round37/`; the 9 clips on Sounds and shipped; the nine instruments; the paper's dictionary's rows on both pages; the pack's scripts, logs, faults logs, README and run_all.sh under `checks/round37/`; 311 ok lines of the pack's logs and 45 controls on Checks (beside 89 and 12); the 11 bridges in the table; `version.json` naming the pack as proposed, not merged, with its study's date; one link to the Atlas per language; the stamp of every page is the filled `release.stamp` of its language, carrying the date in words, the English one `Release N · …`, and `about.html` and `it/about.html` carry both provenance strings, the English one naming the Atlas's version; no process word of `BRIEF_R2b.md` §0 (round N, pack, merged, proposed, release N.N, against/later release, the owner, research note, drill; in Italian round N, pacchetto, integrato / non integrato, proposto, release or versione with a number, proprietario, nota di ricerca, trivell-/perforat-/drill-) in the reading flow of either language, About excepted — on the English pages the text outside `data-b` records (a study's own words cannot be rewritten), on the Italian pages every text node. For the Italian pages: every `data-s` equals its string in `strings_it.json` (every id of `strings.json` present, with a text and a why); every `data-r` equals its item's text (paragraphs joined), stands at its target (the row block, section, page, instrument, clip or part it names) and every item of `racconto.json` is rendered exactly once; every `data-t` equals its item's text in `titoli.json`, every item of `titoli.json` is rendered at least once (a figure's title renders on every page that shows the figure) and every target of `MANIFEST_TITOLI.json` has an item; a row claim `t:row:<id>` ends with no period; every `tells` id exists (a row on the site, a study section `study:§n` / `drill:§n`, a clip, a figure, a script or a check tag, a file of the pack, a figure data file, the lens); the Italian row block's head is the claim `t:row:<id>` and its three record registers open with their labels; **the reading flow is Italian**: every text node of `out/it/*.html` outside `<details>` and outside the record registers' panels is traced to the three tables (`data-s`, `data-r`, `data-t`) or is an id (`[A-Z]{2,4}-…`, a check tag `xx·TAG`), a number or unit, a formula (`.katex`, `data-tex`), a file name, a URL or one of the proper names listed in `PROPER_NAMES` (The Sounding View, The Shifted View, the Cascade Atlas, Music on the labels, The bridges drilled, KaTeX, the names of the references' authors); any other run of three words is an error with its page and text; `lang="it"`; the switch links resolve both ways; no banned word of `it/VOICE_IT.md` in the three tables (`lib/italian.mjs`, `bannedHits`: whole words, every form; *prima* in its temporal uses; *ora* not after an apostrophe; *release*, *versione* and *round N* allowed in the stamp alone) and no process word in them either (About's ids and `page:about` excepted); no stub and no placeholder in the final build (warnings under `SDV_IT=partial`). Last run: see `record/check_log.json`.

## The string tables

- `content/strings.json` — 455 strings, each with a `why`; the 185 of release 2's first pass are the navigation and the switch (`nav.bridges`, `lang.*`), the home's ninth card, the page of the bridges (`b.*`), the row block of the bridges (`blk.*.p`, `atl.*`, `std.bridge*`), the Checks and Pictures additions (`checks.r37*`, `pics.r3*`), the paper's dictionary (`dict.paper*`), the Sources additions (`src.refs2*`, `src.paper`), the three instruments (`i7.*`, `i8.*`, `i9.*`, `inst.*`), the labels the synthesizer reads from the page (`i2.cents`, `i4.body.*`, `ui.hz`), the accessibility labels (`aria.*`, optional), and About's additions (`method.4`, `about.reads.pack*`, `about.italian*`); 14 strings of release 1 changed their text for the new counts (`content/it/MANIFEST.json` lists both). The second pass added 57 (the short stamp's companions `about.provenance` and `about.bridges.rows`; the page's new head `b.sub`, `b.lead`, `b.card.p`; `checks.r36` and the counts words `checks.n.*`; the Italian pages' labels `it.registers.note`, `it.reg.*`, the disclosures' summaries `it.*.card` (`it.byline.card` came and went: the study's byline left the page), `it.home.question.link`, `dict.col.it`, `dict.paper.row.*`; the grade words `gw.*`; the names of the sets and rhythms the instruments show, `set.*`, `rhy.*`), changed 29 (every string that carried a process word, `b.title` to "The bridges", and About's `method.4` and `about.italian.p` for what is no longer so) and removed 9 (`chip.proposed`, `chip.legend.proposed`, `card.rows.proposed`, `b.kicker`, `b.standing`, `b.stamp.k`, `b.item.bridge`, `it.records`, `sounds.clips.r37`); `content/it/MANIFEST_TITOLI.json` lists all three with the old and the new texts.
- `content/it/strings_it.json` — 455 entries, one per id of `strings.json`, the narrator's Italian for the job the string does; `content/it/racconto.json` — 122 narrations (`r:` + target): the home, the eight sections, the 27 + 36 rows, the pages, the nine instruments, the 21 clips, the page of the bridges, its table, its eight items, its opinion, the paper's dictionary, the nine scripts and the twelve figures of the pack; `content/it/titoli.json` (second pass) — 237 titles (`t:` + target): the eight sections' titles, sub-titles, chain headings and card texts, the page of the bridges' title, sub-title, head line and card, the 63 row claims (one line, no final period), the 25 figure captions, the 21 clip titles, the eight items' headings, the eleven bridges' names and reasons, the 34 lens terms, the 17 rows of the paper's dictionary in the Atlas's words, the 11 scripts' lines. The tables are the two narrators' (IT-1 release 1's targets, IT-2 the bridges'), merged by the orchestrator and read by an independent reviewer (24 edits applied in place in the first pass); their record is `it/VOICE_IT.md` (the contract), `it/draft/NOTE_IT-1.md`, `it/draft/NOTE_IT-2.md` (the narrators' notes, with their drafts and their own checks beside them) and `it/REVIEW_IT.md`; the second pass's edits (the process words out of every narration and string, the titles table) are theirs too. The checker verifies the three tables (last run: see `record/check_log.json`).
- `content/bridges_map.json` — the Story maps of the page of the drill (above).

## Screenshots and the console

`record/shots/`: every page, English and Italian (`it_` prefixed), at 1280 and 390 px, light and dark (128 shots). From the disk, no console error on any page and no horizontal scroll at 390 px; the only console lines are the two Google fonts failing for want of a network in this sandbox (reported apart; the system fonts stand in). Read on the Italian shots at 390 px: the header, whose language switch took a row of its own, now shares the register switch's row (the brand on the first row); the instruments' Italian labels wrap into their rows and the readouts under their labels; nothing overflows. Second pass, read on the Italian shots of the home, a section, Sounds, the bridges and the Dictionary at 1280 and 390 px: the reading flow is Italian throughout; the English a reader can meet is inside the collapsed disclosures (their summaries Italian), inside the three record registers (labelled), in the drawings themselves (the 25 SVG figures of the two studies keep the labels their scripts drew; the captions are Italian) and in the note names and ids the instruments print.

## What I could not do, or did otherwise

- **The ring sounding 4, 5, 6, 5, 4, 1** is not in the instrument: its stiffnesses are printed in the log and in `audio/INDEX.md`, not in the figure data, and the instruments show the figure data's numbers only.
- **Ring B's amplitudes** are not in the data (`clips_rings.json` has its partials only): the page plays them equal and says so beneath the instrument. **Ring A's eleventh partial** is nearly silent at the listening mass (as the clip says); the test asserts the ten audible ones.
- **The decays** of the rings of §13 (τ = 1.5 s × (f_low/f)^½) are the clips' listening choice, stated in `audio/INDEX.md`, not a number of the figure data; the bells' τ = 1.8 s × 220/f is `clips.json`'s.
- **The mirror's image of the diatonic set** is seven consecutive semitones, not a diatonic set a fifth-step apart: x ↦ 7x carries the line of fifths onto the line of semitones. The test asserts what the arithmetic gives.
- **The learner texts** of the proposed rows do not exist; their Story register tells them in the study's words or by their research text, and says which.
- **BRIDGE.md grades** stand in a proposed row's Standard register where the item's BRIDGE.md names the row in a numbered section, by its id or by one of its check tags, or where the item drills one bridge; MUS-025 alone (ml·CUBE, named only in an unnumbered section) shows the line "names no bridge for this row".
- **Web fonts** need the network, as before; KaTeX's fonts ship. **Not packaged**: no zip was made; `out/` is the site.
- **The drawings are the studies' files** (second pass): the 25 SVG figures keep their English labels; the site shows them with Italian captions and the English caption in a disclosure. Redrawing them was not the brief's.
- **A study's own words stand on the English page** (second pass): the items of the page of the bridges keep the study's prose in the flow, and that prose says *proposed*, *merged*, *the drill* where the study says so; the checker exempts `data-b` records on the English pages from the process-word rule. On the Italian pages that prose is in disclosures.

---

# Release 1 (2 November 2026), as it was

How the generator works, its string tables, how to rebuild and check, and what is not done.

## Layout

```
site/
  gen/                    the generator (Node 22, KaTeX 0.16.47 and Playwright from NODE_PATH=/opt/npm-tools/node_modules)
    build.mjs             reads the Atlas and the tables below, writes out/ and gen/build/trace.json
    check.mjs             verifies out/ against the sources (exit 0 when clean)
    shoot.cjs             screenshots of every page, 1280 and 390 px, light and dark, from file://, with the console checked
    test_sounds.mjs       the synthesizer's test: Chromium renders sounds.js into an OfflineAudioContext and measures it
    lib/sources.mjs       loads the Atlas's tables and round 36's files; resolve(source) → text; applyPart (declared parts)
    lib/study.mjs         reads the study's HTML into units (paragraphs, list items, captions, displays) and sentences
    lib/tex.mjs           the sister site's lib/tex.mjs, copied unchanged (its inline sub/superscript rules are used)
    lib/scripts.mjs       scriptsH / scriptsP: those rules plus one of this site's ((−1)^|x∧s| is one superscript)
    lib/md.mjs            the inline markdown of the round's indexes (code, bold, italics, links, \|)
    content/strings.json  the site's own strings (220): id, text, why; `optional` for the ones shown only on some data
    content/story_map.json  the Story register: for each row, the study's units or sentence ranges that tell it; the home's question
    content/placements.json the section order and slugs, the clips of each section, each section's instrument, the home's figure
    figures/mark.svg      the site's mark (the clock with the augmented triad)
    assets/               site.css, site.js (the register switch), sounds.js (the synthesizer), RELEASE_NOTES.md
    build/                trace.json (every traced block), build_log.json, check_log.json
  out/                    the site: 15 pages, site.css, site.js, sounds.js, sounds-data.js, katex/, figures/, audio/, checks/, content/version.json, RELEASE_NOTES.md, LICENSE
  record/                 these notes, shots/ (64+ screenshots), shots_report.json, test_sounds.json
```

## How the generator works (release 1)

- **Trace.** `traced(ctx, base, source, {part, render})` resolves a source — `{table, key, field}` on the Atlas's tables, on the round's files, or a site string — applies the declared part (`first-sentence`, `md-plain`, `sentences:a-b`, `grade-word`), records the block in `build/trace.json` and gives the element its `data-b`. A site string is an element with `data-s`.
- **Renderings.** `text` (escaped), `script` (the Atlas's inline sub- and superscripts drawn, the sister site's rules), `md` (the indexes' markdown, already plain, with scripts), `mdlinks` and `links` (URLs as links), `study` (the study's units: formulas set by KaTeX, its "corrected" chips and emphasis kept, scripts drawn).
- **The study.** `lib/study.mjs` cuts the study's body at its headings into units, replaces each KaTeX rendering by its TeX (the annotation the study carries), keeps i, b, code, links and the chips, and splits units into sentences (the sister site's rule). A displayed formula is rendered as `\htmlData{src=<unit>}{…}` with its `\tag` kept outside, so the page names the source of each display; `data-tex` keeps the plain TeX for the checker.
- **Rows.** `rowBlock` writes the head (id, chip from `derived/status.json`, badge, claim = homePhys or the research text's first sentence) and the four registers. Story: `story_map.json` (the study), else the learner text (`texts.json`, level learner, register full), else the research text. Atlas: homeMath, homePhys, kind (and the input's kind), status and badge, cells, depends (grouped by relation, linked when the row is on the site), the reason, since; each evidence with the check's statement (`checks.json` ids), the run record (date, ok, fail, last line; the latest record of the script) and, for round 36, the group's lines of the log. Standard: standardRef (URLs live) and the lens entries whose rows hold the row (else its readings).
- **Sections.** From `page.json` (titles, leads) and `chains.json` (the rows in order, the links with their notes); figures where FIGURES_INDEX.md's row column meets the chain (ranges expanded; the map is the home's); clips from `placements.json`.
- **Sounds.** `sounds-data.js` is written by the build from `figdata/` (cents_table, dissonance_curve, dft, plr_dual, even, chain_modes, partials); `sounds.js` exposes its engine as `window.SDV_ENGINE` so the test renders the same calls offline.

## What the checker verified in release 1

Every traced block equals its source (with its part) and the page shows exactly that text; every `data-b` is traced; every `data-s` shows its string and every string has an id, a text and a why; no run of three words stands outside the traced elements; each chip is its row's status in `derived/status.json`; each row block has its four registers and Story its source line; each section shows its chain's rows in order and its clips; every internal link and anchor resolves and every image, clip, script, stylesheet and KaTeX font ships; exactly one link to the Atlas (About, `data-atlas-link`, `#/music`); every formula renders with KaTeX and no page holds a KaTeX error; no script fetches; `version.json` names the Atlas 4.4.9, the release and the date, and every page carries the stamp; the 13 figures, 12 clips, 34 lens entries, 89 ok lines and the scripts and logs are all there. Last run of release 1: 0 errors, 0 warnings, about 1,700 traced blocks.

## What release 1 could not do, or did otherwise

- **No learner texts**: none exist for the MUS and INP rows or the leads; Story uses the study's prose (21 rows), the Atlas's learner texts (5 rows) or, for ATY-040, its research text, and each block says which.
- **Clips 7 and the sections**: the brief named the clips of five sections; shapes, fourier and question have none, and link instead to the Sounds page's instrument (the Tonnetz walk, the clock).
- **Clicks**: the rhythm's percussive sounds use a 2 ms raised-cosine attack and an exponential decay, not the 20 ms fades of the tones (clip 8's clicks are percussive too).
- **Drift of other walks**: the page computes the just drift of any walk; only the hexatonic one (128/125) is a number of the Atlas's tables, and the test asserts it.
- **Web fonts** need the network, as on the sister site; KaTeX's fonts ship.
- **Not packaged**: no zip and no publish lists were made; `out/` is the site.

## Release 5 (5 November 2026)

- Three experiments corrected (`gen/exp/SPECS_B5_fix.md`, `B5_NOTE.md`): streams (the Lorentzian beams and the bump on the tail from `kinetic.json`), harmonics (Λₙ(λ) by the certified recurrence, the chord weighted), layers (the triplet's shares fluid and kinetic, the hot electrons' wave on the ramp, where the converted wave goes, from `music_layers.log sy·RAMP` and the X–B ramp's `xb_ramp.json`).
- The kinetic X–B ramp read as its own files (`SDV_PACK_XB`, `lib/pack.mjs loadXB`): ten rows as a second chain of the layers chapter, the script among the checks, the figure among the pictures; `version.json.xb` lists its files. NOTE_R5.md has the details.
- Italian: `manifest_r5.mjs`, `it/BRIEF_IT_R5.md`, narrators E1 and E2, `check_r5.mjs`, `merge_r5.py`.
