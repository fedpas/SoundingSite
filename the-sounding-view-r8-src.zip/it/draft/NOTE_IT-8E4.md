# NOTE IT-8E4

Wrote it/draft/r8_E4.json: 146 strings (59 of the experiment `duals`, 87 of `dualcells`); no narrations or titles in this share; check_r8.mjs 0 errors, 0 warnings.

Terms chosen: vertice (corner/vertex), spigolo (edge), faccia, quadrato, cella / cella cubica; tesseratto, 16-celle, 24-celle, 600-celle, 120-celle; campana duale; parziale; laplaciano; parti condivise; rappresentazione irriducibile; misura di Plancherel; settore simmetrico / di torsione; numero d'onda di Bloch; modi di estremità; segnatura, scambio di gauge, flusso π; "scala" for the cube's ladder (the interval panel), kept as in the earlier experiments' "righello" sense only for the cents axis.
Mapping kept exact: 220 Hz × √λ/√2 in both `hear` strings; 1.5 s decay, 1.2 s dual delay, 350.978 cents, MUS-001, MUS-003, MUS-025, all formulas and check tags unchanged.
Choices: the four-part `see` of dualcells uses Primo/Secondo/Terzo/Quarto (the checker bans temporal "prima"). "ladder" is told as "scala" (of levels); a doubt: "scala" also means musical scale, the context (autovalori) disambiguates. The 5-cube/5-cross are "5-cubo/5-croce" after "3-cubo" in the graphs experiment.
No doubt about physics; the strings follow the English exactly in content.
