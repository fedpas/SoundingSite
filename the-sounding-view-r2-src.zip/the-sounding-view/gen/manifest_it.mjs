// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// manifest_it.mjs — writes content/it/MANIFEST.json for the Italian narrators (it/VOICE_IT.md): every narration target
// the Italian pages render (its id, what it is, the English material it stands on, its length), the strings added in
// release 2 (strings_new: id, English text, why) and the strings whose English text changed (strings_changed).
// Usage: node gen/manifest_it.mjs [REPO]
import fs from 'node:fs';
import path from 'node:path';
import { load, GEN, SITE } from './lib/sources.mjs';

const REPO = path.resolve(process.argv[2] || process.env.SDV_ATLAS || path.join(path.dirname(SITE), 'repo'));
const D = load(REPO);
const P = D.pack;
const BM = D.bridgesMap;
const J = (p) => JSON.parse(fs.readFileSync(p, 'utf8'));
const r1 = J(path.join(SITE, '..', 'site_r1_backup', 'gen', 'content', 'strings.json')).strings;
const r1ById = new Map(r1.map((s) => [s.id, s]));
const targets = [];
const T = (target, kind, what, tells, length, where) => targets.push({ target, id: 'r:' + target, kind, what, tells, length, where });
const SECS = D.placements.order.map((id) => ({ id, slug: D.placements.sections[id].slug, chain: [...D.chains.values()].find((c) => c.section === id), lead: D.page.sections.find((x) => x.id === id).lead, place: D.placements.sections[id] }));
const secOfRow = new Map(); for (const s of SECS) for (const r of s.chain.rows) secOfRow.set(r, s);
const clipId = (file) => 'clip:' + file.split('_')[0];
const secNo = (s) => s.replace(/^s(\d+)(?:-(\d+))?$/, (m, a, b) => (b ? `${a}.${b}` : a));
// release 1
T('page:home', 'page', "the home: the question of the site, in the narrator's words, after the study's abstract and MUS-701", ['study:top.3', 'MUS-701'], '120–180', 'index.html, under the question');
for (const s of SECS) T(`section:${s.slug}`, 'section', `the section ${s.slug} of the page music: what it is about, what its rows establish together, what to listen to`, [s.lead, ...s.chain.rows, ...s.place.clips.map(clipId), ...(s.place.instrument ? ['instrument:' + s.place.instrument] : [])], '100–160', `${s.slug}.html, under the lead`);
for (const s of SECS) for (const id of s.chain.rows) {
  const pieces = D.storyMap.rows[id] || [];
  const secs = [...new Set(pieces.map((p) => 'study:§' + secNo(p.unit.split('.')[0])))];
  T(`row:${id}`, 'row', `the row ${id} told: what it claims, what establishes it, the numbers that matter, where it sits in the music (section ${s.slug})`, [id, ...secs], '60–140', `${s.slug}.html#${id}, the Racconto register`);
}
T('page:dictionary', 'page', 'the lens Music: what a grade means, how to read the table and the readings', ['lens:mus'], '100–160', 'dictionary.html, under the head');
T('page:checks', 'page', 'what a check script is, what the two scripts of round 36 compute, what a control is, how to read a log', ['check:music_sound.py', 'check:music_symmetry.py'], '100–160', 'checks.html, under the head');
T('page:pictures', 'page', 'the thirteen figures of Music on the labels as a set', D.figures.map((f) => 'fig:' + f.file.replace(/\.svg$/, '')), '60–120', 'pictures.html, under the head');
T('page:sounds', 'page', 'the Sounds page: the clips and the instruments, how the synthesizer is built and tested', ['clip:01', 'clip:21', 'instrument:clock', 'instrument:rows'], '100–160', 'sounds.html, under the head');
const INST = { clock: ['cents_table.json', 'dft.json', 'MUS-004', 'MUS-005', 'MUS-011'], tonnetz: ['plr_dual.json', 'MUS-006', 'MUS-007', 'clip:07'], rhythm: ['even.json', 'MUS-009', 'clip:08a'], chain: ['chain_modes.json', 'partials.json', 'MUS-002', 'MUS-003', 'clip:01', 'clip:06'], gliss: ['dissonance_curve.json', 'MUS-004', 'clip:05'], commas: ['cents_table.json', 'MUS-001', 'clip:03', 'clip:04'] };
for (const [k, tells] of Object.entries(INST)) T(`instrument:${k}`, 'instrument', `instrument ${k} of the Sounds page: what it plays, what to try, where its numbers come from (its "where the numbers come from" line, strings i1.from … i6.from)`, tells, '60–120', `sounds.html#i-${k}, under the instrument's lead`);
for (const c of D.clips) T(clipId(c.file), 'clip', `what you hear in ${c.file}, after audio/INDEX.md's "what is heard"`, [clipId(c.file), ...new Set([...c.built.matchAll(/MUS-\d{3}/g)].map((m) => m[0]))], '40–90', `sounds.html#clip-${c.file.split('_')[0]}, under "what is heard"`);
T('page:sources', 'page', 'the sources page: the two studies\' references, the paper, the links fetched', ['study:refs', 'drill:refs'], '80–140', 'sources.html, under the head');
T('page:about', 'page', 'the method of the site (the four registers, the chips, the one link to the Atlas, the licence), and the pack read as a study\'s own files, told by the narrator', ['about'], '80–140', 'about.html, under the head');
// release 2
T('page:bridges', 'page', "the page The bridges drilled: the round's question (the ten bridges of round 36 drilled; music leading on ℤ₈ against ℤ₁₂; the Atlas's computation extended to twelve; the four questions left open and tried; the paper), what is proposed and not merged", ['drill:§1', 'drill:§10', 'drill:§16', 'drill:top.2', 'drill:top.3'], '150–220', 'bridges.html, under the head');
T('bridges:table', 'section', 'the table of the eleven bridges, before and after the drill: how to read it', ['drill:BRIDGES_DRILLED.md', 'drill:top.4'], '60–100', 'bridges.html#bridges-table, under the table\'s lead, before the table');
const secName = (s) => 'drill:§' + secNo(s).replace(/^p2$/, 'part 2');
for (const im of BM.items) {
  const it = P.itemOf.get(im.item);
  const figs = P.figures.filter((f) => f.row.includes(it.rows[0].slice(0, 7)) || [...f.row.matchAll(/MUS-\d{3}/g)].some((m) => it.rows.includes(m[0]))).map((f) => 'fig:' + f.file.replace(/\.svg$/, ''));
  T(`bridges:item:${im.item}`, 'section', `the item ${im.item} of the drill: which bridges it drills, what was computed, what grade came out, what to listen to`, [...im.sections.map(secName), ...it.rows, ...figs, ...im.clips.map(clipId), ...(im.instrument ? ['instrument:' + im.instrument] : []), `drill:items/${im.item}/BRIDGE.md`], '120–180', `bridges.html#item-${im.item}, under the item's heading`);
}
for (const it of P.items) for (const id of it.rows) {
  const r = P.rows.get(id);
  const pieces = BM.rows[id] || [];
  T(`row:${id}`, 'row', `the proposed row ${id} (item ${it.item}; status by the rule: ${r.status}; checks ${r.tags.join(', ') || 'none of its own'}) told: what it claims, what establishes it, the numbers that matter; say that it is proposed, not merged, where it helps`, [id, ...new Set(pieces.map((p) => secName(p.unit.split('.')[0]))), ...r.tags.map((t) => 'check:' + [...P.scripts].find(([k, s]) => s.order.includes(t))[0] + '.py')], '60–140', `bridges.html#${id}, the Racconto register`);
}
T('instrument:crt', 'instrument', "instrument 7, the Tonnetz as the CRT grid: the fifth's diagonal, the two cycles, the mirror x ↦ 7x; where its numbers come from (string i7.from)", ['crt_tonnetz.json', 'MUS-016', 'MUS-018', 'drill:§3.1', 'fig:crt_tonnetz'], '80–140', 'sounds.html#i-crt, under the instrument\'s lead');
T('instrument:rings', 'instrument', 'instrument 8, the two rings and the bell: the solved ring against the nearest-neighbour ring, the positive rings, ring A and ring B, the 12-cube and 3-cube bells; where its numbers come from (string i8.from)', ['harmonic_ring.json', 'sets.json', 'clips_rings.json', 'rings.json', 'bell_levels.json', 'MUS-025', 'MUS-030', 'MUS-031', 'MUS-039', 'MUS-041', 'drill:§7', 'drill:§13', 'clip:13', 'clip:14', 'clip:15', 'clip:20', 'clip:21'], '80–140', 'sounds.html#i-rings, under the instrument\'s lead');
T('instrument:rows', 'instrument', "instrument 9, the all-interval rows played by the voicing rule: a row by number or preset, retrograde, inversion, R = T₆; where its numbers come from (string i9.from)", ['all_interval_rows.json', 'berg_row.json', 'fig_rows.json', 'hexachords.json', 'MUS-036', 'MUS-037', 'MUS-038', 'drill:§12', 'clip:16', 'clip:17', 'clip:18', 'fig:fig_rows'], '80–140', 'sounds.html#i-rows, under the instrument\'s lead');
for (const c of P.clips) T(clipId(c.file), 'clip', `what you hear in ${c.file}, after the pack's audio/INDEX.md "what is heard"`, [clipId(c.file), ...new Set([...c.built.matchAll(/MUS-\d{3}/g)].map((m) => m[0])), ...new Set([...c.built.matchAll(/[a-z]{2}·[A-Z0-9]+/g)].map((m) => 'check:' + m[0]))], '40–90', `sounds.html#clip-${c.file.split('_')[0]}, under "what is heard"`);
T('page:acoustics', 'section', "the paper's dictionary: Burns, Daniel, Alexander and Dressel's Tables 3 and 4 carried into three columns (the paper's acoustics, its electromagnetism, the Atlas's words), the grades (9 exact, 14 partial, 9 none), the ten candidates", ['drill:items/acoustics/DICTIONARY.md', 'drill:§15', 'MUS-045', 'MUS-046', 'MUS-047', 'MUS-048', 'MUS-049', 'check:music_acoustics.py'], '120–180', 'bridges.html#dictionary, under the section\'s lead (the same table stands on dictionary.html without a narration)');
// targets the builder added (it/VOICE_IT.md allows it): the nine scripts of the pack, the twelve figures, the opinion
T('checks:round37', 'section', "the nine scripts of the pack on the Checks page: what each computes in one breath (bridges 4, 7, 9; 3, 6, 8; 5, 2, 11; 1; the walk; the rows; the rings; the body; the paper), 311 checks and 45 controls, that none is merged, how to read their logs", ['check:music_clock12.py', 'check:music_labels12.py', 'check:music_duality.py', 'check:music_bell.py', 'check:music_walk.py', 'check:music_rows.py', 'check:music_rings.py', 'check:music_body.py', 'check:music_acoustics.py', 'drill:checks/README.md'], '100–160', 'checks.html#round37, under the heading of the nine scripts');
T('pictures:round37', 'section', 'the twelve figures of The bridges drilled as a set', P.figures.map((f) => 'fig:' + f.file.replace(/\.svg$/, '')), '60–120', 'pictures.html#round37, under the heading of the twelve figures');
T('bridges:opinion', 'section', "the study's opinion (§9: what letting music lead gave, and what it did not) and what part 2 changes (§16), told: the three things gained, the three grades 'exact (arithmetic), none (meaning)', the laws that rewrite", ['drill:§9', 'drill:§16'], '80–140', 'bridges.html#opinion, under the heading, before the study\'s §9');
// the strings
const cur = J(path.join(GEN, 'content', 'strings.json')).strings;
const strings_new = cur.filter((s) => !r1ById.has(s.id)).map((s) => ({ id: s.id, text: s.text, why: s.why, ...(s.optional ? { optional: true } : {}) }));
const strings_changed = cur.filter((s) => r1ById.has(s.id) && r1ById.get(s.id).text !== s.text).map((s) => ({ id: s.id, text: s.text, was: r1ById.get(s.id).text, why: s.why }));
const manifest = {
  about: "The manifest of the Italian side of The Sounding View, release 2, for the two narrators (it/VOICE_IT.md): every narration target the Italian pages render, with what it is, the English material it stands on (tells: row ids; study sections study:§n for Music on the labels and drill:§n for The bridges drilled; clips clip:NN; figures fig:<file>; scripts check:<name>.py; the pack's files drill:<path>; the figure data files by name), the length in words it/VOICE_IT.md asks for, and where the page renders it; then strings_new, every string added in release 2 with its English text and why, and strings_changed, the strings of release 1 whose English text changed (the Italian is rewritten for the new text). Written by gen/manifest_it.mjs.",
  tables: { strings: 'content/it/strings_it.json — one entry per id of content/strings.json (' + cur.length + ' ids: the 220 of release 1 and the ' + strings_new.length + ' below), { id, text, why }; a string marked optional in strings.json is shown only on some data or used as an attribute and must still be filled', racconto: 'content/it/racconto.json — items [{ id: "r:" + target, target, tells, text, why }], one per target below, no target twice; paragraphs separated by a blank line; plain text, no HTML, no markdown' },
  rules: { banned: "the checker flags, whole words, case-insensitive, every form: adesso, nuovo/a/i/e, recente/i, ultimo/a/i/e, aggiornato/a/i/e, precedente/i, corretto/a/i/e, sostituito/a/i/e, superato/a/i/e, versione/i, release, 'round N'; 'ora' as a word (not after an apostrophe: un'ora is fine); 'prima' in its temporal uses only (prima di, prima che, prima del…, come prima, di prima, da prima, or closing a clause before a comma or a full stop) — the ordinal (la prima nota, forma prima) is allowed; release and versione are allowed in the string release.stamp alone", names: 'the record ids, the file names, the check tags, Atlas, Standard, The Sounding View, The Shifted View, the study titles stay as they are', numbers: 'as the records print them' },
  counts: { targets: targets.length, byKind: Object.fromEntries(['page', 'section', 'row', 'instrument', 'clip'].map((k) => [k, targets.filter((t) => t.kind === k).length])), strings_new: strings_new.length, strings_changed: strings_changed.length, strings_total: cur.length },
  targets, strings_new, strings_changed,
};
fs.writeFileSync(path.join(GEN, 'content', 'it', 'MANIFEST.json'), JSON.stringify(manifest, null, 1) + '\n');
console.log(`MANIFEST.json: ${targets.length} targets, ${strings_new.length} new strings, ${strings_changed.length} changed strings`);
