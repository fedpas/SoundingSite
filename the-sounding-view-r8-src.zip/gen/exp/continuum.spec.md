# Builder B1 — Ladder I: one tone, many bodies (five experiments)

Read `CONTRACT.md` and `_common.strings.json` first; then `_kit.js` (the helpers), and `field.js` if it exists. The Atlas rows' claims are in `/tmp/claude-0/-home-claude/394118bf-a32c-5136-a011-44d634d15d21/scratchpad/plan4/atlas_sound.json` (`rows[id].homePhys`, `.status`, `.text`). ATLAS = `/tmp/claude-0/-home-claude/394118bf-a32c-5136-a011-44d634d15d21/scratchpad/in4414/one-rule-src-4.4.14`; its figure data for these five: `checks/selfcheck/round36/figdata/{chain_modes, partials, dissonance_curve, consonance, cents_table}.json`, `checks/selfcheck/round37/figdata/{bell, bell_levels, harmonic_ring, rings, chain, cut_ring, sets, clips, clips_rings}.json`. Read them with `python3 -I`, inspect the shapes (the `source` fields name the check groups), and copy what each experiment needs into `<slug>.data.json`. The Atlas's engine `ATLAS/engines/springEngine.js` (plain ES module: `walsh, verts, edges, omega2, mode, pluck, levelShare, signedLevels`) may be copied into your module as plain functions, with its SPDX header line kept; it needs `ATLAS/engines/bitrule.js` (`popcount`, `sign`): copy what you use.

Pitch mapping for every experiment here: the first partial (or the lowest mode) sounds at 220 Hz unless the spec says otherwise; print the mapping in the `hear` line.



---

## 3. `continuum` — The beaded string becomes a string; bars and drums (MUS-003)

*Panels:* (a) **The limit**: a chain of N beads (N slider 2 … 48) between walls; its spectrum ω_k = 2 sin(πk/(2(N+1))) normalised to ω₁, as bars against the harmonic ruler; as N grows the low modes approach k : 1 — print the error in cents of mode 2 … 6 at the current N; say "harmonic only in the limit". (b) **Four bodies**: a picker string / stiff string / free bar / membrane; the partial ratios from `partials.json` (string 1…8; stiff string with B and its cents above k·f₁; bar x_k ratios; membrane j_mn ratios with the (m, n) labels); the shapes: the string's and bar's standing modes drawn as curves (sin(kπx/L) for the string; for the bar draw the free–free mode shape cosh/cos form only if you compute it exactly — otherwise draw the string's shape and say "shape of a string; the bar's frequencies are the data's"); the membrane's mode as a circular colour map with its nodal circles and diameters (J_m(j_mn r) cos mθ; implement J_0, J_1, J_2 by the series to 30 terms — cheap and exact enough; print the first zeros against the data's j_mn to check). *Hear:* each body struck: the partials from the data with decaying amplitudes (`kit.strike`), 220 Hz first partial. *Legend rows:* MUS-002, MUS-003. *Data:* `partials.json` whole; `chain_modes.json` `P_N_fixed_ends`.

### As built

Mapping: first partial 220 Hz; partial i at 220·(ratio_i). Slow-down: the picture turns at 0.3 turn per second for the first partial, 733× slower than the sound (printed); higher modes turn faster in proportion.
Deviations: the bar's shape is drawn as a string's (said on the drum-bar note); its frequencies are the data's. The membrane's shapes J_m(j_mn r)cos mθ use the Bessel series to 30 terms; J₀, J₁, J₂ at the data's first zeros are printed (they vanish to 6 decimals); nodal circles are found as sign changes of that series on the radius, nodal diameters from cos mθ = 0. The beaded chain uses `chain_modes.json` for N = 2…5 and the formula above; the mode slider goes to 8. The stiff string's partials come from the data's ratio list; the membrane has the data's nine modes, the bar six, the string eight.
