// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// sets — sets as labels; classes, rhythms, rows (MUS-019 … 024, 036 … 038, LAB-024)
(function () {
  'use strict';
  window.SDV_EXP = window.SDV_EXP || {};
  window.SDV_EXP['sets'] = {
    mount: function (root, data, S, kit) {
      var TAU = Math.PI * 2, el = kit.el, NS = 'exp.sets.', snd = false, live = [], timers = [];
      var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      var moving = !reduce, T = 0, mask = [1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0], names = data.names;
      function hz(pc) { return 261.6256 * Math.pow(2, pc / 12); }
      function cell(p) { var c = el('div', { style: 'min-width:0;overflow:hidden' }); p.appendChild(c); return c; }
      function pcs(m) { var r = []; for (var i = 0; i < 12; i++) if (m[i]) r.push(i); return r; }
      function silence() { live.forEach(function (t) { t.stop(); }); live = []; timers.forEach(clearTimeout); timers = []; }
      function chord(p) { if (!snd || !p.length) return; live.forEach(function (t) { t.stop(); }); live = []; p.forEach(function (x) { live.push(kit.tone({ f: hz(x), gain: 0.2 / Math.sqrt(p.length), dur: 1.0 })); }); }
      function pos(i, cx, cy, R) { var a = TAU * i / 12 - Math.PI / 2; return [cx + R * Math.cos(a), cy + R * Math.sin(a)]; }
      function dial(c, cx, cy, R, set, hi) {
        var i, p, q, ps = pcs(set);
        c.strokeStyle = kit.muted(); c.lineWidth = 1; c.beginPath(); c.arc(cx, cy, R, 0, TAU); c.globalAlpha = 0.5; c.stroke(); c.globalAlpha = 1;
        if (ps.length > 1) { c.strokeStyle = kit.accent(); c.lineWidth = 1.6; c.beginPath(); ps.forEach(function (x, j) { p = pos(x, cx, cy, R); if (j) c.lineTo(p[0], p[1]); else c.moveTo(p[0], p[1]); }); c.closePath(); c.globalAlpha = 0.9; c.stroke(); c.globalAlpha = 0.12; c.fillStyle = kit.accent(); c.fill(); c.globalAlpha = 1; }
        for (i = 0; i < 12; i++) {
          p = pos(i, cx, cy, R); q = pos(i, cx, cy, R + 16); var on = set[i];
          c.fillStyle = on ? kit.accent() : kit.panel(); c.strokeStyle = on ? kit.accent() : kit.muted(); c.lineWidth = 1.4; c.beginPath(); c.arc(p[0], p[1], on ? 6 : 4, 0, TAU); c.fill(); c.stroke();
          c.fillStyle = kit.muted(); c.font = '11px system-ui, sans-serif'; c.textAlign = 'center'; c.fillText(names[i], q[0], q[1] + 4);
        }
        if (hi != null) { p = pos(hi, cx, cy, R); c.strokeStyle = kit.warm(); c.lineWidth = 2.5; c.beginPath(); c.arc(p[0], p[1], 10, 0, TAU); c.stroke(); }
      }
      function ivec(m) { var v = [0, 0, 0, 0, 0, 0], p = pcs(m); for (var i = 0; i < p.length; i++) for (var j = i + 1; j < p.length; j++) { var d = (p[j] - p[i]) % 12; if (d > 6) d = 12 - d; v[d - 1]++; } return v; }
      function play(btnParent) {
        var b = kit.button(btnParent, 'exp.common.play', S, function () {
          snd = !snd; b.textContent = S(snd ? 'exp.common.mute' : 'exp.common.play'); b.setAttribute('data-s', snd ? 'exp.common.mute' : 'exp.common.play');
          if (snd) { if (!kit.audio()) kit.line(root, 'exp.common.noaudio', S); chord(pcs(mask)); } else silence();
        }); return b;
      }

      root.classList.add('half');
      // ------------------------------------------------ (a) a set is a label
      var pa = kit.panel_(root, NS + 'panel.a', S), da = kit.canvas(cell(pa), 0.9, 300), ca = kit.controls(pa), boxes = [];
      play(ca);
      var tg = el('div', { class: 'exp-controls' }); pa.appendChild(tg);
      for (var i = 0; i < 12; i++) (function (i) {
        var l = el('label', { class: 'exp-check' }), inp = el('input', { type: 'checkbox' }); inp.checked = !!mask[i];
        inp.addEventListener('change', function () { mask[i] = inp.checked ? 1 : 0; changed(); });
        l.appendChild(inp); l.appendChild(el('span', { text: names[i] })); tg.appendChild(l); boxes.push(inp);
      })(i);
      var cb = kit.controls(pa);
      function setMask(m) { mask = m.slice(); boxes.forEach(function (b, i) { b.checked = !!mask[i]; }); changed(); }
      kit.button(cb, NS + 'T', S, function () { setMask(mask.map(function (_, i) { return mask[(i + 11) % 12]; })); });
      kit.button(cb, NS + 'I', S, function () { setMask(mask.map(function (_, i) { return mask[(12 - i) % 12]; })); });
      kit.button(cb, NS + 'comp', S, function () { setMask(mask.map(function (v) { return v ^ 1; })); });
      kit.slider(cb, { id: NS + 'collins', S: S, min: 1, max: 12, step: 1, value: 1, fmt: function (v) { return String(v); }, onchange: function (v) { var r = data.collins[v - 1], m = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; r.pcs.forEach(function (x) { m[x] = 1; }); setMask(m); } });
      var ra = kit.readout(pa), rb = kit.readout(pa);
      kit.line(pa, NS + 'a.note', S);
      function changed() { chord(pcs(mask)); }
      function drawA() {
        var s = da.size(), c = da.ctx; c.clearRect(0, 0, s.w, s.h); dial(c, s.w / 2, s.h / 2, Math.min(s.w, s.h) * 0.34, mask);
        var bin = mask.join(''), code = 0, m = 0; for (var j = 0; j < 12; j++) { if (mask[j]) { code += Math.pow(2, 11 - j); m += Math.pow(2, j); } }
        ra.textContent = bin + '   mask ' + m + '   code ' + code; rb.textContent = '⟨' + ivec(mask).join(' ') + '⟩   |A| = ' + pcs(mask).length;
      }

      // ------------------------------------------------ (b) the classes
      var pb = kit.panel_(root, NS + 'panel.b', S), db = kit.canvas(cell(pb), 0.62, 260), cbb = kit.controls(pb);
      var rbb = kit.readout(pb); kit.line(pb, NS + 'b.note', S);
      data.zpair.forEach(function (z, idx) {
        var b = kit.button(cbb, NS + (idx ? 'z2' : 'z1'), S, function () { var m = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; z.pcs.forEach(function (x) { m[x] = 1; }); setMask(m); });
        void b;
      });
      var rz = kit.readout(pb); rz.textContent = data.zpair.map(function (z) { return z.name + ' {' + z.pcs.join(',') + '} ⟨' + z.iv.join(' ') + '⟩'; }).join('   ');
      function drawB() {
        var s = db.size(), c = db.ctx, W = s.w, H = s.h, box = { l: 36, t: 14, r: W - 8, b: H - 34 }, n = pcs(mask).length;
        c.clearRect(0, 0, W, H);
        var ax = kit.axes(c, box, { xmin: -0.6, xmax: 12.6, ymin: 0, ymax: 85, xticks: [0, 2, 4, 6, 8, 10, 12], yticks: [0, 20, 40, 60, 80], xlabel: '|A|' });
        for (var k = 0; k <= 12; k++) {
          [[data.per_card_T[k], -0.36, kit.muted()], [data.per_card_TI[k], 0.04, kit.accent()]].forEach(function (b) {
            var x0 = ax.x(k + b[1]), x1 = ax.x(k + b[1] + 0.32), y = ax.y(b[0]); c.fillStyle = b[2]; c.globalAlpha = k === n ? 1 : 0.5; c.fillRect(x0, y, x1 - x0, box.b - y);
          }); c.globalAlpha = 1;
        }
        var tT = data.per_card_T.reduce(function (a, b) { return a + b; }, 0), tI = data.per_card_TI.reduce(function (a, b) { return a + b; }, 0);
        rbb.textContent = '4096 → ' + tT + ' → ' + tI + '   |A| = ' + n + ':  ' + data.per_card_T[n] + ' → ' + data.per_card_TI[n];
      }

      // ------------------------------------------------ (c) rhythms as necklaces
      var pc = kit.panel_(root, NS + 'panel.c', S), dc = kit.canvas(cell(pc), 0.8, 280), cc = kit.controls(pc), ri = 0, step = -1;
      var rbtn = data.rhythms.map(function (r, i) { var b = el('button', { type: 'button', class: 'btn exp-btn', text: (r.name.charAt(0) === 'E' && r.name.charAt(1) === '(' ? '' : r.name.split(';')[0] + ' ') + 'E(' + r.k + ',' + r.n + ')' }); b.addEventListener('click', function () { ri = i; step = -1; }); cc.appendChild(b); return b; });
      kit.check(cc, NS + 'motion', S, moving, function (v) { moving = v; });
      var rc = kit.readout(pc); kit.line(pc, NS + 'c.note', S);
      var rs = kit.readout(pc); rs.textContent = data.bjorklund_steps.join('  →  ');
      function drawC() {
        var s = dc.size(), c = dc.ctx, W = s.w, H = s.h, cx = W / 2, cy = H / 2, R = Math.min(W, H) * 0.36, r = data.rhythms[ri], n = r.n, i;
        c.clearRect(0, 0, W, H); c.strokeStyle = kit.muted(); c.lineWidth = 1; c.beginPath(); c.arc(cx, cy, R, 0, TAU); c.globalAlpha = 0.5; c.stroke(); c.globalAlpha = 1;
        var on = []; for (i = 0; i < n; i++) if (r.x[i] === 'x') on.push(i);
        c.strokeStyle = kit.accent(); c.lineWidth = 1.5; c.beginPath(); on.forEach(function (j, q) { var a = TAU * j / n - Math.PI / 2, x = cx + R * Math.cos(a), y = cy + R * Math.sin(a); if (q) c.lineTo(x, y); else c.moveTo(x, y); }); c.closePath(); c.stroke();
        var cur = Math.floor(T / 0.25) % n;
        for (i = 0; i < n; i++) {
          var a = TAU * i / n - Math.PI / 2, x = cx + R * Math.cos(a), y = cy + R * Math.sin(a), o = r.x[i] === 'x';
          c.fillStyle = o ? kit.accent() : kit.panel(); c.strokeStyle = o ? kit.accent() : kit.muted(); c.lineWidth = 1.5; c.beginPath(); c.arc(x, y, o ? 8 : 5, 0, TAU); c.fill(); c.stroke();
          if (i === cur) { c.strokeStyle = kit.warm(); c.lineWidth = 2.5; c.beginPath(); c.arc(x, y, 13, 0, TAU); c.stroke(); }
        }
        if (cur !== step) { step = cur; if (snd && moving && r.x[cur] === 'x') kit.click(cur === 0 ? 1200 : 800, 0.15); }
        rc.textContent = r.x + '   E(' + r.k + ', ' + r.n + ')';
      }

      // ------------------------------------------------ (d) a tone row as a chain of labels
      var pd = kit.panel_(root, NS + 'panel.d', S), dd = kit.canvas(cell(pd), 0.7, 300), cd = kit.controls(pd), ridx = 0, kk = 12;
      var rowS = kit.slider(cd, { id: NS + 'row', S: S, min: 0, max: data.rows_example.length, step: 1, value: 0, fmt: function (v) { return v ? '#' + v : 'Berg'; }, onchange: function (v) { ridx = v; chordRow(); } });
      var addS = kit.slider(cd, { id: NS + 'added', S: S, min: 0, max: 12, step: 1, value: 12, fmt: function (v) { return String(v); }, onchange: function (v) { kk = v; } });
      kit.button(cd, NS + 'playrow', S, function () {
        if (!snd) return; silence(); var r = rowInfo();
        r.midi.forEach(function (m, i) { live.push(kit.tone({ f: 440 * Math.pow(2, (m - 69) / 12), gain: 0.18, dur: 0.24, at: 0.02 + i * 0.25 })); timers.push(setTimeout(function () { addS.set(i + 1); kk = i + 1; }, 20 + i * 250)); });
      });
      var rd = kit.readout(pd), rn = kit.readout(pd); kit.line(pd, NS + 'd.note', S);
      function rowInfo() {
        if (!ridx) return { pcs: data.berg.pcs, midi: data.berg.midi };
        var str = data.rows_example[ridx - 1], p = [0], m = [60], x = 0, y = 60;
        for (var i = 0; i < str.length; i++) { var d = '123456789TE'.indexOf(str[i]) + 1; x = (x + d) % 12; y += d <= 6 ? d : d - 12; p.push(x); m.push(y); }
        return { pcs: p, midi: m };
      }
      function chordRow() { }
      function drawD() {
        var s = dd.size(), c = dd.ctx, W = s.w, H = s.h, r = rowInfo(), x0 = 40, cw = (W - x0 - 10) / 12, ch = (H - 14) / 13, i, j;
        c.clearRect(0, 0, W, H); c.font = '10px system-ui, sans-serif'; c.textAlign = 'center';
        for (i = 0; i <= 12; i++) {
          var set = {}; for (j = 0; j < i; j++) set[r.pcs[j]] = 1;
          c.fillStyle = i === kk ? kit.warm() : kit.muted(); c.textAlign = 'right'; c.fillText(String(i), x0 - 6, 7 + i * ch + ch * 0.7);
          for (j = 0; j < 12; j++) { c.fillStyle = set[j] ? (i === kk ? kit.accent() : kit.muted()) : kit.panel(); c.strokeStyle = kit.muted(); c.globalAlpha = set[j] ? 0.9 : 0.5; c.fillRect(x0 + j * cw + 1, 6 + i * ch + 1, cw - 2, ch - 2); c.strokeRect(x0 + j * cw + 1, 6 + i * ch + 1, cw - 2, ch - 2); c.globalAlpha = 1; }
          if (i > 0) { c.fillStyle = kit.ink(); c.textAlign = 'center'; c.font = '9px system-ui, sans-serif'; }
        }
        c.strokeStyle = kit.warm(); c.lineWidth = 2; c.strokeRect(x0, 6 + kk * ch, cw * 12, ch);
        var m = 0; for (j = 0; j < kk; j++) m += Math.pow(2, r.pcs[j]);
        var cl = !ridx ? data.berg.chain[kk].class : '';
        rd.textContent = 'k = ' + kk + '   label ' + m + (cl ? '   class ' + cl : '') + '   ' + r.pcs.map(function (x) { return x; }).join(' ');
        rn.textContent = data.rows_count + '   ' + data.rows_numbers.classes_occurring + '   ' + data.rows_numbers.z_rows + '   ' + data.rows_numbers.symmetric;
      }
      void rowS; void ivec;

      var pz = kit.panel_(root, 'exp.common.see', S); kit.line(pz, NS + 'see', S);
      var ph = kit.panel_(root, 'exp.common.hear', S); kit.line(ph, NS + 'hear', S);
      var pdt = el('p', { class: 'exp-line' }); pdt.appendChild(el('strong', { 'data-s': 'exp.common.data', text: S('exp.common.data') })); pdt.appendChild(document.createTextNode(' ')); pdt.appendChild(el('span', { 'data-s': NS + 'data', text: S(NS + 'data') }));
      root.appendChild(el('div', { class: 'exp-panel span' }, [pdt]));
      kit.loop(function (t, dt) { if (moving) T += dt; drawA(); drawB(); drawC(); drawD(); });
    }
  };
})();
