# -*- coding: utf-8 -*-
# IT-2 · the narrator's own check of the two delivered tables (it/draft/racconto_bridges.json, strings_it_new.json):
# the banned words as gen/lib/italian.mjs matches them, the lengths of MANIFEST.json, the markup rule, the ids and tells.
# Run: python3 -I check_IT-2.py (from anywhere; it finds the site from its own path)
import json, re, os
DRAFT = os.path.dirname(os.path.abspath(__file__))
SITE = os.path.dirname(os.path.dirname(DRAFT))
M = json.load(open(os.path.join(SITE, 'gen', 'content', 'it', 'MANIFEST.json'), encoding='utf-8'))
R = json.load(open(os.path.join(DRAFT, 'racconto_bridges.json'), encoding='utf-8'))
S = json.load(open(os.path.join(DRAFT, 'strings_it_new.json'), encoding='utf-8'))

BANNED = ['adesso', 'nuovo', 'nuova', 'nuovi', 'nuove', 'recente', 'recenti', 'ultimo', 'ultima', 'ultimi', 'ultime',
          'aggiornato', 'aggiornata', 'aggiornati', 'aggiornate', 'precedente', 'precedenti', 'corretto', 'corretta',
          'corretti', 'corrette', 'sostituito', 'sostituita', 'sostituiti', 'sostituite', 'superato', 'superata',
          'superati', 'superate', 'versione', 'versioni', 'release']
NL = r"(?<![^\W\d_])"; NLQ = r"(?<![^\W\d_])(?<!['’])"; NF = r"(?![^\W\d_])"
def banned_hits(text):
    hits = []
    for w in BANNED:
        hits += [m.group(1) for m in re.finditer(NLQ + "(" + w + ")" + NF, text, flags=re.I)]
    hits += [m.group(1) for m in re.finditer(NLQ + r"(ora)" + NF, text, flags=re.I)]
    hits += [m.group(1) for m in re.finditer(NL + r"(round\s*\d+)", text, flags=re.I)]
    hits += [m.group(1) for m in re.finditer(NLQ + r"(prima)(?=\s+(?:di|che|del|della|dei|delle|dello|degli|d')\b|\s*[,.;:!?]|\s*$)", text, flags=re.I)]
    hits += [m.group(1) for m in re.finditer(r"\b(?:come|di|da)\s+(prima)" + NF, text, flags=re.I)]
    return hits

targets = {t['target']: t for t in M['targets']}
errors = []
seen = set()
for it in R['items']:
    t = it['target']; mf = targets.get(t)
    if not mf: errors.append('unknown target ' + t); continue
    if t in seen: errors.append('target twice ' + t)
    seen.add(t)
    if it['id'] != 'r:' + t: errors.append('bad id ' + it['id'])
    if it['tells'] != mf['tells']: errors.append('tells differ ' + t)
    lo, hi = [int(x) for x in mf['length'].replace('–', '-').split('-')]
    n = len(it['text'].split())
    if not (lo <= n <= hi): errors.append('length %s: %d, wants %s' % (t, n, mf['length']))
    h = banned_hits(it['text'])
    if h: errors.append('banned %s: %s' % (t, sorted(set(h))))
    if re.search(r'<[a-z][^>]*>|\*\*|^#', it['text'], flags=re.M): errors.append('markup ' + t)
    if not it.get('why'): errors.append('no why ' + t)
new = {s['id']: s for s in M['strings_new']}
ids = [s['id'] for s in S['strings']]
if sorted(ids) != sorted(new): errors.append('string ids differ from strings_new')
for s in S['strings']:
    h = banned_hits(s['text'])
    if h: errors.append('banned string %s: %s' % (s['id'], sorted(set(h))))
    for ph in re.findall(r'\{[a-z]+\}', new.get(s['id'], {}).get('text', '')):
        if ph not in s['text']: errors.append('placeholder %s lost in %s' % (ph, s['id']))
for e in errors: print('ERR', e)
print('narrations %d, strings %d, narration words %d, string words %d, errors %d' % (
    len(R['items']), len(S['strings']), sum(len(i['text'].split()) for i in R['items']), sum(len(s['text'].split()) for s in S['strings']), len(errors)))
