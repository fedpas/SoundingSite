# NOTE IT-8E2

Written: r8_E2.json. Narrations of MUS-238 ... MUS-244 and of checks:duals; titles of the two chains, the seven rows, SHP-001, SPR-003, SHP-004, the two captions, the two scripts; rewrites of section:tone (duals added in the second paragraph, six experiments named) and of card:part:sound; the four strings (checks.intro and pics.intro from previousIt, counts 34 and 37).

Check-only: part:sound rewritten (the English lead names the duals and the violin in motion); page:checks (34 scripts, five groups), page:pictures (37 figures, the three new ones named) and page:sources (refs4: three works) rewritten; page:about checked and kept (the English still lists five works read from their own files, as the Italian does).

Terms: la campana duale, i politopi a croce, la 24-celle / 16-celle / 120-celle / 600-celle, il tesseratto, il laplaciano degli spigoli, le parti condivise, la misura di Plancherel, il livello di riposo (rest level), la segnatura, lo scambio di gauge, il flusso π, i settori di torsione, i modi di estremità. "Curl" avoided as "rotore" (kept for the Clifford rotor).

Doubts: the figure captions run 92 and 98 words (material asks 40-120; the checker's generic limit warns). MUS-244: told that the cube's all-negative signing has flux +1 and no switching reaches it, not that no signing exists on the cube. Counts of checks (29 and 39) taken from the checks README.
