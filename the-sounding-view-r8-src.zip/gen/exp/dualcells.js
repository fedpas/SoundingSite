// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// dualcells — the tesseract and its cells, the 600-cell and the 120-cell, the column of octahedra, the π-flux (MUS-240 … MUS-244)
// The page draws the data's spectra, weights, bands, curves, corners and projections; it computes only the turning and the
// projections of the given corners, the values of the fractions and surds the data prints, m/V where the rows state it, and f = 220 Hz x sqrt(lambda)/sqrt(2).
(function () {
  'use strict';
  window.SDV_EXP = window.SDV_EXP || {};
  window.SDV_EXP['dualcells'] = { mount: function (root, data, S, kit) {
    var P = 'exp.dualcells.', el = kit.el, TAU = Math.PI * 2, F0 = 220 / Math.SQRT2, DECAY = 1.5, GREEN = '#3a8a5a', SWEEP = 8;
    var reduce = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    var T = data.tesseract, C16 = T.sixteen_cell, C6 = data.cayley.cell600, C1 = data.cell120, CO = data.column, FL = data.flux;
    var st = { t: 0, paused: reduce, cell: 0, cox: 'plane', v600: 0, sec: 'sym', mode: 0, N: 6, fx: 'octahedron' };
    // ------------------------------------------------------------ helpers
    function grid(parent, min) { var d = el('div'); d.style.cssText = 'display:grid;grid-template-columns:repeat(auto-fit,minmax(' + (min || 280) + 'px,1fr));gap:12px;align-items:start'; parent.appendChild(d); return d; }
    function cv(parent, a, m) { var d = el('div'); d.style.minWidth = '0'; parent.appendChild(d); return kit.canvas(d, a, m); }
    function txt(c, s, x, y, color, align, size, bold) { c.fillStyle = color || kit.muted(); c.textAlign = align || 'left'; c.font = (bold ? '600 ' : '') + (size || 11) + 'px system-ui, sans-serif'; c.fillText(s, x, y); }
    function R(id, o) { var s = S(P + id); for (var k in (o || {})) s = s.split('{' + k + '}').join(o[k]); return s; }
    function frac(s) { var p = String(s).split('/'); return p.length === 2 ? +p[0] / +p[1] : +p[0]; }
    function surd(s) {   // the value of a number the data prints: 4, "3/8", "9-3sqrt(5)", "5+sqrt(5)"
      if (typeof s === 'number') return s; s = String(s).replace(/\s/g, '');
      var m = s.match(/^(-?[\d.]+)?([+-]?)([\d.]*)sqrt\((\d+)\)$/);
      if (!m) return frac(s);
      return (m[1] ? +m[1] : 0) + (m[2] === '-' ? -1 : 1) * (m[3] ? +m[3] : 1) * Math.sqrt(+m[4]);
    }
    function pretty(s) { return String(s).replace(/sqrt\((\d+)\)/g, '√$1').replace(/sqrt (\d+)/g, '√$1').replace(/\bQ\b/g, 'ℚ').replace(/-1\/phi/g, '−1/φ').replace(/phi/g, 'φ').replace(/omega\^2/g, 'ω²').replace(/omega/g, 'ω').replace(/([\d)])([+-])(\d|√)/g, '$1 $2 $3').replace(/-/g, '−'); }
    function partial(l) {
      if (l === 0) return '0';
      if (typeof l === 'number' && l === Math.round(l) && l > 0) { var a = 1, b = l; for (var q = 2; q * q <= b; q++) while (b % (q * q) === 0) { b /= q * q; a *= q; } return b === 1 ? String(a) : (a > 1 ? a : '') + '√' + b; }
      return /sqrt/.test(String(l)) ? '√(' + pretty(l) + ')' : '√' + pretty(l); }
    function hz(lam) { return F0 * Math.sqrt(lam); }   // one mapping, the dual bells': f = 220 Hz x sqrt(lambda) / sqrt(2)
    function spec(a) { return a.map(function (p) { return pretty(p[0]) + ' ×' + p[1]; }).join(', '); }
    function sub(k) { return '₀₁₂₃₄₅₆₇₈₉'[k]; }
    function foot() {
      var p = kit.panel_(root, 'exp.common.see', S, 'span');
      kit.line(p, P + 'see', S);
      p.appendChild(el('h3', { 'data-s': 'exp.common.hear', text: S('exp.common.hear') })); kit.line(p, P + 'hear', S);
      p.appendChild(el('p', { class: 'exp-source' }, [el('b', { 'data-s': 'exp.common.data', text: S('exp.common.data') }), ' · ', el('span', { 'data-s': P + 'data', text: S(P + 'data') })]));
    }
    function spread(ys, gap, lo, hi) {   // labels pushed apart, top to bottom
      var o = ys.map(function (y, i) { return i; }).sort(function (a, b) { return ys[a] - ys[b]; }), out = ys.slice(), k;
      for (k = 0; k < o.length; k++) out[o[k]] = Math.max(ys[o[k]], k ? out[o[k - 1]] + gap : lo);
      for (k = o.length - 1; k >= 0; k--) if (out[o[k]] > hi - (o.length - 1 - k) * gap) out[o[k]] = hi - (o.length - 1 - k) * gap;
      return out;
    }
    // ------------------------------------------------------------ sound: one at a time; the sounding button reads Mute
    var SND = null, noAudio = null, timer = 0;
    function setBtn(b, on) { var id = on ? 'exp.common.mute' : b._sid; b.textContent = S(id); b.setAttribute('data-s', id); b.setAttribute('aria-pressed', String(on)); }
    function stopSnd() { if (SND) { SND.tones.forEach(function (t) { t.stop(); }); setBtn(SND.btn, false); clearTimeout(timer); SND = null; } }
    function start(btn, kind, groups) {   // groups: [{at, parts: [{f, a}]}]; each tone 0.28 x a / (sum of a in its group)
      stopSnd(); var a = kit.audio(); if (!a) { if (!noAudio) noAudio = kit.line(root, 'exp.common.noaudio', S); return; }
      var tones = [], end = 0;
      groups.forEach(function (g) {
        var tot = g.parts.reduce(function (s, p) { return s + p.a; }, 0); end = Math.max(end, g.at);
        g.parts.forEach(function (p) { tones.push(kit.tone({ f: p.f, gain: 0.28 * p.a / tot, decay: DECAY, maxDur: 7, at: 0.01 + g.at })); });
      });
      SND = { btn: btn, kind: kind, tones: tones, t0: performance.now() }; setBtn(btn, true);
      timer = setTimeout(function () { if (SND && SND.btn === btn) stopSnd(); }, (end + 7.1) * 1000);
    }
    function btn(parent, id, kind, build) { var b = kit.button(parent, id, S, function () { if (SND && SND.btn === b) { stopSnd(); return; } start(b, kind, build()); }); b._sid = id; return b; }
    function again(b, build) { if (SND && SND.btn === b) start(b, SND.kind, build()); }
    function ofSpec(a, n) { return a.filter(function (p) { return surd(p[0]) > 1e-9; }).map(function (p) { return { f: hz(surd(p[0])), a: p[1] / n }; }); }   // multiplicity over the vertices, the rows' rule
    function ofW(a) { return a.filter(function (p) { return surd(p[1]) > 1e-9; }).map(function (p) { return { f: hz(surd(p[1])), a: frac(p[0]) }; }); }   // [weight, lambda] pairs
    // ------------------------------------------------------------ 4D kinematics: a double rotation, dropped to 3D, a fixed tilt, a little perspective
    function rot(x, i, j, a) { var c = Math.cos(a), s = Math.sin(a), xi = x[i], xj = x[j]; x[i] = c * xi - s * xj; x[j] = s * xi + c * xj; }
    function norm(V) { var r = 0; V.forEach(function (v) { var s = 0; v.forEach(function (x) { s += x * x; }); r = Math.max(r, Math.sqrt(s)); }); return r; }
    function turn4(V, a, Rm) {
      return V.map(function (v) {
        var x = v.slice(); while (x.length < 4) x.push(0);
        rot(x, 0, 3, a); rot(x, 1, 2, 0.618 * a); rot(x, 0, 2, 0.45); rot(x, 1, 2, 0.3);
        var p = 3.2 * Rm / (3.2 * Rm - x[2]); return [x[0] * p, x[1] * p, x[2] / Rm];
      });
    }
    function wire(c, X, E, ox, oy, sc, color, lw, hi) {   // edges with depth shading; hi(e) → colour for highlighted edges
      E.forEach(function (e) {
        var a = X[e[0]], b = X[e[1]], h = hi ? hi(e) : null;
        c.globalAlpha = h ? 1 : 0.25 + 0.55 * ((a[2] + b[2]) / 2 + 1) / 2; c.strokeStyle = h || color; c.lineWidth = h ? 2.4 : lw;
        c.beginPath(); c.moveTo(ox + a[0] * sc, oy - a[1] * sc); c.lineTo(ox + b[0] * sc, oy - b[1] * sc); c.stroke();
      });
      c.globalAlpha = 1;
    }

    // ================================================================ (i) the tesseract and its cells
    var p1 = kit.panel_(root, P + 'panel.tesseract', S), g1 = grid(p1);
    var cT = cv(g1, 0.62, 380), cL = cv(g1, 0.62, 380), k1 = kit.controls(p1);
    var RT = norm(T.vertices4d), R16 = norm(C16.vertices4d);
    var cellInfo = T.cells.map(function (cell) {   // the fixed coordinate of the cell and the 16-cell's corner in its direction
      var a = 0, s = 0, m = [0, 0, 0, 0];
      cell.forEach(function (i) { T.vertices4d[i].forEach(function (x, k) { m[k] += x / cell.length; }); });
      m.forEach(function (x, k) { if (Math.abs(x) > Math.abs(m[a])) a = k; }); s = m[a] > 0 ? 1 : -1;
      var best = 0, bd = -1e9; C16.vertices4d.forEach(function (v, j) { var d = 0; v.forEach(function (x, k) { d += x * m[k]; }); if (d > bd) { bd = d; best = j; } });
      var set = {}; cell.forEach(function (i) { set[i] = 1; });
      return { a: a, s: s, v: best, set: set };
    });
    var STR = [
      { id: 'b.vertex', parts: function () { return ofSpec(T.spectra.L0, T.V); }, w: function () { return T.spectra.L0.filter(function (p) { return p[0]; }).map(function (p) { return p[1] + '/' + T.V; }); }, l: function () { return T.spectra.L0.filter(function (p) { return p[0]; }).map(function (p) { return p[0]; }); } },
      { id: 'b.edge', parts: function () { return ofW(T.edge_pluck_weights); }, w: function () { return T.edge_pluck_weights.map(function (p) { return p[0]; }); }, l: function () { return T.edge_pluck_weights.map(function (p) { return p[1]; }); } },
      { id: 'b.square', parts: function () { return ofW(T.face_pluck_weights); }, w: function () { return T.face_pluck_weights.map(function (p) { return p[0]; }); }, l: function () { return T.face_pluck_weights.map(function (p) { return p[1]; }); } },
      { id: 'b.c16', parts: function () { return ofSpec(C16.spectra.L0, C16.vertices4d.length); }, w: function () { return C16.spectra.L0.filter(function (p) { return p[0]; }).map(function (p) { return p[1] + '/' + C16.vertices4d.length; }); }, l: function () { return C16.spectra.L0.filter(function (p) { return p[0]; }).map(function (p) { return p[0]; }); } }
    ];
    STR.forEach(function (q) { btn(k1, P + q.id, 'tess', function () { return [{ at: 0, parts: q.parts() }]; }); });
    var pauseB = kit.button(k1, 'exp.common.pause', S, function () { st.paused = !st.paused; pauseB.setAttribute('aria-pressed', String(st.paused)); }); pauseB.setAttribute('aria-pressed', String(st.paused));
    var k1b = kit.controls(p1);
    kit.slider(k1b, { S: S, id: P + 'cell', min: 1, max: T.cells.length, step: 1, value: 1, fmt: function (v) { var q = cellInfo[v - 1]; return v + ' · x' + sub(q.a + 1) + ' = ' + (q.s > 0 ? '+1' : '−1'); }, onchange: function (v) { st.cell = v - 1; readT(); } });
    var rT = [0, 1, 2, 3, 4, 5, 6, 7].map(function () { return kit.readout(p1); });
    kit.line(p1, P + 'ident', S); kit.line(p1, P + 'cap.tess', S);
    function readT() {
      var q = cellInfo[st.cell], v = C16.vertices4d[q.v], k = v.reduce(function (b, x, i) { return Math.abs(x) > Math.abs(v[b]) ? i : b; }, 0);
      rT[0].textContent = R('rd.counts', { V: T.V, E: T.E, F: T.F, C: T.C });
      rT[1].textContent = R('rd.betti', { r: T.ranks.join(', '), b: '(' + T.betti.join(', ') + ')' });
      rT[2].textContent = R('rd.c16', { s: [0, 1, 2, 3].map(function (j) { var eq = JSON.stringify(C16.spectra['L' + j]) === JSON.stringify(T.spectra['L' + (3 - j)]); return R(eq ? 'rd.eq' : 'rd.neq', { k: sub(j), j: sub(3 - j) }) + ' (' + spec(C16.spectra['L' + j]) + ')'; }).join(' · ') });
      rT[3].textContent = R('rd.cell', { i: st.cell + 1, n: T.cells.length, a: sub(q.a + 1), s: q.s > 0 ? '+1' : '−1', v: (v[k] > 0 ? '+' : '−') + 'e' + sub(k + 1) });
      STR.forEach(function (s, i) { var L = s.l(); rT[4 + i].textContent = R('rd.strike', { n: S(P + s.id), w: s.w().join(', '), l: L.join(', '), f: L.map(function (x) { return kit.num(hz(surd(x)), 1); }).join(', ') }); });
    }
    function drawTess() {
      var c = cT.ctx, w = cT.w, h = cT.h, a = st.t * 0.3, q = cellInfo[st.cell], acc = kit.accent(), ink = kit.ink();
      c.clearRect(0, 0, w, h);
      var X = turn4(T.vertices4d, a, RT), ox = w * 0.32, oy = h * 0.5, sc = Math.min(w * 0.28, h * 0.45) / (RT * 1.05);
      wire(c, X, T.edges, ox, oy, sc, kit.blue, 1.1, function (e) { return q.set[e[0]] && q.set[e[1]] ? acc : null; });
      X.forEach(function (p, i) { var on = q.set[i]; c.fillStyle = on ? acc : ink; c.beginPath(); c.arc(ox + p[0] * sc, oy - p[1] * sc, on ? 3.6 : 2.2, 0, TAU); c.fill(); });
      var Y = turn4(C16.vertices4d, a, R16), ox2 = w * 0.79, sc2 = Math.min(w * 0.15, h * 0.34) / (R16 * 1.05);
      wire(c, Y, C16.edges, ox2, oy, sc2, kit.violet, 1, null);
      Y.forEach(function (p, i) { var on = i === q.v; c.fillStyle = on ? acc : kit.violet; c.beginPath(); c.arc(ox2 + p[0] * sc2, oy - p[1] * sc2, on ? 6 : 2.6, 0, TAU); c.fill(); });
      txt(c, S(P + 'cv.tess'), 8, 16, ink, 'left', 12, true); txt(c, S(P + 'cv.c16'), w * 0.64, 16, kit.violet, 'left', 12, true);
      txt(c, S(P + 'cv.proj'), 8, h - 8, kit.muted(), 'left', 10);
    }
    function drawLadders() {
      var c = cL.ctx, w = cL.w, h = cL.h, top = 30, bot = h - 34, x0 = 54, xr = w - 14, mx = 0, k;
      c.clearRect(0, 0, w, h);
      for (k = 0; k < 4; k++) T.spectra['L' + k].forEach(function (p) { mx = Math.max(mx, p[0]); });
      var Y = function (v) { return bot - v / mx * (bot - top); }, X = function (j) { return x0 + j * (xr - x0) / 3; }, cols = [kit.blue, kit.warm(), GREEN], tk = Math.min(10, (xr - x0) / 24);
      txt(c, S(P + 'cv.lam'), 6, 14, kit.muted(), 'left', 11);
      for (k = 0; k <= mx; k += 2) txt(c, String(k), 16, Y(k) + 4, kit.muted(), 'right', 10);
      [1, 2, 3].forEach(function (j) {   // the shared parts as bands between the ladders j−1 and j
        var A = T.shared['A' + j];
        txt(c, S(P + 'cv.A' + j), (X(j - 1) + X(j)) / 2 - 14, top - 14, cols[j - 1], 'center', 12, true);
        A.forEach(function (p) {
          var y = Y(p[0]); c.fillStyle = cols[j - 1]; c.globalAlpha = 0.28; c.fillRect(X(j - 1) + tk + 3, y - 7, X(j) - X(j - 1) - 2 * tk - 34, 14); c.globalAlpha = 1;
          txt(c, '×' + p[1], (X(j - 1) + X(j)) / 2 - 14, y + 4, kit.ink(), 'center', 10);
        });
      });
      for (k = 0; k < 4; k++) {
        c.strokeStyle = kit.muted(); c.globalAlpha = 0.35; c.lineWidth = 1; c.beginPath(); c.moveTo(X(k), top - 4); c.lineTo(X(k), bot + 4); c.stroke(); c.globalAlpha = 1;
        T.spectra['L' + k].forEach(function (p) {
          var y = Y(p[0]); c.strokeStyle = kit.ink(); c.lineWidth = 2; c.beginPath(); c.moveTo(X(k) - tk, y); c.lineTo(X(k) + tk, y); c.stroke(); c.lineWidth = 1;
          txt(c, '×' + p[1], X(k) - tk - 3, y + 4, kit.ink(), 'right', 10, true);
        });
        var nm = [T.V, T.E, T.F, T.C][k], lab = R('cv.L' + k, { n: nm }), small = w < 520;
        txt(c, small ? lab.split(' · ')[0] : lab, X(k), h - 18, kit.ink(), k === 0 ? 'left' : k === 3 ? 'right' : 'center', 10, true);
        if (small) txt(c, String(nm), X(k), h - 6, kit.muted(), k === 0 ? 'left' : k === 3 ? 'right' : 'center', 10);
      }
    }

    // ================================================================ (ii) the 600-cell and the 120-cell
    var p2 = kit.panel_(root, P + 'panel.icosian', S), g2 = grid(p2);
    var c6 = cv(g2, 1, 440), cI = cv(g2, 0.95, 440), k2 = kit.controls(p2);
    var ADJ = C6.vertices4d.map(function () { return []; }); C6.edges.forEach(function (e) { ADJ[e[0]].push(e[1]); ADJ[e[1]].push(e[0]); });
    function rings(xy, tol) {   // the ring of each projected point, by its distance from the centre
      var rs = xy.map(function (p) { return Math.hypot(p[0], p[1]); }), u = rs.slice().sort(function (a, b) { return a - b; }).filter(function (r, i, a) { return !i || r - a[i - 1] > tol; });
      return { idx: rs.map(function (r) { var b = 0; u.forEach(function (x, i) { if (Math.abs(x - r) < Math.abs(u[b] - r)) b = i; }); return b; }), n: u.length, max: u[u.length - 1] };
    }
    var RG6 = rings(C6.coxeter_plane.xy, 1e-3), RG1 = rings(C1.xy, 1e-3), R6 = norm(C6.vertices4d), RINGC = ['#b23a2c', kit.warm(), GREEN, kit.blue];
    var IR = C6.irreps.filter(function (r) { return r.laplacian_float > 1e-9; });
    function build600() { return IR.map(function (r) { return { f: hz(r.laplacian_float), a: frac(r.weight) }; }); }
    var ROOTS = []; C1.factors.forEach(function (f, fi) { f.roots_float.forEach(function (x, ri) { ROOTS.push({ l: x, w: frac(f.weight), wS: f.weight, field: f.field, fi: fi, c: f.cents[ri] }); }); });
    function build120() { return ROOTS.filter(function (r) { return r.l > 1e-9; }).map(function (r) { return { f: hz(r.l), a: r.w }; }); }
    btn(k2, 'exp.common.play', 'icosian', function () { return [{ at: 0, parts: build600() }]; });
    btn(k2, P + 'b.c120', 'icosian', function () { return [{ at: 0, parts: build120() }]; });
    btn(k2, P + 'b.both', 'icosian', function () { return [{ at: 0, parts: build600() }, { at: 2.2, parts: build120() }]; });
    kit.seg(k2, { S: S, ids: [P + 'seg.plane', P + 'seg.turn'], values: ['plane', 'turn'], value: st.cox, onchange: function (v) { st.cox = v; } });
    kit.slider(k2, { S: S, id: P + 'v600', min: 1, max: C6.vertices4d.length, step: 1, value: 1, fmt: function (v) { return String(v); }, onchange: function (v) { st.v600 = v - 1; read6(); } });
    var r6 = [kit.readout(p2), kit.readout(p2)]; kit.line(p2, P + 'plancherel', S);
    var g2b = grid(p2), c12 = cv(g2b, 1, 440), cJ = cv(g2b, 0.95, 440), r12 = kit.readout(p2); kit.line(p2, P + 'cap.icosian', S);
    function read6() {
      r6[0].textContent = R('rd.v600', { i: st.v600 + 1, n: ADJ[st.v600].length });
      var lo = IR.reduce(function (a, r) { return r.laplacian_float < a.laplacian_float ? r : a; }), ld = IR.reduce(function (a, r) { return frac(r.weight) > frac(a.weight) ? r : a; });
      r6[1].textContent = R('rd.c600', { n: C6.irreps.length, a: kit.num(hz(lo.laplacian_float), 1), b: kit.num(hz(ld.laplacian_float), 1), w: ld.weight, k: kit.num(ld.cents, 3) });
      var nz = ROOTS.filter(function (r) { return r.l > 1e-9; }), lo1 = nz.reduce(function (a, r) { return r.l < a.l ? r : a; }), mw = Math.max.apply(null, nz.map(function (r) { return r.w; }));
      var loud = nz.filter(function (r) { return r.w === mw; });
      r12.textContent = R('rd.cert', { n: C1.factors.length, d: ROOTS.length, v: C1.vertices4d.length, a: kit.num(Math.sqrt(lo1.l), 4), fa: kit.num(hz(lo1.l), 1), b: loud.map(function (r) { return kit.num(Math.sqrt(r.l), 4); }).join(' and '), w: loud[0].wS });
    }
    function drawPlane(cc, xy, E, rg, a, ptCol, edgeCol, ew, pr, hiV, hiN, X4) {
      var c = cc.ctx, w = cc.w, h = cc.h, ox = w / 2, oy = h / 2 - 6, sc = 0.45 * Math.min(w, h - 18) / rg.max, ca = Math.cos(a), sa = Math.sin(a);
      c.clearRect(0, 0, w, h);
      var Q = X4 || xy.map(function (p) { return [ca * p[0] - sa * p[1], sa * p[0] + ca * p[1], 0]; });
      if (X4) sc = 0.45 * Math.min(w, h - 18) / 1.35;
      c.strokeStyle = edgeCol; c.lineWidth = ew; c.globalAlpha = X4 ? 0.22 : 0.3; c.beginPath();
      E.forEach(function (e) { var p = Q[e[0]], q = Q[e[1]]; c.moveTo(ox + p[0] * sc, oy - p[1] * sc); c.lineTo(ox + q[0] * sc, oy - q[1] * sc); });
      c.stroke(); c.globalAlpha = 1;
      if (hiV != null) {
        c.strokeStyle = kit.accent(); c.lineWidth = 2;
        hiN.forEach(function (j) { var p = Q[hiV], q = Q[j]; c.beginPath(); c.moveTo(ox + p[0] * sc, oy - p[1] * sc); c.lineTo(ox + q[0] * sc, oy - q[1] * sc); c.stroke(); });
      }
      Q.forEach(function (p, i) { c.fillStyle = ptCol(i); c.beginPath(); c.arc(ox + p[0] * sc, oy - p[1] * sc, pr, 0, TAU); c.fill(); });
      if (hiV != null) {
        hiN.forEach(function (j) { var p = Q[j]; c.fillStyle = kit.accent(); c.beginPath(); c.arc(ox + p[0] * sc, oy - p[1] * sc, 4, 0, TAU); c.fill(); });
        var p = Q[hiV]; c.fillStyle = kit.ink(); c.beginPath(); c.arc(ox + p[0] * sc, oy - p[1] * sc, 6, 0, TAU); c.fill(); c.fillStyle = kit.accent(); c.beginPath(); c.arc(ox + p[0] * sc, oy - p[1] * sc, 3.5, 0, TAU); c.fill();
      }
    }
    function draw600() {
      var X4 = st.cox === 'turn' ? turn4(C6.vertices4d, st.t * 0.2, R6) : null;
      drawPlane(c6, C6.coxeter_plane.xy, C6.edges, RG6, st.t * 0.03, function (i) { return RINGC[RG6.idx[i] % 4]; }, kit.blue, 0.6, 2.4, st.v600, ADJ[st.v600], X4);
      txt(c6.ctx, R('cv.c600', { v: C6.vertices4d.length, e: C6.edges.length }), c6.w / 2, c6.h - 6, kit.muted(), 'center', 10);
    }
    function draw120() {
      drawPlane(c12, C1.xy, C1.edges, RG1, st.t * 0.03, function () { return '#6e1f17'; }, GREEN, 0.5, 1.5, null, null, null);
      txt(c12.ctx, R('cv.c120', { v: C1.vertices4d.length, e: C1.edges.length }), c12.w / 2, c12.h - 6, kit.muted(), 'center', 10);
    }
    function ladderAxes(c, w, h, box, mxL, mxW, xl, wticks) {
      c.clearRect(0, 0, w, h);
      return kit.axes(c, box, { xmin: 0, xmax: mxW, ymin: 0, ymax: mxL, xticks: wticks, yticks: [], xlabel: xl });
    }
    function drawIrreps() {
      var c = cI.ctx, w = cI.w, h = cI.h, mxL = Math.max.apply(null, C6.irreps.map(function (r) { return r.laplacian_float; })) * 1.06, mxW = Math.max.apply(null, C6.irreps.map(function (r) { return frac(r.weight); }));
      var narrow = w < 470, box = { l: 34, r: w - 8, t: 12, b: h - 34 }, bx = narrow ? 0.32 : 0.36;
      var ax = ladderAxes(c, w, h, box, mxL, mxW / bx, S(P + 'cv.w'), []);
      for (var v = 0; v <= mxL; v += 4) { txt(c, String(v), box.l - 5, ax.y(v) + 4, kit.muted(), 'right', 10); }
      txt(c, S(P + 'cv.lam'), 6, box.t + 8, kit.muted(), 'left', 11);
      var ys = spread(C6.irreps.map(function (r) { return ax.y(r.laplacian_float) + 3; }), 13, box.t + 8, box.b - 2), xlab = ax.x(mxW) + 10;
      C6.irreps.forEach(function (r, i) {
        var y = ax.y(r.laplacian_float), x1 = ax.x(frac(r.weight));
        c.fillStyle = r.laplacian_float > 1e-9 ? kit.blue : kit.muted(); c.fillRect(box.l + 1, y - 3.5, x1 - box.l, 7);
        c.strokeStyle = kit.muted(); c.globalAlpha = 0.5; c.lineWidth = 0.7; c.beginPath(); c.moveTo(x1 + 2, y); c.lineTo(xlab - 3, ys[i] - 3); c.stroke(); c.globalAlpha = 1;
        var o = { l: pretty(r.laplacian), d: r.dim, c: pretty(r.char), w: r.weight, k: r.cents == null ? '' : kit.num(r.cents, 3) };
        txt(c, narrow ? R(r.cents == null ? 'cv.irreps0' : 'cv.irreps', o) : R(r.cents == null ? 'cv.irrep0' : 'cv.irrep', o), xlab, ys[i], kit.ink(), 'left', narrow ? 9 : 10);
      });
    }
    var FIELDS = [], FCOL = { 'Q': '#55595a', 'Q(sqrt 5)': kit.blue, 'Q(sqrt 2)': GREEN, 'Q(sqrt 13)': kit.violet, 'Q(sqrt 21)': '#c8822a' }, XC = ['#c24a3a', '#7a2219'];
    C1.factors.forEach(function (f) { if (FIELDS.indexOf(f.field) < 0) FIELDS.push(f.field); });
    FIELDS.forEach(function (f) { if (!FCOL[f]) FCOL[f] = XC.shift() || kit.muted(); });
    function fieldName(f) { var m = String(f).match(/^cubic, discriminant (\d+)$/); return m ? R('cv.cubic', { d: m[1] }) : pretty(f); }
    function drawRoots() {
      var c = cJ.ctx, w = cJ.w, h = cJ.h, mxL = Math.ceil(Math.max.apply(null, ROOTS.map(function (r) { return r.l; })) + 0.5), mxW = Math.max.apply(null, ROOTS.map(function (r) { return r.w; }));
      var box = { l: 34, r: w - 8, t: 12, b: h - 34 }, ax = ladderAxes(c, w, h, box, mxL, mxW / 0.62, S(P + 'cv.wroot'), []);
      for (var v = 0; v <= mxL; v++) txt(c, String(v), box.l - 5, ax.y(v) + 4, kit.muted(), 'right', 10);
      txt(c, S(P + 'cv.lam'), 6, box.t + 8, kit.muted(), 'left', 11);
      var bh = Math.max(2.5, Math.min(6, (box.b - box.t) / mxL / 6));
      ROOTS.forEach(function (r) { c.fillStyle = FCOL[r.field]; c.fillRect(box.l + 1, ax.y(r.l) - bh / 2, Math.max(1.5, ax.x(r.w) - box.l), bh); });
      var lx = ax.x(mxW) + 12, ly = box.t + 12;
      FIELDS.forEach(function (f, i) { c.fillStyle = FCOL[f]; c.fillRect(lx, ly + i * 15 - 8, 9, 9); txt(c, fieldName(f), lx + 13, ly + i * 15, kit.ink(), 'left', w < 470 ? 9 : 10); });
    }

    // ================================================================ (iii) the column of octahedra
    var p3 = kit.panel_(root, P + 'panel.column', S), g3 = grid(p3);
    var cC = cv(g3, 1.0, 360), cB = cv(g3, 0.72, 360), k3 = kit.controls(p3), k3b = kit.controls(p3);
    var CV = CO.coords3d.vertices, CE = CO.coords3d.edges, zmax = Math.max.apply(null, CV.map(function (v) { return v[2]; }));
    function sectors(N) {   // the sector of each level from its multiplicity: an odd count holds one symmetric level, the rest are twisting pairs
      var sym = [], tw = [];
      CO.spectra[String(N)].forEach(function (p) { if (p[1] % 2) sym.push(p[0]); for (var k = 0; k < (p[1] >> 1); k++) tw.push(p[0]); });
      return { sym: sym, tw: tw.filter(function (x, i, a) { return a.indexOf(x) === i; }), twAll: tw };
    }
    var MODES = []; CO.spectra[String(CO.coords3d.N)].forEach(function (p) { for (var k = 0; k < p[1]; k++) MODES.push({ l: p[0], s: (p[1] % 2 && k === 0) ? 'sym' : 'tw' }); });
    function buildCol() {
      var q = sectors(CO.coords3d.N), sy = q.sym.filter(function (x) { return x > 1e-9; }), a = frac(CO.sector_share.sym) / sy.length, b = frac(CO.sector_share.twist) / q.tw.length;
      return [{ at: 0, parts: sy.map(function (x) { return { f: hz(x), a: a }; }).concat(q.tw.map(function (x) { return { f: hz(x), a: b }; })) }];
    }
    function buildChain() { return [{ at: 0, parts: sectors(CO.coords3d.N).sym.filter(function (x) { return x > 1e-9; }).map(function (x) { return { f: hz(x), a: 1 }; }) }]; }
    btn(k3, 'exp.common.play', 'column', buildCol); btn(k3, P + 'b.chain', 'column', buildChain);
    kit.seg(k3, { S: S, ids: [P + 'seg.sym', P + 'seg.twist'], values: ['sym', 'tw'], value: st.sec, onchange: function (v) { st.sec = v; } });
    kit.slider(k3b, { S: S, id: P + 'mode', min: 1, max: MODES.length, step: 1, value: 1, fmt: function (v) { return v + ' / ' + MODES.length; }, onchange: function (v) { st.mode = v - 1; st.sec = MODES[v - 1].s; segSync(); readC(); } });
    kit.slider(k3b, { S: S, id: P + 'N', min: CO.N[0], max: CO.N[CO.N.length - 1], step: 1, value: st.N, fmt: function (v) { return String(v); }, onchange: function (v) { st.N = v; readC(); } });
    function segSync() { Array.prototype.forEach.call(k3.querySelectorAll('.exp-seg button'), function (b, i) { b.setAttribute('aria-checked', String((i === 0) === (st.sec === 'sym'))); }); }
    var cPl = cv(p3, 0.4, 220), rC = [0, 1, 2, 3, 4, 5].map(function () { return kit.readout(p3); }); kit.line(p3, P + 'cap.column', S);
    var TMAX = CO.pluck_N20.t[CO.pluck_N20.t.length - 1], PLK = CO.pluck_N20.t.map(function (t, i) { return [t, CO.pluck_N20.x[i]]; });
    function readC() {
      var m = MODES[st.mode], q = sectors(st.N), B = CO.bands;
      rC[0].textContent = R('rd.mode', { i: st.mode + 1, n: MODES.length, l: kit.num(m.l, 4), s: S(P + (m.s === 'sym' ? 'seg.sym' : 'seg.twist')), p: kit.num(Math.sqrt(m.l), 4), f: kit.num(hz(m.l), 1) });
      rC[1].textContent = R('rd.levels', { n: st.N, s: q.sym.length, t: q.tw.length });
      rC[2].textContent = R('rd.shares', { a: CO.sector_share.sym, b: CO.sector_share.twist, r: kit.num(Math.sqrt(B.sym[1] / CO.chain_band[1]), 4) });
      ['6', '20'].forEach(function (n, i) { var e = CO.end_modes[n]; if (e) rC[3 + i].textContent = R('rd.end', { n: n, l: e.eigenvalues.map(function (x) { return kit.num(x, 6); }).join(', '), w: kit.sci(e.middle_weight, 3) }); });
      rC[5].textContent = S('exp.common.slowed').replace('{n}', kit.num(Math.round(SWEEP * TAU * F0 / TMAX), 0));
    }
    function drawColumn() {
      var c = cC.ctx, w = cC.w, h = cC.h, a = st.t * 0.4, ph = st.t * 2.2, sc = (h - 40) / (zmax + 2.2), ox = w / 2, oy = h - 22 - sc * 1.1, ink = kit.ink();
      c.clearRect(0, 0, w, h);
      var col = st.sec === 'sym' ? kit.blue : kit.warm(), ca = Math.cos(a), sa = Math.sin(a);
      var X = CV.map(function (v) { var x = ca * v[0] - sa * v[1], y = sa * v[0] + ca * v[1]; return [ox + x * sc * (1 + 0.08 * y), oy - v[2] * sc + y * sc * 0.18, y]; });
      CE.forEach(function (e) {
        var A = X[e[0]], B = X[e[1]], flat = Math.abs(CV[e[0]][2] - CV[e[1]][2]) < 1e-6;
        c.globalAlpha = 0.35 + 0.5 * ((A[2] + B[2]) / 2 + 1) / 2; c.strokeStyle = flat ? col : kit.muted(); c.lineWidth = flat ? 1.8 : 1;
        c.beginPath(); c.moveTo(A[0], A[1]); c.lineTo(B[0], B[1]); c.stroke();
      });
      c.globalAlpha = 1;
      X.forEach(function (p, i) {   // the sector's character on a triangle: alike, or turned by a third (an illustration, not a mode)
        var th = Math.atan2(CV[i][1], CV[i][0]), r = 3.4 + 2.2 * Math.cos(ph - (st.sec === 'sym' ? 0 : th));
        c.fillStyle = col; c.beginPath(); c.arc(p[0], p[1], Math.max(1.2, r), 0, TAU); c.fill();
      });
      txt(c, S(P + (st.sec === 'sym' ? 'cv.colsym' : 'cv.coltw')), 8, 16, col, 'left', 11, true);
      txt(c, 'N = ' + CO.coords3d.N, 8, h - 8, kit.muted(), 'left', 10);
    }
    function drawBands() {
      var c = cB.ctx, w = cB.w, h = cB.h, B = CO.bands, ymax = Math.ceil(Math.max.apply(null, B.twist_plus.concat(B.twist_minus, B.sym))) + (w < 470 ? 3 : 2), nw = w < 470, split = nw ? 0.6 : 0.72;
      var box = { l: 30, r: w * split, t: 22, b: h - 34 }; c.clearRect(0, 0, w, h);
      var ax = kit.axes(c, box, { xmin: 0, xmax: B.k[B.k.length - 1], ymin: 0, ymax: ymax, xticks: [], yticks: [0, 2, 4, 6, 8, 10].filter(function (v) { return v <= ymax; }), xlabel: S(P + 'cv.k') });
      [[0, '0'], [B.k[B.k.length - 1] / 2, 'π/2'], [B.k[B.k.length - 1], 'π']].forEach(function (q) { txt(c, q[1], ax.x(q[0]), box.b + 13, kit.muted(), 'center', 10); });
      var pts = function (y) { return B.k.map(function (k, i) { return [k, y[i]]; }); }, tw = B.twist_plus.concat(B.twist_minus), tlo = Math.min.apply(null, tw), thi = Math.max.apply(null, tw);
      var y45 = (CO.end_modes['20'].eigenvalues[0] + CO.end_modes['20'].eigenvalues[1]) / 2;
      c.save(); c.beginPath(); c.rect(box.l, box.t, box.r - box.l, box.b - box.t); c.clip();
      kit.curve(c, pts(CO.chain_band), ax.x, ax.y, kit.muted(), 1.4, [4, 3]);
      kit.curve(c, pts(B.sym), ax.x, ax.y, kit.blue, 2); kit.curve(c, pts(B.twist_plus), ax.x, ax.y, kit.warm(), 2); kit.curve(c, pts(B.twist_minus), ax.x, ax.y, kit.warm(), 2, [6, 3]);
      c.strokeStyle = kit.red; c.setLineDash([2, 3]); c.beginPath(); c.moveTo(box.l, ax.y(y45)); c.lineTo(w - 6, ax.y(y45)); c.stroke(); c.setLineDash([]);
      var m = MODES[st.mode]; c.strokeStyle = kit.accent(); c.lineWidth = 1.5; c.beginPath(); c.moveTo(box.l, ax.y(m.l)); c.lineTo(box.r, ax.y(m.l)); c.stroke(); c.lineWidth = 1;
      c.restore();
      [['cv.sym', kit.blue, []], ['cv.tw', kit.warm(), []], ['cv.chain', kit.muted(), [4, 3]]].forEach(function (q, i) {
        var y = box.t + 6 + i * 13; c.strokeStyle = q[1]; c.setLineDash(q[2]); c.lineWidth = 2; c.beginPath(); c.moveTo(box.l + 6, y - 3); c.lineTo(box.l + 22, y - 3); c.stroke(); c.setLineDash([]); c.lineWidth = 1;
        txt(c, S(P + q[0]), box.l + 26, y, kit.ink(), 'left', w < 470 ? 8.5 : 10);
      });
      txt(c, S(P + 'cv.end'), box.l + 4, ax.y(y45) - 5, kit.red, 'left', nw ? 9 : 10);
      // the levels at N, by sector
      var q = sectors(st.N), xs = box.r + (w - box.r) * 0.3, xt = box.r + (w - box.r) * 0.72;
      txt(c, R('cv.byN', { n: st.N }), w - 4, 12, kit.ink(), 'right', nw ? 8.5 : 10, true);
      c.fillStyle = kit.warm(); c.globalAlpha = 0.14; c.fillRect(xt - 10, ax.y(thi), 20, ax.y(tlo) - ax.y(thi)); c.globalAlpha = 1;
      var hit = st.N === CO.coords3d.N ? m : null;
      [[q.sym, xs, kit.blue, 'sym'], [q.tw, xt, kit.warm(), 'tw']].forEach(function (g) {
        var prev = -9, off = 0;
        g[0].forEach(function (x) {
          off = Math.abs(ax.y(x) - ax.y(prev)) < 6 ? (off ? 0 : 8) : 0; prev = x; var gx = g[1] + off;
          var end = g[3] === 'tw' && x < tlo - 1e-9; c.fillStyle = end ? kit.red : g[2]; c.beginPath(); c.arc(gx, ax.y(x), 3.6, 0, TAU); c.fill();
          if (hit && hit.s === g[3] && Math.abs(hit.l - x) < 1e-9) { c.strokeStyle = kit.accent(); c.lineWidth = 2; c.beginPath(); c.arc(gx, ax.y(x), 7, 0, TAU); c.stroke(); c.lineWidth = 1; }
        });
        txt(c, S(P + (g[3] === 'sym' ? 'seg.sym' : 'seg.twist')) + (g[3] === 'tw' ? ' ×2' : ''), g[1], box.b + (nw && g[3] === 'tw' ? 24 : 13), kit.muted(), 'center', nw ? 8.5 : 10);
      });
    }
    function drawPluckC() {
      var c = cPl.ctx, w = cPl.w, h = cPl.h, box = { l: 44, r: w - 10, t: 8, b: h - 30 }; c.clearRect(0, 0, w, h);
      var ylo = Math.min.apply(null, CO.pluck_N20.x), ax = kit.axes(c, box, { xmin: 0, xmax: TMAX, ymin: Math.floor(ylo * 10) / 10, ymax: 1.05, xticks: [0, TMAX / 3, 2 * TMAX / 3, TMAX].map(function (v) { return Math.round(v); }), yticks: [-0.5, 0, 0.5, 1].filter(function (v) { return v >= ylo; }), xlabel: S(P + 'cv.t'), ylabel: S(P + 'cv.x') });
      kit.curve(c, PLK, ax.x, ax.y, kit.accent(), 1.6);
      if (SND && SND.kind === 'column') {
        var tc = ((performance.now() - SND.t0) / 1000 / SWEEP * TMAX) % TMAX, v = kit.interp(PLK, tc);
        c.strokeStyle = kit.warm(); c.lineWidth = 1.2; c.beginPath(); c.moveTo(ax.x(tc), box.t); c.lineTo(ax.x(tc), box.b); c.stroke();
        if (v != null) { c.fillStyle = kit.warm(); c.beginPath(); c.arc(ax.x(tc), ax.y(v), 4, 0, TAU); c.fill(); }
      }
    }

    // ================================================================ (iv) the π-flux on triangles
    var p4 = kit.panel_(root, P + 'panel.flux', S), g4 = grid(p4);
    var cF = cv(g4, 0.85, 340), cG = cv(g4, 0.85, 340), k4 = kit.controls(p4);
    var FBY = {}; FL.solids.forEach(function (s) { FBY[s.name] = s; });
    var GEO = (function () {   // the corners, written here in the data's numbering (its edges are the pairs at the shortest distance)
      var ic = [[0, 0, 1], [0, 0, -1]], h = 1 / Math.sqrt(5), r = 2 / Math.sqrt(5), j;
      for (j = 0; j < 5; j++) ic.push([r * Math.cos(TAU * j / 5), r * Math.sin(TAU * j / 5), h]);
      for (j = 0; j < 5; j++) ic.push([r * Math.cos(TAU * j / 5 - Math.PI / 5), r * Math.sin(TAU * j / 5 - Math.PI / 5), -h]);
      var cu = []; for (j = 0; j < 8; j++) cu.push([(j & 1) * 2 - 1, (j >> 1 & 1) * 2 - 1, (j >> 2 & 1) * 2 - 1]);
      return { tetrahedron: [[1, 1, 1], [1, -1, -1], [-1, 1, -1], [-1, -1, 1]], octahedron: [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]], icosahedron: ic, cube: cu };
    })();
    function gcd(a, b) { return b ? gcd(b, a % b) : a; }
    function plainW(s) { var V = GEO[s.name].length; return s.unsigned_spectrum.map(function (p) { var g = gcd(p[1], V); return [(p[1] / g) + '/' + (V / g), p[0]]; }); }   // multiplicity over V, the rows' rule
    function buildFlux() { var s = FBY[st.fx]; return [{ at: 0, parts: ofW(plainW(s)) }, { at: 1.2, parts: ofW(s.weights) }]; }
    var playF = btn(k4, 'exp.common.play', 'flux', buildFlux);
    var FN = FL.solids.map(function (s) { return s.name; });
    kit.seg(k4, { S: S, ids: FN.map(function (n) { return P + 'sol.' + n; }), values: FN, value: st.fx, onchange: function (v) { st.fx = v; readF(); again(playF, buildFlux); } });
    var rF = [kit.readout(p4), kit.readout(p4), kit.readout(p4)], a2line = kit.line(p4, P + 'a2', S); kit.line(p4, P + 'cap.flux', S);
    function readF() {
      var s = FBY[st.fx], sw = FL.switching_to_all_negative[s.name];
      rF[0].textContent = R('rd.neg', { n: s.negative_edges.length, e: s.edges.length, s: s.A2_is_scalar ? '✓' : '✗' });
      rF[1].textContent = sw ? R('rd.switch', { v: sw.map(function (x, i) { return x ? i : null; }).filter(function (x) { return x != null; }).join(', ') }) : S(P + 'rd.noswitch');
      rF[2].textContent = s.partials_cents.length ? R('rd.cents', { c: s.partials_cents.map(function (x) { return kit.num(x, 3); }).join(', ') }) : '';
      rF[2].style.display = s.partials_cents.length ? '' : 'none'; a2line.style.display = s.A2_is_scalar ? '' : 'none';
    }
    function drawFluxWire() {
      var c = cF.ctx, w = cF.w, h = cF.h, s = FBY[st.fx], V = GEO[s.name], a = st.t * 0.45, neg = {};
      s.negative_edges.forEach(function (i) { neg[i] = 1; }); c.clearRect(0, 0, w, h);
      var Rm = norm(V), sc = 0.42 * Math.min(w, h) / Rm, X = V.map(function (v) { var x = v.slice(); rot(x, 0, 1, a); rot(x, 1, 2, 0.5); rot(x, 0, 2, 0.25); var p = 4 * Rm / (4 * Rm - x[2]); return [w / 2 + x[0] * sc * p, h / 2 - x[1] * sc * p, x[2] / Rm]; });
      s.edges.forEach(function (e, i) {
        var A = X[e[0]], B = X[e[1]], n = neg[i]; c.globalAlpha = (n ? 0.55 : 0.3) + 0.45 * ((A[2] + B[2]) / 2 + 1) / 2;
        c.strokeStyle = n ? kit.red : kit.ink(); c.lineWidth = n ? 2.6 : 1.2; c.beginPath(); c.moveTo(A[0], A[1]); c.lineTo(B[0], B[1]); c.stroke();
      });
      c.globalAlpha = 1; X.forEach(function (p) { c.fillStyle = kit.ink(); c.beginPath(); c.arc(p[0], p[1], 3, 0, TAU); c.fill(); });
      txt(c, S(P + 'sol.' + s.name), 8, 16, kit.ink(), 'left', 12, true);
    }
    function drawFluxLadders() {
      var c = cG.ctx, w = cG.w, h = cG.h, s = FBY[st.fx], top = 34, bot = h - 16, mid = w / 2, bm = w * 0.2;
      var L = plainW(s), Rr = s.weights, mx = Math.max.apply(null, L.concat(Rr).map(function (p) { return Math.sqrt(surd(p[1])); })), mw = Math.max.apply(null, L.concat(Rr).map(function (p) { return frac(p[0]); }));
      var Y = function (lam) { return bot - Math.sqrt(surd(lam)) / (mx * 1.05) * (bot - top); };
      c.clearRect(0, 0, w, h);
      c.strokeStyle = kit.ink(); c.lineWidth = 1; c.beginPath(); c.moveTo(mid, top - 6); c.lineTo(mid, bot); c.stroke();
      txt(c, S(P + 'cv.plain'), mid - 8, 14, kit.blue, 'right', 11, true); txt(c, S(P + (s.A2_is_scalar ? 'cv.signedc' : 'cv.signed')), mid + 8, 14, kit.red, 'left', 11, true);
      [[L, -1, kit.blue], [Rr, 1, kit.red]].forEach(function (g) {
        var ys = spread(g[0].map(function (p) { return Y(p[1]); }), 14, top, bot);
        g[0].forEach(function (p, i) {
          var len = frac(p[0]) / mw * bm, y = Y(p[1]); c.fillStyle = g[2]; c.fillRect(g[1] < 0 ? mid - len : mid, y - 5, len, 10);
          txt(c, R('cv.at', { w: p[0], p: partial(p[1]) }), mid + g[1] * (len + 6), ys[i] + 4, g[2], g[1] < 0 ? 'right' : 'left', w < 360 ? 9 : 10);
        });
      });
    }

    foot();
    readT(); read6(); readC(); readF();
    kit.loop(function (t, dt) {
      if (!st.paused) st.t += dt;
      drawTess(); drawLadders(); draw600(); drawIrreps(); draw120(); drawRoots(); drawColumn(); drawBands(); drawPluckC(); drawFluxWire(); drawFluxLadders();
    });
  } };
})();
