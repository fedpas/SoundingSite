// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// build.mjs — the generator of The Sounding View, release 2: reads the Atlas (4.4.9, round 36 merged; read-only), round 37's
// pack (The bridges drilled; read-only, nothing of it merged: its rows are proposed) and the site's own tables (content/),
// and writes the static site to ../out, in English and, under out/it/, in Italian (the narrator's tables content/it/).
// Every block of text is traced: its element carries data-b (a record, an inventory, a study or a file of the pack),
// data-s (a string of content/strings.json or, on the Italian pages, content/it/strings_it.json) or data-r (a narration
// of content/it/racconto.json), and build/trace.json says where each data-b comes from, so that check.mjs can verify it.
// Formulas are set with KaTeX at build time.
// Usage: node gen/build.mjs [REPO]   (REPO: the Atlas's repository; SDV_PACK the pack; SDV_IT=off|partial|full (default full);
//                                     SDV_DATE, SDV_RELEASE override the stamp; SDV_OUT builds elsewhere; SDV_OGG the Ogg clips)
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { load, resolve, applyPart, textKey, sha, norm, GEN, SITE, PACK, firstSentence } from './lib/sources.mjs';
import { pieceRed } from './lib/study.mjs';
import { scriptsH } from './lib/scripts.mjs';
import { mdHtml, mdPlain } from './lib/md.mjs';
import { dependsOf, logGroup as packLogGroup, SCRIPTS, ITEMS } from './lib/pack.mjs';
import { loadItalian, IT_MODE } from './lib/italian.mjs';

const require = createRequire(import.meta.url);
const katex = (() => { try { return require('katex'); } catch { return require('/opt/npm-tools/node_modules/katex'); } })();
const DEFAULT_REPO = path.join(path.dirname(SITE), 'repo');
const REPO = path.resolve(process.argv[2] || process.env.SDV_ATLAS || DEFAULT_REPO);
const OUT = path.resolve(process.env.SDV_OUT || path.join(SITE, 'out'));
const BUILD = path.join(GEN, 'build');
const t0 = Date.now();
const D = load(REPO);
const P = D.pack;
const LOG = { warnings: [], katex: 0, katexFallback: [], htmlData: 0, blocks: 0, pages: [], it: { mode: IT_MODE, missingStrings: [], missingNarrations: [], stubs: [], unrendered: [] } };

const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const VERSION = { site: 'The Sounding View', release: process.env.SDV_RELEASE || '2', atlas: D.pkg.version, round: 36, atlasRun: D.run36 ? D.run36.date : null, date: process.env.SDV_DATE || today(), pack: { name: 'round37_bridges_pack', study: 'The bridges drilled', studyDate: '2026-11-02', against: D.pkg.version, standing: 'proposed, not merged' }, languages: IT_MODE === 'off' ? ['en'] : ['en', 'it'] };

// ------------------------------------------------------------------ the language of the pass
// L: the pass's language, its string table, the prefix of the shared files (../ under out/it/) and the narrations
const EN = { lang: 'en', dir: '', prefix: '', strings: D.site, racconto: new Map() };
let L = EN;
const IT = IT_MODE === 'off' ? null : loadItalian(GEN, D.site);
const esc = (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const fill = (t) => String(t).replace(/\{atlas\}/g, VERSION.atlas).replace(/\{release\}/g, VERSION.release).replace(/\{date\}/g, VERSION.date);
const USED_S = new Set();
function S(id) {
  const s = L.strings.get(id);
  if (!s) {
    if (L.lang === 'it') { LOG.it.missingStrings.push(id); const e = D.site.get(id); if (!e) throw new Error('site string missing: ' + id); return fill(e.text); }
    throw new Error('site string missing: ' + id);
  }
  USED_S.add(id);
  return fill(s.text);
}
const ss = (id, tag = 'span', cls = '') => `<${tag}${cls ? ` class="${cls}"` : ''} data-s="${id}">${esc(S(id))}</${tag}>`;
const A = (p) => `${L.prefix}${p}`; // a shared file (stylesheet, script, figure, clip, check), from the page's folder
const slug = (s) => String(s).replace(/[^A-Za-z0-9_-]+/g, '-');
// a narration of the Italian narrator at its target: on the Italian pages only; a missing one is an error of the full
// build, a visible placeholder (reported by the checker) under SDV_IT=partial
function racc(target, { tag = 'div', cls = '' } = {}) {
  if (L.lang !== 'it') return '';
  const it = L.racconto.get(target);
  L.wanted.add(target);
  if (!it) { LOG.it.missingNarrations.push(target); return IT_MODE === 'partial' ? `<${tag} class="racc racc--missing${cls ? ' ' + cls : ''}" data-r-missing="r:${esc(target)}"><code>r:${esc(target)}</code></${tag}>` : ''; }
  if (it.stub) LOG.it.stubs.push(it.id);
  L.rendered.set(target, (L.rendered.get(target) || 0) + 1);
  const paras = it.text.split(/\n\s*\n/).map((p) => `<p>${esc(norm(p))}</p>`).join('\n');
  return `<${tag} class="racc${it.stub ? ' racc--stub' : ''}${cls ? ' ' + cls : ''}" data-r="${esc(it.id)}">${paras}</${tag}>`;
}

const TRACE = [];
class Ctx {
  constructor(page) { this.page = L.dir + page; this.n = new Map(); }
  bid(base) { const b = base.replace(/[^A-Za-z0-9_.:-]/g, '_'); const k = (this.n.get(b) || 0) + 1; this.n.set(b, k); return k === 1 ? b : `${b}~${k}`; }
}
// a traced block: its text is the source's (with the declared part); the element shows exactly that text
function traced(ctx, base, source, { part = null, render = 'text' } = {}) {
  const full = resolve(D, source);
  if (full == null || full === '') throw new Error(`empty source for ${ctx.page}/${base}: ${JSON.stringify(source)}`);
  const text = applyPart(full, part);
  const blockId = ctx.bid(base);
  TRACE.push({ page: ctx.page, blockId, source, ...(part ? { part } : {}), render, text });
  LOG.blocks++;
  return { blockId, text };
}
// an element of a traced text: render 'text' (escaped), 'script' (the Atlas's inline sub- and superscripts drawn, as the
// sister site draws them), 'md' (the inventories' inline markdown), 'mdlinks' (the same, with its URLs as links),
// 'links' (URLs as links), 'lines' (the lines of a ROWS.md field, scripts drawn), 'ids' (scripts drawn, row ids linked)
function tb(ctx, tag, base, source, { part = null, cls = '', render = 'text', attrs = '', sec = null } = {}) {
  const t = traced(ctx, base, source, { part, render });
  const body = render === 'script' || render === 'md' ? scriptsH(t.text) : render === 'mdlinks' ? mdHtml(t.text, { links: true }) : render === 'links' ? linkUrls(esc(t.text))
    : render === 'lines' ? t.text.split('\n').map((l) => `<span class="ln">${scriptsH(l)}</span>`).join('\n') : render === 'ids' ? linkIds(scriptsH(t.text), sec) : render === 'refs' ? linkRefs(esc(t.text)) : esc(t.text);
  return `<${tag}${cls ? ` class="${cls}"` : ''} data-b="${t.blockId}"${attrs}>${body}</${tag}>`;
}
const URL_RE = /https?:\/\/[^\s<>()]+[^\s<>().,;:]/g;
const linkUrls = (escaped) => escaped.replace(URL_RE, (u) => `<a href="${u}" rel="noopener">${u}</a>`);
// arXiv numbers and DOIs as links (the references of the drill carry no URL)
const linkRefs = (escaped) => linkUrls(escaped).replace(/arXiv:(\d{4}\.\d{4,5})/g, (m, n) => `<a href="https://arxiv.org/abs/${n}" rel="noopener">${m}</a>`).replace(/DOI (10\.\d{4,9}\/[^\s<,;)]*[^\s<,;).])/g, (m, n) => `<a href="https://doi.org/${n}" rel="noopener">${m}</a>`);
const ID_RE = /\b([A-Z]{3,4}-[A-Z]?\d{2,3}[a-z]?)\b/g;
// the ids of rows that are on the site, as links (outside tags only)
function linkIds(html, sec) { return html.split(/(<[^>]+>)/).map((seg) => (seg.startsWith('<') ? seg : seg.replace(ID_RE, (m, id) => { const h = rowHref(id, sec); return h ? `<a class="rid" href="${h}">${id}</a>` : id; }))).join(''); }

// ------------------------------------------------------------------ KaTeX
const TEXCACHE = new Map();
function katexRender(tex, display) {
  const k = (display ? 'D' : 'I') + tex;
  if (TEXCACHE.has(k)) return TEXCACHE.get(k);
  let html;
  try { html = katex.renderToString(tex, { displayMode: display, throwOnError: true, strict: 'ignore', trust: true, output: 'htmlAndMathml' }); LOG.katex++; }
  catch (e) { LOG.katexFallback.push(tex.slice(0, 80) + ' :: ' + e.message.slice(0, 80)); html = katex.renderToString(tex, { displayMode: display, throwOnError: false, strict: 'ignore', trust: true }); }
  TEXCACHE.set(k, html);
  return html;
}
// a display of the study: its body wrapped in \htmlData{src=<the study's unit>} so that the rendered formula names its
// source in the page (data-src), the equation number (\tag) kept outside; the plain TeX stays in data-tex
function texDisplay(tex, src) {
  const m = /^([\s\S]*?)\s*(\\tag\{[^{}]*\})\s*$/.exec(tex);
  const body = m ? m[1] : tex, tag = m ? m[2] : '';
  const wrapped = `\\htmlData{src=${src}}{${body}}${tag ? ' ' + tag : ''}`;
  let html;
  try { html = katex.renderToString(wrapped, { displayMode: true, throwOnError: true, strict: 'ignore', trust: true, output: 'htmlAndMathml' }); LOG.htmlData++; LOG.katex++; }
  catch { html = katexRender(tex, true); LOG.warnings.push(`display ${src}: \\htmlData did not wrap; shown without it`); }
  html = html.replace(/(<annotation encoding="application\/x-tex">)[\s\S]*?(<\/annotation>)/, (m0, a, b) => a + esc(tex) + b);
  return `<span class="dmath" data-tex="${esc(tex)}">${html}</span>`;
}
const texInline = (tex) => `<span class="tmath" data-tex="${esc(tex)}">${katexRender(tex, false)}</span>`;

// a piece of a study as markup: its formulas set with KaTeX, its chips and its emphasis kept
const decodeH = (s) => s.replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&#(\d+);/g, (m, n) => String.fromCodePoint(+n)).replace(/&amp;/g, '&');
function studyHtml(study, red, unitId, { refs = false } = {}) {
  // the text between the markers: its inline scripts drawn (ω_k, ζ^{−k}), as the Atlas's texts are
  red = red.split(/(⟦[^⟧]*⟧)/).map((seg) => (seg.startsWith('⟦') ? seg : refs ? linkRefs(scriptsH(decodeH(seg))) : scriptsH(decodeH(seg)))).join('');
  return red
    .replace(/⟦M(\d+)⟧/g, (m, n) => { const mm = study.math[+n]; return mm.display ? texDisplay(mm.tex, unitId) : texInline(mm.tex); })
    .replace(/⟦C:([^⟧]*)⟧/g, '<span class="corr">$1</span>')
    .replace(/⟦a:([^⟧]+)⟧/g, (m, h) => `<a href="${h}" rel="noopener">`).replace(/⟦\/a⟧/g, '</a>')
    .replace(/⟦(\/?)(i|b|code|em|strong)⟧/g, '<$1$2>');
}
// table: 'study' (Music on the labels) or 'pack.study' (The bridges drilled)
function studyPiece(ctx, base, piece, tag = 'p', cls = '', table = 'study', opts = {}) {
  const study = table === 'study' ? D.study : P.study;
  const t = traced(ctx, base, { table, key: piece.unit, field: piece.sentences || null }, { render: 'study' });
  const u = study.byId.get(piece.unit);
  const isDisplay = u.kind === 'display' || u.kind === 'p.math';
  return `<${isDisplay ? 'div' : tag} class="${isDisplay ? 'sd' : 'sp'}${cls ? ' ' + cls : ''}" data-b="${t.blockId}">${studyHtml(study, pieceRed(study, piece), piece.unit, opts)}</${isDisplay ? 'div' : tag}>`;
}

// ------------------------------------------------------------------ the section model
const SECS = D.placements.order.map((id, i) => {
  const s = D.page.sections.find((x) => x.id === id);
  const chain = [...D.chains.values()].find((c) => c.section === id);
  return { id, i, n: i + 1, slug: D.placements.sections[id].slug, title: s.title, lead: s.lead, chain, place: D.placements.sections[id] };
});
const ROW_SEC = new Map();
for (const s of SECS) for (const r of s.chain.rows) ROW_SEC.set(r, s);
// a row's address: its section page (an Atlas row) or the page of the drill (a proposed row); null when it is not on the site
const rowHref = (id, fromSec) => { const s = ROW_SEC.get(id); if (s) return `${s === fromSec ? '' : s.slug + '.html'}#${id}`; if (P.rows.has(id)) return `${fromSec === 'bridges' ? '' : 'bridges.html'}#${id}`; return null; };
const rowRef = (id, fromSec) => { const h = rowHref(id, fromSec); return h ? `<a class="rid" href="${h}">${esc(id)}</a>` : `<code class="rid">${esc(id)}</code>`; };
// the figures of a section: FIGURES_INDEX.md's row column, ranges expanded; the map is the home's
function figRows(f) {
  const cell = f.row.replace(/`/g, '');
  const out = new Set();
  for (const part of cell.split(/,\s*/)) {
    const m = /^([A-Z]+)-(\d+)\s*…\s*[A-Z]+-(\d+)$/.exec(part.trim());
    if (m) { for (let k = +m[2]; k <= +m[3]; k++) out.add(`${m[1]}-${String(k).padStart(3, '0')}`); } else out.add(part.trim().replace(/\s*\(.*\)$/, ''));
  }
  return out;
}
for (const f of D.figures) { f.rows = figRows(f); f.secs = f.file === D.placements.homeFigure ? [] : SECS.filter((s) => s.chain.rows.some((r) => f.rows.has(r))); f.round = 36; }
// the drill's figures: their rows name proposed rows (and, in parentheses, the Atlas's rows they extend); each stands on the
// item whose ROWS.md proposes its first row
const BM = D.bridgesMap;
const ITEM_OF_ROW = new Map();
for (const it of P.items) for (const r of it.rows) ITEM_OF_ROW.set(r, it.item);
for (const f of P.figures) { f.rows = new Set([...f.row.matchAll(/MUS-\d{3}/g)].map((m) => m[0])); f.items = [...new Set([...f.rows].map((r) => ITEM_OF_ROW.get(r)).filter(Boolean))]; f.round = 37; }

// ------------------------------------------------------------------ the status chip
const STATUS_WORD = { computed: 'chip.computed', 'standard-recomputed': 'chip.standard-recomputed', standard: 'chip.standard', theorem: 'chip.theorem', input: 'chip.input', ours: 'chip.ours', open: 'chip.open', meta: 'chip.meta' };
function chip(ctx, id) {
  const st = D.status[id];
  const w = STATUS_WORD[st.status];
  return `<span class="chip chip--${st.status}" data-status-of="${esc(id)}" data-s="${w}">${esc(S(w))}</span>`;
}
// a proposed row's chip: the status the rule would give, with the outline "proposed"
function chipProposed(ctx, id) {
  const r = P.rows.get(id);
  const w = STATUS_WORD[r.status];
  if (!w) throw new Error(`proposed row ${id}: no chip for the status ${r.status}`);
  return `<span class="chip chip--${esc(r.status)}" data-status-of="${esc(id)}" data-s="${w}">${esc(S(w))}</span> <span class="chip chip--proposed" data-s="chip.proposed">${esc(S('chip.proposed'))}</span>`;
}

// ------------------------------------------------------------------ the shell
const SECTION_NAV = () => SECS.map((s) => `<li><a href="${s.slug}.html" title="${esc(s.title.learner)}" data-nav="${s.slug}">${s.n}</a></li>`).join('');
const PAGE_NAV = [['bridges', 'nav.bridges'], ['sounds', 'nav.sounds'], ['dictionary', 'nav.dictionary'], ['checks', 'nav.checks'], ['pictures', 'nav.pictures'], ['sources', 'nav.sources'], ['about', 'nav.about']];
const MARK = fs.readFileSync(path.join(GEN, 'figures', 'mark.svg'), 'utf8').replace(/<\?xml[^>]*>\s*/, '').replace(/<svg /, '<svg class="mark" aria-hidden="true" focusable="false" ');
function shell(ctx, { title, body, registers = false, scripts = '' }) {
  const page = ctx.page.replace(/^it\//, '');
  const cur = (p) => (page === p ? ' aria-current="page"' : '');
  const regSwitch = registers ? `<div class="seg" role="radiogroup" aria-label="${esc(S('aria.register'))}" data-switch="reg">${['story', 'research', 'atlas', 'standard'].map((r) => `<button type="button" role="radio" aria-checked="false" data-reg="${r}" data-s="reg.${r}">${esc(S('reg.' + r))}</button>`).join('')}</div>` : '';
  const langSwitch = IT ? `<nav class="lang" aria-label="${esc(S('aria.lang'))}"><a href="${L.lang === 'en' ? '' : '../'}${page}.html"${L.lang === 'en' ? ' aria-current="page"' : ''} hreflang="en" data-s="lang.en">${esc(S('lang.en'))}</a><span aria-hidden="true">·</span><a href="${L.lang === 'it' ? '' : 'it/'}${page}.html"${L.lang === 'it' ? ' aria-current="page"' : ''} hreflang="it" data-s="lang.it">${esc(S('lang.it'))}</a></nav>` : '';
  return `<!doctype html>
<html lang="${L.lang}" data-reg="story">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${esc(title)}</title>
<meta name="description" content="${esc(S('brand.sub'))}">
<script>try{var r=localStorage.getItem('sdv.reg');if(r==='story'||r==='research'||r==='atlas'||r==='standard')document.documentElement.setAttribute('data-reg',r);}catch(e){}</script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:ital,wght@0,400;0,500;0,600;1,400&family=Newsreader:ital,opsz,wght@0,6..72,400..600;1,6..72,400..500&display=swap">
<link rel="stylesheet" href="${A('katex/katex.min.css')}">
<link rel="stylesheet" href="${A('site.css')}">
<link rel="icon" href="${A('figures/mark.svg')}" type="image/svg+xml">
</head>
<body data-page="${page}" data-lang="${L.lang}">
<a class="skip" href="#main" data-s="nav.skip">${esc(S('nav.skip'))}</a>
<header class="bar"><div class="bar-in"><a class="brand" href="index.html">${MARK}<span class="brand-t"><span data-s="brand">${esc(S('brand'))}</span><span class="brand-sub" data-s="brand.sub">${esc(S('brand.sub'))}</span></span></a>${langSwitch}${regSwitch}</div>
<nav class="strip" aria-label="${esc(S('aria.pages'))}"><div class="strip-in"><ol class="steps">${SECTION_NAV().replace(`data-nav="${page}"`, `data-nav="${page}" aria-current="page"`)}</ol><ul class="pages">${PAGE_NAV.map(([p, s]) => `<li><a href="${p}.html"${cur(p)} data-s="${s}">${esc(S(s))}</a></li>`).join('')}</ul></div></nav></header>
<main id="main" class="main main--${page}">
${body}
</main>
<footer class="foot"><div class="foot-in"><nav aria-label="${esc(S('aria.pages'))}"><ul><li><a href="index.html" data-s="nav.home">${esc(S('nav.home'))}</a></li>${PAGE_NAV.map(([p, s]) => `<li><a href="${p}.html"${cur(p)} data-s="${s}">${esc(S(s))}</a></li>`).join('')}</ul></nav><p data-s="release.stamp">${esc(S('release.stamp'))}</p><p data-s="foot.licence">${esc(S('foot.licence'))}</p></div></footer>
<script src="${A('site.js')}" defer></script>${scripts}
</body>
</html>
`;
}

// a title in the four registers: Story the learner title, Research the physics title, Atlas and Standard the mathematics one
function regTitle(ctx, base, src, field, tag = 'span', cls = '') {
  const a = traced(ctx, `${base}:learner`, { ...src, field: `${field}.learner` });
  const b = traced(ctx, `${base}:phys`, { ...src, field: `${field}.phys` });
  const c = traced(ctx, `${base}:math`, { ...src, field: `${field}.math` });
  return `<${tag}${cls ? ` class="${cls}"` : ''}><span class="reg reg--story" data-b="${a.blockId}">${esc(a.text)}</span><span class="reg reg--research" data-b="${b.blockId}">${esc(b.text)}</span><span class="reg reg--atlas reg--standard" data-b="${c.blockId}">${esc(c.text)}</span></${tag}>`;
}
// on the Italian pages the three registers of records carry one line saying the records stay in English
const itNote = () => (L.lang === 'it' ? ss('it.records', 'p', 'src-line it-note') : '');

// ------------------------------------------------------------------ a row's block, in the four registers
function logGroup(script, tag) {
  // the lines of a group in a round-36 log: its heading "(n) [tag] …" and its ok / [in] lines up to the next heading
  const key = script.includes('music_sound') ? 'music_sound' : 'music_symmetry';
  const Lg = D.logs[key];
  const start = Lg.findIndex((l) => l.startsWith('(') && l.includes(`[${tag}]`));
  if (start < 0) return null;
  const lines = [];
  for (let i = start + 1; i < Lg.length; i++) { if (/^\(\d+\) \[/.test(Lg[i])) break; if (/^\s+(ok|FAIL)\s/.test(Lg[i]) || /^\s+\[in\]/.test(Lg[i])) lines.push(i + 1); }
  return { key, head: start + 1, lines };
}
const checkRecordOf = (script) => { const s = script.startsWith('checks/') ? script : 'checks/' + script; return D.checks.get(s) ? s : null; };
// a run record in one line: its date, its ok and fail counts where the record has them, its last line
function runLine(ctx, runKey, base) {
  const r = D.runs.get(runKey);
  if (!r) return '';
  const parts = [tb(ctx, 'span', `rund:${base}`, { table: 'check_runs', key: runKey, field: 'date' })];
  if (r.ok != null) parts.push(`<code>ok</code> ${tb(ctx, 'span', `runok:${base}`, { table: 'check_runs', key: runKey, field: 'ok' })}`);
  if (r.fail != null) parts.push(`<code>fail</code> ${tb(ctx, 'span', `runfail:${base}`, { table: 'check_runs', key: runKey, field: 'fail' })}`);
  if (r.lastLine) parts.push(tb(ctx, 'span', `run:${base}`, { table: 'check_runs', key: runKey, field: 'lastLine' }));
  return `<p class="ck-run">${ss('atl.run', 'span', 'k')} ${parts.join(' · ')}</p>`;
}
function checksHtml(ctx, row) {
  if (!row.evidence || !row.evidence.length) return ss('atl.nochecks', 'p', 'muted');
  return row.evidence.map((ev) => {
    const rec = checkRecordOf(ev.script);
    const idx = rec ? D.checks.get(rec).ids.findIndex((x) => x.id === ev.check) : -1;
    const stmt = idx >= 0 ? tb(ctx, 'p', `ckst:${row.id}`, { table: 'checks', key: rec, field: `ids.${idx}.statement` }, { cls: 'ck-st' }) : '';
    let lines = '';
    if (/round36/.test(ev.script)) {
      const g = logGroup(ev.script, ev.check);
      if (g) lines = `<details class="more"><summary>${ss('atl.lines')}</summary><ol class="loglines">${[g.head, ...g.lines].map((n) => tb(ctx, 'li', `log:${g.key}:${n}`, { table: 'log', key: g.key, field: String(n) }, { cls: n === g.head ? 'lh' : /^\s+\[in\]/.test(D.logs[g.key][n - 1]) ? 'in' : 'ok' })).join('')}</ol></details>`;
    }
    const runKey = rec || ev.script;
    const run = runLine(ctx, runKey, row.id);
    return `<div class="ck"><p class="ck-id"><code>${esc(ev.check)}</code> · <code>${esc(path.basename(ev.script))}</code></p>${stmt}${run}${lines}</div>`;
  }).join('');
}
function lensHtml(ctx, id) {
  const ents = D.lens.dictionary.map((e, i) => ({ e, i })).filter(({ e }) => (e.rows || []).includes(id));
  const one = (src, i, base) => `<li class="lens-i">${ss('lens.atlas', 'span', 'lt')} ${tb(ctx, 'span', `${base}a:${id}`, { table: src, key: String(i), field: 'atlas' })} ${ss('lens.music', 'span', 'lt')} ${tb(ctx, 'span', `${base}m:${id}`, { table: src, key: String(i), field: 'term' })} ${gradeHtml(ctx, `${base}g:${id}`, { table: src, key: String(i), field: 'match' }, 'span')}</li>`;
  if (ents.length) return `<h4>${ss('std.lens')}</h4><ul class="lens-l">${ents.map(({ i }) => one('lens', i, 'lens')).join('')}</ul>`;
  const rds = D.readings.map((r, i) => ({ r, i })).filter(({ r }) => r.row === id);
  if (rds.length) return `<h4>${ss('std.lens.reading')}</h4><ul class="lens-l">${rds.map(({ i }) => one('lens_readings', i, 'read')).join('')}</ul>`;
  return ss('std.nolens', 'p', 'muted');
}
function gradeHtml(ctx, base, src, tag = 'span') {
  const t = traced(ctx, base, src);
  const m = /^(exact with an input|exact|partial|analogy|none)\b([\s\S]*)$/.exec(t.text);
  const g = m ? m[1] : '';
  return `<${tag} class="grade grade--${slug(g || 'x')}" data-b="${t.blockId}">${m ? `<b>${esc(m[1])}</b>${esc(m[2])}` : esc(t.text)}</${tag}>`;
}
function rowBlock(ctx, id, sec) {
  const row = D.rows.get(id);
  const st = D.status[id];
  // the head: the id, the chip, the badge, the claim (homePhys, else the research text's first sentence)
  const research = D.texts.get(textKey(id, 'research', 'full'));
  const claim = row.homePhys ? tb(ctx, 'p', `claim:${id}`, { table: 'rows', key: id, field: 'homePhys' }, { cls: 'row-claim', render: 'script' })
    : tb(ctx, 'p', `claim:${id}`, { table: 'texts', key: textKey(id, 'research', 'full') }, { part: 'first-sentence', cls: 'row-claim', render: 'script' });
  const badge = st.badge && st.badge !== S(STATUS_WORD[st.status]) ? tb(ctx, 'span', `badge:${id}`, { table: 'status', key: id, field: 'badge' }, { cls: 'badge' }) : '';
  // Story: the study's prose, else the learner text, else the research text; on the Italian pages the narrator's telling
  let story;
  const pieces = D.storyMap.rows[id];
  if (L.lang === 'it') story = racc(`row:${id}`, { cls: 'story' });
  else if (pieces) {
    const secs = [...new Set(pieces.map((p) => p.unit.split('.')[0]))];
    const from = `<p class="src-line">${ss('blk.from.study')} ${secs.map((s) => tb(ctx, 'span', `stsec:${id}`, { table: 'study.heading', key: s }, { cls: 'src-sec' })).join(', ')}</p>`;
    story = `<div class="story">${pieces.map((p) => studyPiece(ctx, `story:${id}`, p)).join('')}</div>${from}`;
  } else if (D.texts.get(textKey(id, 'learner', 'full'))) {
    story = `<div class="story">${tb(ctx, 'div', `learner:${id}`, { table: 'texts', key: textKey(id, 'learner', 'full') }, { render: 'script', cls: 'tx' })}</div><p class="src-line">${ss('blk.from.learner')}</p>`;
  } else {
    story = `<div class="story">${tb(ctx, 'div', `story-r:${id}`, { table: 'texts', key: textKey(id, 'research', 'full') }, { render: 'script', cls: 'tx' })}</div><p class="src-line">${ss('blk.from.research')}</p>`;
  }
  const researchHtml = `${itNote()}${tb(ctx, 'div', `research:${id}`, { table: 'texts', key: textKey(id, 'research', 'full') }, { render: 'script', cls: 'tx' })}<p class="src-line">${ss('blk.research')}</p>`;
  // Atlas: the row as the Atlas holds it
  const kv = [];
  if (row.homeMath) kv.push([ss('atl.math', 'dt'), tb(ctx, 'dd', `math:${id}`, { table: 'rows', key: id, field: 'homeMath' }, { render: 'script' })]);
  if (row.homePhys) kv.push([ss('atl.phys', 'dt'), tb(ctx, 'dd', `phys:${id}`, { table: 'rows', key: id, field: 'homePhys' }, { render: 'script' })]);
  kv.push([ss('atl.kind', 'dt'), `<dd>${tb(ctx, 'span', `kind:${id}`, { table: 'rows', key: id, field: 'kind' })}${row.inputKindName ? ` · ${tb(ctx, 'span', `ikind:${id}`, { table: 'rows', key: id, field: 'inputKindName' })}` : ''}</dd>`]);
  kv.push([ss('atl.status', 'dt'), `<dd>${tb(ctx, 'span', `status:${id}`, { table: 'status', key: id, field: 'status' })}${st.badge ? ` · ${tb(ctx, 'span', `badge2:${id}`, { table: 'status', key: id, field: 'badge' })}` : ''}</dd>`]);
  if (row.cells && row.cells.length) kv.push([ss('atl.cells', 'dt'), `<dd>${row.cells.map((c, i) => tb(ctx, 'code', `cell:${id}`, { table: 'rows', key: id, field: `cells.${i}` })).join(' ')}</dd>`]);
  if (row.depends && row.depends.length) {
    const byRel = new Map();
    row.depends.forEach((d) => { if (!byRel.has(d.rel)) byRel.set(d.rel, []); byRel.get(d.rel).push(d.id); });
    kv.push([ss('atl.depends', 'dt'), `<dd>${[...byRel].map(([rel, ids]) => `${L.strings.has('dep.' + rel) ? ss('dep.' + rel, 'span', 'k') : `<code>${esc(rel)}</code>`} ${ids.map((x) => rowRef(x, sec)).join(', ')}`).join('; ')}</dd>`]);
  }
  if (row.reason && row.reason.why) kv.push([ss('atl.reason', 'dt'), tb(ctx, 'dd', `reason:${id}`, { table: 'rows', key: id, field: 'reason.why' }, { render: 'script' })]);
  kv.push([ss('atl.since', 'dt'), tb(ctx, 'dd', `since:${id}`, { table: 'rows', key: id, field: 'since' })]);
  const atlasHtml = `${itNote()}<dl class="kv">${kv.map(([a, b]) => `<div>${a}${b}</div>`).join('')}</dl><h4>${ss('atl.checks')}</h4>${checksHtml(ctx, row)}`;
  // Standard: the standard reference and the lens
  const stdHtml = `${itNote()}${row.standardRef ? `<h4>${ss('std.ref')}</h4>${tb(ctx, 'p', `stdref:${id}`, { table: 'rows', key: id, field: 'standardRef' }, { render: 'links', cls: 'stdref' })}` : ''}${lensHtml(ctx, id)}`;
  return `<article class="row" id="${esc(id)}" data-status="${esc(st.status)}">
<header class="row-h"><p class="row-meta"><a class="rid" href="#${esc(id)}">${esc(id)}</a> ${chip(ctx, id)}${badge ? ' ' + badge : ''}</p>${claim}</header>
<div class="reg reg--story">${story}</div>
<div class="reg reg--research">${researchHtml}</div>
<div class="reg reg--atlas">${atlasHtml}</div>
<div class="reg reg--standard">${stdHtml}</div>
</article>`;
}

// ------------------------------------------------------------------ a proposed row's block (the pack's ROWS.md)
const SCRIPT_OF_TAG = new Map();
for (const [key, s] of P.scripts) for (const tag of s.order) SCRIPT_OF_TAG.set(tag, key);
// a check group of the pack: the script's statement (its docstring), the lines its log prints, the run's last line and seconds
function packGroupHtml(ctx, tag, base) {
  const key = SCRIPT_OF_TAG.get(tag);
  if (!key) throw new Error(`no script for the tag ${tag}`);
  const stmt = tb(ctx, 'p', `pst:${base}`, { table: 'pack.script', key, field: `statement.${tag}` }, { cls: 'ck-st' });
  const g = packLogGroup(P.logs[key], tag);
  const lines = g ? `<details class="more"><summary>${ss('atl.lines')}</summary><ol class="loglines">${[g.head, ...g.lines].map((n) => tb(ctx, 'li', `plog:${key}:${n}`, { table: 'pack.log', key, field: String(n) }, { cls: n === g.head ? 'lh' : 'ok' })).join('')}</ol></details>` : '';
  const tail = P.logs[key].findIndex((l) => /^ALL OK/.test(l)) + 1;
  const run = `<p class="ck-run">${ss('atl.run.pack', 'span', 'k')} ${tb(ctx, 'span', `ptail:${base}`, { table: 'pack.log', key, field: String(tail) })} · ${ss('checks.seconds', 'span')} ${tb(ctx, 'span', `psec:${base}`, { table: 'pack.seconds', key })}</p>`;
  return `<div class="ck"><p class="ck-id"><code>${esc(tag)}</code> · <code>${esc(key)}.py</code></p><p class="k" data-s="atl.statement">${esc(S('atl.statement'))}</p>${stmt}${run}${lines}</div>`;
}
function proposedRowBlock(ctx, id) {
  const r = P.rows.get(id);
  const src = (field) => ({ table: 'pack.row', key: id, field });
  const claim = tb(ctx, 'p', `pclaim:${id}`, src('homePhys'), { part: 'md-plain', cls: 'row-claim', render: 'lines' });
  // Story: the study's units for the row, else its research text; on the Italian pages the narrator's telling
  let story;
  const pieces = BM.rows[id];
  if (L.lang === 'it') story = racc(`row:${id}`, { cls: 'story' });
  else if (pieces) {
    const secs = [...new Set(pieces.map((p) => p.unit.split('.')[0]))];
    const from = `<p class="src-line">${ss('blk.from.study')} ${secs.map((s) => tb(ctx, 'span', `pstsec:${id}`, { table: 'pack.study.heading', key: s }, { cls: 'src-sec' })).join(', ')}</p>`;
    story = `<div class="story">${pieces.map((p) => studyPiece(ctx, `pstory:${id}`, p, 'p', '', 'pack.study')).join('')}</div>${from}`;
  } else {
    story = `<div class="story">${tb(ctx, 'div', `pstory-r:${id}`, src('research'), { render: 'script', cls: 'tx' })}</div><p class="src-line">${ss('blk.from.research.p')}</p>`;
  }
  const researchHtml = `${itNote()}${tb(ctx, 'div', `presearch:${id}`, src('research'), { render: 'script', cls: 'tx' })}<p class="src-line">${ss('blk.research.p')}</p>`;
  // Atlas: the row as ROWS.md proposes it
  const kv = [];
  kv.push([ss('atl.math', 'dt'), tb(ctx, 'dd', `pmath:${id}`, src('homeMath'), { part: 'md-plain', render: 'lines' })]);
  kv.push([ss('atl.phys', 'dt'), tb(ctx, 'dd', `pphys:${id}`, src('homePhys'), { part: 'md-plain', render: 'lines' })]);
  kv.push([ss('atl.kind', 'dt'), `<dd>${tb(ctx, 'span', `pkind:${id}`, src('kind'))}</dd>`]);
  kv.push([ss('atl.status', 'dt'), `<dd>${tb(ctx, 'span', `pstatus:${id}`, src('status'))} · ${ss('atl.proposed', 'span', 'k')}</dd>`]);
  kv.push([ss('atl.stage', 'dt'), `<dd>${tb(ctx, 'span', `pstage:${id}`, src('stage'))} · ${tb(ctx, 'span', `pptype:${id}`, src('ptype'))}</dd>`]);
  kv.push([ss('atl.depends', 'dt'), tb(ctx, 'dd', `pdep:${id}`, src('depends'), { part: 'md-plain', render: 'ids', sec: 'bridges' })]);
  kv.push([ss('atl.home.proposed', 'dt'), tb(ctx, 'dd', `phome:${id}`, src('home'), { part: 'md-plain', render: 'md' })]);
  if (r.fields.reason) kv.push([ss('atl.reason', 'dt'), tb(ctx, 'dd', `preason:${id}`, src('reason'), { part: 'md-plain', render: 'lines' })]);
  if (r.fields.chainNote) kv.push([ss('atl.chainnote', 'dt'), tb(ctx, 'dd', `pchain:${id}`, src('chainNote'), { part: 'md-plain', render: 'ids', sec: 'bridges' })]);
  if (r.fields.webClaims) kv.push([ss('atl.webclaims', 'dt'), tb(ctx, 'dd', `pweb:${id}`, src('webClaims'), { part: 'md-plain', render: 'lines' })]);
  const evidence = r.tags.length
    ? `<p class="ck-ev"><span class="k" data-s="atl.evidence.note">${esc(S('atl.evidence.note'))}</span> ${tb(ctx, 'span', `pev:${id}`, src('evidence'), { part: 'md-plain', render: 'md' })}</p>${r.tags.map((tag) => packGroupHtml(ctx, tag, `${id}:${tag}`)).join('')}`
    : `<p class="muted"><span data-s="atl.noevidence">${esc(S('atl.noevidence'))}</span> ${tb(ctx, 'span', `pevnote:${id}`, src('evidenceNote'), { part: 'md-plain', render: 'md' })}</p>`;
  const controls = r.fields.controlsText ? `<h4>${ss('atl.controls')}</h4>${tb(ctx, 'div', `pctl:${id}`, src('controlsText'), { part: 'md-plain', render: 'lines', cls: 'ctl-t small' })}` : '';
  const atlasHtml = `${itNote()}<dl class="kv">${kv.map(([a, b]) => `<div>${a}${b}</div>`).join('')}</dl><h4>${ss('atl.checks')}</h4>${evidence}${controls}`;
  // Standard: the standard reference, and the bridge the item's BRIDGE.md grades for the row
  const it = P.itemOf.get(r.item);
  let bridges = it.bridge.rowBridges.get(id) || [];
  if (!bridges.length && it.bridge.table.size === 1) bridges = [...it.bridge.table.keys()];
  const bridgeHtml = bridges.length
    ? `<h4>${ss('std.bridge')}</h4><ul class="lens-l">${bridges.map((n) => `<li class="lens-i">${ss('std.bridge.k', 'span', 'lt')} <b>${esc(n)}</b> ${tb(ctx, 'span', `pbr:${id}:${n}`, { table: 'pack.bridge', key: r.item, field: `${n}.bridge` }, { part: 'md-plain', render: 'md' })} <span class="grade">${ss('std.bridge.before', 'span', 'lt')} ${tb(ctx, 'span', `pbb:${id}:${n}`, { table: 'pack.bridge', key: r.item, field: `${n}.before` }, { part: 'md-plain', render: 'md' })}</span> <span class="grade">${ss('std.bridge.proposed', 'span', 'lt')} ${tb(ctx, 'span', `pbp:${id}:${n}`, { table: 'pack.bridge', key: r.item, field: `${n}.proposed` }, { part: 'md-plain', render: 'md' })}</span></li>`).join('')}</ul>`
    : ss('std.bridge.none', 'p', 'muted');
  const stdHtml = `${itNote()}<h4>${ss('std.ref')}</h4>${tb(ctx, 'div', `pstd:${id}`, src('standardRef'), { part: 'md-plain', render: 'lines', cls: 'stdref' })}${bridgeHtml}`;
  return `<article class="row row--proposed" id="${esc(id)}" data-status="${esc(r.status)}" data-proposed="${esc(r.item)}">
<header class="row-h"><p class="row-meta"><a class="rid" href="#${esc(id)}">${esc(id)}</a> ${chipProposed(ctx, id)}</p>${claim}</header>
<div class="reg reg--story">${story}</div>
<div class="reg reg--research">${researchHtml}</div>
<div class="reg reg--atlas">${atlasHtml}</div>
<div class="reg reg--standard">${stdHtml}</div>
</article>`;
}

// ------------------------------------------------------------------ figures and clips
function figureHtml(ctx, f, { cls = '' } = {}) {
  const r37 = f.round === 37;
  const table = r37 ? 'pack.figures' : 'figures';
  const cap = traced(ctx, `figcap:${f.file}`, { table, key: f.file, field: 'caption' }, { part: 'md-plain', render: 'md' });
  const data = tb(ctx, 'span', `figdata:${f.file}`, { table, key: f.file, field: 'data' }, { part: 'md-plain', render: 'md' });
  const alt = firstSentence(cap.text);
  // on a phone a figure keeps the width at which its smallest label (11 px at its natural width) prints at 10 px, and
  // scrolls sideways in its frame, as the sister site's figures do
  const file = path.join(r37 ? P.dirs.figs : D.dirs.figs, f.file);
  const nat = +((/<svg[^>]*\swidth="(\d+)"/.exec(fs.readFileSync(file, 'utf8').slice(0, 600)) || [])[1] || 1000);
  return `<figure class="fig${cls ? ' ' + cls : ''}" id="fig-${slug(f.file)}"><div class="plate"><img src="${A(r37 ? 'figures/round37/' : 'figures/')}${esc(f.file)}" alt="${esc(alt)}" loading="lazy" decoding="async" style="--w:${Math.round(nat * 10 / 11)}px"></div><figcaption><span data-b="${cap.blockId}">${scriptsH(cap.text)}</span> <span class="fig-data">${ss('fig.data', 'span', 'k')} ${data}</span></figcaption></figure>`;
}
const clipNo = (file) => file.split('_')[0];
function clipHtml(ctx, base, { narrate = false } = {}) {
  const r37 = P.clipByFile.has(base + '.wav');
  const c = r37 ? P.clipByFile.get(base + '.wav') : D.clipByFile.get(base + '.wav');
  if (!c) throw new Error('clip missing from INDEX.md: ' + base);
  const table = r37 ? 'pack.clips' : 'clips';
  return `<div class="clip" id="clip-${esc(clipNo(base))}"><p class="clip-h">${ss('clip.label', 'span', 'k')} <b>${esc(clipNo(base))}</b> · <code>${esc(base)}.ogg</code> · ${esc(c.seconds)} s</p><audio controls preload="none" src="${A('audio/')}${esc(base)}.ogg"></audio>${tb(ctx, 'p', `clipheard:${base}`, { table, key: base + '.wav', field: 'heard' }, { part: 'md-plain', render: 'md', cls: 'clip-t' })}${narrate ? racc(`clip:${clipNo(base)}`) : ''}<details class="more"><summary>${ss('clip.built')}</summary>${tb(ctx, 'p', `clipbuilt:${base}`, { table, key: base + '.wav', field: 'built' }, { part: 'md-plain', render: 'md' })}</details></div>`;
}

// ------------------------------------------------------------------ the pages of one language
function buildPages() {
  const PAGES = {};
  // ---------------------------------------------------------------- the section pages
  for (const sec of SECS) {
    const ctx = new Ctx(sec.slug);
    const si = D.page.sections.findIndex((x) => x.id === sec.id);
    const title = regTitle(ctx, 'sectitle', { table: 'page' }, `sections.${si}.title`, 'h1', 'sec-title');
    const lead = tb(ctx, 'div', `lead:${sec.lead}`, { table: 'texts', key: textKey(sec.lead, 'research', 'full') }, { render: 'script', cls: 'lead-t' });
    const ch = sec.chain;
    const chainTitle = regTitle(ctx, 'chaintitle', { table: 'chains', key: ch.id }, 'title', 'h2', 'chain-title');
    const blocks = [];
    ch.rows.forEach((id, i) => {
      blocks.push(rowBlock(ctx, id, sec));
      if (i < ch.rows.length - 1) {
        const l = ch.links[i] || {};
        const rel = l.rel && L.strings.has('rel.' + l.rel) ? ss('rel.' + l.rel, 'span', 'rel') : '';
        const from = l.from ? ` <span class="rel-from">← ${rowRef(l.from, sec)}</span>` : '';
        const note = l.note ? ` ${tb(ctx, 'span', `linknote:${ch.id}`, { table: 'chains', key: ch.id, field: `links.${i}.note` }, { cls: 'rel-note' })}` : '';
        blocks.push(`<div class="link" aria-hidden="false">${rel}${from}${note}</div>`);
      }
    });
    const figs = D.figures.filter((f) => f.secs.includes(sec));
    const clips = sec.place.clips;
    const inst = sec.place.instrument ? `<p class="play-link">${ss('sec.play')} <a href="sounds.html#i-${sec.place.instrument}" data-s="inst.${sec.place.instrument}">${esc(S('inst.' + sec.place.instrument))}</a></p>` : '';
    const prev = SECS[sec.i - 1], next = SECS[sec.i + 1];
    const pager = `<nav class="pager" aria-label="${esc(S('aria.sections'))}">${prev ? `<a class="pg pg--prev" href="${prev.slug}.html"><span data-s="sec.prev">${esc(S('sec.prev'))}</span> <b>${prev.n}</b></a>` : '<span></span>'}${next ? `<a class="pg pg--next" href="${next.slug}.html"><span data-s="sec.next">${esc(S('sec.next'))}</span> <b>${next.n}</b></a>` : '<span></span>'}</nav>`;
    const toc = `<nav class="toc" aria-label="${esc(S('aria.onpage'))}"><p class="toc-k" data-s="sec.toc">${esc(S('sec.toc'))}</p><ol>${ch.rows.map((id) => `<li><a href="#${esc(id)}">${esc(id)}</a></li>`).join('')}${figs.length ? `<li><a href="#figures" data-s="sec.figures">${esc(S('sec.figures'))}</a></li>` : ''}${clips.length ? `<li><a href="#clips" data-s="sec.clips">${esc(S('sec.clips'))}</a></li>` : ''}</ol></nav>`;
    const body = `<div class="sec-wrap"><aside class="rail">${toc}</aside><article class="sec">
<header class="sec-head"><p class="kicker">${ss('sec.label')} <b>${sec.n}</b> / ${SECS.length}</p>${title}</header>
<section class="lead"><p class="lead-k">${ss('sec.lead')} · <code>${esc(sec.lead)}</code></p>${lead}<p class="src-line">${ss('sec.lead.note')}</p></section>
${racc(`section:${sec.slug}`, { cls: 'racc--section' })}
<section class="chain"><div class="chain-head">${chainTitle}<p class="chain-note">${ss('sec.chain.note')} ${ss('chip.legend')}</p></div>
${blocks.join('\n')}
</section>
${figs.length ? `<section class="figs" id="figures"><h2 data-s="sec.figures">${esc(S('sec.figures'))}</h2>${figs.map((f) => figureHtml(ctx, f)).join('')}</section>` : ''}
${clips.length ? `<section class="clips" id="clips"><h2 data-s="sec.clips">${esc(S('sec.clips'))}</h2>${clips.map((c) => clipHtml(ctx, c)).join('')}</section>` : ''}
${inst}
${pager}
</article></div>`;
    const tt = resolve(D, { table: 'page', field: `sections.${si}.title.learner` });
    PAGES[sec.slug] = shell(ctx, { title: `${tt} · ${S('brand')}`, body, registers: true });
  }

  // ---------------------------------------------------------------- the home
  {
    const ctx = new Ctx('index');
    const q = D.storyMap.home.map((src, i) => {
      if (src.table === 'study') return `<span class="qs" data-b="${traced(ctx, 'q', { table: 'study', key: src.key, field: src.field }, { render: 'study' }).blockId}">${studyHtml(D.study, pieceRed(D.study, { unit: src.key, sentences: src.field }), src.key)}</span>`;
      return tb(ctx, 'span', 'q', { table: src.table, key: src.key }, { part: src.part, cls: 'qs', render: 'script' });
    }).join(' ');
    const map = D.figByFile.get(D.placements.homeFigure);
    const cards = SECS.map((s) => {
      const si = D.page.sections.findIndex((x) => x.id === s.id);
      const counts = new Map();
      for (const r of s.chain.rows) { const k = D.status[r].status; counts.set(k, (counts.get(k) || 0) + 1); }
      const chips = [...counts].map(([k, n]) => `<span class="chip chip--${k} chip--sm"><b>${n}</b>&nbsp;<span data-s="${STATUS_WORD[k]}">${esc(S(STATUS_WORD[k]))}</span></span>`).join(' ');
      return `<li class="card"><a class="card-a" href="${s.slug}.html"><span class="card-n">${s.n}</span>${regTitle(ctx, `cardtitle:${s.id}`, { table: 'page' }, `sections.${si}.title`, 'h3', 'card-t')}</a>${tb(ctx, 'p', `cardlead:${s.lead}`, { table: 'texts', key: textKey(s.lead, 'research', 'full') }, { render: 'script', cls: 'card-lead' })}<p class="card-meta"><b>${s.chain.rows.length}</b> ${ss('card.rows')} · ${chips}</p><p><a href="${s.slug}.html" data-s="card.open">${esc(S('card.open'))}</a></p></li>`;
    }).join('');
    // the ninth card: the page of the drill, with one traced sentence of its byline and its proposed rows by status
    const pcounts = new Map();
    for (const r of P.rows.values()) pcounts.set(r.status, (pcounts.get(r.status) || 0) + 1);
    const pchips = [...pcounts].map(([k, n]) => `<span class="chip chip--${k} chip--sm"><b>${n}</b>&nbsp;<span data-s="${STATUS_WORD[k]}">${esc(S(STATUS_WORD[k]))}</span></span>`).join(' ');
    const bcard = `<li class="card card--bridges"><a class="card-a" href="bridges.html"><span class="card-n card-n--study" data-s="b.card.badge">${esc(S('b.card.badge'))}</span><h3 class="card-t" data-s="b.title">${esc(S('b.title'))}</h3></a>${studyPiece(ctx, 'bcard', BM.card, 'p', 'card-lead', 'pack.study')}<p class="card-meta"><b>${P.rows.size}</b> ${ss('card.rows.proposed')} · ${pchips} <span class="chip chip--proposed chip--sm" data-s="chip.proposed">${esc(S('chip.proposed'))}</span></p><p><a href="bridges.html" data-s="b.card.open">${esc(S('b.card.open'))}</a></p></li>`;
    const more = [['bridges', 'nav.bridges', 'home.more.bridges'], ['dictionary', 'nav.dictionary', 'home.more.dictionary'], ['checks', 'nav.checks', 'home.more.checks'], ['pictures', 'nav.pictures', 'home.more.pictures'], ['sources', 'nav.sources', 'home.more.sources'], ['about', 'nav.about', 'home.more.about']].map(([p, a, b]) => `<li><a href="${p}.html" data-s="${a}">${esc(S(a))}</a> — ${ss(b)}</li>`).join('');
    const body = `<section class="hero"><h1 class="hero-t" data-s="brand">${esc(S('brand'))}</h1><p class="hero-sub" data-s="brand.sub">${esc(S('brand.sub'))}</p><p class="stamp" data-s="release.stamp">${esc(S('release.stamp'))}</p></section>
<section class="question"><h2 data-s="home.question">${esc(S('home.question'))}</h2><p class="q">${q}</p><p class="src-line">${ss('home.question.note')}</p>${racc('page:home')}</section>
<section class="home-map"><h2 data-s="home.map">${esc(S('home.map'))}</h2>${figureHtml(ctx, map, { cls: 'fig--map' })}</section>
<section class="home-secs"><h2 data-s="home.sections">${esc(S('home.sections'))}</h2><p class="src-line">${ss('home.sections.note')} ${ss('chip.legend')} ${ss('chip.legend.proposed')}</p><ol class="cards">${cards}${bcard}</ol></section>
<section class="callout"><h2 data-s="home.play">${esc(S('home.play'))}</h2>${ss('home.play.p', 'p')}<p><a class="btn" href="sounds.html" data-s="home.play.go">${esc(S('home.play.go'))}</a></p></section>
<section class="more-l"><h2 data-s="home.more">${esc(S('home.more'))}</h2><ul>${more}</ul></section>`;
    PAGES.index = shell(ctx, { title: `${S('brand')} · ${S('brand.sub')}`, body, registers: true });
  }

  // ---------------------------------------------------------------- the paper's dictionary (DICTIONARY.md), on two pages
  function paperDictionary(ctx, { candidates = false, narrate = false, sec = null } = {}) {
    const Dc = P.dictionary;
    const top = `${tb(ctx, 'p', 'pdtop', { table: 'pack.dict.top', key: '0' }, { part: 'md-plain', render: 'refs', cls: 'page-intro-2' })}<h3 data-s="dict.paper.how">${esc(S('dict.paper.how'))}</h3><ul class="pd-how">${[2, 3, 4, 5].map((i) => tb(ctx, 'li', 'pdhow', { table: 'pack.dict.top', key: String(i) }, { part: 'md-plain', render: 'ids', sec })).join('')}</ul>`;
    const rows = Dc.rows.map((r, i) => `<tr id="pd-${slug(r.n)}"><td class="c-n">${esc(r.n)}</td>${tb(ctx, 'td', `pda:${r.n}`, { table: 'pack.dict', key: String(i), field: 'a' }, { part: 'md-plain', render: 'lines' })}${tb(ctx, 'td', `pdb:${r.n}`, { table: 'pack.dict', key: String(i), field: 'b' }, { part: 'md-plain', render: 'lines' })}${tb(ctx, 'td', `pdc:${r.n}`, { table: 'pack.dict', key: String(i), field: 'c' }, { part: 'md-plain', render: 'ids', sec })}</tr>`).join('');
    const counts = `<div class="tbl tbl--narrow"><table class="pdc"><thead><tr><th></th><th data-s="dict.paper.c.exact">${esc(S('dict.paper.c.exact'))}</th><th data-s="dict.paper.c.partial">${esc(S('dict.paper.c.partial'))}</th><th data-s="dict.paper.c.none">${esc(S('dict.paper.c.none'))}</th></tr></thead><tbody>${Dc.counts.map((c, i) => `<tr>${tb(ctx, 'td', `pdcl:${i}`, { table: 'pack.dict.counts', key: String(i), field: 'label' })}${['exact', 'partial', 'none'].map((f) => tb(ctx, 'td', `pdc${f}:${i}`, { table: 'pack.dict.counts', key: String(i), field: f }, { cls: 'c-n' })).join('')}</tr>`).join('')}</tbody></table></div>`;
    const cand = candidates ? `<h3 data-s="dict.paper.cand">${esc(S('dict.paper.cand'))}</h3>${ss('dict.paper.cand.p', 'p')}<ol class="cands">${Dc.candidates.map((c) => `<li id="cand-${c.n}"><p class="cand-t">${tb(ctx, 'b', `pcand:${c.n}`, { table: 'pack.dict.cand', key: c.n, field: 'title' }, { part: 'md-plain', render: 'md' })}</p><ul>${c.bullets.map((b, j) => tb(ctx, 'li', `pcandb:${c.n}`, { table: 'pack.dict.cand', key: c.n, field: `bullets.${j}` }, { part: 'md-plain', render: 'ids', sec })).join('')}</ul></li>`).join('')}</ol>
<details class="more"><summary>${ss('dict.paper.slips')}</summary><div class="tbl"><table class="slips"><thead><tr><th data-s="dict.paper.slip.where">${esc(S('dict.paper.slip.where'))}</th><th data-s="dict.paper.slip.printed">${esc(S('dict.paper.slip.printed'))}</th><th data-s="dict.paper.slip.computed">${esc(S('dict.paper.slip.computed'))}</th></tr></thead><tbody>${Dc.slips.map((s, i) => `<tr>${['where', 'printed', 'computed'].map((f) => tb(ctx, 'td', `pslip${f}:${i}`, { table: 'pack.dict.slips', key: String(i), field: f }, { part: 'md-plain', render: 'md' })).join('')}</tr>`).join('')}</tbody></table></div></details>`
      : `<p class="small">${ss('dict.paper.more')} <a href="bridges.html#dictionary" data-s="dict.paper">${esc(S('dict.paper'))}</a></p>`;
    return `<h2 data-s="dict.paper">${esc(S('dict.paper'))}</h2>${ss('dict.paper.p', 'p')}${narrate ? racc('page:acoustics') : ''}${top}
<div class="tbl"><table class="dict pd"><thead><tr><th data-s="dict.paper.col.n">${esc(S('dict.paper.col.n'))}</th><th data-s="dict.paper.col.a">${esc(S('dict.paper.col.a'))}</th><th data-s="dict.paper.col.b">${esc(S('dict.paper.col.b'))}</th><th data-s="dict.paper.col.c">${esc(S('dict.paper.col.c'))}</th></tr></thead><tbody>${rows}</tbody></table></div>
<h3 data-s="dict.paper.counts">${esc(S('dict.paper.counts'))}</h3>${counts}${cand}`;
  }

  // ---------------------------------------------------------------- the page of the drill: The bridges drilled
  {
    const ctx = new Ctx('bridges');
    const stamp = `<p class="stamp"><span data-s="b.stamp.k">${esc(S('b.stamp.k'))}</span> ${studyPiece(ctx, 'bstamp', BM.stamp, 'span', 'src-sec', 'pack.study')}</p>`;
    const standing = `<p class="standing">${ss('b.standing', 'span')} ${studyPiece(ctx, 'bstanding', BM.standing, 'span', '', 'pack.study')}</p>`;
    const question = `<section class="b-question" id="question"><h2 data-s="b.question">${esc(S('b.question'))}</h2><div class="story">${BM.question.map((p) => studyPiece(ctx, 'bq', p, 'p', '', 'pack.study')).join('')}</div><p class="src-line">${ss('b.question.note')}</p></section>`;
    const table = `<section class="b-table" id="bridges-table"><h2 data-s="b.table">${esc(S('b.table'))}</h2>${ss('b.table.p', 'p')}${racc('bridges:table')}<div class="tbl"><table class="dict bridges"><thead><tr><th data-s="b.col.n">${esc(S('b.col.n'))}</th><th data-s="b.col.bridge">${esc(S('b.col.bridge'))}</th><th data-s="b.col.before">${esc(S('b.col.before'))}</th><th data-s="b.col.after">${esc(S('b.col.after'))}</th><th data-s="b.col.item">${esc(S('b.col.item'))}</th></tr></thead><tbody>${[...P.bridges.keys()].map((n) => `<tr id="bridge-${esc(n)}"><td class="c-n">${esc(n)}</td>${tb(ctx, 'td', `br:${n}:bridge`, { table: 'pack.bridges', key: n, field: 'bridge' }, { part: 'md-plain', render: 'md' })}${tb(ctx, 'td', `br:${n}:before`, { table: 'pack.bridges', key: n, field: P.bridgesHead[2] }, { part: 'md-plain', render: 'md' })}${tb(ctx, 'td', `br:${n}:after`, { table: 'pack.bridges', key: n, field: P.bridgesHead[3] }, { part: 'md-plain', render: 'md' })}${tb(ctx, 'td', `br:${n}:item`, { table: 'pack.bridges', key: n, field: P.bridgesHead[4] }, { part: 'md-plain', render: 'md' })}</tr>`).join('')}</tbody></table></div></section>`;
    const skip = new Set(BM.skipKinds);
    const items = BM.items.map((im, i) => {
      const it = P.itemOf.get(im.item);
      const units = im.sections.flatMap((s) => (P.study.bySec.get(s) || []).filter((u) => !skip.has(u.kind)));
      const heads = im.sections.map((s) => tb(ctx, 'span', `bih:${im.item}`, { table: 'pack.study.heading', key: s }, { cls: 'src-sec' })).join(', ');
      const prose = `<div class="story b-story">${units.map((u) => studyPiece(ctx, `bi:${im.item}`, { unit: u.id }, 'p', u.kind === 'li' ? 'sp--li' : '', 'pack.study')).join('')}</div><p class="src-line">${ss('blk.from.study')} ${heads}</p>`;
      const rows = it.rows.map((id) => proposedRowBlock(ctx, id)).join('\n');
      const figs = P.figures.filter((f) => f.items[0] === im.item);
      const clips = im.clips;
      const inst = im.instrument ? `<p class="play-link">${ss('sec.play')} <a href="sounds.html#i-${im.instrument}" data-s="inst.${im.instrument}">${esc(S('inst.' + im.instrument))}</a></p>` : '';
      return `<section class="b-item" id="item-${im.item}">
<header class="sec-head"><p class="kicker">${ss('b.item.k')} <b>${i + 1}</b> / ${BM.items.length}</p><h2 class="sec-title" data-s="b.item.${im.item}">${esc(S('b.item.' + im.item))}</h2><p class="src-line">${ss('b.item.bridge')} ${tb(ctx, 'span', `bit:${im.item}`, { table: 'pack.bridge', key: im.item, field: 'title' }, { cls: 'src-sec' })}</p></header>
${racc(`bridges:item:${im.item}`, { cls: 'racc--section' })}
${prose}
<section class="chain"><div class="chain-head"><h3 data-s="b.rows">${esc(S('b.rows'))}</h3><p class="chain-note">${ss('b.rows.note')} ${ss('chip.legend')} ${ss('chip.legend.proposed')}</p></div>
${rows}
</section>
${figs.length ? `<section class="figs" id="figures-${im.item}"><h3 data-s="sec.figures">${esc(S('sec.figures'))}</h3>${figs.map((f) => figureHtml(ctx, f)).join('')}</section>` : ''}
${clips.length ? `<section class="clips" id="clips-${im.item}"><h3 data-s="sec.clips">${esc(S('sec.clips'))}</h3>${clips.map((c) => clipHtml(ctx, c)).join('')}</section>` : ''}
${inst}
</section>`;
    }).join('\n');
    const dictionary = `<section class="b-dict" id="dictionary">${paperDictionary(ctx, { candidates: true, narrate: true, sec: 'bridges' })}</section>`;
    const opinion = `<section class="b-opinion" id="opinion"><h2 data-s="b.opinion">${esc(S('b.opinion'))}</h2>${racc('bridges:opinion')}<div class="story">${BM.opinion.map((p) => studyPiece(ctx, 'bop', p, 'p', '', 'pack.study')).join('')}</div><div class="story b-part2">${BM.part2.map((p) => studyPiece(ctx, 'bp2', p, 'p', '', 'pack.study')).join('')}</div><p class="src-line">${ss('b.opinion.note')}</p></section>`;
    const refs = `<section class="b-refs" id="references"><h2 data-s="b.refs">${esc(S('b.refs'))}</h2><p>${ss('b.refs.p', 'span')} <a href="sources.html#refs2" data-s="src.refs2">${esc(S('src.refs2'))}</a></p></section>`;
    const toc = `<nav class="toc" aria-label="${esc(S('aria.onpage'))}"><p class="toc-k" data-s="sec.toc">${esc(S('sec.toc'))}</p><ol><li><a href="#question" data-s="b.question">${esc(S('b.question'))}</a></li><li><a href="#bridges-table" data-s="b.table">${esc(S('b.table'))}</a></li>${BM.items.map((im, i) => `<li><a href="#item-${im.item}"><span data-s="b.item.k">${esc(S('b.item.k'))}</span> ${i + 1}</a></li>`).join('')}<li><a href="#dictionary" data-s="dict.paper">${esc(S('dict.paper'))}</a></li><li><a href="#opinion" data-s="b.opinion">${esc(S('b.opinion'))}</a></li></ol></nav>`;
    const body = `<div class="sec-wrap"><aside class="rail">${toc}</aside><article class="sec sec--bridges">
<header class="sec-head"><p class="kicker" data-s="b.kicker">${esc(S('b.kicker'))}</p><h1 class="sec-title" data-s="b.title">${esc(S('b.title'))}</h1>${stamp}${standing}</header>
${racc('page:bridges', { cls: 'racc--section' })}
${question}
${table}
<section class="b-items"><h2 data-s="b.items">${esc(S('b.items'))}</h2><p class="src-line">${ss('b.items.note')}</p></section>
${items}
${dictionary}
${opinion}
${refs}
</article></div>`;
    PAGES.bridges = shell(ctx, { title: `${S('b.title')} · ${S('brand')}`, body, registers: true });
  }

  // ---------------------------------------------------------------- the dictionary
  {
    const ctx = new Ctx('dictionary');
    const Ln = D.lens;
    const gradeOf = (m) => (/^exact with an input/.test(m) ? 'exact with an input' : (/^(exact|partial|analogy|none)/.exec(m) || [, ''])[1]);
    const counts = new Map();
    Ln.dictionary.forEach((e) => { const g = gradeOf(e.match); counts.set(g, (counts.get(g) || 0) + 1); });
    // the grade words, each traced to the first entry graded with it (the words are the lens's own)
    const legend = [['exact', 'grade.exact'], ['exact with an input', 'grade.exact-input'], ['partial', 'grade.partial'], ['analogy', 'grade.analogy'], ['none', 'grade.none']].map(([g, s]) => { const i = Ln.dictionary.findIndex((e) => gradeOf(e.match) === g); return `<li>${tb(ctx, 'b', `gw:${slug(g)}`, { table: 'lens', key: String(i), field: 'match' }, { part: 'grade-word', cls: `gw grade--${slug(g)}` })} <span class="n">${counts.get(g) || 0}</span> — ${ss(s)}</li>`; }).join('');
    const rows = Ln.dictionary.map((e, i) => `<tr id="lens-${i + 1}"><td class="c-n">${i + 1}</td>${tb(ctx, 'td', `la:${i}`, { table: 'lens', key: String(i), field: 'atlas' }, { render: 'script' })}${tb(ctx, 'td', `lm:${i}`, { table: 'lens', key: String(i), field: 'term' }, { render: 'script' })}${gradeHtml(ctx, `lg:${i}`, { table: 'lens', key: String(i), field: 'match' }, 'td')}<td class="c-ev">${(e.evidence || []).map((x) => `<code>${esc(x)}</code>`).join(' ')}</td><td class="c-rows">${(e.rows || []).map((x) => rowRef(x, null)).join(' ')}</td></tr>`).join('');
    // the readings, grouped by the page where the row is at home (its first place in the Atlas)
    const byPage = new Map();
    D.readings.forEach((r, i) => { const row = D.rows.get(r.row); const home = row && row.shownOn && row.shownOn[0] ? row.shownOn[0].page : '—'; if (!byPage.has(home)) byPage.set(home, []); byPage.get(home).push(i); });
    const groups = [...byPage].sort((a, b) => b[1].length - a[1].length || a[0].localeCompare(b[0])).map(([pg, list]) => {
      const pt = D.pages.has(pg) ? tb(ctx, 'span', `pgtitle:${pg}`, { table: 'pages', key: pg, field: 'title.phys' }) : '';
      return `<section class="rd-g"><h3><code>${esc(pg)}</code> ${pt} <span class="n">${list.length}</span></h3><ul class="rd-l">${list.map((i) => { const r = D.readings[i]; return `<li>${rowRef(r.row, null)} ${ss('lens.atlas', 'span', 'lt')} ${tb(ctx, 'span', `ra:${i}`, { table: 'lens_readings', key: String(i), field: 'atlas' }, { render: 'script' })} ${ss('lens.music', 'span', 'lt')} ${tb(ctx, 'span', `rm:${i}`, { table: 'lens_readings', key: String(i), field: 'term' }, { render: 'script' })} ${gradeHtml(ctx, `rg:${i}`, { table: 'lens_readings', key: String(i), field: 'match' })} <span class="via" data-s="via.${r.via}">${esc(S('via.' + r.via))}</span></li>`; }).join('')}</ul></section>`;
    }).join('');
    const body = `<header class="page-head"><h1 data-s="nav.dictionary">${esc(S('nav.dictionary'))}</h1>${ss('dict.intro', 'p', 'page-intro')}<p class="lens-rec">${tb(ctx, 'b', 'lensname', { table: 'lens', key: 'record', field: 'name' })} · <code>mus</code> · ${tb(ctx, 'span', 'lenskind', { table: 'lens', key: 'record', field: 'kind' })} · ${tb(ctx, 'span', 'lensrole', { table: 'lens', key: 'record', field: 'role' })}</p><p>${ss('dict.describes', 'span', 'k')} ${tb(ctx, 'span', 'lensdesc', { table: 'lens', key: 'record', field: 'describes' })}</p>${racc('page:dictionary')}</header>
<section class="legend-b"><h2 data-s="dict.grades">${esc(S('dict.grades'))}</h2>${ss('dict.grades.p', 'p')}<ul class="grades">${legend}</ul></section>
<section><h2 data-s="dict.entries">${esc(S('dict.entries'))}</h2><div class="tbl"><table class="dict"><thead><tr><th>#</th><th data-s="dict.col.atlas">${esc(S('dict.col.atlas'))}</th><th data-s="dict.col.music">${esc(S('dict.col.music'))}</th><th data-s="dict.col.grade">${esc(S('dict.col.grade'))}</th><th data-s="dict.col.evidence">${esc(S('dict.col.evidence'))}</th><th data-s="dict.col.rows">${esc(S('dict.col.rows'))}</th></tr></thead><tbody>${rows}</tbody></table></div></section>
<section class="readings"><h2 data-s="dict.readings">${esc(S('dict.readings'))}</h2>${ss('dict.readings.p', 'p')}${groups}</section>
<section class="paper-dict" id="paper">${paperDictionary(ctx)}</section>`;
    PAGES.dictionary = shell(ctx, { title: `${S('nav.dictionary')} · ${S('brand')}`, body });
  }

  // ---------------------------------------------------------------- checks
  {
    const ctx = new Ctx('checks');
    const scripts = [['checks/selfcheck/round36/music_sound.py', 'music_sound'], ['checks/selfcheck/round36/music_symmetry.py', 'music_symmetry']];
    const blocks = scripts.map(([sc, key]) => {
      const rec = D.checks.get(sc);
      const Lg = D.logs[key];
      const groups = rec.ids.map((g, gi) => {
        const lg = logGroup(sc, g.id);
        const lines = lg ? [lg.head, ...lg.lines].map((n) => tb(ctx, 'li', `log:${key}:${n}`, { table: 'log', key, field: String(n) }, { cls: n === lg.head ? 'lh' : /^\s+\[in\]/.test(Lg[n - 1]) ? 'in' : 'ok' })).join('') : '';
        return `<section class="grp" id="${slug(g.id)}"><h4><code>${esc(g.id)}</code> <span class="n">${lg ? lg.lines.filter((n) => /^\s+ok\s/.test(Lg[n - 1])).length : 0}</span></h4>${tb(ctx, 'p', `gst:${g.id}`, { table: 'checks', key: sc, field: `ids.${gi}.statement` }, { cls: 'ck-st' })}<ol class="loglines">${lines}</ol></section>`;
      }).join('');
      const fk = key + '_faults';
      const faults = D.logs[fk].map((l, i) => ({ l, n: i + 1 })).filter((x) => /^== --fault/.test(x.l)).map((x) => tb(ctx, 'li', `fault:${key}:${x.n}`, { table: 'log', key: fk, field: String(x.n) })).join('');
      const tail = Lg.map((l, i) => ({ l, n: i + 1 })).filter((x) => /^(checks: |FAILS |ALL OK)/.test(x.l)).map((x) => tb(ctx, 'li', `tail:${key}:${x.n}`, { table: 'log', key, field: String(x.n) })).join('');
      const run = D.runs.get(sc);
      const runHtml = `<dl class="kv">${['date', 'machine', 'ok', 'fail', 'seconds', 'lastLine', 'status'].map((f) => `<div><dt><code>${f}</code></dt>${tb(ctx, 'dd', `run:${key}:${f}`, { table: 'check_runs', key: sc, field: f })}</div>`).join('')}</dl>`;
      const kv = [['checks.what', 'what'], ['checks.method', 'method'], ['checks.route', 'independentRoute'], ['checks.controls', 'controls']].map(([s, f]) => `<div>${ss(s, 'dt')}${tb(ctx, 'dd', `ck:${key}:${f}`, { table: 'checks', key: sc, field: f })}</div>`).join('');
      return `<section class="script" id="${key}"><h2><code>${esc(path.basename(sc))}</code></h2><p class="links"><a href="${A('checks/')}${key}.py" data-s="checks.script">${esc(S('checks.script'))}</a> · <a href="${A('checks/')}${key}.log" data-s="checks.log">${esc(S('checks.log'))}</a> · <a href="${A('checks/')}${key}.faults.log" data-s="checks.faultlog">${esc(S('checks.faultlog'))}</a></p>
<dl class="kv">${kv}<div>${ss('checks.rows', 'dt')}<dd>${rec.rowsNaming.map((r) => rowRef(r, null)).join(' ')}</dd></div></dl>
<h3 data-s="checks.groups">${esc(S('checks.groups'))}</h3>${groups}<ol class="loglines tail">${tail}</ol>
<h3 data-s="checks.faults">${esc(S('checks.faults'))}</h3>${ss('checks.faults.p', 'p')}<ul class="faults">${faults}</ul>
<h3 data-s="checks.run">${esc(S('checks.run'))}</h3>${runHtml}
<details class="more"><summary>${ss('checks.fulllog')}</summary>${tb(ctx, 'pre', `logfile:${key}`, { table: 'logfile', key }, { cls: 'logpre' })}</details></section>`;
    }).join('');
    // the nine scripts of the pack: the docstring's statements, the lines of the logs, the controls, the seconds
    const ROWS_OF_SCRIPT = new Map(SCRIPTS.map((s) => [s, []]));
    for (const r of P.rows.values()) for (const tag of r.tags) { const s = SCRIPT_OF_TAG.get(tag); if (s && !ROWS_OF_SCRIPT.get(s).includes(r.id)) ROWS_OF_SCRIPT.get(s).push(r.id); }
    const pblocks = SCRIPTS.map((key) => {
      const s = P.scripts.get(key);
      const Lg = P.logs[key];
      const groups = s.order.map((tag) => {
        const lg = packLogGroup(Lg, tag);
        const lines = lg ? [lg.head, ...lg.lines].map((n) => tb(ctx, 'li', `plog:${key}:${n}`, { table: 'pack.log', key, field: String(n) }, { cls: n === lg.head ? 'lh' : 'ok' })).join('') : '';
        return `<section class="grp" id="${slug(tag)}"><h4><code>${esc(tag)}</code> <span class="n">${lg ? lg.lines.length : 0}</span></h4>${tb(ctx, 'p', `pgst:${tag}`, { table: 'pack.script', key, field: `statement.${tag}` }, { cls: 'ck-st' })}<ol class="loglines">${lines}</ol></section>`;
      }).join('');
      const faults = P.logs[`${key}_faults`].map((l, i) => ({ l, n: i + 1 })).filter((x) => /^== --fault/.test(x.l)).map((x) => tb(ctx, 'li', `pfault:${key}:${x.n}`, { table: 'pack.log', key: `${key}_faults`, field: String(x.n) })).join('');
      const tail = Lg.map((l, i) => ({ l, n: i + 1 })).filter((x) => /^(checks: |FAILS |ALL OK)/.test(x.l)).map((x) => tb(ctx, 'li', `ptail:${key}:${x.n}`, { table: 'pack.log', key, field: String(x.n) })).join('');
      const legend = `<div>${ss('checks.r37.legend', 'dt')}<dd>${[...s.legend.keys()].map((k) => `<p><code>[${k}]</code> ${tb(ctx, 'span', `plegend:${key}:${k}`, { table: 'pack.script', key, field: `legend.${k}` })}</p>`).join('')}</dd></div>`;
      const kv = `<div>${ss('checks.r37.what', 'dt')}${tb(ctx, 'dd', `phead:${key}`, { table: 'pack.script', key, field: 'head' })}</div>${legend}${s.scope ? `<div>${ss('checks.r37.scope', 'dt')}${tb(ctx, 'dd', `pscope:${key}`, { table: 'pack.script', key, field: 'scope' })}</div>` : ''}<div>${ss('checks.seconds', 'dt')}${tb(ctx, 'dd', `pseconds:${key}`, { table: 'pack.seconds', key })}</div>`;
      return `<section class="script" id="${key}"><h2><code>${esc(key)}.py</code></h2><p class="links"><a href="${A('checks/round37/')}${key}.py" data-s="checks.script">${esc(S('checks.script'))}</a> · <a href="${A('checks/round37/')}${key}.log" data-s="checks.log">${esc(S('checks.log'))}</a> · <a href="${A('checks/round37/')}${key}.faults.log" data-s="checks.faultlog">${esc(S('checks.faultlog'))}</a></p>
<dl class="kv">${kv}<div>${ss('checks.rows', 'dt')}<dd>${ROWS_OF_SCRIPT.get(key).map((r) => rowRef(r, null)).join(' ')}</dd></div></dl>
<h3 data-s="checks.groups">${esc(S('checks.groups'))}</h3>${groups}<ol class="loglines tail">${tail}</ol>
<h3 data-s="checks.faults">${esc(S('checks.faults'))}</h3>${ss('checks.faults.p', 'p')}<ul class="faults">${faults}</ul>
<details class="more"><summary>${ss('checks.fulllog')}</summary>${tb(ctx, 'pre', `plogfile:${key}`, { table: 'pack.logfile', key }, { cls: 'logpre' })}</details></section>`;
    }).join('');
    const packHead = `<section class="script script--r37" id="round37"><h2 data-s="checks.r37">${esc(S('checks.r37'))}</h2>${ss('checks.r37.p', 'p')}${racc('checks:round37')}<p class="links"><a href="${A('checks/round37/')}README.md" data-s="checks.r37.readme">${esc(S('checks.r37.readme'))}</a> · <a href="${A('checks/round37/')}run_all.sh" data-s="checks.r37.runall">${esc(S('checks.r37.runall'))}</a></p><p class="small">${ss('checks.r37.ogg', 'span', 'k')} ${tb(ctx, 'span', 'pogg', { table: 'pack.ogg', key: '0' })}</p></section>`;
    // the Atlas's own checks of the rows these pages tell
    const other = new Map();
    for (const s of SECS) for (const id of s.chain.rows) for (const ev of (D.rows.get(id).evidence || [])) if (!/round36/.test(ev.script)) { const k = ev.script + '|' + ev.check; if (!other.has(k)) other.set(k, { ev, rows: [] }); other.get(k).rows.push(id); }
    const otherHtml = [...other.values()].map(({ ev, rows }) => {
      const rec = checkRecordOf(ev.script);
      const idx = rec ? D.checks.get(rec).ids.findIndex((x) => x.id === ev.check) : -1;
      const runKey = rec || ev.script;
      return `<li><p><code>${esc(ev.check)}</code> · <code>${esc(ev.script)}</code> · ${rows.map((r) => rowRef(r, null)).join(' ')}</p>${idx >= 0 ? tb(ctx, 'p', `ost:${ev.check}`, { table: 'checks', key: rec, field: `ids.${idx}.statement` }, { cls: 'ck-st' }) : ''}${runLine(ctx, runKey, 'o:' + ev.check)}</li>`;
    }).join('');
    const body = `<header class="page-head"><h1 data-s="nav.checks">${esc(S('nav.checks'))}</h1>${ss('checks.intro', 'p', 'page-intro')}${racc('page:checks')}</header>${blocks}${packHead}${pblocks}<section class="script"><h2 data-s="checks.other">${esc(S('checks.other'))}</h2><ul class="other">${otherHtml}</ul></section>`;
    PAGES.checks = shell(ctx, { title: `${S('nav.checks')} · ${S('brand')}`, body });
  }

  // ---------------------------------------------------------------- pictures
  {
    const ctx = new Ctx('pictures');
    const items = D.figures.map((f) => `${figureHtml(ctx, f, { cls: 'fig--pic' })}<p class="fig-meta">${ss('pics.rows', 'span', 'k')} ${tb(ctx, 'span', `figrow:${f.file}`, { table: 'figures', key: f.file, field: 'row' }, { part: 'md-plain', render: 'md' })}${f.secs.length ? ` · ${ss('pics.where', 'span', 'k')} ${f.secs.map((s) => `<a href="${s.slug}.html#fig-${slug(f.file)}">${s.n}</a>`).join(', ')}` : ''}</p>`).join('');
    const pitems = P.figures.map((f) => `${figureHtml(ctx, f, { cls: 'fig--pic' })}<p class="fig-meta">${ss('pics.rows', 'span', 'k')} ${tb(ctx, 'span', `figrow:${f.file}`, { table: 'pack.figures', key: f.file, field: 'row' }, { part: 'md-plain', render: 'ids', sec: null })} · ${ss('pics.where.bridges', 'span', 'k')} <a href="bridges.html#fig-${slug(f.file)}" data-s="b.title">${esc(S('b.title'))}</a></p>`).join('');
    const body = `<header class="page-head"><h1 data-s="nav.pictures">${esc(S('nav.pictures'))}</h1>${ss('pics.intro', 'p', 'page-intro')}${racc('page:pictures')}</header><section class="pics"><h2 data-s="pics.r36">${esc(S('pics.r36'))}</h2>${items}</section><section class="pics" id="round37"><h2 data-s="pics.r37">${esc(S('pics.r37'))}</h2>${ss('pics.r37.p', 'p', 'src-line')}${racc('pictures:round37')}${pitems}</section>`;
    PAGES.pictures = shell(ctx, { title: `${S('nav.pictures')} · ${S('brand')}`, body });
  }

  // ---------------------------------------------------------------- sources
  {
    const ctx = new Ctx('sources');
    const refs = (D.study.bySec.get('refs') || []).filter((u) => u.kind === 'li').map((u) => studyPiece(ctx, 'ref', { unit: u.id }, 'li')).join('');
    const refs2 = (P.study.bySec.get('refs') || []).filter((u) => u.kind === 'li').map((u) => studyPiece(ctx, 'ref2', { unit: u.id }, 'li', '', 'pack.study', { refs: true })).join('');
    const fetched = D.sourcesMd.filter((s) => /https?:\/\//.test(s.link)).map((s) => `<tr><td><code>${esc(s.id)}</code></td>${tb(ctx, 'td', `srcs:${s.sec}:${s.id}`, { table: 'sources_md', key: `${s.sec}:${s.id}`, field: 'source' }, { part: 'md-plain', render: 'md' })}${tb(ctx, 'td', `srcl:${s.sec}:${s.id}`, { table: 'sources_md', key: `${s.sec}:${s.id}`, field: 'link' }, { part: 'md-plain', render: 'mdlinks', cls: 'c-link' })}${s.grade ? tb(ctx, 'td', `srcg:${s.sec}:${s.id}`, { table: 'sources_md', key: `${s.sec}:${s.id}`, field: 'grade' }, { part: 'md-plain', render: 'md' }) : '<td></td>'}</tr>`).join('');
    const body = `<header class="page-head"><h1 data-s="nav.sources">${esc(S('nav.sources'))}</h1>${ss('src.intro', 'p', 'page-intro')}${racc('page:sources')}</header>
<section><h2 data-s="src.refs">${esc(S('src.refs'))}</h2><ol class="refs">${refs}</ol></section>
<section id="refs2"><h2 data-s="src.refs2">${esc(S('src.refs2'))}</h2><p class="src-line">${ss('src.refs2.p', 'span')}</p><p class="paper" data-s="src.paper">${linkRefs(esc(S('src.paper')))}</p><ol class="refs">${refs2}</ol></section>
<section><h2 data-s="src.fetched">${esc(S('src.fetched'))}</h2><div class="tbl"><table class="srct"><thead><tr><th data-s="src.col.id">${esc(S('src.col.id'))}</th><th data-s="src.col.source">${esc(S('src.col.source'))}</th><th data-s="src.col.link">${esc(S('src.col.link'))}</th><th data-s="src.col.grade">${esc(S('src.col.grade'))}</th></tr></thead><tbody>${fetched}</tbody></table></div></section>`;
    PAGES.sources = shell(ctx, { title: `${S('nav.sources')} · ${S('brand')}`, body });
  }

  // ---------------------------------------------------------------- about
  {
    const ctx = new Ctx('about');
    const chips = ['computed', 'standard-recomputed', 'input', 'ours', 'open'].map((k) => `<span class="chip chip--${k}" data-s="${STATUS_WORD[k]}">${esc(S(STATUS_WORD[k]))}</span>`).join(' ');
    const body = `<header class="page-head"><h1 data-s="nav.about">${esc(S('nav.about'))}</h1>${ss('about.intro', 'p', 'page-intro')}${racc('page:about')}</header><section class="about">
<h2 data-s="about.method">${esc(S('about.method'))}</h2>${ss('method.1', 'p')}${ss('method.2', 'p')}${ss('method.3', 'p')}${ss('method.4', 'p')}
<h2 data-s="about.registers">${esc(S('about.registers'))}</h2><ul class="regs"><li>${ss('reg.story.p')}</li><li>${ss('reg.research.p')}</li><li>${ss('reg.atlas.p')}</li><li>${ss('reg.standard.p')}</li></ul>
<h2 data-s="about.chips">${esc(S('about.chips'))}</h2><p class="chips-demo">${chips} <span class="chip chip--proposed" data-s="chip.proposed">${esc(S('chip.proposed'))}</span></p>${ss('chip.legend', 'p')}${ss('chip.legend.proposed', 'p')}
<h2 data-s="about.reads">${esc(S('about.reads'))}</h2>${ss('about.reads.p', 'p')}${ss('about.reads.pack', 'p')}<p>${ss('about.reads.pack.k', 'span', 'k')} ${tb(ctx, 'span', 'readme', { table: 'pack.readme', key: '0' }, { part: 'md-plain', render: 'md' })}</p>
<h2 data-s="about.italian">${esc(S('about.italian'))}</h2>${ss('about.italian.p', 'p')}
<h2 data-s="about.notthere">${esc(S('about.notthere'))}</h2>${ss('about.notthere.p', 'p')}
<h2 data-s="about.atlas">${esc(S('about.atlas'))}</h2>${ss('about.atlas.p', 'p')}<p class="atlas-link"><a href="${ATLAS_URL}" data-atlas-link data-s="about.atlas.link">${esc(S('about.atlas.link'))}</a></p><p class="stamp" data-s="release.stamp">${esc(S('release.stamp'))}</p>
<h2 data-s="about.licence">${esc(S('about.licence'))}</h2>${ss('about.licence.p', 'p')}<p><a href="https://polyformproject.org/licenses/noncommercial/1.0.0" data-s="about.licence.terms">${esc(S('about.licence.terms'))}</a></p>${ss('about.credit.study', 'p')}${ss('about.credit.audio', 'p')}${ss('about.credit.katex', 'p')}${ss('about.credit.fonts', 'p')}
</section>`;
    PAGES.about = shell(ctx, { title: `${S('nav.about')} · ${S('brand')}`, body });
  }

  // ---------------------------------------------------------------- sounds
  {
    const ctx = new Ctx('sounds');
    const clips = D.clips.map((c) => clipHtml(ctx, c.file.replace(/\.wav$/, ''), { narrate: true })).join('');
    const pclips = P.clips.map((c) => clipHtml(ctx, c.file.replace(/\.wav$/, ''), { narrate: true })).join('');
    const from = (id) => `<p class="from">${ss('ui.from', 'span', 'k')} ${ss(id)}</p>`;
    const tuning = (name) => `<div class="seg seg--sm" role="radiogroup" aria-label="${esc(S('aria.tuning'))}" data-tuning="${name}"><button type="button" role="radio" aria-checked="true" data-v="tet" data-s="ui.tet">${esc(S('ui.tet'))}</button><button type="button" role="radio" aria-checked="false" data-v="just" data-s="ui.just">${esc(S('ui.just'))}</button></div>`;
    const btn = (act, s, cls = '') => `<button type="button" class="btn${cls ? ' ' + cls : ''}" data-act="${act}" data-s="${s}">${esc(S(s))}</button>`;
    // the labels sounds.js reads from the page (hidden; the script never holds a word of its own)
    const labels = (ids) => `<span class="labels" hidden>${ids.map((id) => `<span data-s="${id}">${esc(S(id))}</span>`).join('')}</span>`;
    const inst = (id, name, h, p, inner, fromId) => `<section class="inst" id="i-${id}" data-inst="${name}"><h3 data-s="${h}">${esc(S(h))}</h3>${ss(p, 'p')}${racc(`instrument:${name}`)}
${inner}${from(fromId)}</section>`;
    const body = `<header class="page-head"><h1 data-s="nav.sounds">${esc(S('nav.sounds'))}</h1>${ss('sounds.intro', 'p', 'page-intro')}${racc('page:sounds')}</header>
<section class="synth"><h2 data-s="sounds.synth">${esc(S('sounds.synth'))}</h2>${ss('sounds.synth.p', 'p')}<noscript><p data-s="sounds.noscript">${esc(S('sounds.noscript'))}</p></noscript>
${inst('clock', 'clock', 'i1.h', 'i1.p', `<div class="inst-body"><div class="dial" data-dial aria-label="${esc(S('aria.clock'))}"></div><div class="ctl"><div class="pcs" data-pcs role="group" aria-label="${esc(S('aria.pcs'))}"></div><div class="row-btns">${btn('chord', 'i1.chord', 'btn--main')}${btn('arp', 'i1.arp')}${btn('clear', 'i1.clear')}${btn('stop', 'ui.stop')}</div><div class="row-btns"><span class="k" data-s="ui.tuning">${esc(S('ui.tuning'))}</span> ${tuning('clock')}</div><div class="presets"><span class="k" data-s="ui.presets">${esc(S('ui.presets'))}</span> <span data-presets></span></div>
<dl class="readout"><div><dt data-s="i1.card">${esc(S('i1.card'))}</dt><dd data-out="card">0</dd></div><div><dt data-s="i1.iv">${esc(S('i1.iv'))}</dt><dd data-out="iv">—</dd></div></dl>
<div class="dftbox"><p class="k" data-s="i1.dft">${esc(S('i1.dft'))}</p><div data-out="dft"></div><p class="small" data-out="exactnote" hidden><span data-s="i1.exact">${esc(S('i1.exact'))}</span> · <span data-out="setname"></span></p></div></div></div>`, 'i1.from')}
${inst('tonnetz', 'tonnetz', 'i2.h', 'i2.p', `<div class="inst-body inst-body--wide"><div class="tz" data-tz aria-label="${esc(S('aria.tz'))}"></div><div class="ctl"><div class="row-btns plr">${['P', 'L', 'R'].map((x) => `<button type="button" class="btn btn--plr" data-act="${x}" aria-label="${x}">${x}</button>`).join('')}</div><div class="row-btns"><span class="k" data-s="ui.tuning">${esc(S('ui.tuning'))}</span> ${tuning('tonnetz')}</div><div class="presets"><span class="k" data-s="ui.presets">${esc(S('ui.presets'))}</span> ${btn('hex', 'i2.hex')}${btn('oct', 'i2.oct')}${btn('beet', 'i2.beet')}${btn('lr', 'i2.lr')}${btn('stop', 'ui.stop')}</div>
<dl class="readout"><div><dt data-s="i2.word">${esc(S('i2.word'))}</dt><dd data-out="word">—</dd></div><div><dt data-s="i2.drift">${esc(S('i2.drift'))}</dt><dd data-out="drift">—</dd></div></dl><p class="small" data-out="chord"></p>${labels(['i2.cents', 'ui.hz'])}</div></div>`, 'i2.from')}
${inst('rhythm', 'rhythm', 'i3.h', 'i3.p', `<div class="inst-body"><div class="neck" data-neck aria-label="${esc(S('aria.neck'))}"></div><div class="ctl"><div class="nums"><label><span data-s="i3.k">${esc(S('i3.k'))}</span> <input type="number" min="1" max="16" value="3" data-in="k"></label><label><span data-s="i3.n">${esc(S('i3.n'))}</span> <input type="number" min="1" max="16" value="8" data-in="n"></label><label><span data-s="i3.tempo">${esc(S('i3.tempo'))}</span> <input type="number" min="60" max="600" step="10" value="240" data-in="tempo"></label></div><div class="row-btns">${btn('play', 'ui.play', 'btn--main')}${btn('stop', 'ui.stop')}</div><div class="presets"><span class="k" data-s="ui.presets">${esc(S('ui.presets'))}</span> <span data-presets></span></div>
<p class="rstr"><code data-out="str"></code></p><p class="small" data-out="match" hidden><span data-s="i3.match">${esc(S('i3.match'))}</span> <span data-out="mname"></span></p></div></div>`, 'i3.from')}
${inst('chain', 'chain', 'i4.h', 'i4.p', `<div class="inst-body"><div class="modes" data-modes aria-label="${esc(S('aria.modes'))}"></div><div class="ctl"><div class="nums"><label><span data-s="i4.N">${esc(S('i4.N'))}</span> <input type="number" min="1" max="8" value="5" data-in="N"></label><label><span data-s="i4.body">${esc(S('i4.body'))}</span> <select data-in="body"><option value="string" data-s="i4.body.string">${esc(S('i4.body.string'))}</option><option value="stiff" data-s="i4.body.stiff">${esc(S('i4.body.stiff'))}</option><option value="bar" data-s="i4.body.bar">${esc(S('i4.body.bar'))}</option><option value="membrane" data-s="i4.body.membrane">${esc(S('i4.body.membrane'))}</option></select></label></div><div class="row-btns">${btn('chain', 'i4.chain', 'btn--main')}${btn('ring', 'i4.ring')}${btn('tone', 'i4.tone')}${btn('stop', 'ui.stop')}</div>
<dl class="readout"><div><dt data-s="i4.exact">${esc(S('i4.exact'))}</dt><dd data-out="exact">—</dd></div></dl><p class="small" data-out="freqs"></p>${labels(['ui.hz'])}</div></div>`, 'i4.from')}
${inst('gliss', 'gliss', 'i5.h', 'i5.p', `<div class="curve" data-curve aria-label="${esc(S('aria.curve'))}"></div><div class="ctl ctl--row"><div class="seg seg--sm" role="radiogroup" aria-label="${esc(S('aria.timbre'))}" data-timbre><button type="button" role="radio" aria-checked="true" data-v="harmonic" data-s="i5.harm">${esc(S('i5.harm'))}</button><button type="button" role="radio" aria-checked="false" data-v="bar" data-s="i5.bar">${esc(S('i5.bar'))}</button></div>${btn('play', 'ui.play', 'btn--main')}${btn('stop', 'ui.stop')}<span class="small" data-out="r"></span>${labels(['ui.hz'])}</div>`, 'i5.from')}
${inst('commas', 'commas', 'i6.h', 'i6.p', `<div class="ctl ctl--row">${btn('just', 'i6.just')}${btn('tet', 'i6.tet')}${btn('comma', 'i6.comma')}${btn('chordj', 'i6.chordj')}${btn('chordt', 'i6.chordt')}${btn('stop', 'ui.stop')}</div><dl class="readout"><div><dt data-s="i6.beat">${esc(S('i6.beat'))}</dt><dd data-out="beat">—</dd></div></dl><p class="small" data-out="freqs"></p>${labels(['ui.hz'])}`, 'i6.from')}
${inst('crt', 'crt', 'i7.h', 'i7.p', `<div class="inst-body"><div class="crt" data-crt aria-label="${esc(S('aria.crt'))}"></div><div class="ctl"><div class="row-btns">${btn('fifths', 'i7.fifths', 'btn--main')}${btn('cycles', 'i7.cycles')}${btn('mirror', 'i7.mirror')}${btn('clear', 'i1.clear')}${btn('stop', 'ui.stop')}</div><div class="row-btns"><div class="seg seg--sm" role="radiogroup" aria-label="${esc(S('aria.note'))}" data-sound><button type="button" role="radio" aria-checked="true" data-v="note" data-s="i7.note">${esc(S('i7.note'))}</button><button type="button" role="radio" aria-checked="false" data-v="triad" data-s="i7.triad">${esc(S('i7.triad'))}</button></div></div><div class="presets"><span class="k" data-s="ui.presets">${esc(S('ui.presets'))}</span> ${btn('diatonic', 'i7.diatonic')}${btn('aug', 'i7.aug')}${btn('dim', 'i7.dim')}${btn('whole', 'i7.whole')}</div>
<dl class="readout"><div><dt data-s="i7.set">${esc(S('i7.set'))}</dt><dd data-out="set">—</dd></div><div><dt data-s="i7.coords">${esc(S('i7.coords'))}</dt><dd data-out="coords">—</dd></div><div><dt data-s="i7.image">${esc(S('i7.image'))}</dt><dd data-out="image">—</dd></div><div><dt data-s="i7.mirror.rule">${esc(S('i7.mirror.rule'))}</dt><dd data-out="rule">—</dd></div></dl></div></div>`, 'i7.from')}
${inst('rings', 'rings', 'i8.h', 'i8.p', `<div class="inst-body inst-body--wide"><div class="strip" data-strip aria-label="${esc(S('aria.strip'))}"></div><div class="ctl"><div class="row-btns">${btn('solved', 'i8.solved', 'btn--main')}${btn('nn', 'i8.nn')}${btn('pos7', 'i8.pos7')}${btn('pos4', 'i8.pos4')}${btn('ringA', 'i8.ringA')}${btn('ringB', 'i8.ringB')}${btn('bell12', 'i8.bell12')}${btn('bell3', 'i8.bell3')}${btn('stop', 'ui.stop')}</div>
<dl class="readout"><div><dt data-s="i8.partials">${esc(S('i8.partials'))}</dt><dd data-out="partials">—</dd></div><div><dt data-s="i8.weights">${esc(S('i8.weights'))}</dt><dd data-out="weights">—</dd></div><div><dt data-s="i8.loudest">${esc(S('i8.loudest'))}</dt><dd data-out="loudest">—</dd></div></dl><p class="small" data-out="note"></p>${labels(['ui.hz', 'i8.note.solved', 'i8.note.nn', 'i8.note.pos', 'i8.note.ab', 'i8.note.bell', 'i8.note.bell3'])}</div></div>`, 'i8.from')}
${inst('rows', 'rows', 'i9.h', 'i9.p', `<div class="inst-body inst-body--wide"><div class="staff" data-staff aria-label="${esc(S('aria.staff'))}"></div><div class="ctl"><div class="nums"><label><span data-s="i9.index">${esc(S('i9.index'))}</span> <input type="number" min="1" max="3856" value="1" data-in="index"></label><div class="seg seg--sm" role="radiogroup" aria-label="${esc(S('aria.len'))}" data-len><button type="button" role="radio" aria-checked="true" data-v="0.3" data-s="i9.short">${esc(S('i9.short'))}</button><button type="button" role="radio" aria-checked="false" data-v="0.5" data-s="i9.long">${esc(S('i9.long'))}</button></div></div><div class="row-btns">${btn('row', 'i9.row', 'btn--main')}${btn('retro', 'i9.retro')}${btn('inv', 'i9.inv')}${btn('rt6', 'i9.rt6')}${btn('stop', 'ui.stop')}</div><div class="presets"><span class="k" data-s="ui.presets">${esc(S('ui.presets'))}</span> ${btn('berg', 'i9.berg')}${btn('least', 'i9.least')}${btn('greatest', 'i9.greatest')}${btn('wedge', 'i9.wedge')}</div>
<dl class="readout"><div><dt data-s="i9.pcs">${esc(S('i9.pcs'))}</dt><dd data-out="pcs">—</dd></div><div><dt data-s="i9.ints">${esc(S('i9.ints'))}</dt><dd data-out="ints">—</dd></div><div><dt data-s="i9.melody">${esc(S('i9.melody'))}</dt><dd data-out="melody">—</dd></div><div><dt data-s="i9.class">${esc(S('i9.class'))}</dt><dd data-out="class">—</dd></div><div><dt data-s="i9.hex">${esc(S('i9.hex'))}</dt><dd data-out="hex">—</dd></div><div><dt data-s="i9.sym">${esc(S('i9.sym'))}</dt><dd data-out="sym">—</dd></div></dl>${labels(['ui.hz', 'i9.yes', 'i9.no', 'i9.class.tir', 'i9.class.g3'])}</div></div>`, 'i9.from')}
</section>
<section class="clips" id="clips"><h2 data-s="sounds.clips">${esc(S('sounds.clips'))}</h2>${clips}${tb(ctx, 'p', 'clipsoutro', { table: 'clips.outro' }, { part: 'md-plain', render: 'md', cls: 'src-line' })}<div id="clips-round37">${ss('sounds.clips.r37', 'p', 'src-line')}${pclips}${P.clipOutros.map((o, i) => tb(ctx, 'p', 'pclipsoutro', { table: 'pack.clips.outro', key: String(i) }, { part: 'md-plain', render: 'md', cls: 'src-line' })).join('')}</div></section>`;
    PAGES.sounds = shell(ctx, { title: `${S('nav.sounds')} · ${S('brand')}`, body, scripts: `\n<script src="${A('sounds-data.js')}" defer></script>\n<script src="${A('sounds.js')}" defer></script>` });
  }
  return PAGES;
}
const ATLAS_URL = 'https://toy-model-v0.vercel.app/#/music';

// ------------------------------------------------------------------ the data of the sounds page (a script, not JSON: file:// pages fetch nothing)
function soundsData() {
  const F = D.figdata, G = P.figdata;
  const ct = F['cents_table.json'], dc = F['dissonance_curve.json'], pd = F['plr_dual.json'], ev = F['even.json'], cm = F['chain_modes.json'], pa = F['partials.json'], dft = F['dft.json'];
  const just = {}; for (const r of ct.rows) if (r.semitones < 12) just[r.semitones] = r.just;
  const crt = G['crt_tonnetz.json'], hr = G['harmonic_ring.json'], bl = G['bell_levels.json'], sets = G['sets.json'], cr = G['clips_rings.json'], rg = G['rings.json'], air = G['all_interval_rows.json'], berg = G['berg_row.json'], fr = G['fig_rows.json'], hx = G['hexachords.json'], cl = G['clips.json'];
  const setOf = (s) => sets.realizable.find((r) => r.set.join() === s.join());
  return {
    about: 'The numbers of the Sounds page, copied by gen/build.mjs from checks/selfcheck/round36/figdata/ of the Cascade Atlas ' + VERSION.atlas + ' and from checks/selfcheck/round37/figdata/ of the pack The bridges drilled (each key names its file).',
    C4: ct.C4_hz, just, justFrom: 'cents_table.json', amps: dc.amplitudes, ampsFrom: 'dissonance_curve.json',
    commas: ct.commas, chordBeats: ct.chord_beats_hz_12tet, hexatonic: ct.hexatonic,
    dft: { convention: dft.convention, sets: dft.sets.map((s) => ({ name: s.name, pcs: s.pcs, abs2: s.abs2_exact, abs: s.abs })), from: 'dft.json' },
    plr: { nodes: pd.nodes, edges: pd.edges, hexatonic: pd.hexatonic, octatonic: pd.octatonic, LR_cycle: pd.LR_cycle, beethoven: pd.beethoven_first_19, from: 'plr_dual.json' },
    even: { rhythms: ev.rhythms, from: 'even.json' },
    chain: { P: cm.P_N_fixed_ends, C12: { omega2: cm.C12.omega2, omega2_float: cm.C12.omega2_float }, from: 'chain_modes.json' },
    partials: { string: pa.string, stiff: pa.stiff_string, bar: pa.bar_free_free.ratio, membrane: pa.membrane.ratio, from: 'partials.json' },
    curve: { r: dc.r, D_harmonic: dc.D_harmonic, D_bar: dc.D_bar, minima_harmonic: dc.minima_harmonic.map((m) => ({ r: m.r, just: m.just })), minima_bar: dc.minima_bar.map((m) => ({ r: m.r, kind: m.kind })), glide_times_s: dc.glide_times_s, f1: dc.f1_hz, partials_bar: dc.partials_bar, from: 'dissonance_curve.json' },
    // round 37: the three instruments of the drill
    crt: { cells: crt.cells, fifths_path_ab: crt.fifths_path_ab, fifths_pcs: crt.fifths_pcs, semitone_ab: crt.semitone_ab, H1: crt.H1_cycles, mirror_x7: crt.mirror_x7, from: 'crt_tonnetz.json' },
    rings: {
      solved: { weights_exact: hr.weights_exact, weights: hr.weights, spectrum: hr.spectrum_harmonic, pluck: hr.pluck_amplitudes, f1: cl.f1_hz }, nn: { spectrum: hr.spectrum_nearest_neighbour, cents: hr.cents_nearest_neighbour, f1: cl.f1_hz },
      pos7: { set: setOf([7, 8, 9, 10, 11, 12]), unit: cr.clip20[0].measured_hz[0] / cr.clip20[0].assignment[0] }, pos4: { set: setOf([4, 6, 7, 8, 9, 10]), unit: cr.clip20[1].measured_hz[0] / Math.min.apply(null, cr.clip20[1].assignment) },
      ringA: { hz: cr.clip21.ringA_hz, amps: cr.clip21.ringA_amps, springs: rg.ring_A.springs, masses: rg.ring_A.masses }, ringB: { hz: cr.clip21.ringB_hz, springs: rg.ring_B.springs, masses: rg.ring_B.masses },
      bell12: { levels: bl.cube12.map((l) => ({ j: l.j, ratio: l.ratio_float, weight: l.weight_float, weight_exact: l.weight, cents: l.cents })), f1: cl.f1_hz, tau1: cl.clip13.tau1_s }, bell3: { levels: bl.cube3.map((l) => ({ j: l.j, ratio: l.ratio_float, weight: l.weight_float, weight_exact: l.weight })), f1: cl.f1_hz, tau1: cl.clip13.tau1_s },
      from: ['harmonic_ring.json', 'sets.json', 'clips_rings.json', 'rings.json', 'bell_levels.json', 'clips.json'],
    },
    rows: { rows: air.rows, class_TIR: air.class_TIR, class_G3: air.class_G3, counts: air.counts, symmetric: air.symmetric, tritone_position: air.tritone_position, first_hexachord: air.first_hexachord, hexachord_names: air.hexachord_names, combinatoriality: air.combinatoriality, hexachords: hx.classes.map((c) => ({ name: c.name, prime_form: c.prime_form, type: c.type })), types: hx.types,
      berg: { pcs: berg.pcs_C0, names: berg.names, intervals: berg.intervals, melody_midi: berg.melody_midi, retrograde_midi: berg.retrograde_midi, retrograde_pcs: berg.retrograde_pcs, first_hexachord: berg.first_hexachord, symmetric: berg.symmetric_R_eq_T6 }, wedge: { pcs: fr.wedge.pcs, intervals: fr.wedge.intervals, name: fr.wedge.name },
      voicing: air.voicing, note_s: G['clips_rows.json'].note_s, partials: G['clips_rows.json'].partials, amplitudes: G['clips_rows.json'].amplitudes, from: ['all_interval_rows.json', 'berg_row.json', 'fig_rows.json', 'hexachords.json', 'clips_rows.json'] },
  };
}

// ------------------------------------------------------------------ build both languages
const ALL = {};
for (const lang of VERSION.languages) {
  L = lang === 'en' ? EN : { lang: 'it', dir: 'it/', prefix: '../', strings: IT.strings, racconto: IT.racconto, wanted: new Set(), rendered: new Map() };
  const pages = buildPages();
  for (const [p, html] of Object.entries(pages)) ALL[L.dir + p] = html;
  if (lang === 'it') for (const [target] of IT.racconto) if (!L.rendered.has(target)) LOG.it.unrendered.push(target);
}
L = EN;

// ------------------------------------------------------------------ write
fs.mkdirSync(OUT, { recursive: true });
if (!IT) fs.rmSync(path.join(OUT, 'it'), { recursive: true, force: true }); // SDV_IT=off: the English site alone
for (const d of ['figures/round37', 'audio', 'checks/round37', 'content', 'katex/fonts', ...(IT ? ['it'] : [])]) fs.mkdirSync(path.join(OUT, d), { recursive: true });
for (const [p, html] of Object.entries(ALL)) { fs.writeFileSync(path.join(OUT, `${p}.html`), html); LOG.pages.push(p); }
const copy = (a, b) => { const buf = fs.readFileSync(a); try { if (Buffer.compare(fs.readFileSync(b), buf) === 0) return; } catch {} fs.writeFileSync(b, buf); };
for (const f of D.figures) copy(path.join(D.dirs.figs, f.file), path.join(OUT, 'figures', f.file));
for (const f of P.figures) copy(path.join(P.dirs.figs, f.file), path.join(OUT, 'figures', 'round37', f.file));
copy(path.join(GEN, 'figures', 'mark.svg'), path.join(OUT, 'figures', 'mark.svg'));
const OGG = process.env.SDV_OGG || path.join(path.dirname(SITE), 'audio_ogg');
for (const c of D.clips) copy(path.join(OGG, c.file.replace(/\.wav$/, '.ogg')), path.join(OUT, 'audio', c.file.replace(/\.wav$/, '.ogg')));
for (const c of P.clips) copy(path.join(P.dirs.audio, c.file.replace(/\.wav$/, '.ogg')), path.join(OUT, 'audio', c.file.replace(/\.wav$/, '.ogg')));
for (const f of ['music_sound.py', 'music_symmetry.py']) copy(path.join(D.dirs.r36, f), path.join(OUT, 'checks', f));
for (const f of fs.readdirSync(D.dirs.logs).filter((x) => x.endsWith('.log'))) copy(path.join(D.dirs.logs, f), path.join(OUT, 'checks', f));
for (const s of SCRIPTS) { copy(path.join(P.dirs.r37, `${s}.py`), path.join(OUT, 'checks', 'round37', `${s}.py`)); copy(path.join(P.dirs.logs, `${s}.log`), path.join(OUT, 'checks', 'round37', `${s}.log`)); copy(path.join(P.dirs.logs, `${s}.faults.log`), path.join(OUT, 'checks', 'round37', `${s}.faults.log`)); }
for (const f of ['README.md', 'run_all.sh']) copy(path.join(P.dirs.r37, f), path.join(OUT, 'checks', 'round37', f));
// KaTeX's stylesheet and fonts, shipped with the site (the sister site's way)
const KATEX_DIST = path.join(path.dirname(require.resolve('katex/package.json', { paths: [SITE, '/opt/npm-tools/node_modules'] })), 'dist');
copy(path.join(KATEX_DIST, 'katex.min.css'), path.join(OUT, 'katex', 'katex.min.css'));
for (const f of fs.readdirSync(path.join(KATEX_DIST, 'fonts')).filter((x) => x.endsWith('.woff2'))) copy(path.join(KATEX_DIST, 'fonts', f), path.join(OUT, 'katex', 'fonts', f));
for (const f of ['site.css', 'site.js', 'sounds.js']) copy(path.join(GEN, 'assets', f), path.join(OUT, f));
fs.writeFileSync(path.join(OUT, 'sounds-data.js'), `// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors\nwindow.SDV_DATA = ${JSON.stringify(soundsData())};\n`);
copy(path.join(GEN, 'assets', 'RELEASE_NOTES.md'), path.join(OUT, 'RELEASE_NOTES.md'));
copy(path.join(REPO, 'LICENSE'), path.join(OUT, 'LICENSE'));
const enPages = Object.keys(ALL).filter((p) => !p.startsWith('it/'));
VERSION.counts = {
  pages: enPages.length, pagesIt: Object.keys(ALL).length - enPages.length, sections: SECS.length, rowBlocks: SECS.reduce((n, s) => n + s.chain.rows.length, 0), proposedRows: P.rows.size, tracedBlocks: TRACE.length,
  figures: D.figures.length + P.figures.length, clips: D.clips.length + P.clips.length, lensEntries: D.lens.dictionary.length, readings: D.readings.length, katex: LOG.katex, htmlData: LOG.htmlData,
  instruments: 9, scripts: 2 + SCRIPTS.length, strings: D.site.size, narrations: IT ? IT.racconto.size : 0,
};
VERSION.inputs = D.inputs.map((p) => ({ file: path.relative(REPO, p), sha256: sha(p) }));
VERSION.packInputs = P.inputs.map((p) => ({ file: path.relative(PACK, p), sha256: sha(p) }));
fs.writeFileSync(path.join(OUT, 'content', 'version.json'), JSON.stringify(VERSION, null, 1) + '\n');
fs.mkdirSync(BUILD, { recursive: true });
fs.writeFileSync(path.join(BUILD, 'trace.json'), JSON.stringify({ version: VERSION, blocks: TRACE }, null, 0));
// the Italian build: what is missing, what is a stub, what is rendered nowhere
const itProblems = [];
if (IT) {
  const uniq = (a) => [...new Set(a)];
  LOG.it.missingStrings = uniq(LOG.it.missingStrings); LOG.it.missingNarrations = uniq(LOG.it.missingNarrations); LOG.it.stubs = uniq(LOG.it.stubs);
  if (LOG.it.missingStrings.length) itProblems.push(`strings_it.json lacks ${LOG.it.missingStrings.length} strings: ${LOG.it.missingStrings.join(', ')}`);
  if (LOG.it.missingNarrations.length) itProblems.push(`racconto.json lacks ${LOG.it.missingNarrations.length} narrations: ${LOG.it.missingNarrations.map((t) => 'r:' + t).join(', ')}`);
  if (LOG.it.stubs.length) itProblems.push(`racconto.json holds ${LOG.it.stubs.length} stubs: ${LOG.it.stubs.join(', ')}`);
  if (IT.stubStrings.length) itProblems.push(`strings_it.json holds ${IT.stubStrings.length} stub strings`);
  if (LOG.it.unrendered.length) itProblems.push(`${LOG.it.unrendered.length} narrations have no target on the site: ${LOG.it.unrendered.map((t) => 'r:' + t).join(', ')}`);
}
const buildLog = JSON.stringify({ ...LOG, itProblems, usedStrings: [...USED_S].sort(), seconds: (Date.now() - t0) / 1000 }, null, 1);
fs.writeFileSync(path.join(BUILD, 'build_log.json'), buildLog);
fs.mkdirSync(path.join(SITE, 'record'), { recursive: true });
fs.writeFileSync(path.join(SITE, 'record', 'build_log.json'), buildLog); // the record of the run, beside the notes
console.log(`built ${enPages.length} pages${IT ? ` (and ${Object.keys(ALL).length - enPages.length} in Italian, SDV_IT=${IT_MODE})` : ''} into ${OUT}: ${TRACE.length} traced blocks, ${VERSION.counts.rowBlocks} row blocks + ${P.rows.size} proposed, ${VERSION.counts.figures} figures, ${VERSION.counts.clips} clips, ${D.lens.dictionary.length} lens entries, ${D.readings.length} readings; KaTeX ${LOG.katex} (\\htmlData ${LOG.htmlData}), fallbacks ${LOG.katexFallback.length}, warnings ${LOG.warnings.length}; ${((Date.now() - t0) / 1000).toFixed(1)} s`);
for (const w of LOG.warnings) console.log('  warning: ' + w);
for (const w of LOG.katexFallback) console.log('  katex: ' + w);
for (const p of itProblems) console.log('  italian: ' + p);
if (itProblems.length && IT_MODE !== 'partial') { console.log('the Italian build is not complete (SDV_IT=partial renders the missing narrations as placeholders)'); process.exit(1); }
