// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// test_sounds.mjs — the synthesizer's own test. Chromium (Playwright) opens out/sounds.html from the disk, the page's
// engine (sounds.js) renders instruments into an OfflineAudioContext, and the test measures what came out, as the
// Atlas's group mu·AUDIO measures its clips: FFT peaks (Hann window, zero-padded, parabolic interpolation), onsets on
// the envelope, a beat on the envelope's spectrum. The measuring code is the test's own (an independent route), not
// the page's. Asserted to within 1 %: the chord's partials, the rhythm's onsets and the chain's five modes.
// Usage: node gen/test_sounds.mjs           exit 0 when every assertion holds; the record goes to record/test_sounds.json
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { chromium } = (() => { try { return require('playwright'); } catch { return require('/opt/npm-tools/node_modules/playwright'); } })();
const SITE = path.dirname(path.dirname(new URL(import.meta.url).pathname));
const OUT = path.join(SITE, 'out');
const exe = '/opt/pw-browsers/chromium-1194/chrome-linux/chrome';

const browser = await chromium.launch({ executablePath: fs.existsSync(exe) ? exe : undefined, args: ['--autoplay-policy=no-user-gesture-required'] });
const page = await browser.newPage();
const consoleErrors = [];
page.on('console', (m) => { if (m.type() === 'error' && !/fonts\.(googleapis|gstatic)|ERR_TUNNEL|ERR_INTERNET|ERR_NAME/.test(m.text() + ((m.location() || {}).url || ''))) consoleErrors.push(m.text()); });
page.on('pageerror', (e) => consoleErrors.push('pageerror: ' + e.message));
await page.goto('file://' + path.join(OUT, 'sounds.html'), { waitUntil: 'load' });
await page.waitForFunction(() => window.SDV_ENGINE && window.SDV_DATA);

const R = await page.evaluate(async () => {
  const E = window.SDV_ENGINE, DATA = window.SDV_DATA, SR = 44100, results = [];
  const ok = (name, pass, detail) => results.push({ name, pass: !!pass, detail });
  // ---- the measuring tools (the test's own)
  function fft(re, im) {
    const n = re.length;
    for (let i = 1, j = 0; i < n; i++) { let bit = n >> 1; for (; j & bit; bit >>= 1) j ^= bit; j ^= bit; if (i < j) { [re[i], re[j]] = [re[j], re[i]]; [im[i], im[j]] = [im[j], im[i]]; } }
    for (let len = 2; len <= n; len <<= 1) {
      const a = -2 * Math.PI / len, wr = Math.cos(a), wi = Math.sin(a);
      for (let i = 0; i < n; i += len) { let cr = 1, ci = 0; for (let j = 0; j < len / 2; j++) { const ur = re[i + j], ui = im[i + j], vr = re[i + j + len / 2] * cr - im[i + j + len / 2] * ci, vi = re[i + j + len / 2] * ci + im[i + j + len / 2] * cr; re[i + j] = ur + vr; im[i + j] = ui + vi; re[i + j + len / 2] = ur - vr; im[i + j + len / 2] = ui - vi; const t = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = t; } }
    }
  }
  function spectrum(x, sr, t0, t1, pad = 4) {
    const a = Math.floor(t0 * sr), b = Math.floor(t1 * sr), len = b - a;
    let n = 1; while (n < len * pad) n <<= 1;
    const re = new Float64Array(n), im = new Float64Array(n);
    for (let i = 0; i < len; i++) re[i] = x[a + i] * (0.5 - 0.5 * Math.cos(2 * Math.PI * i / (len - 1)));
    fft(re, im);
    const mag = new Float64Array(n / 2);
    for (let i = 0; i < n / 2; i++) mag[i] = Math.hypot(re[i], im[i]);
    return { mag, df: sr / n };
  }
  function peakNear(S, f, tol) {
    const lo = Math.max(1, Math.floor(f * (1 - tol) / S.df)), hi = Math.min(S.mag.length - 2, Math.ceil(f * (1 + tol) / S.df));
    let k = lo;
    for (let i = lo; i <= hi; i++) if (S.mag[i] > S.mag[k]) k = i;
    const y0 = S.mag[k - 1], y1 = S.mag[k], y2 = S.mag[k + 1], d = (y0 - y2) / (2 * (y0 - 2 * y1 + y2) || 1);
    return { f: (k + (Number.isFinite(d) ? d : 0)) * S.df, mag: y1 };
  }
  async function render(dur, fn) {
    const oc = new OfflineAudioContext(1, Math.ceil(SR * dur), SR);
    const m = E.master(oc);
    fn(oc, m);
    const buf = await oc.startRendering();
    return buf.getChannelData(0);
  }
  const peakAbs = (x) => { let p = 0; for (let i = 0; i < x.length; i++) p = Math.max(p, Math.abs(x[i])); return p; };

  // ---- 1. the clock: a chord's partials, in 12-TET and in just intonation
  for (const tuning of ['tet', 'just']) {
    const pcs = [0, 4, 7];
    const x = await render(2.2, (oc, m) => E.playChord(oc, m, 0.05, pcs, tuning, 2.0, false));
    const S = spectrum(x, SR, 0.15, 1.95);
    let gmax = 0; for (const v of S.mag) gmax = Math.max(gmax, v);
    let worst = 0, weakest = 1, n = 0;
    const voices = pcs.map((pc) => E.freqOf(pc, tuning));
    for (const f of voices) for (let k = 1; k <= 6; k++) {
      const want = k * f, p = peakNear(S, want, 0.003); // searched within ±0.3 %, asserted within 1 %
      worst = Math.max(worst, Math.abs(p.f / want - 1)); weakest = Math.min(weakest, p.mag / gmax); n++;
    }
    ok(`clock: the ${tuning} major chord C–E–G has its 18 partials k·f (k = 1 … 6) as spectral peaks within 1 %`, worst < 0.01 && weakest > 0.05, { voicesHz: voices.map((f) => +f.toFixed(4)), partials: n, worstRelError: +worst.toExponential(2), weakestPeakRel: +weakest.toFixed(3) });
    ok(`clock: the ${tuning} chord's peak stays under the master level of −6 dBFS`, peakAbs(x) <= Math.pow(10, -6 / 20) + 1e-3, { peak: +peakAbs(x).toFixed(4), dBFS: +(20 * Math.log10(peakAbs(x))).toFixed(2) });
  }
  // the just voices are cents_table.json's 4:5:6 on C4
  ok('clock: just C, E, G are 261.6256, 327.0320 and 392.4383 Hz (cents_table.json: 1, 5/4, 3/2 on C4)', [0, 4, 7].every((pc, i) => Math.abs(E.freqOf(pc, 'just') - DATA.C4 * [1, 1.25, 1.5][i]) < 1e-9), [0, 4, 7].map((pc) => E.freqOf(pc, 'just')));
  // |f̂(k)| against dft.json, the interval vectors of the Z-pair
  let dmax = 0;
  for (const s of DATA.dft.sets) { const a = E.dftAbs(s.pcs); for (let k = 0; k <= 6; k++) dmax = Math.max(dmax, Math.abs(a[k] - s.abs[String(k)])); }
  ok('clock: |f̂(k)| computed in the page equals dft.json\'s for its twelve named sets, k = 0 … 6 (to 10⁻⁵)', dmax < 1e-5, { maxDiff: dmax });
  const z15 = E.intervalVector([0, 1, 4, 6]), z29 = E.intervalVector([0, 1, 3, 7]);
  ok('clock: 4-Z15 and 4-Z29 have one interval vector, ⟨1 1 1 1 1 1⟩', z15.join() === z29.join() && z15.join() === '1,1,1,1,1,1', { z15, z29 });

  // ---- 2. rhythms: Bjorklund against even.json and against E(k, n) = {⌊in/k⌋}; the onsets of a rendered rhythm
  const named = DATA.even.rhythms.map((r) => ({ k: r.k, n: r.n, name: r.name, page: E.bjorklund(r.k, r.n), file: r.bjorklund }));
  ok('rhythm: Bjorklund in the page gives even.json\'s five strings (ms·EVEN)', named.every((r) => r.page === r.file), named);
  let rot = 0, pairs = 0;
  for (let n = 1; n <= 16; n++) for (let k = 1; k <= n; k++) {
    pairs++;
    const s = E.bjorklund(k, n), f = Array.from({ length: n }, () => '.');
    for (let i = 0; i < k; i++) f[Math.floor(i * n / k)] = 'x';
    const fs = f.join('');
    let isRot = false; for (let r = 0; r < n; r++) if (s.slice(r) + s.slice(0, r) === fs) isRot = true;
    if (isRot) rot++;
  }
  ok('rhythm: for all 136 pairs 1 ≤ k ≤ n ≤ 16 the page\'s Bjorklund string is a rotation of E(k, n) = {⌊in/k⌋}', rot === pairs && pairs === 136, { pairs, rotations: rot });
  for (const [k, n, ppm] of [[7, 12, 360], [3, 8, 240], [5, 16, 480]]) {
    const str = E.bjorklund(k, n), dt = 60 / ppm, t0 = 0.05;
    const x = await render(t0 + n * dt + 0.3, (oc, m) => E.scheduleRhythm(oc, m, t0, str, ppm, 1));
    // the onset pulses: the 1200 Hz click's energy in each pulse (Goertzel), against the 3.5 kHz tick
    const g = (a, b, f) => { let s0 = 0, s1 = 0, s2 = 0; const c = 2 * Math.cos(2 * Math.PI * f / SR); for (let i = a; i < b; i++) { s0 = x[i] + c * s1 - s2; s2 = s1; s1 = s0; } return Math.sqrt(s1 * s1 + s2 * s2 - c * s1 * s2); };
    const e = []; for (let i = 0; i < n; i++) { const a = Math.floor((t0 + i * dt) * SR); e.push(g(a, a + Math.floor(0.06 * SR), 1200)); }
    const emax = Math.max(...e), heard = e.map((v) => (v > 0.3 * emax ? 'x' : '.')).join('');
    // the onset times: at each onset, the first sample whose level passes a fifth of the click's peak (the soft ticks
    // of the other pulses sit under the tail of the click before them, so only the onsets are timed)
    let worst = 0;
    for (let i = 0; i < n; i++) {
      if (str[i] !== 'x') continue;
      const ti = t0 + i * dt, a = Math.floor((ti - 0.004) * SR), b = Math.floor((ti + 0.04) * SR);
      let pk = 0; for (let j = a; j < b; j++) pk = Math.max(pk, Math.abs(x[j]));
      let j = a; while (j < b && Math.abs(x[j]) < 0.2 * pk) j++;
      worst = Math.max(worst, Math.abs(j / SR - ti) / dt);
    }
    ok(`rhythm: E(${k}, ${n}) rendered at ${ppm} pulses a minute has its onsets on ${str}, each within 1 % of its pulse`, heard === str && worst < 0.01, { expected: str, heard, worstOnsetError: `${(100 * worst).toFixed(3)} % of a pulse (${(1000 * worst * dt).toFixed(3)} ms)` });
  }

  // ---- 3. the chain of five masses: its five modes, ω_k = 2 sin(kπ/12) scaled to ω₁ = 220 Hz (clip 1's 220.00 … 821.05)
  {
    const x = await render(0.05 + 5 * 0.55 + 0.2, (oc, m) => E.chainModes(oc, m, 0.05, 5));
    const want = [1, 2, 3, 4, 5].map((k) => 220 * Math.sin(k * Math.PI / 12) / Math.sin(Math.PI / 12));
    const clip = [220.00, 425.01, 601.05, 736.13, 821.05];
    const got = want.map((f, i) => { const S = spectrum(x, SR, 0.05 + i * 0.55 + 0.04, 0.05 + i * 0.55 + 0.46, 8); return peakNear(S, f, 0.05).f; });
    const err = got.map((g, i) => Math.abs(g / want[i] - 1)), errClip = got.map((g, i) => Math.abs(g / clip[i] - 1));
    ok('chain: the five modes of N = 5 sound at 220.00, 425.01, 601.05, 736.13, 821.05 Hz, each within 1 % (measured by FFT)', Math.max(...err) < 0.01 && Math.max(...errClip) < 0.01, { expectedHz: want.map((f) => +f.toFixed(3)), measuredHz: got.map((f) => +f.toFixed(3)), worstRelError: +Math.max(...err).toExponential(2) });
    const exact = DATA.chain.P['5'].omega2_float, w = E.chainFreqs(5, 1).map((f) => f * 2 * Math.sin(Math.PI / 12));
    ok('chain: the page\'s ω_k² for N = 5 equal chain_modes.json\'s 2 − √3, 1, 2, 3, 2 + √3', w.every((v, i) => Math.abs(v * v - exact[i]) < 1e-12), { page: w.map((v) => +(v * v).toFixed(12)), file: exact });
  }

  // ---- 4. more: the ring's modes, the comma's beat, the hexatonic drift, the glissando's end points, the Tonnetz edges
  {
    const x = await render(0.05 + 12 * 0.5 + 0.1, (oc, m) => E.ringModes(oc, m, 0.05));
    const want = DATA.chain.C12.omega2_float.map((w2) => 440 * Math.sqrt(w2));
    let worst = 0;
    want.forEach((f, k) => { if (f === 0) return; const S = spectrum(x, SR, 0.05 + k * 0.5 + 0.04, 0.05 + k * 0.5 + 0.42, 8); worst = Math.max(worst, Math.abs(peakNear(S, f, 0.05).f / f - 1)); });
    const silent = peakAbs(x.subarray(Math.floor(0.06 * SR), Math.floor(0.5 * SR)));
    ok('ring: the modes k = 1 … 11 of C₁₂ sound at 440·ω_k (227.76 … 880.00 Hz) within 1 %, mode 0 silent', worst < 0.01 && silent < 1e-6, { worstRelError: +worst.toExponential(2), mode0Peak: silent });
  }
  {
    const f1 = 220, f2 = 220 * E.ratio(DATA.commas.Pythagorean);
    const x = await render(3.3, (oc, m) => { E.tone(oc, m, 0.05, 3.2, f1, [1], [1], 0.45); E.tone(oc, m, 0.05, 3.2, f2, [1], [1], 0.45); });
    // the envelope: the squared signal averaged over 10 ms, then its spectrum
    const a = Math.floor(0.3 * SR), b = Math.floor(3.0 * SR), win = Math.floor(0.01 * SR), env = new Float64Array(b - a);
    let acc = 0; for (let i = a - win; i < b; i++) { acc += x[i] * x[i]; if (i - win >= a - win) acc -= x[i - win] * x[i - win]; if (i >= a) env[i - a] = acc / win; }
    const mean = env.reduce((s, v) => s + v, 0) / env.length; for (let i = 0; i < env.length; i++) env[i] -= mean;
    const S = spectrum(env, SR, 0, env.length / SR - 1e-6, 16);
    const beat = peakNear(S, 3.0, 0.2).f, want = 393415 / 131072;
    ok('commas: two sine tones a Pythagorean comma apart (220 and 220·531441/524288 Hz) beat at 3.0015 Hz within 1 % (mu·ROTOR: 393415/131072)', Math.abs(beat / want - 1) < 0.01, { measuredHz: +beat.toFixed(4), expectedHz: +want.toFixed(6) });
  }
  {
    const T = E.triads(), seq = DATA.plr.hexatonic[0].concat([DATA.plr.hexatonic[0][0]]);
    let v = E.startVoices(T.byName[seq[0]], 'just');
    const f0 = v.map((x) => x.f);
    for (let i = 1; i < seq.length; i++) v = E.moveVoices(v, T.byName[seq[i]], 'just');
    const d = E.driftCents(v, T.byName[seq[0]]), want = 1200 * Math.log2(128 / 125);
    const ratios = v.map((x, i) => x.f / f0[i]);
    ok('Tonnetz: the hexatonic cycle in just intonation, common tones held, returns 128/125 sharp (+41.06 cents, cents_table.json)', Math.abs(d - want) < 1e-6 && ratios.every((r) => Math.abs(r - 128 / 125) < 1e-12), { driftCents: +d.toFixed(6), expected: +want.toFixed(6), voiceRatios: ratios });
    let tv = E.startVoices(T.byName[seq[0]], 'tet');
    const t0 = tv.map((x) => x.f);
    for (let i = 1; i < seq.length; i++) tv = E.moveVoices(tv, T.byName[seq[i]], 'tet');
    ok('Tonnetz: the same cycle in 12-TET returns exactly (PL)³ = 1', tv.every((x, i) => Math.abs(x.f / t0[i] - 1) < 1e-12), tv.map((x) => x.f));
    const maxEdge = +document.querySelector('[data-tz] svg').getAttribute('data-maxedge');
    ok('Tonnetz: the 36 P, L, R edges of plr_dual.json join triads at distance 1/√3 once the domain is identified', Math.abs(maxEdge - 1 / Math.sqrt(3)) < 1e-3, { maxEdge, oneOverSqrt3: 1 / Math.sqrt(3) });
  }
  {
    const C = DATA.curve;
    const x = await render(8.2, (oc, m) => E.playGliss(oc, m, 0.05, 'harmonic'));
    // the upper tone's sixth partial, which no partial of the lower tone shares, at r(t)·6·f₁ (clip 5's measure)
    let worst = 0; const rows = [];
    for (const [r, t] of Object.entries(C.glide_times_s)) {
      if (r === '1') continue;
      const ratioR = E.ratio(r), tt = 0.05 + t, want = 6 * C.f1 * ratioR;
      const S = spectrum(x, SR, tt - 0.05, tt + 0.05, 8), got = peakNear(S, want, 0.01).f;
      const cents = 1200 * Math.log2(got / want); worst = Math.max(worst, Math.abs(cents)); rows.push({ r, t: +t.toFixed(3), wantHz: +want.toFixed(2), gotHz: +got.toFixed(2), cents: +cents.toFixed(2) });
    }
    ok('glissando: at the six minima\'s times of dissonance_curve.json the upper sixth partial is at r(t)·6·261.6256 Hz within 1 %', worst < 1200 * Math.log2(1.01), { worstCents: +worst.toFixed(2), rows });
  }

  // ---- 5. round 37: the Tonnetz as the CRT grid
  {
    const pcs = DATA.crt.fifths_pcs, step = 0.32, t0 = 0.05;
    const x = await render(t0 + pcs.length * step + 0.2, (oc, m) => E.playSeq(oc, m, t0, pcs, step, false));
    const heard = pcs.map((pc, i) => { const S = spectrum(x, SR, t0 + i * step + 0.04, t0 + i * step + 0.3, 8); const f = peakNear(S, E.freqOf(pc, 'tet'), 0.04).f; return ((Math.round(12 * Math.log2(f / DATA.C4)) % 12) + 12) % 12; });
    ok('CRT grid: the fifth\'s diagonal plays the twelve pitch classes in the order of fifths, 0 7 2 9 4 11 6 1 8 3 10 5 (crt_tonnetz.json), each recovered from its FFT peak', heard.join() === pcs.join() && pcs.join() === '0,7,2,9,4,11,6,1,8,3,10,5', { expected: pcs, heard });
    const rule = E.crtMirror();
    ok('CRT grid: the rule of x ↦ 7x on the grid, computed from the cells, is (a, b) ↦ (a, −b), the file\'s mirror_x7', rule === '(a, b) -> (a, -b)' && rule === DATA.crt.mirror_x7, { computed: rule, file: DATA.crt.mirror_x7 });
    const diatonic = [0, 2, 4, 5, 7, 9, 11], img = E.mirror7(diatonic);
    const consecutive = (set) => { const s = set.slice().sort((a, b) => a - b); for (let r = 0; r < 12; r++) { if (s.every((v, i) => v === (r + i) % 12 || s.includes((r + i) % 12)) && s.every((v) => ((v - r + 12) % 12) < s.length)) return r; } return null; };
    const fifthsLine = (set) => { for (let r = 0; r < 12; r++) { const line = Array.from({ length: set.length }, (_, i) => (r + 7 * i) % 12).sort((a, b) => a - b); if (line.join() === set.slice().sort((a, b) => a - b).join()) return r; } return null; };
    ok('CRT grid: the mirror sends the diatonic set, seven consecutive fifths on the diagonal, onto seven consecutive semitones (the image of the line of fifths is the line of semitones), and keeps the whole-tone set, the augmented triad and the diminished seventh', fifthsLine(diatonic) === 5 && consecutive(img) === 11 && E.mirror7([0, 2, 4, 6, 8, 10]).join() === '0,2,4,6,8,10' && E.mirror7([0, 4, 8]).join() === '0,4,8' && E.mirror7([0, 3, 6, 9]).join() === '0,3,6,9', { diatonic, image: img, imageStartsAt: consecutive(img) });
    const sem = DATA.crt.semitone_ab, fifth = DATA.crt.fifths_path_ab[1];
    ok('CRT grid: the fifth is the step (1, 1) and the semitone (1, 3) = (1, −1) on the torus; the mirror exchanges them', fifth.join() === '1,1' && sem.join() === '1,3' && E.crtCoords(7).join() === '1,1' && E.crtCoords(1).join() === '1,3', { fifth, semitone: sem });
  }
  // ---- 6. round 37: the two rings and the bell (partials within 0.1 %)
  {
    // a struck sound measured by FFT over [a, b]; each partial decays with its own τ, so its peak is divided by the
    // mean of exp(−t/τ) over the window to read the amplitude it was struck with
    const measure = async (kind, dur, tol, a = 0.08, b = 0.9, only = null) => {
      const r = E.ringSound(kind);
      const x = await render(dur + 0.1, (oc, m) => E.playRing(oc, m, 0.05, kind, dur));
      const S = spectrum(x, SR, a, Math.min(dur, b), 8);
      let gmax = 0; for (const v of S.mag) gmax = Math.max(gmax, v);
      const t0 = 0.054, n = Math.floor(Math.min(dur, b) * SR) - Math.floor(a * SR);
      const hannMean = (tau) => { let num = 0, den = 0; for (let i = 0; i < n; i++) { const w = 0.5 - 0.5 * Math.cos(2 * Math.PI * i / (n - 1)); num += w * Math.exp(-(a + i / SR - t0) / tau); den += w; } return num / den; };
      const peaks = r.freqs.map((f, k) => { const p = peakNear(S, f, tol); return { f: p.f, mag: p.mag, amp: p.mag / hannMean(r.taus[k]) }; });
      const used = only ? peaks.slice(0, only) : peaks;
      const worst = Math.max(...used.map((p, k) => Math.abs(p.f / r.freqs[k] - 1)));
      const loudest = used.reduce((bb, p, k) => (p.amp > used[bb].amp ? k : bb), 0);
      return { r, peaks, worst, loudest, gmax, x };
    };
    const a = await measure('solved', 1.2, 0.01);
    ok('rings: the solved ring sounds 220·(1, 2, 3, 4, 5, 6) Hz within 0.1 %, with three of its six stiffnesses negative (harmonic_ring.json: 4 + 2√3, −2, 1, −2/3, 4 − 2√3, −1/2)', a.worst < 0.001 && a.r.negative === 3 && a.r.freqs.join() === '220,440,660,880,1100,1320', { measuredHz: a.peaks.map((p) => +p.f.toFixed(3)), worstRelError: +a.worst.toExponential(2), weights: a.r.weights });
    const amp6 = a.peaks[5].amp / ((a.peaks[0].amp + a.peaks[1].amp + a.peaks[2].amp + a.peaks[3].amp + a.peaks[4].amp) / 5);
    const spread = Math.max(...a.peaks.slice(0, 5).map((p) => p.amp)) / Math.min(...a.peaks.slice(0, 5).map((p) => p.amp));
    ok('rings: the pluck gives the modes 1 … 5 the amplitude 2/12 and the mode 6 the amplitude 1/12 (the character expansion δ₀ = (1/12) Σ χ_k): the first five peaks equal within 10 % and the sixth is half of them within 10 %, the decays compensated', Math.abs(amp6 - 0.5) < 0.05 && spread < 1.1, { sixthOverMean: +amp6.toFixed(4), spreadOfFive: +spread.toFixed(4) });
    const b = await measure('nn', 1.2, 0.01);
    const want = [1, 2, 3, 4, 5, 6].map((k) => Math.sin(k * Math.PI / 12) / Math.sin(Math.PI / 12));
    const dataDiff = Math.max(...want.map((w, i) => Math.abs(w - DATA.rings.nn.spectrum[i])));
    ok('rings: the nearest-neighbour ring sounds 220·(1, 1.9319, 2.7321, 3.3461, 3.7321, 3.8637) Hz within 0.1 %, and the page\'s ω_k = 2 sin(πk/12) ratios equal harmonic_ring.json\'s to 10⁻⁹', b.worst < 0.001 && dataDiff < 1e-9, { measuredHz: b.peaks.map((p) => +p.f.toFixed(3)), computedRatios: want.map((w) => +w.toFixed(6)), dataDiff });
    const c = await measure('bell12', 1.2, 0.01);
    ok('rings: the 12-cube bell sounds its twelve partials 220√j Hz (220.00 … 762.10) within 0.1 %, the loudest at j = 6 (538.89 Hz, weight 924/4096 = 231/1024)', c.worst < 0.001 && c.loudest === 5 && Math.abs(c.r.freqs[5] - 220 * Math.sqrt(6)) < 1e-9 && Math.abs(c.r.amps[5] - 924 / 4096) < 1e-12, { measuredHz: c.peaks.map((p) => +p.f.toFixed(2)), loudestIndex: c.loudest, loudestHz: +c.r.freqs[c.loudest].toFixed(2), weightExact: c.r.weights[5] });
    const d = await measure('bell3', 1.2, 0.01);
    const ratio3 = d.peaks[2].amp / d.peaks[0].amp, ratio2 = d.peaks[1].amp / d.peaks[0].amp;
    ok('rings: the 3-cube bell sounds 220·(1, √2, √3) Hz within 0.1 % with the weights 3/8, 3/8, 1/8 (the second peak equal to the first and the third a third of it, within 10 %, the decays compensated)', d.worst < 0.001 && Math.abs(ratio2 - 1) < 0.1 && Math.abs(ratio3 - 1 / 3) < 0.034, { measuredHz: d.peaks.map((p) => +p.f.toFixed(3)), ratios: [1, +ratio2.toFixed(3), +ratio3.toFixed(3)] });
    const e = await measure('pos7', 1.2, 0.01);
    ok('rings: the ring with positive springs sounds the partials 7 … 12 on 110 Hz (770 … 1320 Hz) within 0.1 %, every stiffness positive (sets.json: 15 + 6√3, 1, 6, 7/3, 15 − 6√3, 5/2)', e.worst < 0.001 && e.r.negative === 0 && e.r.freqs.join() === '770,880,990,1100,1210,1320' && e.r.weights[0] === '15 + 6√3', { measuredHz: e.peaks.map((p) => +p.f.toFixed(2)), weights: e.r.weights });
    const g = await measure('ringA', 1.2, 0.02, 0.08, 0.9, 10);
    ok('rings: ring A, equal masses with springs that differ along the ring, sounds 110·(1 … 11) Hz: its ten audible partials within 0.5 % (clips_rings.json, the float spectrum; k = 11 is nearly silent at the listening mass, as the clip says)', g.worst < 0.005 && g.r.freqs.length === 11 && g.r.freqs.every((f, k) => Math.abs(f / (110 * (k + 1)) - 1) < 1e-9) && g.r.amps[10] < 1e-4, { measuredHz: g.peaks.slice(0, 10).map((p) => +p.f.toFixed(2)), amp11: g.r.amps[10] });
  }
  // ---- 7. round 37: the all-interval rows
  {
    const R = DATA.rows;
    const berg = R.berg.pcs, midis = E.voicing(berg), d = 0.3, t0 = 0.05;
    ok('rows: the voicing rule on Berg\'s row gives berg_row.json\'s melody, MIDI 65 64 60 57 55 50 56 61 63 66 70 71 (F4 … B4), and on its retrograde 71 70 66 63 61 56 62 67 69 72 76 77', midis.join() === R.berg.melody_midi.join() && E.voicing(E.retrograde(berg)).join() === R.berg.retrograde_midi.join(), { melody: midis, retrograde: E.voicing(E.retrograde(berg)) });
    const x = await render(t0 + 12 * d + 0.2, (oc, m) => E.playRow(oc, m, t0, midis, d));
    const heardHz = midis.map((mm, j) => { const S = spectrum(x, SR, t0 + j * d + 0.03, t0 + (j + 1) * d - 0.03, 8); return peakNear(S, E.midiHz(mm), 0.03).f; });
    const recovered = heardHz.slice(1).map((f, j) => ((Math.round(12 * Math.log2(f / heardHz[j])) % 12) + 12) % 12);
    ok('rows: Berg\'s row rendered by the rule is recovered interval by interval, round(12 log₂(f_{j+1}/f_j)) mod 12 = 11 8 9 10 7 6 5 2 3 4 1 (the eleven intervals once), the first note 349.23 Hz', recovered.join() === R.berg.intervals.join() && Math.abs(heardHz[0] / 349.2282 - 1) < 0.001, { recovered, expected: R.berg.intervals, firstHz: +heardHz[0].toFixed(2) });
    const rm = E.voicing(E.retrograde(berg));
    const x2 = await render(t0 + 12 * d + 0.2, (oc, m) => E.playRow(oc, m, t0, rm, d));
    const retroHz = rm.map((mm, j) => { const S = spectrum(x2, SR, t0 + j * d + 0.03, t0 + (j + 1) * d - 0.03, 8); return peakNear(S, E.midiHz(mm), 0.03).f; });
    const ratios = retroHz.map((f, j) => f / heardHz[j]);
    ok('rows: R = T₆ measured: each note of Berg\'s retrograde is √2 times the row\'s note within 0.1 % (the retrograde is the row a tritone up), and the page says so', ratios.every((r) => Math.abs(r / Math.SQRT2 - 1) < 0.001) && E.isRT6(berg), { ratios: ratios.map((r) => +r.toFixed(4)) });
    // the rule on all 3856 rows: every melody ends 6 semitones above its first note and spans 11 to 21 semitones (audio/INDEX.md)
    let endOk = true, spanMin = 99, spanMax = 0, sym = 0;
    for (const seq of R.rows) { const pcs = E.rowPcs(seq), m = E.voicing(pcs); if (m[11] - m[0] !== 6) endOk = false; const span = Math.max(...m) - Math.min(...m); spanMin = Math.min(spanMin, span); spanMax = Math.max(spanMax, span); if (E.isRT6(pcs)) sym++; }
    ok('rows: on all 3856 rows of all_interval_rows.json the rule\'s melody ends exactly 6 semitones above its first note and spans 11 to 21 semitones; exactly 176 rows have R = T₆ (the file\'s symmetric list)', endOk && spanMin === 11 && spanMax === 21 && sym === 176 && R.symmetric.length === 176 && R.symmetric.every((i) => E.isRT6(E.rowPcs(R.rows[i]))), { rows: R.rows.length, spanMin, spanMax, symmetric: sym });
    const least = R.rows[0], greatest = R.rows[R.rows.length - 1];
    const inv = E.rowSeq(E.inversion(E.rowPcs(least)));
    ok('rows: the least row 1 2 4 7 3 6 11 10 8 5 9 and the greatest 11 10 8 5 9 6 1 2 4 7 3 are each other\'s inversion (every interval 12 − d), as clip 17 plays them', least === '124736ET859' && greatest === 'ET859612473' && inv === greatest, { least, greatest, inversionOfLeast: inv });
    const wedge = R.wedge.pcs, wm = E.voicing(wedge);
    ok('rows: Slonimsky\'s Grandmother chord 0 e 1 t 2 9 3 8 4 7 5 6 is one of the 176 (R = T₆), and the rule\'s melody obeys m₁₁₋ᵢ = mᵢ + 6 for i = 0 … 5 (the second half is the first read backwards, a tritone up)', E.isRT6(wedge) && [0, 1, 2, 3, 4, 5].every((i) => wm[11 - i] === wm[i] + 6), { melody: wm });
  }
  // ---- 8. round 38: the ring with two stiffnesses (partials within 0.1 %)
  {
    const ST = DATA.stiff;
    const hz = (s, top, lam) => 440 * Math.sqrt(s * lam / top);
    // the data's five ratios: the page's partials for (κ, μ) against 440·√(ω²/top), mode by mode, on both rings
    let worstData = 0, nData = 0;
    for (const r of ST.ratios) {
      const top = Math.max(r.kappa, r.mu), M = E.stiffModes(r.kappa, r.mu);
      for (const [ring, key] of [['sound', 'omega2_longitudinal'], ['shear', 'omega2_transverse']]) for (const w of r[key]) {
        if (w.k > 6) continue;
        const want = 440 * Math.sqrt(w.float / top), got = M[ring][w.k].f;
        if (want === 0) { if (got !== 0) worstData = 1; } else worstData = Math.max(worstData, Math.abs(got / want - 1));
        nData++;
      }
    }
    ok('stiff: for the five ratios κ/μ of two_stiffnesses.json (0, 1/4, 1, 4, ∞) the instrument\'s frequencies on both rings, mode by mode, equal 440·√(ω²/ω²_max) within 0.1 % (' + nData + ' modes)', worstData < 0.001, { worstData, nData });
    // the clip's segments: the sound ring at κ, the shear ring at μ = κ/3
    const seg = ST.clip.segments, Mp = E.stiffModes(3, 1);
    const w1 = Math.max(...seg[0].partials_hz.map((f, i) => Math.abs(Mp.sound.filter((m) => !m.silent)[i].f / f - 1)));
    const w2 = Math.max(...seg[1].partials_hz.map((f, i) => Math.abs(Mp.shear.filter((m) => !m.silent)[i].f / f - 1)));
    ok('stiff: the Poisson solid (μ = κ/3) sounds clip 22\'s partials, the sound ring 227.76 … 880 Hz and the shear ring 131.50 … 508.07 Hz (F_T = 254.034 Hz), within 0.1 %', w1 < 0.001 && w2 < 0.001, { w1, w2 });
    // the sound itself, rendered and measured by FFT: the six partials of the sound ring and of the shear ring
    const heard = async (which, kappa, mu) => {
      const x = await render(1.3, (oc, m) => E.playStiff(oc, m, 0.05, which, kappa, mu, 1.2));
      const S = spectrum(x, SR, 0.08, 0.9, 8), M = E.stiffModes(kappa, mu)[which].filter((m) => !m.silent);
      return Math.max(...M.map((m) => Math.abs(peakNear(S, m.f, 0.01).f / m.f - 1)));
    };
    const hs = await heard('sound', 3, 1), ht = await heard('shear', 3, 1);
    ok('stiff: rendered and measured by FFT, the sound ring and the shear ring of the Poisson solid sound their six partials within 0.1 %', hs < 0.001 && ht < 0.001, { hs, ht });
    // the zero modes are silent: k = 0 on every ring, and a ring whose spring is zero (air: no shear; MacCullagh: no sound)
    const air = E.stiffModes(1, 0), mac = E.stiffModes(0, 1), one = E.stiffModes(1, 1);
    const silentAir = air.shear.every((m) => m.silent) && air.sound[0].silent && air.sound.slice(1).every((m) => !m.silent);
    const silentMac = mac.sound.every((m) => m.silent) && mac.shear[0].silent && mac.shear.slice(1).every((m) => !m.silent);
    const xa = await render(1.3, (oc, m) => E.playStiff(oc, m, 0.05, 'shear', 1, 0, 1.2));
    const xm = await render(1.3, (oc, m) => E.playStiff(oc, m, 0.05, 'sound', 0, 1, 1.2));
    const xs = await render(1.3, (oc, m) => E.playStiff(oc, m, 0.05, 'sound', 1, 1, 1.2));
    const peak = (x) => x.reduce((p, v) => Math.max(p, Math.abs(v)), 0);
    ok('stiff: the zero modes are silent: k = 0 on every ring, the whole shear ring in air (μ = 0) and the whole sound ring for MacCullagh (κ = 0) render to silence (peak 0), where the other rings sound (peak > 0.1)', silentAir && silentMac && peak(xa) === 0 && peak(xm) === 0 && peak(xs) > 0.1, { silentAir, silentMac, pa: peak(xa), pm: peak(xm), ps: peak(xs) });
    // one speed: the two rings sound the same six partials
    ok('stiff: at one speed (κ = μ) the sound ring and the shear ring have the same six partials', one.sound.every((m, i) => m.f === one.shear[i].f), {});
    // the Poisson coincidence: the shear k = 4 at the pitch of the sound k = 2, from the data and from the instrument
    const P = E.stiffModes(3, 1);
    ok('stiff: the Poisson coincidence — the shear mode k = 4 sounds at the pitch of the sound mode k = 2 (440 Hz; ω_T(4)² = 3μ/m = κ/m = ω_L(2)²), within 0.1 %, and the data names it', Math.abs(P.shear[4].f / P.sound[2].f - 1) < 0.001 && Math.abs(P.sound[2].f - 440) < 0.44 && /omega_T\(4\)\^2/.test(ST.poisson.shared_pitch), { shear4: P.shear[4].f, sound2: P.sound[2].f });
  }
  return results;
});

await browser.close();
const fails = R.filter((r) => !r.pass);
if (consoleErrors.length) fails.push({ name: 'console errors on sounds.html', detail: consoleErrors });
const record = { date: new Date().toISOString(), page: 'out/sounds.html (file://)', engine: 'sounds.js, rendered in an OfflineAudioContext at 44 100 Hz by Chromium', results: R, consoleErrors, passed: R.length - R.filter((r) => !r.pass).length, failed: fails.length };
fs.writeFileSync(path.join(SITE, 'record', 'test_sounds.json'), JSON.stringify(record, null, 1));
for (const r of R) console.log(`${r.pass ? 'PASS' : 'FAIL'}  ${r.name}${r.pass ? '' : '  ' + JSON.stringify(r.detail).slice(0, 400)}`);
for (const e of consoleErrors) console.log('CONSOLE ' + e);
console.log(`test_sounds: ${R.length - R.filter((r) => !r.pass).length} of ${R.length} PASS${consoleErrors.length ? `, ${consoleErrors.length} console errors` : ''}`);
process.exit(fails.length ? 1 : 0);
