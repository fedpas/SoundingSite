# NOTE IT-5 E1

Wrote r5_E1.json: ten row narrations MUS-190 ... MUS-199 (order 190, 199, 191 ... 198) with titles; chain heading "Dall'onda X all'onda di Bernstein sulla rampa di densità"; caption of fig_xb_ramp (7 panels, told, not translated); one-line script title; seven strings (blk.research.own and atl.faults new; checks.intro, pics.intro, about.bridges.rows, about.reads.pack, checks.light.p from previousIt).

Terms: "onda all'indietro", "onda convertita", "il triplete", "la rampa di Budden", the three forms: primo ordine completo / forma di Ram e Schultz (named in MUS-190 text) / forma della quantità di moto; "quota convertita"; "estremo denso". Numbers as the records print them. Method-page-only phrase "non sono ancora nelle tavole dell'Atlante" is in about.bridges.rows and page:about; blk.research.own says it otherwise.

Rewritten (check_only): section:layers (second chain added), checks:light (sixteen scripts), page:checks (27 scripts, 16 in Part III), page:pictures (30 figures, ramp figure named), page:about (exception sentence for the ramp's ten rows).
Kept (not rewritten, no contradiction): section:streams, section:harmonics are not in r5_E1.json.

Doubts: MUS-196's "meno di un centesimo / circa due" speaks of C in units of incident power; MUS-195 "metà" is Budden's 1/2 (e^{-pi eta}) within 0.02.
