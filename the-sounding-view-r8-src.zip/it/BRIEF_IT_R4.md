# The Sounding View, release 4 — the Italian narrators (C1, C2, D1, D2)

The owner's words for the Italian side: *"un agente professionista della musica, della matematica e della fisica che racconta il nostro sito"*. You are that narrator: you **tell** the site in Italian, you do not translate it. Release 2's voice is the model (read `it/VOICE_IT.md` §"voice" and the rules, and the `voice_samples` in your material file); keep it: present tense, precise, warm, "voi" for the reader where you address them, the narrator's "io" rarely.

The site (`SITE = /tmp/claude-0/-home-claude/394118bf-a32c-5136-a011-44d634d15d21/scratchpad/work/music/site_r4`) is told as a story in four parts — **Sound** (tone, consonance), **Twelve** (clock, scales, groups, shapes, Fourier), **Sound beside light** (nine chapters in four movements: *the field* — sound and light side by side, the medium with two stiffnesses, the spin of sound; *the charged fluid* — a charged fluid; *beside the magnetic field* — the magnetized fluid, layers, the gyration's harmonics; *sound that fades or grows* — the fading wave, two streams and the sheet), **The question** — with a map of the bridges, a Sounds page (22 clips, 10 instruments and 23 experiments) and a Reference menu. **New in this release: the experiments.** Each chapter opens with one or more experiments: a picture that moves (the Atlas's own numbers drawn on a canvas) with switches and sliders, and a sound you can play. Their words are site strings with ids `exp.<name>.*` (and `exp.common.*` for the shared buttons): titles, leads, panel headings, the labels of sliders and switches, the captions, the lines *What you see* and *What you hear*, and the data line. A label must stay a label (as short as the English, one or two words), a caption a caption; a `{placeholder}` is filled by the page with a number and must be kept exactly.

## What you read (only this)

1. `it/draft/r4_<you>_material.json` — your targets with their English material, lengths and where they render; the release-2 Italian of what you rewrite or check; voice samples. **This is your main source.**
2. `it/draft/r4_assign.json` — your exact list of ids.
3. `it/VOICE_IT.md` — the voice and the rules (skim the tables of targets: they describe release 2).
4. For a row's detail, when the material is not enough: the row's full research text is in `/tmp/claude-0/-home-claude/394118bf-a32c-5136-a011-44d634d15d21/scratchpad/plan4/atlas_sound.json` under `rows["MUS-…"].text` (read it with a small `python3 -I` extract, never the whole file). For an experiment's context (D1, D2): its spec `gen/exp/<name>.spec.md` (what the picture shows) and its screenshot `gen/exp/_harness_<name>_1280.png`.

## What you write

One file, `it/draft/r4_<you>.json` (you are `C1`, `C2`, `D1` or `D2`):

```json
{ "narrator": "C1",
  "racconto": [ { "id": "r:row:MUS-050", "target": "row:MUS-050", "tells": ["MUS-050"], "text": "…", "why": "one English line: what this narration tells" } ],
  "titoli":   [ { "id": "t:row:MUS-050", "target": "row:MUS-050", "text": "…", "why": "…" } ],
  "strings":  [ { "id": "i10.h", "text": "…" } ] }
```

- Every id of your assignment exactly once: `narrations` and `rewrite_narrations` → `racconto`; `titles` and `rewrite_titles` → `titoli`; `strings` → `strings`. A `check_only` target goes into `racconto` **only if** you rewrite it (because its release-2 Italian contradicts the English material or tells something that moved); say in your note which you checked and kept.
- `tells`: start from the `tells` the material gives; you may add ids the narration draws on, of the forms already in use (row ids such as `MUS-047`, `clip:22`, `fig:two_stiffnesses`, `check:music_aether.py`).
- Plain text: no HTML, no markdown, no TeX. Write the notation as the records print it (ω², ℤ₁₂, √3, c_P, κ/μ, Cl(1,3), 12-TET) and the numbers as the records print them (decimal point, same digits, same units), so a reader finds the same figure in the English record.
- Lengths: as the material asks (`length`, in words). Titles: one line, at most the words asked, no final period.
- Strings: the Italian for the job the string does (a label stays a label, a button stays a button); keep every `{placeholder}` exactly; where `previousIt` exists, start from it and change only what the English changed.

## The rules that the checker enforces (and the owner cares about)

- **No bookkeeping in the reading flow.** Never: round, pacchetto, proposto/a (as "proposed"), integrato/a (as "merged"), proprietario, nota di ricerca, versione, release, trivellato/perforato/drill, "non ancora nelle tavole". A reader of music, mathematics and physics does not care how the work was organized; tell what is computed, measured, read or open. (That the part *Sound beside light* reads a study whose rows are not yet the Atlas's is said once, on the Method page, by a text that is not yours: never say it.)
- **No history words** (they date the text): adesso, ora (as "now"), nuovo/a/i/e, recente, ultimo, aggiornato, precedente, corretto, sostituito, superato, "prima" in its temporal uses. The ordinal "la prima nota" is fine.
- **Names stay as they are**: record ids, file names, check tags, Atlas, Standard, The Sounding View, study titles (*Music on the labels*, *The bridges* — the site no longer calls it "The bridges drilled": never write "drilled" — *Sound beside light* as a study). Refer to the **parts and chapters by their Italian titles** (the titles you or the other narrator write; agree with the other narrator's file if it exists when you finish, else use a plain Italian description).
- Status words as release 2 says them: calcolato, standard ricalcolato, dato in ingresso, nostra lettura, aperto.
- Italian only: no English sentence in your texts (an English term of art in italics is not available — say it in Italian, or keep the proper name).

## Your share

**C1** — the rows of the chapters *the magnetized fluid* (MUS-088 … 100), *layers* (MUS-151 … 161) and *two streams and the sheet* (MUS-101 … 111, MUS-138 … 143): narration and title of each; the three chapters' own narrations, titles, subtitles, chain headings and cards; the four movements' titles and leads (`movement:m1 … m4`); and the 21 site strings (new and changed) of the structure.

**C2** — the rows of the chapters *the gyration's harmonics* (MUS-164 … 173, MUS-177 … 185) and *the fading wave* (MUS-112 … 122, MUS-125 … 131): narration and title of each; the two chapters' narrations, titles, subtitles, chain headings and cards; the page of the experiment that would decide the spin (`page:experiment`: a one-paragraph telling of the acoustic Beth experiment — its question, its apparatus, its reading, from the English material — and its title); the lens entries 48 … 62; the nine scripts' one-line titles; and the **review** of 43 targets whose English changed (`check_only`): read the English now and the Italian of release 3, keep what still holds, rewrite only what contradicts (the review notes say what changed; the biggest are MUS-049, MUS-066, MUS-055, MUS-065, MUS-070, MUS-087).

**D1** — the strings of the experiments of Parts I and II and of the first two of Part III: `rotor, graphs, continuum, rings, twotones, clockring, sets, fifths, triads, torusband, fourier12, field, noimage`, and the shared `exp.common.*`.

**D2** — the strings of the experiments `stiffness, spin, plasmawaves, coupling, whistler, alfven, layers, harmonics, landau, streams`.

For the experiments (D1, D2): the `why` of each string says what it is for and where it shows; the material file groups them by experiment with the experiment's title and lead first, so read an experiment's strings together before writing them. Keep the Atlas's notation and ids as they are; keep numbers as printed; the status words as release 3 says them; the lens grades as the four words of `exp.common.grade.*`. The terms of release 3's narrators hold: spigolo temporale, settore di taglio, campi di potenza, anello del suono / anello di taglio, molla di trazione / molla di taglio, rigidezza, modulo di compressione, nodo di pressione, lettura (for *reading*), calcolato / standard ricalcolato / dato in ingresso / nostra lettura / aperto.

## Before you finish

Run `node it/draft/check_r4.mjs it/draft/r4_<you>.json` from `SITE` (NODE_PATH=/opt/npm-tools/node_modules not needed): 0 errors. Read its warnings (lengths, English left) and fix what is real. Then write `it/draft/NOTE_IT-4<you>.md` (short: what you wrote, the Italian titles you gave the parts and chapters, what you checked and kept, any doubt about a row's physics) and report in a few lines. Do not edit anything else: the coordinator merges your file into the tables and builds. Work economically.
