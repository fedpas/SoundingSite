<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors -->
# The Sounding View — deployable source (release 8)

A standalone static website: music, read with the Cascade Atlas. Release 8 tells the site as a story in four parts — *Sound* (three chapters: the tone, which ends with the duals of the Atlas's shapes; consonance; the violin, at rest and in motion), *Twelve*, *Sound beside light* (nine chapters in four movements), *The question* — and opens every chapter with its **experiments**: twenty-seven pictures that move, drawn from the Atlas's own figure data, each with a sound you can play and a legend of the rows it stands on; a map of the bridges, a Sounds page (22 clips, 10 instruments, the experiments) and a Reference menu (Dictionary, Checks, Pictures, Sources, Method), in English and in Italian (the Italian is a narrator's telling, not a translation).

**The site is the folder `out/`.** It is committed here, already built and checked, because building it needs inputs this repository does not carry (below). A host deploys `out/` as it is; nothing runs at deploy time.

## Deploy

- **Vercel.** Import the repository (or run `npx vercel --prod` in this folder). `vercel.json` sets framework *Other*, no build, output directory `out`, and the content types the site needs (`.py`, `.log`, `.sh`, `.md` as `text/plain`, `.ogg` as `audio/ogg`). Nothing to configure in the dashboard.
- **Netlify.** Connect the repository or drag the folder `out/` onto the dashboard; `netlify.toml` sets the publish folder and the same content types.
- **GitHub Pages.** `.github/workflows/pages.yml` publishes `out/` on every push to `main`: in the repository's *Settings → Pages* set *Source* to *GitHub Actions*. (Pages sets content types by extension itself; the scripts and logs open as text in the browser.)
- **Any static host.** Upload the contents of `out/` to the web root. All links are relative, so the site also works under a sub-path (`example.org/sounding/`). Serve `.ogg` as `audio/ogg` and `.py`, `.log` as `text/plain` where the host lets you.

A local look: `npm run serve` (no install needed) and open `http://localhost:8080/`.

The site's one link into the Atlas is on *Method* (`out/about.html` and `out/it/about.html`, `data-atlas-link`): `https://toy-model-v0.vercel.app/#/music`. To point it elsewhere, change `ATLAS_URL` in `gen/build.mjs` and the address the checker accepts in `gen/check.mjs`, rebuild, and commit `out/`.

## Rebuild (optional)

The generator is `gen/` (Node 20 or later; `npm install` brings KaTeX 0.16.47 and Playwright 1.56, the latter for the tests and the screenshots only). It reads, outside this repository:

- the Atlas's source repository at release 4.4.14 (`one-rule-src-4.4.14`: `content/`, `checks/selfcheck/`, `package.json`) — the argument or `SDV_ATLAS`;
- the Atlas's archive for what the source does not carry (the study *Music on the labels*, `FIGURES_INDEX.md`, `lit/SOURCES.md` and the SVG figures of rounds 36 and 37) — `SDV_ARCHIVE`;
- the study files of *The bridges* (`round37_bridges_pack`: the study document and the bridge tables) — `SDV_PACK`, and of *Sound beside light* (`round38_sound_light_pack`: the three `BRIDGE.md`, the four SVG figures) — `SDV_PACK38`;
- the kinetic X–B ramp, a work after 4.4.14 read as its own files (`xb-ramp-pending/pack`: `items/xb_ramp/ROWS.md`, `checks/selfcheck/sound_light/music_xb_ramp.py` with its logs and `figdata/xb_ramp.json`, `figs/fig_xb_ramp.svg` with `FIGURES_INDEX.md`) — `SDV_PACK_XB` (an input of release 5: the layers chapter names its chain and the layers experiment four of its rows);
- three more works after it, read the same way (`SDV_PACK_T`, `SDV_PACK_O`, `SDV_PACK_S`; defaults: the delivered folders `xb-triplet-pending/pack`, `ox-step-pending/pack`, `spin-probes-pending/pack`; `SDV_PACK_S=off` builds without the spin pack): the kinetic triplet's cavity phase (MUS-200 … MUS-202) and the O–X step (MUS-203 … MUS-208), told in the layers chapter, and the spin of sound on its probes (MUS-213 … MUS-221), told in the spin chapter; the layers and spin experiments draw their figure data;
- the violin (MUS-223 … MUS-230), a work read the same way but told as the third chapter of Part I, its script beside the Atlas's `checks/selfcheck/round36/` scripts and its figure and script in their own group on the pictures and checks pages (`SDV_PACK_V`; default: the delivered folder `violin-pending/pack`; `SDV_PACK_V=off` builds without the chapter); the violin experiment draws its figure data.
- the violin in motion (MUS-231 … MUS-237), a second chain of the violin chapter read the same way (`SDV_PACK_W`; default: the delivered folder `violin-body-pending/pack`; `off` builds without it); the experiment `violinbody` draws its figure data.
- the dual bells (MUS-238, MUS-239) and the duals one step further (MUS-240 … MUS-244), two chains told at the end of the tone chapter, their scripts beside the Atlas's `checks/selfcheck/round36/` scripts and their figures and scripts in a group of their own (`SDV_PACK_D`, `SDV_PACK_E`; defaults: the delivered folders `dual-bells-pending/pack`, `dual-cells-pending/pack`; `off` builds without either); the experiments `duals` and `dualcells` draw their figure data. An Atlas chapter may add chains told on its section after its own (`content/structure.json`: `chapters.tone.chains`).
- round 36's twelve clips as Ogg Vorbis, here in `audio_ogg/` (the script sets `SDV_OGG=audio_ogg`);
- optionally NASA's recordings of whistlers, chorus and hiss as `audio/nasa/whistler.mp3`, `audio/nasa/chorus.mp3`, `audio/nasa/hiss.wav` beside `audio_ogg/` (from https://www.nasa.gov/missions/mms/nasa-listens-in-as-electrons-whistle-while-they-work/ ; NASA's media may be used for educational purposes with NASA named as the source): when present they are copied to `out/audio/nasa/` and played under the whistler experiment with the credit "Source: NASA"; when absent the page links the recording.

```
npm install
export SDV_ATLAS=/path/to/one-rule-src-4.4.14 SDV_ARCHIVE=/path/to/one-rule-src-archive SDV_PACK=/path/to/round37_bridges_pack SDV_PACK38=/path/to/round38_sound_light_pack SDV_PACK_XB=/path/to/xb-ramp-pending/pack
npm run site:build    # writes out/; about 2 s
npm run site:check    # 0 errors, 0 warnings required (both languages)
npm run site:test     # the synthesizer: 43 assertions (Chromium)
npm run site:shots    # screenshots into record/shots/ (not committed); every experiment must mount, no console error
```

`SDV_IT=off` builds the English site alone; `SDV_IT=partial` renders missing Italian texts as marked placeholders; the default refuses to finish while one is missing. `record/SITE_NOTES.md`, `NOTE_R4.md`, `NOTE_R5.md` and `RELEASE_NOTES.md` say what the generator does and what changed.

### The experiments

Each experiment is a module in `gen/exp/` (`<name>.js`, its strings `<name>.strings.json`, its data `<name>.data.json`, its spec `<name>.spec.md`), built on the kit `gen/exp/_kit.js` under the contract `gen/exp/CONTRACT.md`; the generator mounts them on the chapters named in `gen/content/structure.json` and bundles them into `out/experiments.js`. `node gen/exp/_harness.mjs <name>` writes a standalone test page for one module.

## Layout

```
out/          the site (deploy this): 29 pages, out/it/ the 29 Italian pages, experiments.js, katex/, figures/, audio/, checks/, content/version.json
gen/          the generator: build.mjs, check.mjs, test_sounds.mjs, shoot.cjs, manifest_*.mjs, lib/, exp/ (the experiments), content/ (structure.json,
              the string table; content/it/ the three Italian tables and the manifests), assets/, build/ (the build's trace)
it/           the Italian side's record: the voice contract, the narrators' briefs, drafts, checks and notes
audio_ogg/    round 36's twelve clips as Ogg Vorbis (a build input)
record/       SITE_NOTES.md, build_log.json, check_log.json, test_sounds.json, shots_report.json
tools/        serve.mjs, a dependency-free static server for a local look
vercel.json · netlify.toml · .github/workflows/pages.yml   the three deploy configurations
```

## Licence

The Cascade Atlas, its tables, figures, scripts and clips, and this site with its generator, are under the PolyForm Noncommercial License 1.0.0 (`LICENSE`). Required Notice: Copyright (c) 2026 the Cascade Atlas authors. KaTeX is MIT (its fonts ship in `out/katex/`); the text fonts are loaded from Google Fonts at run time, with the system fonts as the fallback.
