# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# mk_r7.py — from gen/content/it/MANIFEST_R7.json, the two narrators' assignment (r7_assign.json) and material files:
#   r7_E1_material.json: the eight rows of the violin (chapter violin, Part I), their chain heading, figure caption and script line,
#                        the chapter's own narration and titles (section, sub, card), the site strings that are new or changed,
#                        and the targets to re-read (Part I's page, the checks page, the pages whose counts changed);
#   r7_E2_material.json: the strings of the experiment violin.
# Usage: python3 -I it/draft/mk_r7.py   (the pack's figure index is read for the caption: SDV_PACK_V or the delivered folder)
import json, os, re
DRAFT = os.path.dirname(os.path.abspath(__file__)); SITE = os.path.dirname(os.path.dirname(DRAFT))
IT = os.path.join(SITE, 'gen', 'content', 'it')
def J(p): return json.load(open(p, encoding='utf-8'))
def W(p, o):
    with open(p, 'w', encoding='utf-8') as f: f.write(json.dumps(o, ensure_ascii=False, indent=1) + '\n')
M = J(os.path.join(IT, 'MANIFEST_R7.json'))
R = {i['target']: i for i in J(os.path.join(IT, 'racconto.json'))['items']}
T = {i['target']: i for i in J(os.path.join(IT, 'titoli.json'))['items']}
S = {i['id']: i for i in J(os.path.join(IT, 'strings_it.json'))['strings']}
C1 = J(os.path.join(DRAFT, 'r4_C1_material.json')); D2 = J(os.path.join(DRAFT, 'r4_D2_material.json'))
rules = M['rules']
PACK_V = os.environ.get('SDV_PACK_V') or '/home/claude/deliver_r37/violin/violin-pending/pack'
WHAT_V = ("the violin: the bowed string's Helmholtz motion (the corner on its parabola, the two-valued velocity, the sawtooth at the bridge, the amplitude law), "
          "the four strings from their tensions (pitches tempered and just, impedances, the stiff E), Schelleng's two limits of the bow force, the free square plate's modes "
          "by Rayleigh–Ritz and the plate held at its centre, a student report's claims recomputed, the added piece (an odd drive on a mirror-symmetric chain and plate, "
          "the soundpost that breaks the mirror), the air of the box through an elliptic hole (the perimeter law, A0), and the wolf (a string on a resonant bridge, the split and the beat)")
def caption_of(pack, fig):
    p = os.path.join(pack, 'figs', 'FIGURES_INDEX.md')
    if not os.path.exists(p): return None, None
    for line in open(p, encoding='utf-8'):
        if line.startswith('|') and fig in line:
            cells = [c.strip() for c in line.strip().strip('|').split(' | ')]
            if len(cells) >= 4: return cells[1], cells[3]
    return None, None
for t in M['titles']:
    m = re.match(r'^fig:(fig_\w+)$', t['target'])
    if m and m.group(1) == 'fig_violin':
        cap, rows = caption_of(PACK_V, 'fig_violin')
        t['what'] = "the Italian caption of the figure fig_violin.svg (one to three sentences, as the other figures' captions in titoli.json: say what each panel shows, in the narrator's words, not a translation of the English caption)"
        t['length'] = '40–110 words'; t['where'] = 'violin.html and pictures.html, under the figure'
        t['material'] = {'caption_en': cap, 'rows': rows, 'sample_it': T.get('fig:fig_spin_probes', {}).get('text'), 'sample_it_2': T.get('fig:fig_xb_ramp', {}).get('text')}
    m = re.match(r'^check:(music_\w+)$', t['target'])
    if m and m.group(1) == 'music_violin':
        t['material']['note'] = f"say what the script computes ({WHAT_V}); do not say that the rows are proposed or not merged: that is the work's bookkeeping, never the reader's"
        t['material']['sample_it'] = T.get('check:music_spin_probes', T.get('check:music_sound', {})).get('text')
    if t['target'] in ('section:violin', 'section:violin:sub', 'card:section:violin'):
        t['material']['chapter_lead_en'] = None
for t in M['titles']:
    if t['target'] in ('section:violin', 'section:violin:sub', 'card:section:violin'):
        t['material']['samples_it'] = {k: {'title': T.get(f'section:{k}', {}).get('text'), 'sub': T.get(f'section:{k}:sub', {}).get('text'), 'card': T.get(f'card:section:{k}', {}).get('text')} for k in ('spin', 'layers')}
        t['material']['part_I_titles_it'] = {k: T.get(f'section:{k}', {}).get('text') for k in ('tone', 'consonance')}
for n in M['narrations']:
    if n['target'] == 'section:violin':
        n['what'] = ("the chapter of the violin, the third of Part I: what it is about (a true object with pieces added, after the symmetric objects of the first two chapters), "
                     "what its eight rows establish together, what the experiment at its head shows and lets you hear (the bowed string and its sawtooth, the plate's modes and the plate held at its centre, the added piece, the air of the box, the wolf)")
        n['material']['samples_it'] = {k: R.get(f'section:{k}', {}).get('text') for k in ('tone', 'consonance', 'spin')}
reread = []
for item in M['review']:
    for tg in [x.strip() for x in item['target'].split(',')]:
        cur = R.get(tg)
        reread.append({'target': tg, 'priority': item['priority'], 'why': item['why'], 'current_it': cur['text'] if cur else None, 'tells': cur.get('tells') if cur else None})
E1 = {
    'about': ("Narrator E1: your targets with their English material (your part of MANIFEST_R7.json): the eight rows of the violin (MUS-223 … MUS-230), narration and title each; "
              "the heading of their chain; the caption of their figure; the one-line title of their script; the chapter's own narration and titles (its title, its one line, its card); "
              "the site strings that are new or changed (with the previous Italian where there is one); and the narrations to re-read (Part I's page, the checks page, the pages whose counts changed; with their current Italian). Voice samples from the earlier narrators follow."),
    'rules': rules, 'narrations': M['narrations'], 'titles': M['titles'], 'strings': M['strings_new'] + M['strings_changed'], 'check_only': reread,
    'part_I_rows_it': {tg: T[tg]['text'] for tg in ['row:MUS-001', 'row:MUS-002', 'row:MUS-003', 'row:MUS-004', 'row:MUS-040', 'row:MUS-041'] if tg in T},
    'part_I_narrations_it': {tg: R[tg]['text'] for tg in ['row:MUS-001', 'row:MUS-003', 'row:MUS-041', 'section:tone', 'section:consonance', 'part:sound'] if tg in R},
    'part_I_titles_it': {tg: T[tg]['text'] for tg in ['section:tone', 'section:consonance', 'part:sound', 'chain:tone', 'chain:consonance'] if tg in T},
    'chapter_lead_en': None,
    'part_I_card_title_it': {'target': 'card:part:sound', 'current_it': T.get('card:part:sound', {}).get('text'), 'en_now': None, 'what': 'the card of Part I on the home page (a title target you may rewrite: 20–40 words, no final period): the English card gained the violin'},
    'voice_samples': C1['voice_samples'],
}
try:
    cur = J(os.path.join(SITE, 'gen', 'content', 'strings.json'))
    E1['chapter_lead_en'] = next((s['text'] for s in cur['strings'] if s['id'] == 'ch.violin.lead'), None)
    E1['chapter_card_en'] = next((s['text'] for s in cur['strings'] if s['id'] == 'ch.violin.card'), None)
    E1['part_I_card_title_it']['en_now'] = next((s['text'] for s in cur['strings'] if s['id'] == 'part.sound.card'), None)
    E1['part_I_lead_en_now'] = next((s['text'] for s in cur['strings'] if s['id'] == 'part.sound.lead'), None)
except Exception:
    pass
ex = M['experiments']['strings']
byexp = {}
for s in ex: byexp.setdefault(s['experiment'], []).append(s)
E2 = {
    'about': ("Narrator E2: the strings of the experiment violin (your part of MANIFEST_R7.json, group \"experiments\"): every string of the experiment is new. "
              "The Italian of the experiments of Part I and of the spin experiment is given for the terms and the voice, so that the pages read as one hand."),
    'rules': rules, 'narrations': [], 'titles': [], 'strings': ex, 'check_only': [],
    'strings_by_experiment': {k: {'title_it': S.get(f'exp.{k}.title', {}).get('text'), 'lead_it': S.get(f'exp.{k}.lead', {}).get('text'), 'strings': v} for k, v in byexp.items()},
    'italian_of_other_experiments': {k: [{'id': i, 'en': None, 'it': S[i]['text']} for i in S if i.startswith(f'exp.{k}.') and not S[i].get('stub')] for k in ('rotor', 'continuum', 'twotones', 'spin')},
    'common_strings_it': [{'id': i, 'it': S[i]['text']} for i in S if i.startswith('exp.common.') and not S[i].get('stub')],
    'voice_samples': D2.get('voice_samples', C1['voice_samples']),
}
EN = {}
for k in ('rotor', 'continuum', 'twotones', 'spin'):
    p = os.path.join(SITE, 'gen', 'exp', f'{k}.strings.json')
    if os.path.exists(p):
        for e in J(p)['strings']: EN[e['id']] = e['text']
for k, lst in E2['italian_of_other_experiments'].items():
    for e in lst: e['en'] = EN.get(e['id'])
assign = {
    'E1': {'narrations': [n['target'] for n in M['narrations']], 'titles': [t['target'] for t in M['titles']], 'strings': [s['id'] for s in E1['strings']], 'rewrite_narrations': [], 'rewrite_titles': ['card:part:sound'], 'check_only': [r['target'] for r in reread]},
    'E2': {'narrations': [], 'titles': [], 'strings': [s['id'] for s in ex], 'rewrite_narrations': [], 'rewrite_titles': [], 'check_only': []},
}
W(os.path.join(DRAFT, 'r7_assign.json'), assign); W(os.path.join(DRAFT, 'r7_E1_material.json'), E1); W(os.path.join(DRAFT, 'r7_E2_material.json'), E2)
print('E1', {k: len(v) for k, v in assign['E1'].items()}, 'E2', {k: len(v) for k, v in assign['E2'].items()})
