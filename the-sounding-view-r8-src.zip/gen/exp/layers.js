// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// layers.js — mode conversion through layers: the profile and the field, transmitted / reflected / absorbed / converted, the flux, the cavity, the cavity's phase as the plasma cools, the O–X window.
(function () {
  'use strict';
  window.SDV_EXP = window.SDV_EXP || {};
  var SL = 'layers', P = 'exp.layers.';
  window.SDV_EXP[SL] = { mount: function (root, data, S, kit) {
    root.classList.add('two');
    var D = data, reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches, st = { hy: '9/10', sy: '9/10', sf: 'mom', tv: 1, form: 'full', hv: 'near', hp: !!reduce, py: '9/10', view: 'near', cold: true, warm: true, ni: 2, model: 'cold', kase: 'pair', cs: 1, ei: 2, fric: false, snd: false };
    var FREQ = 2000 / D.ramp_Y;                     // omega_ce <-> 2000 Hz, so omega = omega_ce / Y
    var redraw = [];
    function cvs(panel, a, m) { var b = kit.el('div'); panel.appendChild(b); var c = kit.canvas(b, a, m); redraw.push(function () { c.size(); }); return c; }
    function fmtE(v) { return kit.sci(v, 1); }

    // ------------------------------------------------------------ (a) the profile
    var pa = kit.panel_(root, P + 'panel.profile', S);
    var c1 = kit.controls(pa);
    kit.seg(c1, { ids: [P + 'view.near', P + 'view.whole'], values: ['near', 'whole'], value: 'near', S: S, onchange: function (v) { st.view = v; draw(); } });
    kit.check(c1, P + 'show.cold', S, true, function (v) { st.cold = v; draw(); });
    kit.check(c1, P + 'show.warm', S, true, function (v) { st.warm = v; draw(); });
    var cvA = cvs(pa, 0.5, 320);
    kit.line(pa, P + 'cap.profile', S);
    var c2 = kit.controls(pa);
    var nS = kit.slider(c2, { id: P + 'n', S: S, min: 0, max: D.budden_N.length - 1, step: 1, value: st.ni, fmt: function (v) { return String(D.budden_N[Math.round(v)]); }, onchange: function (v) { st.ni = Math.round(v); draw(); } });
    var cvN = cvs(pa, 0.34, 190);
    kit.line(pa, P + 'cap.budden', S);
    var rdN = kit.readout(pa);

    // ------------------------------------------------------------ (b) the shares
    var pb = kit.panel_(root, P + 'panel.shares', S);
    var c3 = kit.controls(pb);
    kit.seg(c3, { ids: [P + 'case.pair', P + 'case.triplet'], values: ['pair', 'triplet'], value: 'pair', S: S, onchange: function (v) { st.kase = v; draw(); } });
    kit.seg(c3, { ids: [P + 'model.cold', P + 'model.warm'], values: ['cold', 'warm'], value: 'cold', S: S, onchange: function (v) { st.model = v; draw(); } });
    var csS = kit.slider(c3, { id: P + 'cs', S: S, min: 0, max: 2, step: 1, value: 1, fmt: function (v) { return kit.num(D.warm_cs_over_c[Math.round(v)], 3); }, onchange: function (v) { st.cs = Math.round(v); draw(); } });
    var eS = kit.slider(c3, { id: P + 'eta', S: S, min: 0, max: D.C_layered_etaL.length - 1, step: 1, value: st.ei, fmt: function (v) { return kit.num(D.C_layered_etaL[Math.round(v)], 3); }, onchange: function (v) { st.ei = Math.round(v); draw(); } });
    var c3b = kit.controls(pb);
    var DEN = [20, 40, 80, 160], FORMS = ['full', 'rs', 'mom', 'fluid'];
    var tvS = kit.seg(c3b, { ids: DEN.map(function (n) { return P + 'tv.' + n; }), values: [0, 1, 2, 3], value: st.tv, S: S, onchange: function (v) { st.tv = v; draw(); } });
    var fmS = kit.seg(c3b, { ids: FORMS.map(function (n) { return P + 'form.' + n; }), values: FORMS, value: st.form, S: S, onchange: function (v) { st.form = v; draw(); } });
    var cvB = cvs(pb, 0.62, 240);
    var rdB = kit.readout(pb);
    var trWrap = kit.el('div'); pb.appendChild(trWrap);
    var cvTr = cvs(trWrap, 0.75, 260);
    kit.line(trWrap, P + 'cap.triplet', S);
    var rdTr1 = kit.readout(trWrap), rdTr2 = kit.readout(trWrap), rdTr3 = kit.readout(trWrap);
    var c4 = kit.controls(pb);
    kit.button(c4, P + 'send', S, send);
    var bPlay = kit.button(c4, 'exp.common.play', S, function () { togglePlay(); });
    var nf = kit.line(pb, 'exp.common.noaudio', S, 'exp-note'); nf.style.display = 'none';
    kit.line(pb, P + 'cap.shares', S);

    // ------------------------------------------------------------ (c) the flux
    var pc = kit.panel_(root, P + 'panel.flux', S);
    var c5 = kit.controls(pc);
    kit.check(c5, P + 'friction', S, false, function (v) { st.fric = v; fr.style.display = v ? '' : 'none'; });
    var cvF = cvs(pc, 0.36, 220);
    kit.line(pc, P + 'cap.flux', S);
    var fr = kit.line(pc, P + 'cap.friction', S, 'exp-note'); fr.style.display = 'none';

    // ------------------------------------------------------------ (d) the cavity
    var pd = kit.panel_(root, P + 'panel.cavity', S);
    var cvC = cvs(pd, 0.62, 260);
    kit.line(pd, P + 'cap.cavity', S);
    var rdC = kit.readout(pd);

    // ------------------------------------------------------------ (e) the hot electrons' wave on the ramp (MUS-192, MUS-194)
    var XB = D.xb, RK = XB.ramps['0.9_kinetic'], RF = XB.ramps['0.9_fluid'], WIN = 0.8, TAU = 0, TWO = 2 * Math.PI;
    var ph = kit.panel_(root, P + 'panel.hot', S, 'span');
    var ch = kit.controls(ph);
    kit.seg(ch, { ids: [P + 'view.near', P + 'view.whole'], values: ['near', 'whole'], value: 'near', S: S, onchange: function (v) { st.hv = v; draw(); } });
    kit.seg(ch, { ids: [P + 'path.y910', P + 'path.y25'], values: ['9/10', '2/5'], value: st.hy, S: S, onchange: function (v) { st.hy = v; draw(); } });
    var bHp = kit.button(ch, 'exp.common.pause', S, function () { st.hp = !st.hp; bHp.setAttribute('aria-pressed', String(st.hp)); }); bHp.setAttribute('aria-pressed', String(st.hp));
    var cvH1 = cvs(ph, 0.55, 230), cvH2 = cvs(ph, 0.45, 170), cvH3 = cvs(ph, 0.3, 74), cvH4 = cvs(ph, 0.5, 130);
    kit.line(ph, P + 'cap.hot', S);
    var rdH1 = kit.readout(ph), rdH2 = kit.readout(ph);

    // ------------------------------------------------------------ (e2) a sharp step (MUS-193)
    var pst = kit.panel_(root, P + 'panel.step', S, 'span');
    var cst = kit.controls(pst);
    kit.seg(cst, { ids: [P + 'path.y910', P + 'path.y25'], values: ['9/10', '2/5'], value: st.sy, S: S, onchange: function (v) { st.sy = v; draw(); } });
    kit.seg(cst, { ids: [P + 'form.mom', P + 'form.rs'], values: ['mom', 'rs'], value: st.sf, S: S, onchange: function (v) { st.sf = v; draw(); } });
    var cvSt = cvs(pst, 0.55, 280);
    kit.line(pst, P + 'cap.step', S);
    var rdSt = kit.readout(pst);

    // ------------------------------------------------------------ (f) where the converted wave goes (MUS-198)
    var pp = kit.panel_(root, P + 'panel.path', S, 'span');
    var cp = kit.controls(pp);
    kit.seg(cp, { ids: [P + 'path.y910', P + 'path.y25', P + 'path.y27'], values: ['9/10', '2/5', '2/7'], value: st.py, S: S, onchange: function (v) { st.py = v; draw(); } });
    var cvP = cvs(pp, 0.75, 300);
    kit.line(pp, P + 'cap.path', S);
    var rdP1 = kit.readout(pp), rdP2 = kit.readout(pp), rdP3 = kit.readout(pp);

    // ------------------------------------------------------------ (g) the cavity's best length as the plasma cools (MUS-200, MUS-201, MUS-202)
    var TP = D.triplet_phase, OX = D.ox, plays = [bPlay];
    st.pt = 1; st.gs = '2'; st.peta = TP.extrema.full40_max1.x; st.os = '1'; st.oz = 3; st.or = '0.6882';
    var pq = kit.panel_(root, P + 'panel.phase', S, 'span');
    var cq = kit.controls(pq);
    kit.seg(cq, { ids: DEN.map(function (n) { return P + 'tv.' + n; }), values: [0, 1, 2, 3], value: st.pt, S: S, onchange: function (v) { st.pt = v; draw(); } });
    var cvQ = cvs(pq, window.innerWidth < 600 ? 0.8 : 0.42, 340);
    kit.line(pq, P + 'cap.phase', S);
    var rdQ1 = kit.readout(pq), rdQ2 = kit.readout(pq), rdQ3 = kit.readout(pq);
    var cq2 = kit.controls(pq);
    kit.slider(cq2, { id: P + 'ph.eta', S: S, min: TP.grid[0], max: TP.grid[TP.grid.length - 1], step: 0.005, value: st.peta, fmt: function (v) { return kit.num(v, 3); }, onchange: function (v) { st.peta = v; draw(); } });
    kit.button(cq2, P + 'send', S, sendPhase);
    plays.push(kit.button(cq2, 'exp.common.play', S, togglePlay));
    var rdQ4 = kit.readout(pq);
    var gq = kit.el('div'); gq.style.cssText = 'display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px;align-items:start;margin-top:10px'; pq.appendChild(gq);
    var gq1 = kit.el('div'), gq2 = kit.el('div'); gq.appendChild(gq1); gq.appendChild(gq2);
    gq1.appendChild(kit.el('h4', { 'data-s': P + 'ph.gentle', text: S(P + 'ph.gentle'), style: 'margin:0 0 6px;font-size:0.85rem' }));
    var cg = kit.controls(gq1);
    kit.seg(cg, { ids: [P + 'ph.s1', P + 'ph.s2', P + 'ph.s4'], values: ['1', '2', '4'], value: st.gs, S: S, onchange: function (v) { st.gs = v; draw(); } });
    var cvG = cvs(gq1, 0.7, 260);
    var rdG = kit.readout(gq1);
    kit.line(gq2, P + 'cap.gentle', S);
    kit.line(gq2, P + 'cap.nodes', S);

    // ------------------------------------------------------------ (h) the O–X window (MUS-204, MUS-206, MUS-207, MUS-208)
    var po = kit.panel_(root, P + 'panel.ox', S, 'span');
    var co = kit.controls(po);
    kit.seg(co, { ids: [P + 'ox.s1', P + 'ox.s2', P + 'ox.s4', P + 'ox.s16'], values: ['1', '2', '4', '16'], value: st.os, S: S, onchange: function (v) { st.os = v; ozIn.max = String(oxPts().length - 1); st.oz = Math.min(st.oz, oxPts().length - 1); ozS.set(st.oz); draw(); } });
    var ozS = kit.slider(co, { id: P + 'ox.nz', S: S, min: 0, max: 10, step: 1, value: 3, fmt: function (v) { var p = oxPts()[Math.min(Math.round(v), oxPts().length - 1)]; return p ? kit.num(p[0], 4) : ''; }, onchange: function (v) { st.oz = Math.min(Math.round(v), oxPts().length - 1); draw(); } });
    var ozIn = ozS.el.querySelector('input');
    kit.button(co, P + 'send', S, sendOX);
    plays.push(kit.button(co, 'exp.common.play', S, togglePlay));
    var cvO = cvs(po, window.innerWidth < 600 ? 0.8 : 0.42, 330);
    var rdO1 = kit.readout(po), rdO2 = kit.readout(po);
    kit.line(po, P + 'cap.ox', S);
    var go = kit.el('div'); go.style.cssText = 'display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px;align-items:start;margin-top:10px'; po.appendChild(go);
    var go1 = kit.el('div'), go2 = kit.el('div'), go3 = kit.el('div'); go.appendChild(go1); go.appendChild(go2); go.appendChild(go3);
    go1.appendChild(kit.el('h4', { 'data-s': P + 'ox.roots', text: S(P + 'ox.roots'), style: 'margin:0 0 6px;font-size:0.85rem' }));
    var cr = kit.controls(go1);
    kit.seg(cr, { ids: [P + 'ox.r60', P + 'ox.r688', P + 'ox.r80'], values: ['0.6000', '0.6882', '0.8000'], value: st.or, S: S, onchange: function (v) { st.or = v; draw(); } });
    var cvR = cvs(go1, 0.75, 280);
    kit.line(go1, P + 'cap.roots', S);
    go2.appendChild(kit.el('h4', { 'data-s': P + 'ox.chain', text: S(P + 'ox.chain'), style: 'margin:0 0 6px;font-size:0.85rem' }));
    var cvCh = cvs(go2, 0.75, 280);
    kit.line(go2, P + 'cap.chain', S);
    go3.appendChild(kit.el('h4', { 'data-s': P + 'ox.ny', text: S(P + 'ox.ny'), style: 'margin:0 0 6px;font-size:0.85rem' }));
    var cvNy = cvs(go3, 0.75, 280);
    kit.line(go3, P + 'cap.ny', S);

    // ------------------------------------------------------------ the shares from the data
    function shares() {
      if (st.kase === 'pair') {
        if (st.model === 'cold') return { T: D.cold_TRA[0], R: D.cold_TRA[1], X: D.cold_TRA[2], xs: 'absorbed' };
        return { T: D.warm_T[st.cs], R: D.warm_R[st.cs], X: D.warm_C[st.cs], xs: 'converted' };
      }
      if (st.model === 'warm') { var Cw = tripC(st.form, st.tv); return { T: 0, R: 1 - Cw, X: Cw, xs: 'converted' }; }
      var C = D.C_layered[st.ei]; return { T: 0, R: 1 - C, X: C, xs: 'absorbed' };
    }
    function tripC(form, i) { return form === 'fluid' ? XB.triplet.fluid_9_10[i] : XB.triplet.byform_9_10[form][i][1]; }
    function send() {
      var s = shares(); if (!st.snd || !s) return;
      var f = FREQ;
      kit.tone({ f: f, gain: 0.2, dur: 0.4, at: 0 });
      if (s.R > 1e-4) kit.tone({ f: f, gain: 0.28 * Math.sqrt(s.R), dur: 0.5, at: 0.7 });
      if (s.T > 1e-4) kit.tone({ f: f * 2, gain: 0.28 * Math.sqrt(s.T), dur: 0.5, at: 0.7 });
    }

    // ------------------------------------------------------------ drawing
    var UH = 0, RC = D.ramp_xprime_cutoff;
    function drawProfile() {
      var c = cvA.ctx, W = cvA.size().w, H = cvA.h; c.clearRect(0, 0, W, H);
      var half = st.view === 'near' ? 2.5 : 12, box = { l: 40, r: W - 10, t: 12, b: H - 34 };
      var ax = kit.axes(c, box, { xmin: -half, xmax: half, ymin: 0, ymax: 1.7, xticks: [-half, 0, half].map(function (v) { return -v; }).reverse().map(function (v) { return v; }), yticks: [0, 1], xlabel: S(P + 'cv.x'), ylabel: S(P + 'cv.e') });
      // x runs against x' so that the density rises to the right
      function X(xp) { return ax.x(-xp); }
      c.save(); c.beginPath(); c.rect(box.l, box.t, box.r - box.l, box.b - box.t); c.clip();
      c.fillStyle = 'rgba(14,115,104,0.07)'; c.fillRect(box.l, box.t, X(RC) - box.l, box.b - box.t);
      c.fillStyle = 'rgba(107,116,112,0.22)'; c.fillRect(X(RC), box.t, X(UH) - X(RC), box.b - box.t);
      c.fillStyle = 'rgba(14,115,104,0.07)'; c.fillRect(X(UH), box.t, box.r - X(UH), box.b - box.t);
      c.restore();
      var xs = D.ramp_cold_x.map(function (v) { return -v; });
      function line(arr, col, w, dash, g) { var pts = []; for (var i = 0; i < arr.length; i++) if (Math.abs(xs[i]) <= half) pts.push([xs[i], arr[i] * (g || 1)]); pts.sort(function (a, b) { return a[0] - b[0]; }); kit.curve(c, pts, ax.x, function (v) { return ax.y(Math.max(0, v)); }, col, w, dash); }
      if (st.cold) line(D.ramp_cold_absE, kit.ink(), 1.5);
      if (st.warm) { line(D.ramp_warm_absE, kit.accent(), 1.8); line(D.ramp_warm_rep1.map(function (v) { return Math.abs(v); }), kit.red, 1.2, [3, 3], 50); }
      // the sheet at the upper hybrid and the cutoff
      c.strokeStyle = kit.warm(); c.lineWidth = 2.5; c.beginPath(); c.moveTo(X(UH), box.t); c.lineTo(X(UH), box.b); c.stroke();
      c.strokeStyle = kit.muted(); c.setLineDash([4, 3]); c.lineWidth = 1; c.beginPath(); c.moveTo(X(RC), box.t); c.lineTo(X(RC), box.b); c.stroke(); c.setLineDash([]);
      c.font = '11px system-ui, sans-serif'; c.fillStyle = kit.warm(); c.textAlign = 'left'; c.fillText(S(P + 'cv.uh'), X(UH) + 4, box.t + 11);
      c.fillStyle = kit.muted(); c.textAlign = 'right'; c.fillText(S(P + 'cv.cutoff'), X(RC) - 4, box.t + 11);
      // the density, a thin line with its own scale on the top
      c.strokeStyle = kit.blue; c.lineWidth = 1; c.globalAlpha = 0.6; c.beginPath(); var on = false;
      D.ramp_warm_x.forEach(function (xp, i) { if (Math.abs(xp) > half) return; var x = X(xp), y = box.b - (box.b - box.t) * 0.7 * Math.min(1, D.ramp_warm_X[i] / 1.5) ; if (!on) { c.moveTo(x, y); on = true; } else c.lineTo(x, y); });
      c.stroke(); c.globalAlpha = 1;
    }
    function drawBudden() {
      var c = cvN.ctx, W = cvN.size().w, H = cvN.h; c.clearRect(0, 0, W, H);
      var box = { l: 48, r: W - 12, t: 10, b: H - 32 }, N = D.budden_N, dv = D.budden_maxdev;
      var ax = kit.axes(c, box, { xmin: 150, xmax: 4000, xlog: true, ymin: 3e-6, ymax: 3e-3, ylog: true, xticks: N, yticks: [1e-5, 1e-4, 1e-3], xlabel: S(P + 'cv.n'), ylabel: S(P + 'cv.dev') });
      var pts = N.map(function (n, i) { return [n, dv[i]]; }); kit.curve(c, pts, ax.x, ax.y, kit.muted(), 1.2);
      // second order: a line of slope -2 through the first point
      kit.curve(c, [[N[0], dv[0]], [N[4], dv[0] * Math.pow(N[0] / N[4], 2)]], ax.x, ax.y, kit.accent(), 1, [4, 3]);
      N.forEach(function (n, i) { c.fillStyle = i === st.ni ? kit.warm() : kit.ink(); c.beginPath(); c.arc(ax.x(n), ax.y(dv[i]), i === st.ni ? 6 : 3.5, 0, 6.2832); c.fill(); });
      var i = st.ni; rdN.textContent = 'N = ' + N[i] + ':  ' + fmtE(dv[i]) + (i > 0 ? '   (' + kit.num(dv[i - 1] / dv[i], 2) + ' × smaller than at N = ' + N[i - 1] + ')' : '');
    }
    function bar(c, x0, y, w, h, frac, col, label, val) {
      c.fillStyle = kit.panel(); c.strokeStyle = kit.muted(); c.lineWidth = 1; c.fillRect(x0, y, w, h); c.strokeRect(x0, y, w, h);
      c.fillStyle = col; c.fillRect(x0, y, w * Math.max(0, Math.min(1, frac)), h);
      c.fillStyle = kit.ink(); c.font = '12px system-ui, sans-serif'; c.textAlign = 'left'; c.fillText(label, x0 + 6, y + h / 2 + 4); c.textAlign = 'right'; c.fillText(val, x0 + w - 6, y + h / 2 + 4);
    }
    function drawBars() {
      var c = cvB.ctx, W = cvB.size().w, H = cvB.h; c.clearRect(0, 0, W, H);
      var s = shares(); var bh = Math.min(38, (H - 20) / 4.6), x0 = 10, w = W - 20;
      if (!s) { c.fillStyle = kit.muted(); c.font = '13px system-ui, sans-serif'; c.textAlign = 'center'; c.fillText(S('exp.common.outside'), W / 2, H / 2); rdB.textContent = ''; return; }
      var rows = [[s.T, kit.blue, S(P + 'bar.transmitted')], [s.R, kit.red, S(P + 'bar.reflected')], [s.X, kit.accent(), S(P + (s.xs === 'converted' ? 'bar.converted' : 'bar.absorbed'))]];
      rows.forEach(function (r, i) { bar(c, x0, 8 + i * (bh + 8), w, bh, r[0], r[1], r[2], kit.num(r[0], 3)); });
      rdB.textContent = 'T + R + ' + (s.xs === 'converted' ? 'C' : 'A') + ' = ' + kit.num(s.T + s.R + s.X, 4) + (st.kase === 'triplet' ? '    η_L = ' + kit.num(st.model === 'warm' ? XB.triplet.etaL : D.C_layered_etaL[st.ei], 3) + ', η_R = ' + kit.num(D.triplet_etaR, 4) : '    ' + (st.model === 'warm' ? 'c_s/c = ' + kit.num(D.warm_cs_over_c[st.cs], 3) : 'η = ln 2 / π'));
      eS.el.style.display = (st.kase === 'triplet' && st.model === 'cold') ? '' : 'none'; var tw = st.kase === 'triplet' && st.model === 'warm'; c3b.style.display = tw ? '' : 'none'; trWrap.style.display = tw ? '' : 'none'; csS.el.style.display = (st.kase === 'pair' && st.model === 'warm') ? '' : 'none';
    }
    function drawFlux() {
      var c = cvF.ctx, W = cvF.size().w, H = cvF.h; c.clearRect(0, 0, W, H);
      var s = shares(), box = { l: 40, r: W - 10, t: 12, b: H - 30 };
      var ax = kit.axes(c, box, { xmin: -1, xmax: 1, ymin: 0, ymax: 1.1, xticks: [], yticks: [0, 1], xlabel: S(P + 'cv.x'), ylabel: S(P + 'cv.flux') });
      if (!s) { c.fillStyle = kit.muted(); c.textAlign = 'center'; c.fillText(S('exp.common.outside'), W / 2, H / 2); return; }
      var xs = ax.x(0), xr = ax.x(-0.35), yin = ax.y(1 - s.R), yout = ax.y(st.model === 'warm' && st.kase === 'pair' ? s.T : s.T);
      c.fillStyle = 'rgba(107,116,112,0.22)'; c.fillRect(xr, box.t, xs - xr, box.b - box.t);
      c.strokeStyle = kit.accent(); c.lineWidth = 2.2; c.beginPath(); c.moveTo(box.l, yin); c.lineTo(xs, yin);
      var cold = st.model === 'cold';
      if (cold) c.lineTo(xs, yout); else c.moveTo(xs, yin);
      c.lineTo(box.r, cold ? yout : yin); c.stroke();
      if (!cold) { c.strokeStyle = kit.accent(); c.lineWidth = 2.2; c.beginPath(); c.moveTo(box.l, ax.y(s.T)); c.lineTo(box.r, ax.y(s.T)); c.stroke(); }
      c.strokeStyle = kit.warm(); c.lineWidth = 2.5; c.beginPath(); c.moveTo(xs, box.t); c.lineTo(xs, box.b); c.stroke();
      c.fillStyle = kit.warm(); c.font = '11px system-ui, sans-serif'; c.textAlign = 'left'; c.fillText(S(P + 'cv.uh'), xs + 4, box.t + 11);
    }
    function drawCavity() {
      var c = cvC.ctx, W = cvC.size().w, H = cvC.h; c.clearRect(0, 0, W, H);
      var box = { l: 44, r: W - 12, t: 12, b: H - 34 }, E = D.triplet_etaL, hi = E[E.length - 1];
      var ax = kit.axes(c, box, { xmin: 0, xmax: 6, ymin: 0, ymax: 1.02, xticks: [0, 1, 2, 3, 4, 5, 6], yticks: [0, 0.5, 1], xlabel: S(P + 'cv.etal'), ylabel: S(P + 'cv.c') });
      kit.curve(c, E.map(function (e, i) { return [e, D.C_closed[i]]; }), ax.x, ax.y, kit.muted(), 1.4);
      D.C_layered_etaL.forEach(function (e, i) { c.fillStyle = i === st.ei && st.kase === 'triplet' ? kit.warm() : kit.accent(); c.beginPath(); c.arc(ax.x(e), ax.y(D.C_layered[i]), i === st.ei && st.kase === 'triplet' ? 6 : 3.5, 0, 6.2832); c.fill(); });
      D.complete_etaL.forEach(function (e) { c.strokeStyle = kit.ink(); c.setLineDash([2, 3]); c.beginPath(); c.moveTo(ax.x(e), box.t); c.lineTo(ax.x(e), box.b); c.stroke(); c.setLineDash([]); });
      rdC.textContent = 'C = 1 at η_L = ' + D.complete_etaL.map(function (e) { return kit.num(e, 4); }).join(', ') + '   (η_R = ' + kit.num(D.triplet_etaR, 4) + ' = ln 2 / π)';
    }
    function drawTrip() {
      var c = cvTr.ctx, W = cvTr.size().w, H = cvTr.h; c.clearRect(0, 0, W, H);
      var box = { l: 58, r: W - 10, t: 10, b: H - 36 }, T = XB.triplet, F = D.triplet_fluid_161;
      var ax = kit.axes(c, box, { xmin: 0.005, xmax: 0.06, xlog: true, ymin: 5e-5, ymax: 1, ylog: true, xticks: [0.00625, 0.0125, 0.025, 0.05], yticks: [0.0001, 0.001, 0.01, 0.1, 1], xlabel: S(P + 'cv.vt'), ylabel: S(P + 'cv.omc') });
      var cols = { full: kit.accent(), rs: kit.warm(), mom: kit.violet, fluid: kit.blue };
      FORMS.forEach(function (fm) {
        var pts = DEN.map(function (n, i) { return [1 / n, 1 - tripC(fm, i)]; });
        kit.curve(c, pts, ax.x, ax.y, cols[fm], fm === st.form ? 2.6 : 1.3, fm === 'fluid' ? [5, 3] : null);
        pts.forEach(function (p, i) { c.fillStyle = cols[fm]; c.beginPath(); c.arc(ax.x(p[0]), ax.y(p[1]), i === st.tv && fm === st.form ? 5.5 : 3, 0, 6.2832); c.fill(); });
      });
      c.strokeStyle = kit.muted(); c.lineWidth = 1; c.setLineDash([3, 3]); c.beginPath(); c.moveTo(ax.x(1 / DEN[st.tv]), box.t); c.lineTo(ax.x(1 / DEN[st.tv]), box.b); c.stroke(); c.setLineDash([]);
      c.font = '11px system-ui, sans-serif'; c.textAlign = 'left'; FORMS.forEach(function (fm, j) { c.fillStyle = cols[fm]; c.fillText(S(P + 'form.' + fm), box.l + 8, box.t + 13 + 13 * j); });
      var n = DEN[st.tv];
      rdTr1.textContent = S(P + 'rd.tri').replace('{n}', n) + ' ' + FORMS.map(function (fm) { var C = tripC(fm, st.tv); return S(P + 'form.' + fm) + ': C = ' + kit.num(C, 5) + ', R = ' + kit.num(1 - C, 5); }).join(';  ');
      rdTr2.textContent = S(P + 'tri.leave.kin') + ' ' + S(P + 'tri.leave.fl');
      rdTr3.textContent = S(P + 'tri.cold').replace('{a}', kit.num(F.cold_A, 5)) + '   η_L = ' + kit.num(F.etaL, 5) + ', η_R = ' + kit.num(D.triplet_etaR, 4);
    }
    // ---- the hot electrons' wave on the ramp
    function umap(u) { if (st.hv === 'near') return u / WIN; return (u < 0 ? -1 : 1) * Math.log(1 + Math.abs(u) / 0.05) / Math.log(1 + 40 / 0.05); }
    function hbox(W, H, bot) { return { l: 50, r: W - 12, t: 10, b: H - bot }; }
    function hx(box, xp) { return box.l + (umap(-xp) + 1) / 2 * (box.r - box.l); }
    function hframe(c, box, labelsOn, H) {
      c.strokeStyle = kit.muted(); c.lineWidth = 1; c.strokeRect(box.l, box.t, box.r - box.l, box.b - box.t);
      var tk = st.hv === 'near' ? [-0.8, -0.4, 0, 0.4, 0.8] : [-40, -10, -1, -0.1, 0, 0.1, 1, 10, 40];
      c.fillStyle = kit.muted(); c.font = '11px system-ui, sans-serif'; c.textAlign = 'center';
      tk.forEach(function (u) { var x = box.l + (umap(u) + 1) / 2 * (box.r - box.l); c.beginPath(); c.moveTo(x, box.b); c.lineTo(x, box.b + 4); c.stroke(); if (labelsOn) c.fillText(String(u), x, box.b + 15); });
      if (labelsOn) c.fillText(S(P + 'cv.x'), (box.l + box.r) / 2, H - 4);
      var x0 = box.l + (umap(0) + 1) / 2 * (box.r - box.l); c.strokeStyle = kit.warm(); c.lineWidth = 2; c.beginPath(); c.moveTo(x0, box.t); c.lineTo(x0, box.b); c.stroke();
    }
    function vis(R) { var o = []; R.x.forEach(function (x, i) { if (st.hv === 'whole' || Math.abs(x) <= WIN) o.push(i); }); return o; }
    function trace(c, box, R, arr, ymax, y0, h, col, w, dash, mid) {
      c.strokeStyle = col; c.lineWidth = w; c.setLineDash(dash || []); c.beginPath(); var first = true;
      vis(R).sort(function (a, b) { return hx(box, R.x[a]) - hx(box, R.x[b]); }).forEach(function (i) { var x = hx(box, R.x[i]), y = mid ? y0 - arr[i] / ymax * h : y0 - arr[i] / ymax * h; if (first) { c.moveTo(x, y); first = false; } else c.lineTo(x, y); });
      c.stroke(); c.setLineDash([]);
    }
    function mx(a, idx) { var m = 0; idx.forEach(function (i) { m = Math.max(m, Math.abs(a[i])); }); return m; }
    function drawHot() {
      var yk = st.hy === '9/10' ? '0.9' : '0.4'; RK = XB.ramps[yk + '_kinetic']; RF = XB.ramps[yk + '_fluid'];
      var c = cvH1.ctx, W = cvH1.size().w, H = cvH1.h; c.clearRect(0, 0, W, H);
      var box = hbox(W, H, 34), h = box.b - box.t - 6;
      hframe(c, box, true, H);
      c.save(); c.beginPath(); c.rect(box.l, box.t, box.r - box.l, box.b - box.t); c.clip();
      // the density, faint: area under X / 1.5
      c.fillStyle = 'rgba(43,95,158,0.10)'; c.beginPath(); c.moveTo(box.r, box.b); c.moveTo(box.l, box.b);
      var iv = vis(RK).sort(function (a, b) { return hx(box, RK.x[a]) - hx(box, RK.x[b]); });
      iv.forEach(function (i) { c.lineTo(hx(box, RK.x[i]), box.b - RK.X[i] / 1.5 * h * 0.75); }); c.lineTo(box.r, box.b); c.closePath(); c.fill();
      var mk = mx(RK.absEy, vis(RK)), mf = mx(RF.absEy, vis(RF));
      trace(c, box, RF, RF.absEy, mf, box.b - 3, h, kit.ink(), 1.5, [5, 3]);
      trace(c, box, RK, RK.absEy, mk, box.b - 3, h, kit.accent(), 2);
      c.restore();
      c.font = '11px system-ui, sans-serif'; c.textAlign = 'left';
      var lx0 = box.l + 8; [['hot.kin', kit.accent()], ['hot.fl', kit.ink()], ['hot.dens', kit.blue]].forEach(function (p) { c.fillStyle = p[1]; c.fillText(S(P + p[0]), lx0, box.t + 14); lx0 += c.measureText(S(P + p[0])).width + 16; });
      c.save(); c.translate(12, (box.t + box.b) / 2); c.rotate(-Math.PI / 2); c.textAlign = 'center'; c.fillStyle = kit.muted(); c.fillText(S(P + 'hot.ey'), 0, 0); c.restore();
      // Re E_x, near the layer only
      c = cvH2.ctx; W = cvH2.size().w; H = cvH2.h; c.clearRect(0, 0, W, H);
      box = hbox(W, H, 12); hframe(c, box, false, H);
      var nk = 0, nf2 = 0;
      if (st.hv === 'near') {
        var ik = vis(RK), iF = vis(RF); nk = mx(RK.reEx, ik); nf2 = mx(RF.reEx, iF);
        var mid = (box.t + box.b) / 2, hh = (box.b - box.t) / 2 - 4;
        c.save(); c.beginPath(); c.rect(box.l, box.t, box.r - box.l, box.b - box.t); c.clip();
        c.strokeStyle = kit.muted(); c.lineWidth = 1; c.beginPath(); c.moveTo(box.l, mid); c.lineTo(box.r, mid); c.stroke();
        trace(c, box, RF, RF.reEx, nf2, mid, hh, kit.ink(), 1.4, [5, 3]);
        trace(c, box, RK, RK.reEx, nk, mid, hh, kit.accent(), 1.8);
        c.restore();
      } else { c.fillStyle = kit.muted(); c.font = '12px system-ui, sans-serif'; c.textAlign = 'center'; c.fillText(S(P + 'hot.nearonly'), (box.l + box.r) / 2, (box.t + box.b) / 2); }
      c.save(); c.translate(12, (box.t + box.b) / 2); c.rotate(-Math.PI / 2); c.textAlign = 'center'; c.fillStyle = kit.muted(); c.font = '11px system-ui, sans-serif'; c.fillText(S(P + 'hot.ex'), 0, 0); c.restore();
      // the bars: R, T, C of both
      c = cvH4.ctx; W = cvH4.size().w; H = cvH4.h; c.clearRect(0, 0, W, H);
      var gw = (W - 40) / 2, bw = Math.min(46, gw / 4), base = H - 38, top = 16, labs = ['R', 'T', 'C'];
      [[RK, kit.accent(), 'hot.kin'], [RF, kit.ink(), 'hot.fl']].forEach(function (g, gi) {
        var x0 = 20 + gi * (gw + 0), cx = x0 + gw / 2;
        [g[0].R, g[0].T, g[0].C].forEach(function (v, j) {
          var x = cx + (j - 1) * (bw + 10) - bw / 2, hgt = v * (base - top);
          c.fillStyle = g[1]; c.globalAlpha = 0.85; c.fillRect(x, base - hgt, bw, hgt); c.globalAlpha = 1;
          c.fillStyle = kit.ink(); c.font = '11px system-ui, sans-serif'; c.textAlign = 'center'; c.fillText(kit.num(v, 3), x + bw / 2, base - hgt - 3); c.fillStyle = kit.muted(); c.fillText(labs[j], x + bw / 2, base + 12);
        });
        c.fillStyle = g[1]; c.textAlign = 'center'; c.fillText(S(P + g[2]), cx, H - 4);
      });
      var f5 = function (v) { return kit.num(v, 3); };
      rdH1.textContent = S(P + 'rd.hot1').replace('{a}', f5(mk)).replace('{b}', f5(mf)).replace('{c}', st.hv === 'near' ? f5(nk) : '—').replace('{d}', st.hv === 'near' ? f5(nf2) : '—');
      rdH2.textContent = S(P + (st.hy === '9/10' ? 'rd.hot.y910' : 'rd.hot.y25')) + ' ' + S(P + 'rd.hot2').replace('{a}', f5(RK.R) + ', ' + f5(RK.T) + ', ' + f5(RK.C)).replace('{b}', f5(RF.R) + ', ' + f5(RF.T) + ', ' + f5(RF.C));
      drawCrests();
    }
    // crests, kinematically: positions where the phase gathered along the data's local wavenumber is a multiple of 2π, moving with the phase
    function runs(R, key, sign) { // points on one side within the window whose wavenumber is real, ordered outward from the layer (sign +1: x' > 0), with the phase gathered outward
      var pts = []; R.x.forEach(function (x, i) { if (sign * x > 0 && sign * x <= WIN && R[key][i][1] === 0) pts.push([sign * x, Math.abs(R[key][i][0])]); });
      pts.sort(function (a, b) { return a[0] - b[0] }); var s = 0, out = [[pts[0][0], 0]];
      for (var i = 1; i < pts.length; i++) { s += (pts[i][1] + pts[i - 1][1]) / 2 * (pts[i][0] - pts[i - 1][0]); out.push([pts[i][0], s]); }
      return out;
    }
    var CRES = { '9/10': { k: runs(XB.ramps['0.9_kinetic'], 'k2', -1), f: runs(XB.ramps['0.9_fluid'], 'k1', 1) }, '2/5': { k: runs(XB.ramps['0.4_kinetic'], 'k1', 1), f: runs(XB.ramps['0.4_fluid'], 'k1', 1) } };
    function crestXs(P_, cphase, sign) { // x' of the crests: phase s = cphase mod 2π; with the phase moving outward (sign of motion) as cphase grows
      var send = P_[P_.length - 1][1], xs = [], s = ((cphase % TWO) + TWO) % TWO;
      for (; s <= send; s += TWO) { var lo = 0, hi = P_.length - 1; while (hi - lo > 1) { var m = (lo + hi) >> 1; if (P_[m][1] <= s) lo = m; else hi = m; } var a = P_[lo], b = P_[hi]; xs.push(b[1] === a[1] ? a[0] : a[0] + (b[0] - a[0]) * (s - a[1]) / (b[1] - a[1])); }
      return xs;
    }
    function drawCrests() {
      var c = cvH3.ctx, W = cvH3.size().w, H = cvH3.h; c.clearRect(0, 0, W, H);
      if (st.hv !== 'near') return;
      var box = hbox(W, H, 0); box.t = 0; box.b = H;
      var ph0 = TAU * TWO * 0.6, CK = CRES[st.hy].k, CF = CRES[st.hy].f;
      if (st.hy === '2/5') {
        c.strokeStyle = kit.accent(); c.lineWidth = 2; crestXs(CK, ph0, 1).forEach(function (x) { var X = hx(box, x); c.beginPath(); c.moveTo(X, 3); c.lineTo(X, 12); c.stroke(); });
        c.strokeStyle = kit.ink(); crestXs(CF, ph0, 1).forEach(function (x) { var X = hx(box, x); c.beginPath(); c.moveTo(X, 14); c.lineTo(X, 23); c.stroke(); });
        var xa = hx(box, 0), La = Math.min(110, xa * 0.6); c.font = '11px system-ui, sans-serif'; c.textBaseline = 'middle';
        kit.arrow(c, xa - 14, 36, xa - 14 - La, 36, kit.accent(), 1.6); kit.arrow(c, xa - 14, 52, xa - 14 - La, 52, kit.accent(), 1.6);
        c.fillStyle = kit.accent(); c.textAlign = 'right'; c.fillText(S(P + 'hot.energy'), xa - 14 - La - 6, 36); c.fillText(S(P + 'hot.crests'), xa - 14 - La - 6, 52); c.textBaseline = 'alphabetic'; return;
      }
      // hot electrons: dense side (x' < 0); the phase gathered outward from the layer decreases in time there: the crests run toward the layer
      c.strokeStyle = kit.accent(); c.lineWidth = 2; crestXs(CK, -ph0, -1).forEach(function (x) { var X = hx(box, -x); c.beginPath(); c.moveTo(X, 3); c.lineTo(X, 20); c.stroke(); });
      c.strokeStyle = kit.ink(); c.lineWidth = 2; crestXs(CF, ph0, 1).forEach(function (x) { var X = hx(box, x); c.beginPath(); c.moveTo(X, 3); c.lineTo(X, 20); c.stroke(); });
      var x0 = hx(box, 0), L = Math.min(110, (box.r - x0) * 0.6), y1 = 33, y2 = 48; c.font = '11px system-ui, sans-serif'; c.textBaseline = 'middle';
      // dense side (right): energy away from the layer, crests toward it
      kit.arrow(c, x0 + 14, y1, x0 + 14 + L, y1, kit.accent(), 1.6); kit.arrow(c, x0 + 14 + L, y2, x0 + 14, y2, kit.accent(), 1.6);
      c.fillStyle = kit.accent(); c.textAlign = 'left'; c.fillText(S(P + 'hot.energy'), x0 + 14 + L + 6, y1); c.fillText(S(P + 'hot.crests'), x0 + 14 + L + 6, y2);
      // low-density side (left): both outward
      kit.arrow(c, x0 - 14, y1, x0 - 14 - L, y1, kit.ink(), 1.6); kit.arrow(c, x0 - 14, y2, x0 - 14 - L, y2, kit.ink(), 1.6);
      c.fillStyle = kit.ink(); c.textAlign = 'right'; c.fillText(S(P + 'hot.energy'), x0 - 14 - L - 6, y1); c.fillText(S(P + 'hot.crests'), x0 - 14 - L - 6, y2);
      c.textBaseline = 'alphabetic';
    }
    // ---- where the converted wave goes
    function crossAt(lam, arr, level) { for (var i = 1; i < lam.length; i++) { var a = arr[i - 1], b = arr[i]; if (a == null || b == null) continue; if ((a - level) * (b - level) <= 0 && a !== b) return lam[i - 1] + (lam[i] - lam[i - 1]) * (level - a) / (b - a); } return null; }
    function drawPath() {
      var c = cvP.ctx, W = cvP.size().w, H = cvP.h; c.clearRect(0, 0, W, H);
      var p = XB.paths[st.py], U = p.XUH, box = { l: 58, r: W - 12, t: 10, b: H - 36 };
      var ax = kit.axes(c, box, { xmin: 0, xmax: 5, ymin: 0.3, ymax: 12, ylog: true, xticks: [0, 1, 2, 3, 4, 5], yticks: [0.5, 1, 2, 5, 10], xlabel: S(P + 'cv.lam'), ylabel: S(P + 'cv.xs') });
      c.save(); c.beginPath(); c.rect(box.l, box.t, box.r - box.l, box.b - box.t); c.clip();
      c.strokeStyle = kit.muted(); c.lineWidth = 1; c.setLineDash([2, 3]); c.beginPath(); c.moveTo(box.l, ax.y(1)); c.lineTo(box.r, ax.y(1)); c.stroke(); c.setLineDash([]);
      [[p.Xends[1] / U, 'path.dense', 0.5], [p.Xends[0] / U, 'path.low', 0.25]].forEach(function (e) { c.fillStyle = 'rgba(107,116,112,' + e[2] + ')'; c.fillRect(box.l, ax.y(e[0]) - 2, box.r - box.l, 4); });
      var rat = function (a) { return a.map(function (v) { return v == null ? null : v / U; }); };
      kit.curve(c, p.lam.map(function (l, i) { return [l, p.X1[i] == null ? NaN : p.X1[i] / U]; }), ax.x, ax.y, kit.ink(), 1.5, [5, 3]);
      kit.curve(c, p.lam.map(function (l, i) { return [l, p.Xstar[i] == null ? NaN : p.Xstar[i] / U]; }), ax.x, ax.y, kit.accent(), 2.4);
      c.restore();
      p.certified.forEach(function (q) { c.strokeStyle = kit.ink(); c.lineWidth = 1.6; c.beginPath(); c.arc(ax.x(q[0]), ax.y(q[1] / U), 4.5, 0, 6.2832); c.stroke(); });
      var turn = XB.turn[st.py];
      if (turn) { c.fillStyle = kit.warm(); c.beginPath(); c.arc(ax.x(turn.lam), ax.y(turn.X / U), 5.5, 0, 6.2832); c.fill(); }
      c.font = '11px system-ui, sans-serif'; c.textAlign = 'left';
      if (W > 480) [['path.full', kit.accent()], ['path.first', kit.ink()], ['path.cert', kit.ink()], ['path.dense', kit.muted()], ['path.low', kit.muted()]].concat(turn ? [['path.turn', kit.warm()]] : []).forEach(function (q, j) { c.fillStyle = q[1]; c.fillText(S(P + q[0]), box.l + 8, box.t + 14 + 13 * j); });
      var lam = p.lam, dn = p.Xends[1], lo = p.Xends[0], f3 = function (v) { return v == null ? S(P + 'path.never') : kit.num(v, 2); };
      rdP1.textContent = S(P + 'rd.path.dense').replace('{e}', kit.num(dn / U, 2)).replace('{a}', f3(crossAt(lam, p.Xstar, dn))).replace('{b}', f3(crossAt(lam, p.X1, dn)));
      rdP2.textContent = st.py === '9/10' ? '' : S(P + 'rd.path.low').replace('{e}', kit.num(lo / U, 2)).replace('{b}', f3(crossAt(lam, p.X1, lo)));
      rdP3.textContent = turn ? S(P + 'rd.turn').replace('{l}', kit.num(turn.lam, 3)).replace('{x}', kit.num(turn.X / U, 4)).replace('{xp}', kit.num(turn.x, 4)).replace('{ph}', turn.phase.map(function (q) { return 'v_t/c = 1/' + q[0] + ': ' + kit.num(q[1], 3) + ' rad (' + kit.num(q[1] / TWO, 3) + ')'; }).join(';  ')) : '';
    }
    function drawStep() {
      var c = cvSt.ctx, W = cvSt.size().w, H = cvSt.h; c.clearRect(0, 0, W, H);
      var st0 = XB.steps[st.sf + '|' + st.sy], Xs = XB.steps_X[st.sy], mid = W / 2, ph = H * 0.52, wide = W < 480;
      c.fillStyle = 'rgba(43,95,158,' + (0.06 + 0.22 * Xs[0]) + ')'; c.fillRect(0, 0, mid, ph); c.fillStyle = 'rgba(43,95,158,' + (0.06 + 0.22 * Xs[1]) + ')'; c.fillRect(mid, 0, W - mid, ph);
      c.strokeStyle = kit.warm(); c.lineWidth = 2.5; c.beginPath(); c.moveTo(mid, 0); c.lineTo(mid, ph); c.stroke();
      c.font = '11px system-ui, sans-serif'; c.fillStyle = kit.muted(); c.textAlign = 'left'; c.fillText(S(P + 'step.low') + '  X = ' + kit.num(Xs[0], 2), 8, 14); c.textAlign = 'right'; c.fillText(S(P + 'step.dense') + '  X = ' + kit.num(Xs[1], 2), W - 8, 14);
      var lw = function (v) { return 1.5 + 9 * v; }, L = Math.min(110, mid - 30);
      kit.arrow(c, mid - L - 10, ph * 0.5, mid - 8, ph * 0.5, kit.ink(), lw(1));
      kit.arrow(c, mid - 12, ph * 0.28, mid - 12 - L, ph * 0.28, kit.red, lw(st0.R));
      kit.arrow(c, mid - 12, ph * 0.78, mid - 12 - L, ph * 0.78, kit.accent(), lw(st0.C1));
      kit.arrow(c, mid + 12, ph * 0.28, mid + 12 + L, ph * 0.28, kit.blue, lw(st0.T));
      kit.arrow(c, mid + 12, ph * 0.78, mid + 12 + L, ph * 0.78, kit.accent(), lw(st0.C2));
      var vals = [[st0.R, kit.red, S(P + 'bar.reflected')], [st0.T, kit.blue, S(P + 'bar.transmitted')], [st0.C2, kit.accent(), S(P + 'step.c.dense')], [st0.C1, kit.accent(), S(P + 'step.c.low')]];
      var base = H - 44, top = ph + 20, bw = Math.min(70, (W - 40) / 4 - 10);
      vals.forEach(function (v, i) {
        var cx = 20 + (W - 40) * (i + 0.5) / 4, hgt = v[0] * (base - top);
        c.fillStyle = v[1]; c.globalAlpha = 0.85; c.fillRect(cx - bw / 2, base - hgt, bw, hgt); c.globalAlpha = 1;
        c.fillStyle = kit.ink(); c.textAlign = 'center'; c.fillText(kit.num(v[0], 6), cx, base - hgt - 3);
        c.fillStyle = kit.muted(); var ws = v[2].split(' '), ln = '', yy = H - 24, cw = (W - 40) / 4 - 6; ws.forEach(function (w) { if (ln && c.measureText(ln + ' ' + w).width > cw) { c.fillText(ln, cx, yy); yy += 12; ln = w; } else ln = ln ? ln + ' ' + w : w; }); c.fillText(ln, cx, yy);
      });
      c.strokeStyle = kit.muted(); c.lineWidth = 1; c.beginPath(); c.moveTo(14, base); c.lineTo(W - 14, base); c.stroke();
      rdSt.textContent = S(P + 'rd.step').replace('{y}', st.sy).replace('{a}', Xs[0] === 0.05 ? '1/20' : '1/2').replace('{b}', Xs[1] === 0.25 ? '1/4' : '1').replace('{f}', S(P + 'form.' + st.sf)).replace('{r}', kit.num(st0.R, 6)).replace('{t}', kit.num(st0.T, 6)).replace('{c2}', kit.num(st0.C2, 6)).replace('{c1}', kit.num(st0.C1, 6)).replace('{s}', (st0.R + st0.T + st0.C1 + st0.C2).toFixed(10));
    }
    // ---- shared sound switch: every Play on the page turns the same sound on
    function togglePlay() {
      if (!st.snd) { if (!kit.audio()) { nf.style.display = ''; return; } st.snd = true; } else st.snd = false;
      plays.forEach(function (b) { b.textContent = S(st.snd ? 'exp.common.mute' : 'exp.common.play'); b.setAttribute('data-s', st.snd ? 'exp.common.mute' : 'exp.common.play'); });
    }
    // ---- (g) the cavity's phase
    var PK = ['full20', 'full40', 'full80', 'full160'];
    function supE(v) { var e = Math.floor(Math.log10(Math.abs(v))), m = v / Math.pow(10, e); return kit.num(m, 1) + '·10' + String(e).split('').map(function (ch) { return '⁻⁰¹²³⁴⁵⁶⁷⁸⁹'.charAt('-0123456789'.indexOf(ch)); }).join(''); }
    function logE(s) { var p = s.split('e'); return p[0] + '·10' + String(+p[1]).split('').map(function (ch) { return '⁻⁰¹²³⁴⁵⁶⁷⁸⁹'.charAt('-0123456789'.indexOf(ch)); }).join(''); }
    function phaseR(eta, i) { // R = 1 - C at eta from the data of temperature i: the scan (1/40, 1/80) or the five points about the extrema (1/20, 1/160)
      var C = null;
      if (i === 1 || i === 2) C = kit.interp(TP.grid.map(function (e, j) { return [e, TP.scan[i === 1 ? 'full40' : 'full80'][j]]; }), eta);
      else { var k = PK[i]; C = kit.interp(TP.mini[k + '_max1'], eta); if (C == null) C = kit.interp(TP.mini[k + '_min1'], eta); }
      return C == null ? null : 1 - C;
    }
    function sendPhase() { if (!st.snd) return; var R = phaseR(st.peta, st.pt); kit.tone({ f: FREQ, gain: 0.2, dur: 0.4, at: 0 }); if (R != null && R > 1e-4) kit.tone({ f: FREQ, gain: 0.28 * Math.sqrt(R), dur: 0.5, at: 0.7 }); }
    function leg(c, items, x, y) { // a small legend on a light ground: items [[text, colour]]
      c.font = '11px system-ui, sans-serif'; var w = 0; items.forEach(function (q) { w = Math.max(w, c.measureText(q[0]).width); });
      c.globalAlpha = 0.88; c.fillStyle = kit.panel(); c.fillRect(x - 4, y - 11, w + 8, 13 * items.length + 4); c.globalAlpha = 1;
      c.textAlign = 'left'; items.forEach(function (q, j) { c.fillStyle = q[1]; c.fillText(q[0], x, y + 13 * j); });
    }
    function vline(c, x, t, b, col, dash) { c.strokeStyle = col; c.lineWidth = 1; c.setLineDash(dash || [2, 3]); c.beginPath(); c.moveTo(x, t); c.lineTo(x, b); c.stroke(); c.setLineDash([]); }
    function dot(c, x, y, r, col, open) { c.beginPath(); c.arc(x, y, r, 0, 6.2832); if (open) { c.strokeStyle = col; c.lineWidth = 1.5; c.fillStyle = kit.panel(); c.fill(); c.stroke(); } else { c.fillStyle = col; c.fill(); } }
    function drawPhase() {
      var c = cvQ.ctx, W = cvQ.size().w, H = cvQ.h; c.clearRect(0, 0, W, H);
      var box = { l: 44, r: W - 12, t: 12, b: H - 34 }, G = TP.grid;
      var ax = kit.axes(c, box, { xmin: 0.2, xmax: 3.2, ymin: 0, ymax: 1.03, xticks: [0.5, 1, 1.5, 2, 2.5, 3], yticks: [0, 0.5, 1], xlabel: S(P + 'cv.etal'), ylabel: S(P + 'cv.c') });
      TP.zeros.forEach(function (z) { if (z < 3.2) vline(c, ax.x(z), box.t, box.b, kit.muted()); });
      vline(c, ax.x(TP.nodes[0]), box.t, box.b, kit.ink());
      kit.curve(c, TP.cold_fine, ax.x, ax.y, 'rgba(107,116,112,0.55)', 3);
      kit.curve(c, G.map(function (e, j) { return [e, TP.scan.fluid40[j]]; }), ax.x, ax.y, kit.warm(), 1.5, [6, 4]);
      kit.curve(c, G.map(function (e, j) { return [e, TP.scan.full40[j]]; }), ax.x, ax.y, kit.accent(), st.pt === 1 ? 2.6 : 1.6);
      kit.curve(c, G.map(function (e, j) { return [e, TP.scan.full80[j]]; }), ax.x, ax.y, kit.blue, st.pt === 2 ? 2.4 : 1.3, [2, 3]);
      TP.cold_layered.forEach(function (p) { dot(c, ax.x(p[0]), ax.y(p[1]), 3.5, kit.ink(), true); });
      TP.gridc.forEach(function (e, j) {
        var x = ax.x(e), y1 = ax.y(TP.scan.rs40[j]), y2 = ax.y(TP.scan.mom40[j]);
        c.strokeStyle = kit.violet; c.lineWidth = 1.4; c.strokeRect(x - 3.5, y1 - 3.5, 7, 7);
        c.strokeStyle = '#2f8a5f'; c.beginPath(); c.moveTo(x, y2 - 4.5); c.lineTo(x + 4, y2 + 3); c.lineTo(x - 4, y2 + 3); c.closePath(); c.stroke();
      });
      var k = PK[st.pt], mx = TP.extrema[k + '_max1'], mn = TP.extrema[k + '_min1'];
      if (st.pt === 0 || st.pt === 3) { kit.curve(c, TP.mini[k + '_max1'], ax.x, ax.y, kit.warm(), 1.2); kit.curve(c, TP.mini[k + '_min1'], ax.x, ax.y, kit.warm(), 1.2); }
      dot(c, ax.x(mx.x), ax.y(mx.C), 6, kit.warm()); dot(c, ax.x(mn.x), ax.y(mn.C), 6, kit.warm());
      var pr = phaseR(st.peta, st.pt); vline(c, ax.x(st.peta), box.t, box.b, kit.accent(), [6, 3]);
      if (pr != null) dot(c, ax.x(st.peta), ax.y(1 - pr), 4, kit.accent());
      c.font = '11px system-ui, sans-serif'; c.textAlign = 'left'; c.fillStyle = kit.muted();
      c.fillText(S(P + 'ph.zero'), ax.x(TP.zeros[0]) + 4, box.b - 6); c.fillText(S(P + 'ph.node'), ax.x(TP.nodes[0]) + 4, box.t + 12);
      if (W > 560) leg(c, [['ph.l.cold', 'rgba(107,116,112,0.9)'], ['ph.l.layered', kit.ink()], ['ph.l.fluid', kit.warm()], ['ph.l.full40', kit.accent()], ['ph.l.full80', kit.blue], ['ph.l.rs', kit.violet], ['ph.l.mom', '#2f8a5f'], ['ph.l.ext', kit.warm()]].map(function (q) { return [S(P + q[0]), q[1]]; }), ax.x(0.8), ax.y(0.43));
      var d = TP.xdigits, n = DEN[st.pt], z = TP.at_cold_zero, sh = TP.shift;
      rdQ1.textContent = S(P + 'ph.rd.max').replace('{n}', n).replace('{x}', kit.num(mx.x, d.max[st.pt])).replace('{d}', (sh.shift[st.pt] >= 0 ? '+' : '') + kit.num(sh.shift[st.pt], 3)).replace('{z}', kit.num(TP.zeros[0], 5)).replace('{s}', supE(sh.short[st.pt])).replace('{m}', kit.num(mn.x, d.min[st.pt])).replace('{c}', logE(TP.cmin_log[st.pt]));
      var part = z.part[st.pt], w = part < 0.05 ? 'ph.split.lower' : part > 0.95 ? 'ph.split.moved' : 'ph.split.both';
      rdQ2.textContent = S(P + 'ph.rd.split').replace('{t}', supE(z.total[st.pt])).replace('{a}', supE(z.lower[st.pt])).replace('{b}', supE(z.moved[st.pt])).replace('{p}', kit.num(part, 2)) + ' ' + S(P + w);
      var E = TP.extrema; rdQ3.textContent = S(P + 'ph.rd.forms').replace('{rs}', kit.num(E.rs40_max1.x, 3)).replace('{rc}', kit.num(E.rs40_max1.C, 4)).replace('{mo}', kit.num(E.mom40_max1.x, 3)).replace('{mc}', kit.num(E.mom40_max1.C, 4)).replace('{fl}', kit.num(E.fluid40_max1.x, 4)).replace('{fc}', kit.num(E.fluid40_max1.C, 4));
      rdQ4.textContent = pr == null ? S(P + 'ph.rd.r').replace('{x}', kit.num(st.peta, 3)).replace('{n}', n).replace('{r}', S('exp.common.outside')) : S(P + 'ph.rd.r').replace('{x}', kit.num(st.peta, 3)).replace('{n}', n).replace('{r}', kit.num(pr, 5));
    }
    function drawGentle() {
      var c = cvG.ctx, W = cvG.size().w, H = cvG.h; c.clearRect(0, 0, W, H);
      var g = TP.gentle[st.gs], cf = g.cold_fine, x0 = cf[0][0], x1 = cf[cf.length - 1][0];
      var fl = g.curves.fluid40 || TP.grid.map(function (e, j) { return [e, TP.scan.fluid40[j]]; }).filter(function (p) { return p[0] >= x0 && p[0] <= x1; });
      var fu = g.curves.full40 || TP.grid.map(function (e, j) { return [e, TP.scan.full40[j]]; }).filter(function (p) { return p[0] >= x0 && p[0] <= x1; });
      var ys = cf.concat(fl, fu).map(function (p) { return p[1]; }), y0 = Math.min.apply(null, ys), y1 = Math.max.apply(null, ys), pad = (y1 - y0) * 0.08;
      var box = { l: 46, r: W - 10, t: 10, b: H - 32 };
      var ax = kit.axes(c, box, { xmin: x0, xmax: x1, ymin: y0 - pad, ymax: y1 + pad, xticks: [x0, (x0 + x1) / 2, x1].map(function (v) { return +v.toFixed(2); }), yticks: [y0, y1].map(function (v) { return +v.toFixed(2); }), xlabel: S(P + 'cv.etal'), ylabel: S(P + 'cv.c') });
      c.strokeStyle = kit.muted(); c.setLineDash([2, 3]); c.beginPath(); c.moveTo(box.l, ax.y(g.env)); c.lineTo(box.r, ax.y(g.env)); c.stroke(); c.setLineDash([]);
      vline(c, ax.x(g.cold_zero), box.t, box.b, kit.muted());
      kit.curve(c, cf, ax.x, ax.y, 'rgba(107,116,112,0.55)', 3);
      kit.curve(c, fl, ax.x, ax.y, kit.warm(), 1.5, [6, 4]); kit.curve(c, fu, ax.x, ax.y, kit.accent(), 2);
      dot(c, ax.x(g.max.fluid40[0]), ax.y(g.max.fluid40[1]), 4.5, kit.warm()); dot(c, ax.x(g.max.full40[0]), ax.y(g.max.full40[1]), 4.5, kit.accent());
      var f4 = function (v) { return (v >= 0 ? '+' : '−') + kit.num(Math.abs(v), 4); };
      rdG.textContent = S(P + 'ph.rd.gentle').replace('{s}', st.gs).replace('{e}', kit.num(g.env, 6)).replace('{z}', kit.num(g.cold_zero, 5)).replace('{x}', kit.num(g.max.full40[0], 3)).replace('{c}', kit.num(g.max.full40[1], 4)).replace('{dc}', f4(g.max.full40[1] - g.env)).replace('{xf}', kit.num(g.max.fluid40[0], 3)).replace('{cf}', kit.num(g.max.fluid40[1], 4)).replace('{df}', f4(g.max.fluid40[1] - g.env));
    }
    // ---- (h) the O–X window
    var OXC = { '1': kit.blue, '2': '#2f8a5f', '4': kit.warm(), '16': kit.violet };
    function oxPts() { // the layered points of the chosen stretch, with N_z,opt from the chain (MUS-208: A = T_OX there), sorted
      var w = OX.window[st.os], pts = w.Nz.map(function (z, i) { return [z, w.T[i]]; }), si = OX.chain.s.indexOf(+st.os);
      if (st.os !== '16' && si >= 0) pts.push([OX.marks.Nzopt, OX.chain.A[si], 'opt']);
      return pts.sort(function (a, b) { return a[0] - b[0]; });
    }
    function mjAt(s, z) { var w = OX.window[s]; return kit.interp(w.mjNz.map(function (q, i) { return [q, w.mj[i]]; }), z); }
    function sendOX() {
      if (!st.snd) return; var p = oxPts()[st.oz]; if (!p) return; var T = p[1], R = 1 - T;
      kit.tone({ f: FREQ, gain: 0.2, dur: 0.4, at: 0 });
      if (T > 1e-4) kit.tone({ f: FREQ * 2 / 3, gain: 0.28 * T, dur: 0.6, at: 0.7 });
      if (R > 1e-4) kit.tone({ f: FREQ, gain: 0.28 * R, dur: 0.5, at: 0.7 });
    }
    function drawOX() {
      var c = cvO.ctx, W = cvO.size().w, H = cvO.h; c.clearRect(0, 0, W, H);
      var box = { l: 44, r: W - 12, t: 12, b: H - 34 }, M = OX.marks;
      var ax = kit.axes(c, box, { xmin: 0.5, xmax: 0.96, ymin: 0, ymax: 1.05, xticks: [0.5, 0.6, 0.7, 0.8, 0.9], yticks: [0, 0.5, 1], xlabel: S(P + 'ox.cv.nz'), ylabel: S(P + 'ox.cv.t') });
      vline(c, ax.x(M.Nzopt), box.t, box.b, kit.ink()); vline(c, ax.x(OX.Nz_fastX_log), box.t, box.b, kit.muted(), [5, 3]);
      ['1', '2', '4', '16'].forEach(function (s) {
        var w = OX.window[s], col = OXC[s], sel = s === st.os;
        kit.curve(c, w.mjNz.map(function (q, i) { return [q, w.mj[i]]; }), ax.x, ax.y, col, sel ? 1.6 : 1, [1.5, 3]);
        var pts = w.Nz.map(function (z, i) { return [z, w.T[i]]; });
        if (s !== '16') kit.curve(c, pts, ax.x, ax.y, col, sel ? 2.6 : 1.4);
        pts.forEach(function (p) { dot(c, ax.x(p[0]), ax.y(p[1]), sel ? 4 : 3, col); });
        var si = OX.chain.s.indexOf(+s); if (s !== '16' && si >= 0) dot(c, ax.x(M.Nzopt), ax.y(OX.chain.A[si]), sel ? 4.5 : 3.5, col, true);
      });
      dot(c, ax.x(OX.peak1[0]), ax.y(OX.peak1[1]), 6, kit.blue, true);
      var p = oxPts()[st.oz]; if (p) { vline(c, ax.x(p[0]), box.t, box.b, kit.accent(), [6, 3]); dot(c, ax.x(p[0]), ax.y(p[1]), 6.5, kit.accent()); }
      c.font = '11px system-ui, sans-serif'; c.fillStyle = kit.muted(); c.textAlign = 'left';
      c.fillText(S(P + 'ox.l.opt'), ax.x(M.Nzopt) + 4, box.b - 6); c.textAlign = 'right'; c.fillText(S(P + 'ox.l.fast'), ax.x(OX.Nz_fastX_log) - 4, box.b - 6); c.textAlign = 'left';
      leg(c, ['1', '2', '4', '16'].map(function (s) { return [S(P + 'ox.s' + s), OXC[s]]; }).concat([[S(P + 'ox.l.mj'), kit.muted()]]), box.l + 8, ax.y(0.42));
      if (!p) return;
      var m = p[2] === 'opt' ? OX.chain.mj[OX.chain.s.indexOf(+st.os)] : mjAt(st.os, p[0]);
      rdO1.textContent = S(P + 'ox.rd').replace('{s}', st.os).replace('{z}', kit.num(p[0], 4)).replace('{t}', kit.num(p[1], 5)).replace('{r}', kit.num(1 - p[1], 5)).replace('{m}', m == null ? S('exp.common.outside') : kit.num(m, 5));
      var atOpt = Math.abs(p[0] - M.Nzopt) < 1e-3, si = OX.chain.s.indexOf(+st.os), line = '';
      if (atOpt && st.os !== '16') line = S(P + 'ox.rd.opt').replace('{t}', kit.num(OX.chain.A[si], 5)).replace('{m}', kit.num(OX.chain.mj[si], 0));
      if (st.os === '16') line = S(P + 'ox.rd.s16').replace('{w}', kit.num(OX.s16_within, 4));
      if (st.os === '1') line = (line ? line + ' ' : '') + S(P + 'ox.rd.top').replace('{t}', kit.num(OX.peak1[1], 5)).replace('{z}', kit.num(OX.peak1[0], 3)).replace('{f}', kit.num(OX.Nz_fastX_log, 5)).replace('{o}', kit.num(M.Nzopt, 4));
      rdO2.textContent = line; rdO2.style.display = line ? '' : 'none';
    }
    function drawRoots() {
      var c = cvR.ctx, W = cvR.size().w, H = cvR.h; c.clearRect(0, 0, W, H);
      var R = OX.roots[st.or], M = OX.marks, box = { l: 44, r: W - 10, t: 10, b: H - 32 };
      var ax = kit.axes(c, box, { xmin: 0, xmax: 1.45, ymin: -0.6, ymax: 1.6, xticks: [0, 0.5, 1], yticks: [-0.5, 0, 0.5, 1, 1.5], xlabel: S(P + 'ox.cv.x'), ylabel: S(P + 'ox.cv.u') });
      c.save(); c.beginPath(); c.rect(box.l, box.t, box.r - box.l, box.b - box.t); c.clip();
      var X = R.X, n = X.length, i;
      for (i = 0; i < n; i++) {
        var xa = ax.x(i ? (X[i - 1] + X[i]) / 2 : X[i]), xb = ax.x(i < n - 1 ? (X[i] + X[i + 1]) / 2 : X[i]), cpx = R.u1[i][1] !== 0 || R.u2[i][1] !== 0;
        if (cpx) { c.fillStyle = 'rgba(107,116,112,0.18)'; c.fillRect(xa, box.t, xb - xa, box.b - box.t); }
        else if (X[i] > M.XUH && Math.min(R.u1[i][0], R.u2[i][0]) < 0) { c.fillStyle = 'rgba(180,85,43,0.16)'; c.fillRect(xa, box.t, xb - xa, box.b - box.t); }
      }
      // hatch the complex pair
      c.strokeStyle = 'rgba(107,116,112,0.5)'; c.lineWidth = 1;
      var cx0 = null; for (i = 0; i < n; i++) if (R.u1[i][1] !== 0 || R.u2[i][1] !== 0) { cx0 = ax.x(X[i]); break; }
      if (cx0 != null) for (var hx_ = cx0; hx_ < box.r; hx_ += 9) { c.beginPath(); c.moveTo(hx_, box.b); c.lineTo(hx_ + 40, box.t); c.stroke(); }
      c.strokeStyle = kit.muted(); c.beginPath(); c.moveTo(box.l, ax.y(0)); c.lineTo(box.r, ax.y(0)); c.stroke();
      // two tracks, paired by continuity (the roots are stored by size)
      var a = [], b = [], pa_ = R.u1[0][0], pb_ = R.u2[0][0];
      for (i = 0; i < n; i++) { var u = R.u1[i][0], v = R.u2[i][0]; if (Math.abs(u - pa_) + Math.abs(v - pb_) > Math.abs(v - pa_) + Math.abs(u - pb_)) { var t_ = u; u = v; v = t_; } a.push([X[i], u]); b.push([X[i], v]); pa_ = u; pb_ = v; }
      function cut(arr) { return arr.map(function (p) { return Math.abs(p[1]) > 3 ? [p[0], NaN] : p; }); }
      kit.curve(c, cut(a), ax.x, ax.y, kit.accent(), 2); kit.curve(c, cut(b), ax.x, ax.y, kit.blue, 2);
      c.restore();
      vline(c, ax.x(M.XUH), box.t, box.b, kit.warm()); vline(c, ax.x(M.X1), box.t, box.b, kit.ink());
      c.font = '11px system-ui, sans-serif'; c.textAlign = 'left'; c.fillStyle = kit.warm(); c.fillText(S(P + 'cv.uh'), ax.x(M.XUH) + 3, box.t + 11);
      c.fillStyle = kit.ink(); c.fillText('X = 1', ax.x(1) + 3, box.t + 24);
      leg(c, [[S(P + 'ox.l.gap'), 'rgba(180,85,43,0.95)'], [S(P + 'ox.l.cpx'), kit.muted()]], box.l + 14, box.b - 20);
    }
    function drawChain() {
      var c = cvCh.ctx, W = cvCh.size().w, H = cvCh.h; c.clearRect(0, 0, W, H);
      var C = OX.chain, box = { l: 40, r: W - 10, t: 10, b: H - 32 };
      var ax = kit.axes(c, box, { xmin: 0.8, xmax: 20, xlog: true, ymin: 0, ymax: 1.05, xticks: [1, 2, 4, 16], yticks: [0, 0.5, 1], xlabel: S(P + 'ox.cv.s'), ylabel: S(P + 'ox.cv.share') });
      var A = C.s.map(function (s, i) { return [s, C.A[i]]; }), RO = C.s.map(function (s, i) { return [s, C.RO[i]]; }), B = C.s.map(function (s, i) { return [s, C.buddenA[i]]; });
      kit.curve(c, B, ax.x, ax.y, kit.muted(), 1.2, [2, 3]); kit.curve(c, A, ax.x, ax.y, kit.accent(), 2); kit.curve(c, RO, ax.x, ax.y, kit.warm(), 1.6, [6, 4]);
      A.forEach(function (p) { dot(c, ax.x(p[0]), ax.y(p[1]), 3.5, kit.accent()); }); RO.forEach(function (p) { dot(c, ax.x(p[0]), ax.y(p[1]), 3.5, kit.warm()); }); B.forEach(function (p) { dot(c, ax.x(p[0]), ax.y(p[1]), 3, kit.muted(), true); });
      [['0.54', '×'], ['0.56', '+']].forEach(function (q) { var L = OX.leak[q[0]]; c.fillStyle = kit.violet; c.font = '13px system-ui, sans-serif'; c.textAlign = 'center'; L.s.forEach(function (s, i) { c.fillText(q[1], ax.x(s), ax.y(L.RX[i]) + 4); }); });
      c.font = '11px system-ui, sans-serif'; c.textAlign = 'left';
      leg(c, [['ox.l.A', kit.accent()], ['ox.l.RO', kit.warm()], ['ox.l.budden', kit.muted()], ['ox.l.leak', kit.violet]].map(function (q) { return [S(P + q[0]), q[1]]; }), ax.x(1.6), ax.y(0.62));
    }
    function drawNy() {
      var c = cvNy.ctx, W = cvNy.size().w, H = cvNy.h; c.clearRect(0, 0, W, H);
      var N = OX.ny, box = { l: 40, r: W - 10, t: 10, b: H - 32 };
      var ax = kit.axes(c, box, { xmin: -0.32, xmax: 0.32, ymin: 0, ymax: 1.05, xticks: [-0.3, -0.2, -0.1, 0, 0.1, 0.2, 0.3], yticks: [0, 0.5, 1], xlabel: S(P + 'ox.cv.ny'), ylabel: S(P + 'ox.cv.t') });
      var T = N.Ny.map(function (y, i) { return [y, N.T[i]]; }), Mj = N.Ny.map(function (y, i) { return [y, N.mj[i]]; });
      kit.curve(c, Mj, ax.x, ax.y, kit.blue, 1.3, [1.5, 3]); kit.curve(c, T, ax.x, ax.y, kit.blue, 2);
      T.forEach(function (p) { dot(c, ax.x(p[0]), ax.y(p[1]), 3.5, kit.blue); });
      leg(c, [[S(P + 'ox.l.layers'), kit.blue], [S(P + 'ox.l.mj'), kit.muted()]], box.l + 8, box.b - 20);
    }
    function draw() { drawProfile(); drawBudden(); drawBars(); drawTrip(); drawFlux(); drawCavity(); drawHot(); drawStep(); drawPath(); drawPhase(); drawGentle(); drawOX(); drawRoots(); drawChain(); drawNy(); }
    kit.loop(function (tm, dt) { if (!st.hp) TAU += dt * 0.35; drawCrests(); });
    window.addEventListener('resize', function () { redraw.forEach(function (f) { f(); }); draw(); });
    draw();
    explain(root, SL, S, kit);
  } };
  function explain(root, slug, S, kit) {
    var p = kit.panel_(root, null, S, 'span');
    var a = kit.panel_(p, 'exp.common.see', S); kit.line(a, 'exp.' + slug + '.see', S);
    var h = kit.panel_(p, 'exp.common.hear', S); kit.line(h, 'exp.' + slug + '.hear', S);
    p.appendChild(kit.el('p', { class: 'exp-source' }, [kit.el('b', { 'data-s': 'exp.common.data', text: S('exp.common.data') }), ' ', kit.el('span', { 'data-s': 'exp.' + slug + '.data', text: S('exp.' + slug + '.data') })]));
  }
})();
