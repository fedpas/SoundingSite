// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// coupling.js — The coupling by grade (MUS-078, 079, 081, 084, 094, 095, 107)
(function () {
  'use strict';
  window.SDV_EXP = window.SDV_EXP || {};
  window.SDV_EXP['coupling'] = { mount: function (root, data, S, kit) {
    var P = 'exp.coupling.', el = kit.el, TAU = Math.PI * 2;
    var st = { b0: false, two: false, stream: false, on: false };
    function cv(parent, a, m) { var d = el('div', { class: 'exp-cvwrap' }); parent.appendChild(d); return kit.canvas(d, a, m); }
    function txt(ctx, s, x, y, color, align, size) { ctx.fillStyle = color || kit.muted(); ctx.textAlign = align || 'left'; ctx.font = (size || 11) + 'px system-ui, sans-serif'; ctx.fillText(s, x, y); }
    function short(n) { return n.split(' =')[0]; }

    var pa = kit.panel_(root, P + 'panel.cube', S, 'span');
    var cc = cv(pa, 1.2, 330), ctl = kit.controls(pa);
    var playB = kit.button(ctl, 'exp.common.play', S, function () { st.on = !st.on; playB.textContent = S(st.on ? 'exp.common.mute' : 'exp.common.play'); playB.setAttribute('data-s', st.on ? 'exp.common.mute' : 'exp.common.play'); if (st.on) kit.click(600, 0.12); });
    function sw(key, sid, f) { kit.check(ctl, sid, S, false, function (v) { st[key] = v; if (st.on) kit.click(v ? f : f * 0.7, 0.12); draw(); readout(); }); }
    sw('b0', P + 'sw.b0', 700); sw('two', P + 'sw.two', 900); sw('stream', P + 'sw.stream', 1100);
    var rd = kit.readout(pa), rdM = kit.readout(pa);
    rdM.textContent = data.labels.map(function (l) { return 'g' + l.grade + ': ' + l.names.map(function (n, i) { return n + ' (' + l.masks[i] + ')'; }).join(' '); }).join('   ·   ');
    var lines = { base: kit.line(pa, P + 'line.base', S), b0: kit.line(pa, P + 'line.b0', S), two: kit.line(pa, P + 'line.two', S), stream: kit.line(pa, P + 'line.stream', S) };
    var ids = el('p', { class: 'exp-line' }); [['MUS-078', 'computed'], ['MUS-081', 'computed'], ['MUS-084', 'computed'], ['MUS-095', 'computed'], ['MUS-107', 'computed']].forEach(function (m) { ids.appendChild(el('code', { text: m[0] })); ids.appendChild(document.createTextNode(' ')); ids.appendChild(kit.chip(m[1])); ids.appendChild(document.createTextNode('  ')); }); pa.appendChild(ids);
    function readout() {
      lines.b0.style.display = st.b0 ? '' : 'none'; lines.two.style.display = st.two ? '' : 'none'; lines.stream.style.display = st.stream ? '' : 'none';
      rd.textContent = [st.b0 ? 'B₀' : '', st.two ? '2 fluids' : '1 fluid', st.stream ? 'stream' : ''].filter(Boolean).join(' · ');
    }

    var kinds = ['measurable', 'potential', 'source'];
    function layout(w, h) {
      var top = 28, g0 = 22, rh = (h - top - 32) / 5, cols = [], i;
      var usable = w - g0 - 6, nF = st.two ? 2 : 1, bw = st.two ? usable * 0.24 : usable * 0.34;
      for (i = 0; i < nF; i++) cols.push({ side: 'acoustics', x: g0 + (st.two ? i * usable * 0.31 : 0), w: bw });
      cols.push({ side: 'electromagnetism', x: g0 + usable - bw, w: bw });
      var rects = {};
      cols.forEach(function (col, ci) {
        for (var g = 0; g < 5; g++) {
          var items = []; kinds.forEach(function (k) { (data.fields[col.side][k] || []).forEach(function (f) { if (f.grade === g) items.push({ kind: k, name: short(f.name) }); }); });
          var ih = Math.min(22, (rh - 6) / Math.max(items.length, 1));
          items.forEach(function (it, j) { it.x = col.x; it.w = col.w; it.y = top + g * rh + 3 + j * (ih + 1); it.h = ih; rects[ci + ':' + g + ':' + it.kind] = it; });
        }
      });
      return { cols: cols, rects: rects, top: top, rh: rh, g0: g0, nF: nF };
    }
    function link(ctx, a, b, color, width, label, dash, off) {
      if (!a || !b) return; off = off || 0;
      var ax = a.x < b.x ? a.x + a.w : a.x, bx = a.x < b.x ? b.x : b.x + b.w, ay = a.y + a.h / 2 + off, by = b.y + b.h / 2 + off;
      ctx.setLineDash(dash || []); kit.arrow(ctx, ax, ay, bx, by, color, width || 1.5); ctx.setLineDash([]);
      if (label) txt(ctx, label, (ax + bx) / 2, (ay + by) / 2 - 4, color, 'center', 10);
    }
    function elbow(ctx, a, b, color, label) {
      var x = a.x - 7, ya = a.y + a.h / 2, yb = b.y + b.h / 2;
      ctx.strokeStyle = color; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(a.x, ya); ctx.lineTo(x, ya); ctx.lineTo(x, yb - 0.1); ctx.stroke(); kit.arrow(ctx, x, yb - 3, a.x - 0.5, yb, color, 1.6);
      if (label) txt(ctx, label, x - 2, (ya + yb) / 2, color, 'right', 9);
    }
    function draw() {
      var ctx = cc.ctx, w = cc.w, h = cc.h, L = layout(w, h), acc = kit.accent(), ink = kit.ink(), g, ci;
      ctx.clearRect(0, 0, w, h);
      L.cols.forEach(function (col, ci) {
        var isE = col.side === 'electromagnetism';
        txt(ctx, isE ? S(P + 'col.em') : (L.nF === 2 ? S(P + (ci ? 'col.ion' : 'col.el')) : S(P + 'col.fluid')), col.x + col.w / 2, 16, isE ? kit.red : kit.blue, 'center', 11);
      });
      for (g = 0; g < 5; g++) { ctx.strokeStyle = kit.muted(); ctx.globalAlpha = 0.25; ctx.beginPath(); ctx.moveTo(14, L.top + g * L.rh); ctx.lineTo(w - 4, L.top + g * L.rh); ctx.stroke(); ctx.globalAlpha = 1; txt(ctx, String(g), 4, L.top + g * L.rh + L.rh / 2 + 4, kit.ink(), 'left', 12); }
      Object.keys(L.rects).forEach(function (key) {
        var it = L.rects[key], isE = L.cols[+key.split(':')[0]].side === 'electromagnetism', col = isE ? kit.red : kit.blue;
        ctx.lineWidth = 1.2; ctx.strokeStyle = col; ctx.setLineDash(it.kind === 'potential' ? [4, 3] : []);
        if (it.kind === 'source') { ctx.fillStyle = col; ctx.globalAlpha = 0.14; ctx.fillRect(it.x, it.y, it.w, it.h); ctx.globalAlpha = 1; }
        ctx.strokeRect(it.x, it.y, it.w, it.h); ctx.setLineDash([]); txt(ctx, it.name, it.x + it.w / 2, it.y + it.h / 2 + 4, ink, 'center', 11);
      });
      var E = L.nF;                                         // index of the Maxwell column
      for (ci = 0; ci < L.nF; ci++) {
        link(ctx, L.rects[ci + ':1:measurable'], L.rects[E + ':1:source'], ink, 1.6, ci === 0 && !st.two ? S(P + 'lab.cur') : '', null, ci ? 4 : 0);
        link(ctx, L.rects[E + ':2:measurable'], L.rects[ci + ':2:source'], ink, 1.6, ci === 0 && !st.two ? S(P + 'lab.force') : '', null, ci ? 4 : 0);
        if (st.b0) { elbow(ctx, L.rects[ci + ':1:measurable'], L.rects[ci + ':2:source'], acc, ''); elbow(ctx, L.rects[ci + ':2:source'], L.rects[ci + ':3:measurable'], acc, ''); }
        if (st.stream) link(ctx, L.rects[ci + ':1:measurable'], L.rects[E + ':1:source'], acc, 3, ci === 0 && !st.two ? S(P + 'lab.stream') : '', null, ci ? -4 : -5);
      }
      if (st.two) { var a = L.rects['0:2:potential'], b = L.rects['1:2:potential'], y = L.top + 2.5 * L.rh; ctx.strokeStyle = kit.muted(); ctx.setLineDash([3, 3]); ctx.beginPath(); ctx.moveTo(a.x + a.w, y); ctx.lineTo(b.x, y); ctx.stroke(); ctx.setLineDash([]); var mx = (a.x + a.w + b.x) / 2; ctx.beginPath(); ctx.moveTo(mx - 4, y - 4); ctx.lineTo(mx + 4, y + 4); ctx.moveTo(mx + 4, y - 4); ctx.lineTo(mx - 4, y + 4); ctx.stroke(); txt(ctx, S(P + 'lab.nolink'), mx, y - 8, kit.muted(), 'center', 9); }
      if (st.b0) txt(ctx, S(P + 'lab.b0'), L.cols[0].x + 2, h - 17, acc, 'left', 10);
      txt(ctx, S(P + 'kind.measurable') + ' ▭   ' + S(P + 'kind.potential') + ' ┄   ' + S(P + 'kind.source') + ' ▮', w / 2, h - 3, kit.muted(), 'center', 10);
    }

    var pb = kit.panel_(root, P + 'panel.edge', S, 'span');
    var ec = cv(pb, 0.3, 140);
    var gr = el('div', { class: 'exp-grades' }); kit.grade(gr, 'none', 'exp.common.grade.none', S); gr.lastChild.appendChild(el('span', { 'data-s': P + 'grade.edge', text: ' ' + S(P + 'grade.edge') })); pb.appendChild(gr);
    var l79 = kit.line(pb, P + 'edge.line', S); l79.appendChild(document.createTextNode(' ')); l79.appendChild(el('code', { text: 'MUS-079' })); l79.appendChild(document.createTextNode(' ')); l79.appendChild(kit.chip('computed'));
    function drawEdge() {
      var ctx = ec.ctx, w = ec.w, h = ec.h, bw = Math.min(110, w * 0.26);
      ctx.clearRect(0, 0, w, h);
      [[8, S(P + 'col.fluid'), kit.blue], [w - 8 - bw, S(P + 'col.em'), kit.red]].forEach(function (b) { ctx.strokeStyle = b[2]; ctx.lineWidth = 1.5; ctx.strokeRect(b[0], 10, bw, h - 20); txt(ctx, b[1], b[0] + bw / 2, h / 2 + 4, b[2], 'center', 12); });
      kit.arrow(ctx, 8 + bw, h * 0.32, w - 8 - bw, h * 0.32, kit.ink(), 2); txt(ctx, S(P + 'edge.phys'), w / 2, h * 0.32 - 6, kit.ink(), 'center', 11);
      ctx.setLineDash([6, 5]); kit.arrow(ctx, 8 + bw, h * 0.7, w - 8 - bw, h * 0.7, kit.muted(), 1.6); ctx.setLineDash([]);
      txt(ctx, S(P + 'edge.time'), w / 2, h * 0.7 - 6, kit.muted(), 'center', 11);
      var mx = w / 2, my = h * 0.7; ctx.strokeStyle = kit.red; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(mx - 5, my + 4); ctx.lineTo(mx + 5, my + 14); ctx.moveTo(mx + 5, my + 4); ctx.lineTo(mx - 5, my + 14); ctx.stroke();
    }
    function all() { draw(); drawEdge(); }
    readout(); all();
    window.addEventListener('resize', all);
    kit.loop(function () { all(); });
  } };
})();
