# B7 note: `violin`, five panels for the Violin chapter

Built: `violin.js` (336 lines), `violin.strings.json` (128 strings; rows MUS-223, 225, 224, 227, 230, 228, 226, 229, 001, 002, 003, 029, 041), `violin.data.json` (90 kB, `violin.json` whole), `violin.spec.md` (spec + "As built"), `_harness_violin.html`, `_harness_violin_1280.png`, `_harness_violin_390.png`. Console clean at both widths, also after clicking every switch and moving every slider to both ends.

## What the page draws
- The bowed string: the Helmholtz corner on its dotted parabola (kinematics), the bow mark, the data's bridge sawtooth and the two-valued bow velocity with a moving cursor; Schelleng's wedge at the chosen v_b (interpolated across 0.05, 0.1, 0.2 m/s; "no data here" above 0.2), the (β, F) point and its regime; readouts of pitch (tempered, just, cents), amplitude, bridge force, Z₀, c, β*.
- The plate: the chosen mode W cos ωt (Legendre coefficients) with nodal lines, free or held at the centre; W₁ (the data's form) beside the held four-arc mode; λ², class, the nylon plate's frequencies and inputs, E_eff; the bar's roots and half-roots.
- The added piece: the chain of twelve with mirror, drive arrows, exact vectors, the data's sums; |Q| against λ² and the driven plate with/without post at six λ².
- The air: an equal-area ellipse stretched to a slit; A0 = A0_circle √(C/C_circle) against aspect with the measured band and the three computed f-holes.
- The wolf: the two roots against Q (exact and quadratic), Q*, f_b; the struck beat with its envelope.

## Sounds
String sawtooth at f_just (through three peaks at 280/455/545 Hz, Q 15, on the switch; octave up below F_min, noise above F_max); plate strike at the real frequencies (λ² × 3.9993 Hz); A0 knock with Q = 20 (≈ 23 ms); the wolf's two real parts held together. One shared switch.

## What I could not place, or placed with a caveat
- Plate shapes at ν = 0.3: the data have none; λ² printed, shapes from 0.39, said on the page.
- The spec's 45.4 and 181.6 Hz are not in the data: printed 45.0383 (N = 24), 44.87 extrapolated, 180.1 and 179.5 Hz.
- `plate.lambda2_note` speaks of the rigid zeros, not of convergence; the slow-convergence words are MUS-227's (and the log's vl·PLATE #5).
- Pair held on the chain: no vector in the data; the free one drawn faint with masses 6, 7 marked, sum 0 printed.
- The air's curve holds the wall term fixed (about 5 Hz above the computed 5 cm² hole); "slow decay" at Q = 20 is in fact a 23 ms knock.
- The wolf's decays are drawn, not sounded; `post.response[].scale_*`, `helmholtz.shape` and `product_mode` are carried but not drawn.

## String ids (all `exp.violin.*`)
title, lead, see, hear, data; panel.string, panel.plate, panel.post, panel.air, panel.wolf; str.G, str.D, str.A, str.E, body.string, body.body, beta, vb, force, str.rd1, str.rd2, wedge.rd, wedge.rd.out, wedge.in, wedge.below, wedge.above, wedge.star, cv.bridge, cv.nut, cv.bow, cv.saw, cv.vel, cv.slip, cv.stick, cv.beta, cv.force, cv.fmax, cv.fmin, cv.play, cap.corner, cap.slip, cap.saw, cap.fifths, cap.wedge, cap.inputs, cap.measured, hear.string; nu.03, nu.039, plate.free, plate.held, mode.1 … mode.8, held.1, held.2, plate.rd, plate.rd03, plate.rd.hz1, plate.rd.std, plate.rd.held, plate.rd.hz, plate.rd.in, plate.shape039, plate.heldnu, cv.free, cv.heldc, cv.w1, cv.held, cap.plate, cap.std, cap.held, cap.w1, cap.photo, w1.rd, beam.rd, hear.plate; post.free, post.held3, post.held67, post.rd, post.novec, cv.mirror, cap.chain, post.omega, post.no, post.yes, post.rd.q, cv.lam, cv.q, cv.qzero, cv.post, cap.post, cap.mono, hear.post; air.aspect, air.a4, air.a5, air.a6, air.rd, air.rd.f, cv.hole, cv.band, cv.a0, cv.aspect, cv.fhole, cap.air, cap.air2, hear.air; wolf.q, wolf.rd, wolf.rd.th, cv.qq, cv.ref, cv.exact, cv.quad, cv.fb, cv.qstar, cv.beat, cv.t, cap.wolf, cap.wolf2, hear.wolf.

## After the review of pack V (corrected figure data and rows)
- Data re-pasted whole (90 kB, new `source`). Held plate: three modes in the singular basis (Legendre + r² ln r + r⁴ ln r, evaluated as given), picker of three in MUS-227's words, "upper bound" printed, crossings printed; the extrapolated values and "N = 24" removed. The right canvas now shows W₁ beside the **third** held mode, the photograph's pattern (345.5 Hz, 2.23 × 155 Hz, E = 0.51–0.58 GPa needed); W₁ = 0.9967 of held 2; the effective modulus of about 2 GPa and the 0.9972 coincidence are gone. Driver's-mass picker (0.1 … 20) with λ² of the third family and the ring radius (0.269 … 0.013). Free λ² labelled once as Ritz upper bounds at 16 × 16. Strike: held set uses the three held `f_Hz`.
- Captions: fifths (a twelfth of the Pythagorean comma), wolf (no sharp threshold in the exact equation; 1.09 Hz at Q = 7.85), air (a third as fast; c = 343 m/s, INP-131). INP-131 in the legend rows.
- New ids: held.3, plate.rd.cross, cap.ritz, mass, mass.0 … mass.5, mass.rd, cap.mass. Changed: see, cap.fifths, held.1, held.2, plate.rd, plate.rd03, plate.rd.held, cv.held, cap.held, cap.photo, w1.rd, hear.plate, cap.air, cap.air2, cap.wolf, hear.wolf. Removed: plate.rd.hz.
- Harness regenerated; screenshots at 1280 and 390 after the first button; console clean, also after exercising every switch (the three held modes, the six masses) and slider.
