# NOTE IT-8 E1

Written: r8_E1.json — 7 row narrations (MUS-231..237, 77-91 words), the rewrite of section:violin (225 words: first chain kept and tightened, second chain in one sentence list, second experiment in two sentences), 10 titles (chain, 7 rows, caption fig_violin_body, script line), 5 strings from previousIt (checks.violin, checks.violin.p, src.refs4, src.refs4.p, it.refs4.card).

Terms: fotografia / piastra fotografata / punteggio; funzioni singolari all'anima; ammettenza del ponticello; linee di ritardo; scorrimento multiplo; diagramma di Schelleng calcolato; inviluppo; il ponticello che dondola (rocking bridge); tavola di abete, fondo di acero; limiti superiori ancora in discesa; piastre incernierate, fasce, catena, anima; A0, B1- e B1+ del modello. "Tesina di laurea (Durham, 2022)" in MUS-231, MUS-233 and the chapter lead; no author name.

Checked and kept: nothing check_only beyond section:violin (rewritten). Checker: 0 errors; one generic warning (caption 44 words, over the 40 default; kept, five panels).

Doubts: MUS-233 prints "91 to 357" in the research and "[356,357] / [91,92]" in homeMath; I used the research's 91 to 357. The section's second-experiment sentences follow the brief's description of what the page plays, not the spec (not read).
