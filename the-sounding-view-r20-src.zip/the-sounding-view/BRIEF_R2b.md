# The Sounding View — release 2, second pass: the Italian pages are the narrator's site

The owner opened the Italian site (deployed at sounding-site.vercel.app) and said, with screenshots:

> "why english is still there? the two lines intro makes no sense to any human wanting to read a website. … as an example: 'SPR-M01 · calcolato · harmonic oscillator, inverted oscillator and free motion · La riga SPR-M01…'. Awful how it looks. An italian human reader has to read SPR-M01, then english and then what do you understand? Is that a narrative way?"

He is right. What was built is a bilingual document: the English records stand in the reading flow (the question, the section titles and leads, the row heads' claims, the figure captions, the clips' "what is heard", the study's prose on the bridges page, the lens table), and the narrator's Italian hangs under them as a quoted block. The owner asked for a narrated Italian site. The rule for this pass:

**On an Italian page, the reading flow is Italian.** Everything a reader meets while reading — titles, leads, claims, captions, labels, the text of every block in the default register — comes from the narrator's tables. The Atlas's English records remain available, but out of the flow: inside the *Ricerca · Atlas · Standard* registers (which the reader opens on purpose) and inside collapsed disclosures labelled in Italian ("la scheda dell'Atlante, in inglese", "dallo studio, in inglese"). Nothing English is shown open on an Italian page except ids (SPR-M01, mu·ROTOR), file names, formulas, numbers, proper names and titles of works (*Music on the labels*, *The bridges drilled*, *The Sounding View*).

The checker enforces it: on `out/it/*.html`, every text node outside `<details>` disclosures and outside the three record registers must be traced to an Italian table (`data-s` → `strings_it.json`, `data-r` → `racconto.json`, `data-t` → `titoli.json`) or be an id, a number, a formula, a file name, a URL or a listed proper name. Any run of three words outside those is an error.

The owner added, on the drill page's head ("The study's stamp: A research note written for the Atlas's owner, 2 November 2026, against release 4.4.9 (round 36 merged). A study's page: its rows are proposed, not merged into the Atlas's tables. Nothing is merged: the round is stored as a pack for a later release."):

> "The bridges also you use drilled in a website, that was for you to reason. … What does a reader of music / math / physics care about these information?"

So, in **both languages**, the site drops the bookkeeping of the work from the reading flow:

## 0. No bookkeeping in the flow (both languages)

- **No process words on any page** except About / Il metodo: no "round N", "pack", "merged / not merged", "proposed", "release 4.4.9", "against release", "stored for a later release", "the owner", "research note", "drill / drilled". They are the work's words, not the reader's. A reader of music, mathematics or physics meets the content: what a row says, what establishes it, what to listen to.
- **The page's name**: `bridges.html` is **The bridges** (EN; h1 "Eleven bridges between the Atlas and music" or simply "The bridges" with a one-line subtitle in the site's words), **I ponti** (IT, `t:page:bridges`). The study's title *The bridges drilled* appears only where a source is named (Sources / Fonti, About / Il metodo, the study's own link). Navigation: "Bridges" / "Ponti" (already so).
- **The drill page's head**: no study byline, no standing line. The page opens like a section page: title, subtitle, the lead (EN: the study's abstract sentences that say what the bridges are, chosen so that they carry no process words — or a site string of two sentences; IT: `r:page:bridges`).
- **The "proposed" marking goes**: the rows of the bridges page carry their status chip like every other row (computed, standard, ours…), nothing else. That their rows are not yet in the Atlas's tables is said once, on About / Il metodo (EN and IT), in one sentence a reader can skip. The home card says "36 rows" with the counts by status, not "proposed". The legend of the chips loses the "proposed" line.
- **Checks / Verifiche**: the scripts are grouped under the two studies' names ("the scripts of *Music on the labels*", "the scripts of the bridges"), not "round 36 / round 37", and the line "these are the pack's and not merged" goes.
- **Sounds / Suoni**: the clips are the clips; no "the rows they illustrate are proposed".
- **The narrations and the strings**: the narrators are removing the bookkeeping sentences from `racconto.json` and `strings_it.json` on their halves (the orchestrator merges their edits); you remove it from `strings.json` (list the ids you changed in `MANIFEST_TITOLI.json` under `strings_changed`, with old and new, so the narrators re-word the Italian). The checker's banned list, for both languages, gains the process words above as a test on the reading flow (not on About / Il metodo, not on `version.json`, not inside the record registers and disclosures, where the Atlas's own texts may say "release").
- **`version.json`, `RELEASE_NOTES.md`, `SITE_NOTES.md`** keep the full provenance: they are the record, not the site.

## 1. The stamp line — both languages

The stamp under every page's title ("The Sounding View · release 2 · built from the Cascade Atlas 4.4.9 (round 36) and the pack of round 37, proposed and not merged · 2026-11-02") is for nobody. Replace it with one short human line, on every page, in both languages: EN `Release 2 · 2 November 2026`, IT `Edizione 2 · 2 novembre 2026` (strings `release.stamp` with `{release}` and the date in words: give the build a `{dateWords}` placeholder, or compose it from the date in each language). The provenance (built from the Atlas 4.4.9 with *Music on the labels* merged, and from the pack of *The bridges drilled*, proposed and not merged) goes to About / Il metodo in one readable sentence (a string per language; the Italian one in the narrator's words, without "round N"). `version.json` keeps the full provenance.

## 2. The new Italian table: `gen/content/it/titoli.json`

Short items the narrators write (they are writing now, in parallel with you): `{"about": …, "voice": …, "items": [{"id": "t:<target>", "target": "<target>", "text": "…", "why": "…"}]}`. Targets and what they are:

| target | what | count |
|---|---|---|
| `section:<slug>` | the section's Italian title (the page's h1 and the home card's title) | 8 |
| `section:<slug>:sub` | one line under the title (the Italian counterpart of the physics/mathematics titles, in one line) | 8 |
| `chain:<slug>` | the heading of the rows' list on the section page | 8 |
| `card:section:<slug>` | the home card's text (40–70 words) | 8 |
| `page:bridges`, `page:bridges:sub`, `page:bridges:head`, `card:page:bridges` | the drill page's h1, its one-line subtitle, the one line that replaces the study's byline (what the study is, for whom, when), the home card's text | 4 |
| `row:<id>` | the row's one-line claim in Italian: the head of the row block (≤ 14 words, no final period) — 27 Atlas rows + 36 proposed | 63 |
| `fig:<name>` | the figure's Italian caption (15–45 words); `<name>` the SVG's basename without extension (13 of round 36: beethoven chain clock dft dissonance fifths mobius music_map plr_dual rhythm tet tonnetz tonnetz3d; 12 of the drill: crt_tonnetz fig_288 fig_bell_levels fig_chain fig_grades fig_harmonic_ring fig_johnson_tonnetz fig_motors fig_rows fig_sets two_clocks two_cuts) | 25 |
| `clip:<nn>` | the clip's short title (≤ 10 words), `<nn>` as the file's number (01 … 10 with 08a 08b 08c, 13 … 21) | 21 |
| `item:<item>` | the drill item's Italian title (clock labels duality walk rows rings body acoustics) | 8 |
| `bridge:<n>`, `bridge:<n>:why` | the bridge's Italian name (≤ 8 words) and what decided its grade (≤ 25 words), n = 1 … 11 | 22 |
| `lens:<n>` | the Italian music term of the lens entry n (1 … 34, the order of `lenses.json`'s `mus` dictionary) (≤ 10 words) | 34 |
| `paper:<row>` | the Italian for the Atlas column of the paper's dictionary row (rows 0, 1a, 1b, 2 … 15 as DICTIONARY.md numbers them) (≤ 10 words) | 17 |
| `check:<script>` | one line: what the script computes (≤ 16 words), the 11 scripts (music_sound, music_symmetry, music_clock12, music_labels12, music_duality, music_bell, music_walk, music_rows, music_rings, music_body, music_acoustics) | 11 |

Write `gen/content/it/MANIFEST_TITOLI.json` **within your first fifteen minutes** (the narrators read it): every target above with the English material it stands on (the section's three titles and lead; the row's id, homePhys and research text's first sentence; the figure's English caption; the clip's "what is heard" first sentence; the item's BRIDGE.md heading; the bridge's row of the eleven-bridges table; the lens entry's atlas and term; the paper row's three columns; the script's docstring's first paragraph), plus `strings_new` for every string you add in this pass with its English text and why. Regenerate it if a key changes and say so in NOTE_R2b.md.

## 3. The Italian pages, rebuilt as the narrator's site

- **Home**: h1 and subtitle (strings, as now); the short stamp; "La domanda": the narrator's `r:page:home` as the text, plain (no quote bar), no English abstract — a small link "la domanda nelle parole dello studio, in inglese" to `../index.html#question` (string); the cards: `t:section:<slug>` as the title, `t:card:section:<slug>` as the text, the counts with the Italian chip words; the drill's card with `t:page:bridges` and `t:card:page:bridges`; the pointer to Suoni (string).
- **Section pages**: h1 `t:section:<slug>`, under it `t:section:<slug>:sub`; the lead block is the narrator's `r:section:<slug>` as plain paragraphs; the Atlas's English lead (MUS-741 …) inside a collapsed `<details>` "L'apertura dell'Atlante, in inglese" (string) with its source line; the rows' heading `t:chain:<slug>`; the rows' intro string (as now, Italian).
- **The row block (Italian)**: head = the Italian claim `t:row:<id>` as the block's title (the same weight the English claim has on the English page), then a small line with the id and the chip (and "proposta" where it applies); body = the Racconto register: `r:row:<id>` as plain paragraphs, no quote bar, no "La riga X è…" rewording by you (the narrations stay as written). The other registers keep the English records, each opening with one small label (string: "la scheda dell'Atlante, in inglese" / "il testo di ricerca, in inglese" / "il riferimento standard e la lente, in inglese") instead of the sentence repeated three times now. One note near the register switch per page (string) says once that the three record registers are the Atlas's English.
- **Figures**: `t:fig:<name>` as the caption; the English caption, data file and rows inside a `<details>` "la scheda della figura, in inglese" (the rows' ids may stay visible as links under the Italian caption).
- **Clips**: `t:clip:<nn>` as the title line, `r:clip:<nn>` as the text (plain), the `<audio>`; the English "what is heard / built from" inside "la scheda del clip, in inglese".
- **Instruments**: as now (Italian strings), the narration plain, not quoted.
- **The drill page**: h1 `t:page:bridges`, `t:page:bridges:sub`, head line `t:page:bridges:head` (the study's English byline in a disclosure); the standing line (string, Italian, as now); "La domanda e il metodo": `r:page:bridges` plain, the study's §1 English inside "dallo studio, in inglese"; the eleven bridges' table: columns in Italian (strings), cells `t:bridge:<n>` / grade words (strings) / `t:bridge:<n>:why`, the English table inside a disclosure; `r:bridges:table` plain above it; the items: heading `t:item:<item>`, `r:bridges:item:<item>` plain, the study's English prose and formulas of the item inside "dallo studio, in inglese" (collapsed), then the proposed rows, figures, clips, instrument link; the paper's dictionary: `r:page:acoustics` plain, the table with a fourth column "in italiano" (`t:paper:<row>`) and the three English columns kept (they are the paper's and the Atlas's terms; a reader of a dictionary expects both languages) — or the English table inside a disclosure with the Italian column beside the row numbers; your call, say which; the candidates and slips inside a disclosure (English); the opinion: `r:bridges:opinion` plain, §9 and §16 inside the disclosure.
- **Dizionario**: `r:page:dictionary` plain; the lens table with the column "termine musicale" showing `t:lens:<n>` and the English term small under it (or in a disclosure per row), the grade word in Italian (string), the evidence tags and rows as ids; the 124 readings (English) inside one collapsed disclosure "Le 124 letture dell'Atlante attraverso la lente, in inglese"; the paper's dictionary as on the drill page.
- **Verifiche**: `r:page:checks` and `r:checks:round37` plain; each script: `t:check:<script>` as its line, the counts (Italian strings), its docstring's statements and the log lines inside a collapsed disclosure "la scheda dello script e il suo log, in inglese"; the links to the files.
- **Figure (Pictures)**: the Italian captions, as above.
- **Fonti**: `r:page:sources` plain; the references as they are (bibliography).
- **Il metodo**: strings (Italian), `r:page:about` plain; the provenance sentence.
- **Header**: unchanged (EN · IT, Racconto · Ricerca · Atlas · Standard).

Keep the English pages as they are except the stamp and the About provenance sentence. The two sites must stay the same site: same CSS, same chips, same layout; the disclosures use the site's existing `<details>` style (or add one, quiet, with the summary in small caps as the labels).

## 4. The checker

Add to rule 11: the Italian reading flow (text nodes of `out/it/*.html` outside `details` and outside the record registers' panels) is traced to the three Italian tables; the allowed untraced tokens are ids (`[A-Z]{2,4}-[0-9A-Za-z]+`, check tags `xx·TAG`), numbers and units, formulas (`.katex`, `data-tex`), file names, URLs, and the proper names listed in a small array in the checker (The Sounding View, The Shifted View, Cascade Atlas, Music on the labels, The bridges drilled, KaTeX, the people's names in the references). Report every other run of three words as an error with its page and text. Every item of `titoli.json` is rendered at least once (titles of figures shared by pages render more than once — allow it, unlike narrations); every target of `MANIFEST_TITOLI.json` has an item. The banned-word check runs on `titoli.json` too.

## 5. Delivery

Develop against stubs as before (`SDV_IT=partial`, stubs marked, refused by the full build). The orchestrator merges the narrators' `it/draft/titoli_r1.json` and `titoli_bridges.json` into `gen/content/it/titoli.json` and messages you; then the final build, check (0/0), tests, screenshots (EN and IT), the notes (`record/SITE_NOTES.md`, `gen/assets/RELEASE_NOTES.md`: the second pass described in one paragraph — the Italian pages are the narrator's; the records out of the flow; the short stamp), `NOTE_R2b.md` (what changed, the strings added, what you had to decide). Do not zip; do not touch REPO or PACK. Look at the Italian screenshots yourself — index, tone, sounds, bridges, dictionary at 1280 and 390 — and ask of each: would an Italian reader meet any English while reading? If yes, it is not done.
