# NOTE_IT-4D1

D1: 386 strings of rotor, graphs, continuum, rings, twotones, clockring, sets, fifths, triads, torusband, fourier12, field, noimage and exp.common.*, written from the material file (spec and screenshots not opened; the `why` lines and the English were enough). Checker: 0 errors, 0 warnings.

Choices: ritmo "collana" (as release 3), "orologio" for the clock, "quadrante" for the dial, "serie" for tone row / all-interval row, "naturale" for just (intonation, fifth, third), "righello" for ruler, "parcelle" for parcels of air, "segno" for the field marker, "Colpisci" for Strike. "ora" and "ultimo" avoided by rephrasing. Lens grades: esatto / parziale / analogia / nessuno.

Doubts: exp.field.cv.s.parcels "trattini" for ticks; exp.triads.title "centralizzante" (the centralizer, as a noun-adjective) is a little technical but exact.
