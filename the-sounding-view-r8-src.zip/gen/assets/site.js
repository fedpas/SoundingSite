// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// The Sounding View — site.js: the register switch (Story · Research · Atlas · Standard), remembered per reader in
// localStorage when the browser allows it. No data is fetched: the pages carry their text, the Sounds page its numbers.
(function () {
  'use strict';
  var root = document.documentElement;
  var REGS = ['story', 'research', 'atlas', 'standard'];
  function get() { var r = root.getAttribute('data-reg'); return REGS.indexOf(r) >= 0 ? r : 'story'; }
  function set(r, keep) {
    if (REGS.indexOf(r) < 0) return;
    root.setAttribute('data-reg', r);
    var bs = document.querySelectorAll('[data-switch="reg"] button');
    for (var i = 0; i < bs.length; i++) bs[i].setAttribute('aria-checked', bs[i].getAttribute('data-reg') === r ? 'true' : 'false');
    if (keep) { try { localStorage.setItem('sdv.reg', r); } catch (e) { /* storage refused: the switch still works */ } }
  }
  function init() {
    set(get(), false);
    var seg = document.querySelector('[data-switch="reg"]');
    if (!seg) return;
    seg.addEventListener('click', function (e) {
      var b = e.target.closest('button[data-reg]');
      if (!b) return;
      // keep the row in view when the register changes the height of the page
      var anchor = null, top = 0, rows = document.querySelectorAll('.row');
      for (var i = 0; i < rows.length; i++) { var rc = rows[i].getBoundingClientRect(); if (rc.bottom > 90) { anchor = rows[i]; top = rc.top; break; } }
      set(b.getAttribute('data-reg'), true);
      if (anchor) window.scrollBy(0, anchor.getBoundingClientRect().top - top);
    });
    seg.addEventListener('keydown', function (e) {
      if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
      var i = REGS.indexOf(get()) + (e.key === 'ArrowRight' ? 1 : -1);
      i = (i + REGS.length) % REGS.length;
      set(REGS[i], true);
      var b = seg.querySelector('button[data-reg="' + REGS[i] + '"]');
      if (b) b.focus();
      e.preventDefault();
    });
  }
  // the experiments of the page: their strings are inlined as JSON, in the page's language; no fetch
  function mountExperiments() {
    var sj = document.getElementById('exp-strings');
    if (!sj || !window.SDV_EXP || !window.SDV_EXP._kit) return;
    var T = JSON.parse(sj.textContent);
    window.SDV_EXP._kit.mountAll(function (id) { if (!(id in T)) { console.error('missing string ' + id); return '[' + id + ']'; } return T[id]; });
  }
  function start() { init(); mountExperiments(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
