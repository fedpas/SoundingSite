# NOTE IT-5E2

91 strings of streams (32), harmonics (11), layers (48); 12 changed ones rewritten from previousIt.
Terms: triplete (not release-4 "tripletto", per brief); Colpisci / Suona / Gonfia (Swell) / Invia / Da capo; "gobba sulla coda" (bump on the tail); "fasci lorentziani"; "semilarghezza"; "racchiudimenti" (enclosures); "onda all'indietro"; "lato denso / bassa densità"; "forma della quantità di moto"; "primo ordine completo"; "relazione completa".
Doubt: layers.hear "at v_t/c = 1/160 almost nothing" read as "almost nothing converted" (returns R = 1 - C near 1 is the opposite reading; check against the English if intended otherwise).
Checker: 0 errors, 0 warnings.
E3 (resumed): 10 layers strings in r5_E3.json (Y = 2/5 switch readouts, panel 'Un gradino netto', cap.hot from previousIt); used 'triplete' per the brief, not 'tripletto'.
