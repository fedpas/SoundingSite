// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// spin.js — The spin of sound, and the experiment that would decide it (MUS-060 … 069, MUS-087, MUS-066 open; INP-136 … 139); the special places (cube, triangle, tetrahedron) and the still point of the water tank
(function () {
  'use strict';
  window.SDV_EXP = window.SDV_EXP || {};
  window.SDV_EXP['spin'] = { mount: function (root, data, S, kit) {
    var P = 'exp.spin.', el = kit.el, TAU = Math.PI * 2, F = 1000, PIC_HZ = 0.5, SLOW = Math.round(F / PIC_HZ), MAG = 40;
    var reduce = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    var st = { A1: 1, A2: 1, phi: 90, g: 0.5, probe: 'A3', freq: '1000', x: 0.1, da: 0.0231, t: 0, paused: reduce, on: false, dirty: true };
    var MECH = frac(data.mechanical);
    function frac(s) { var p = String(s).split('/'); return p.length === 2 ? +p[0] / +p[1] : +p[0]; }
    function cv(parent, a, m) { var d = el('div', { class: 'exp-cvwrap' }); parent.appendChild(d); return kit.canvas(d, a, m); }
    function txt(ctx, s, x, y, color, align, size) { ctx.fillStyle = color || kit.muted(); ctx.textAlign = align || 'left'; ctx.font = (size || 11) + 'px system-ui, sans-serif'; ctx.fillText(s, x, y); }
    function s3() { var a = st.A1, b = st.A2; return 2 * a * b * Math.sin(st.phi * Math.PI / 180) / (a * a + b * b); }       // FINAL.md eq. 5
    function Roff(x, mu) { var c = Math.cos(Math.PI * x), s = Math.sin(Math.PI * x); return 2 * c / (1 + c * c + mu * s * s); } // eq. 11 on one axis, k = pi / L
    function grid() { var d = el('div', { class: 'exp-subgrid' }); d.style.cssText = 'display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:12px;align-items:start'; return d; }
    function codeChip(parent, id, status) { parent.appendChild(el('code', { text: id })); parent.appendChild(document.createTextNode(' ')); parent.appendChild(kit.chip(status)); parent.appendChild(document.createTextNode('  ')); }

    // ================================================================ (a) the parcel's ellipse
    var pa = kit.panel_(root, P + 'panel.ellipse', S);
    var ga = grid(); pa.appendChild(ga);
    var ec = cv(ga, 0.9, 300), mc = cv(ga, 0.9, 300);
    var ctlA = kit.controls(pa), slPhi;
    kit.slider(ctlA, { S: S, id: P + 'A1', min: 0.2, max: 1, step: 0.05, value: 1, fmt: function (v) { return kit.num(v, 2); }, onchange: function (v) { st.A1 = v; st.dirty = true; upd(); } });
    kit.slider(ctlA, { S: S, id: P + 'A2', min: 0.2, max: 1, step: 0.05, value: 1, fmt: function (v) { return kit.num(v, 2); }, onchange: function (v) { st.A2 = v; st.dirty = true; upd(); } });
    slPhi = kit.slider(ctlA, { S: S, id: 'exp.common.phase', min: 0, max: 360, step: 1, value: 90, fmt: function (v) { return Math.round(v) + '°'; }, onchange: function (v) { st.phi = v; st.dirty = true; upd(); } });
    var pauseB = kit.button(ctlA, 'exp.common.pause', S, function () { st.paused = !st.paused; pauseB.setAttribute('aria-pressed', String(st.paused)); }); pauseB.setAttribute('aria-pressed', String(st.paused));
    var rdA = kit.readout(pa), rdSlow = kit.readout(pa); rdSlow.textContent = S('exp.common.slowed').replace('{n}', String(SLOW));
    kit.line(pa, P + 'ellipse.line', S); kit.line(pa, P + 'map.line', S);
    function upd() { var v = s3(); rdA.textContent = 's₃ = 2A₁A₂ sin φ / (A₁² + A₂²) = ' + kit.num(v, 3) + (Math.abs(Math.abs(v) - 1) < 0.005 ? '   ' + S(P + 'circular') : ''); updPair(); readC(); }
    function drawEllipse() {
      var ctx = ec.ctx, w = ec.w, h = ec.h, cx = w / 2, cy = h / 2, U = 0.42 * Math.min(w, h), ph = st.phi * Math.PI / 180, i;
      ctx.clearRect(0, 0, w, h);
      ctx.strokeStyle = kit.muted(); ctx.globalAlpha = 0.4; ctx.beginPath(); ctx.moveTo(8, cy); ctx.lineTo(w - 8, cy); ctx.moveTo(cx, 8); ctx.lineTo(cx, h - 8); ctx.stroke(); ctx.globalAlpha = 1;
      var V = function (u) { return [-st.A1 * Math.sin(u), st.A2 * Math.sin(ph - u)]; };
      ctx.strokeStyle = kit.accent(); ctx.lineWidth = 1.6; ctx.beginPath(); for (i = 0; i <= 120; i++) { var v = V(TAU * i / 120); if (i) ctx.lineTo(cx + U * v[0], cy - U * v[1]); else ctx.moveTo(cx + U * v[0], cy - U * v[1]); } ctx.stroke();
      var u = TAU * PIC_HZ * st.t, p = V(u);
      for (i = 1; i <= 14; i++) { var q = V(u - 0.06 * i); ctx.fillStyle = kit.ink(); ctx.globalAlpha = 0.35 * (1 - i / 15); ctx.beginPath(); ctx.arc(cx + U * q[0], cy - U * q[1], 3, 0, TAU); ctx.fill(); } ctx.globalAlpha = 1;
      kit.arrow(ctx, cx, cy, cx + U * p[0], cy - U * p[1], kit.red, 2.2);
      ctx.fillStyle = kit.ink(); ctx.beginPath(); ctx.arc(cx, cy, 3, 0, TAU); ctx.fill();
      txt(ctx, 'x', w - 10, cy - 5, kit.muted(), 'right', 11); txt(ctx, 'y', cx + 6, 14, kit.muted(), 'left', 11);
      var sgn = s3(); txt(ctx, (sgn > 0.02 ? '↺ ' : sgn < -0.02 ? '↻ ' : '↔ ') + 's₃ = ' + kit.num(sgn, 2), 8, h - 8, kit.ink(), 'left', 12);
    }
    var mapCache = null;
    function drawMap() {
      var ctx = mc.ctx, w = mc.w, h = mc.h, side = Math.min(w, h) - 16, ox = (w - side) / 2, oy = (h - side) / 2, n = 40, i, j, ph = st.phi * Math.PI / 180, nrm = 2 * st.A1 * st.A2 / (st.A1 * st.A1 + st.A2 * st.A2);
      ctx.clearRect(0, 0, w, h);
      var cs = side / n, F2 = [];
      for (j = 0; j <= n; j++) { F2[j] = []; for (i = 0; i <= n; i++) { var a = Math.PI * ((i / n) - 0.5), b = Math.PI * ((j / n) - 0.5); F2[j][i] = Math.sqrt(st.A1 * st.A1 * Math.sin(a) * Math.sin(a) + st.A2 * st.A2 * Math.sin(b) * Math.sin(b) + 2 * st.A1 * st.A2 * Math.cos(ph) * Math.sin(a) * Math.sin(b)); } }
      for (j = 0; j < n; j++) for (i = 0; i < n; i++) { var a2 = Math.PI * ((i + 0.5) / n - 0.5), b2 = Math.PI * ((j + 0.5) / n - 0.5); ctx.fillStyle = kit.cmap(nrm * Math.cos(a2) * Math.cos(b2) * Math.sin(ph)); ctx.fillRect(ox + i * cs, oy + (n - 1 - j) * cs, cs + 0.6, cs + 0.6); }
      var levels = [0.2, 0.5, 0.9, 1.3].map(function (l) { return l * (st.A1 + st.A2) / 2; });
      ctx.strokeStyle = kit.ink(); ctx.lineWidth = 0.9; ctx.globalAlpha = 0.7;
      levels.forEach(function (L) {
        for (j = 0; j < n; j++) for (i = 0; i < n; i++) {
          var c = [F2[j][i], F2[j][i + 1], F2[j + 1][i + 1], F2[j + 1][i]], pts = [], e, X = [[0, 0], [1, 0], [1, 1], [0, 1]];
          for (e = 0; e < 4; e++) { var a0 = c[e], b0 = c[(e + 1) % 4]; if ((a0 - L) * (b0 - L) < 0) { var f = (L - a0) / (b0 - a0), p0 = X[e], p1 = X[(e + 1) % 4]; pts.push([ox + (i + p0[0] + f * (p1[0] - p0[0])) * cs, oy + (n - (j + p0[1] + f * (p1[1] - p0[1]))) * cs]); } }
          for (e = 0; e + 1 < pts.length; e += 2) { ctx.beginPath(); ctx.moveTo(pts[e][0], pts[e][1]); ctx.lineTo(pts[e + 1][0], pts[e + 1][1]); ctx.stroke(); }
        }
      });
      ctx.globalAlpha = 1; ctx.strokeStyle = kit.ink(); ctx.lineWidth = 1.5; ctx.strokeRect(ox, oy, side, side);
      var cx = ox + side / 2, cy = oy + side / 2; ctx.strokeStyle = kit.accent(); ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(cx - 6, cy); ctx.lineTo(cx + 6, cy); ctx.moveTo(cx, cy - 6); ctx.lineTo(cx, cy + 6); ctx.stroke();
      txt(ctx, S(P + 'map.node'), cx + 9, cy - 8, kit.accent(), 'left', 11);
    }

    // ================================================================ (b) three densities by representation
    var pb = kit.panel_(root, P + 'panel.rep', S);
    var bc = cv(pb, 0.62, 260), ctlB = kit.controls(pb);
    kit.slider(ctlB, { S: S, id: P + 'gauge', min: -1, max: 2, step: 0.01, value: 0.5, fmt: function (v) { return kit.num(v, 2); }, onchange: function (v) { st.g = v; readB(); } });
    var rdB = kit.readout(pb);
    kit.line(pb, P + 'rep.gauge', S); kit.line(pb, P + 'rep.ticks', S);
    var legB = el('div', { class: 'exp-line' }); pb.appendChild(legB);
    [['MUS-063', 'standard-recomputed', 'mech'], ['MUS-062', 'computed', 'scalar'], ['MUS-062', 'computed', 'vector'], ['MUS-062', 'computed', 'spinor'], ['MUS-068', 'computed', 'gauge']].forEach(function (r) {
      var p = el('p', { class: 'exp-line' }); codeChip(p, r[0], r[1]); p.appendChild(el('span', { 'data-s': P + 'bar.' + r[2], text: S(P + 'bar.' + r[2]) })); legB.appendChild(p);
    });
    function readB() { rdB.textContent = 'ρ⟨x × v⟩ = ' + data.mechanical + ' = ' + kit.num(MECH, 3) + '   ·   ' + kit.num(st.g, 2) + ' × ' + data.mechanical + ' = ' + kit.num(st.g * MECH, 3); }
    function drawBars() {
      var ctx = bc.ctx, w = bc.w, h = bc.h, x0 = 16, x1 = w - 16, lo = -6, hi = 11, X = function (v) { return x0 + (v - lo) / (hi - lo) * (x1 - x0); };
      var rows = [['bar.mech', MECH, kit.ink(), data.mechanical], ['bar.scalar', frac(data.vec.scalar), kit.accent(), data.vec.scalar], ['bar.vector', frac(data.vec.vector), kit.accent(), data.vec.vector], ['bar.spinor', frac(data.vec.spinor), kit.accent(), data.vec.spinor], ['bar.gauge', st.g * MECH, kit.violet, kit.num(st.g * MECH, 2)]];
      var rh = (h - 10) / rows.length;
      ctx.clearRect(0, 0, w, h);
      ctx.strokeStyle = kit.ink(); ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(X(0), 4); ctx.lineTo(X(0), h - 4); ctx.stroke();
      ctx.setLineDash([5, 4]); ctx.strokeStyle = kit.ink(); ctx.beginPath(); ctx.moveTo(X(MECH), 4); ctx.lineTo(X(MECH), h - 4); ctx.stroke(); ctx.setLineDash([]);
      rows.forEach(function (r, i) {
        var y = 5 + i * rh; txt(ctx, S(P + r[0]), x0, y + 12, kit.muted(), 'left', 11);
        var bw = X(r[1]) - X(0); ctx.fillStyle = r[2]; ctx.globalAlpha = i === 0 ? 0.35 : 0.8; ctx.fillRect(Math.min(X(0), X(0) + bw), y + 17, Math.abs(bw), rh * 0.4); ctx.globalAlpha = 1;
        txt(ctx, r[3], r[1] >= 0 ? X(r[1]) + 5 : X(r[1]) - 5, y + 17 + rh * 0.3, kit.ink(), r[1] >= 0 ? 'left' : 'right', 12);
      });
    }

    // ================================================================ (c) the experiment
    var pc = kit.panel_(root, P + 'panel.exp', S);
    var ctlC = kit.controls(pc);
    var probeSeg = kit.seg(ctlC, { S: S, ids: ['A3', 'A6', 'S5', 'S8'].map(function (k) { return P + 'probe.' + k; }), values: ['A3', 'A6', 'S5', 'S8'], value: 'A3', onchange: function (v) { st.probe = v; readC(); } });
    kit.seg(ctlC, { S: S, ids: [P + 'f1', P + 'f3'], values: ['1000', '3000'], value: '1000', onchange: function (v) { st.freq = v; st.da = Math.min(0.025, cur().delta_over_a); dSl.set(st.da); readC(); } });
    var ac = cv(pc, 0.4, 230), rdC = kit.readout(pc), rdC2 = kit.readout(pc), rdX = kit.readout(pc);
    var gc = grid(); pc.appendChild(gc);
    function sub(sid) { var d = el('div'); d.appendChild(el('h4', { 'data-s': sid, text: S(sid), style: 'margin:0 0 6px;font-size:0.85rem' })); gc.appendChild(d); return d; }
    var s1 = sub(P + 'scan.phase'), c1 = cv(s1, 0.8, 240), r1 = kit.readout(s1);
    var s2 = sub(P + 'scan.offset'), c2 = cv(s2, 0.8, 240), cs2 = kit.controls(s2), r2 = kit.readout(s2);
    kit.slider(cs2, { S: S, id: P + 'xL', min: 0, max: 0.25, step: 0.005, value: st.x, fmt: function (v) { return kit.num(v, 3); }, onchange: function (v) { st.x = v; readC(); } });
    var s3d = sub(P + 'scan.extrap'), c3 = cv(s3d, 0.8, 240), cs3 = kit.controls(s3d), r3 = kit.readout(s3d), dSl;
    dSl = kit.slider(cs3, { S: S, id: P + 'da', min: 0, max: 0.025, step: 0.0005, value: st.da, fmt: function (v) { return kit.num(v, 4); }, onchange: function (v) { st.da = v; readC(); } });
    kit.line(pc, P + 'exp.line.offset', S); kit.line(pc, P + 'exp.line.est', S);
    var hdl = kit.line(pc, P + 'exp.open', S); hdl.appendChild(document.createTextNode(' ')); hdl.appendChild(el('code', { text: 'MUS-066' })); hdl.appendChild(document.createTextNode(' ')); hdl.appendChild(kit.chip('open'));
    var ld = kit.line(pc, P + 'exp.line.readings', S); ld.appendChild(document.createTextNode(' ')); ld.appendChild(el('code', { text: 'MUS-087' })); ld.appendChild(document.createTextNode(' ')); ld.appendChild(kit.chip('computed'));
    var cards = el('div', { class: 'exp-cards' }); pc.appendChild(cards);
    ['136', '137', '138', '139'].forEach(function (n) { var p = el('p', { class: 'exp-line' }); codeChip(p, 'INP-' + n, 'input'); p.appendChild(el('span', { 'data-s': P + 'inp.' + n, text: S(P + 'inp.' + n) })); cards.appendChild(p); });
    // the generator links the analysis page under the legend (exp.spin.analysis)
    function cur() { return data.probes[st.freq][st.probe]; }
    function sci(v) { var e = Math.floor(Math.log10(Math.abs(v))); return kit.num(v / Math.pow(10, e), 2) + ' × 10^' + e; }
    function readC() {
      var p = cur(), v = s3(), th = p.theta_mrad * v;
      rdC.textContent = st.probe + ' · ' + (st.freq === '1000' ? '1' : '3') + ' kHz:  P = ' + kit.num(p.P_uW, 2) + ' µW   ·   T = ' + sci(p.T_full) + ' / ' + sci(p.T_half) + ' N m (full / half)   ·   δ/a = ' + kit.num(p.delta_over_a, 4) + '   ·   μ = ' + kit.num(p.mu, 3);
      rdC2.textContent = 'twist at this φ: ' + kit.num(th, 1) + ' / ' + kit.num(th / 2, 1) + ' mrad (full / half)   ·   at s₃ = 1: ' + kit.num(p.theta_mrad, 1) + ' / ' + kit.num(p.theta_mrad / 2, 1) + ' mrad';
      rdX.textContent = S(P + 'exag').replace('{n}', String(MAG)) + '   ·   error budget ' + kit.num(data.budget_total_pct, 2) + ' % (1 σ)  ·  full and half ' + kit.num(data.separation_sigma, 0) + ' σ apart';
      r1.textContent = 'φ = ' + Math.round(st.phi) + '°:  R = ' + kit.num(v, 3) + '  /  ' + kit.num(v / 2, 3);
      var mus = [data.mu_rod, data.mu_sphere, 1];
      r2.textContent = 'x/L = ' + kit.num(st.x, 3) + ':  ' + mus.map(function (m) { return kit.num(Roff(st.x, m), 3); }).join(' · ') + '  /  ' + kit.num(Roff(st.x, data.mu_rod) / 2, 3);
      r3.textContent = 'δ/a = ' + kit.num(st.da, 4) + ':  R = ' + kit.num(1 - data.cs_estimate * st.da, 3) + '  /  ' + kit.num((1 - data.cs_estimate * st.da) / 2, 3) + '   ·   δ/a → 0:  1  /  ½';
    }
    function drawApp() {
      var ctx = ac.ctx, w = ac.w, h = ac.h, side = Math.min(h - 20, w * 0.38), ox = 14, oy = (h - side) / 2, cx = ox + side / 2, cy = h / 2, p = cur(), v = s3(), thF = p.theta_mrad / 1000 * v * MAG, thH = thF / 2;
      ctx.clearRect(0, 0, w, h);
      ctx.strokeStyle = kit.ink(); ctx.lineWidth = 2; ctx.strokeRect(ox, oy, side, side);
      var a = side * 0.36; kit.arrow(ctx, cx - a * st.A1, cy, cx + a * st.A1, cy, kit.blue, 1.4); kit.arrow(ctx, cx + a * st.A1, cy, cx - a * st.A1, cy, kit.blue, 1.4);
      kit.arrow(ctx, cx, cy + a * st.A2, cx, cy - a * st.A2, kit.red, 1.4); kit.arrow(ctx, cx, cy - a * st.A2, cx, cy + a * st.A2, kit.red, 1.4);
      var rl = side * 0.2;
      [[thH, true, kit.red], [thF, false, kit.blue]].forEach(function (r) { ctx.strokeStyle = r[2]; ctx.lineWidth = 3.2; ctx.setLineDash(r[1] ? [5, 4] : []); ctx.beginPath(); ctx.moveTo(cx - rl * Math.cos(r[0]), cy + rl * Math.sin(r[0])); ctx.lineTo(cx + rl * Math.cos(r[0]), cy - rl * Math.sin(r[0])); ctx.stroke(); ctx.setLineDash([]); });
      ctx.fillStyle = kit.ink(); ctx.beginPath(); ctx.arc(cx, cy, 4, 0, TAU); ctx.fill();
      txt(ctx, S(P + 'app.cavity'), ox + 4, oy - 4, kit.muted(), 'left', 10); txt(ctx, S(P + 'app.probe'), cx + 8, cy + 18 + rl * 0.1, kit.muted(), 'left', 10);
      // the mirror on the fibre and its beam on a scale
      var mx = ox + side + 34, sx = w - 26;
      ctx.strokeStyle = kit.muted(); ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(sx, 12); ctx.lineTo(sx, h - 12); ctx.stroke();
      ctx.strokeStyle = kit.ink(); ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(mx - 4, cy - 10); ctx.lineTo(mx + 4, cy + 10); ctx.stroke();
      kit.arrow(ctx, cx + 6, cy, mx - 6, cy, kit.muted(), 1);
      ctx.strokeStyle = kit.ink(); ctx.globalAlpha = 0.4; ctx.setLineDash([4, 3]); ctx.beginPath(); ctx.moveTo(mx, cy); ctx.lineTo(sx, cy); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1;
      [[thH, kit.red], [thF, kit.blue]].forEach(function (r) { var yy = cy - (sx - mx) * Math.sin(2 * r[0]) * 0.4; ctx.strokeStyle = r[1]; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(mx, cy); ctx.lineTo(sx, yy); ctx.stroke(); ctx.fillStyle = r[1]; ctx.beginPath(); ctx.arc(sx, yy, 4, 0, TAU); ctx.fill(); });
      txt(ctx, S(P + 'app.mirror'), mx, cy + 26, kit.muted(), 'center', 10); txt(ctx, S(P + 'app.scale'), sx - 4, 12, kit.muted(), 'right', 10);
      txt(ctx, S(P + 'read.full'), w * 0.5, h - 8, kit.blue, 'left', 11); txt(ctx, S(P + 'read.half'), w * 0.5 + 90, h - 8, kit.red, 'left', 11);
    }
    function plotBox(c) { return { l: 38, t: 10, r: c.w - 10, b: c.h - 32 }; }
    function drawPhase() {
      var ctx = c1.ctx, w = c1.w, h = c1.h, box = plotBox(c1), i; ctx.clearRect(0, 0, w, h);
      var ax = kit.axes(ctx, box, { xmin: 0, xmax: 360, ymin: -1, ymax: 1, xticks: [0, 90, 180, 270, 360], yticks: [-1, 0, 1], xlabel: S('exp.common.phase'), ylabel: 'R' });
      var f = []; for (i = 0; i <= 120; i++) f.push([i * 3, 2 * st.A1 * st.A2 * Math.sin(i * 3 * Math.PI / 180) / (st.A1 * st.A1 + st.A2 * st.A2)]);
      kit.curve(ctx, f, ax.x, ax.y, kit.blue, 2); kit.curve(ctx, f.map(function (q) { return [q[0], q[1] / 2]; }), ax.x, ax.y, kit.red, 2, [6, 4]);
      var xx = ax.x(st.phi); ctx.strokeStyle = kit.accent(); ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(xx, box.t); ctx.lineTo(xx, box.b); ctx.stroke();
      var v = s3(); [[v, kit.blue], [v / 2, kit.red]].forEach(function (q) { ctx.fillStyle = q[1]; ctx.beginPath(); ctx.arc(xx, ax.y(q[0]), 4.5, 0, TAU); ctx.fill(); });
    }
    function drawOffset() {
      var ctx = c2.ctx, w = c2.w, h = c2.h, box = plotBox(c2), i; ctx.clearRect(0, 0, w, h);
      var ax = kit.axes(ctx, box, { xmin: 0, xmax: 0.25, ymin: 0.4, ymax: 1.02, xticks: [0, 0.05, 0.1, 0.15, 0.2, 0.25], yticks: [0.5, 0.75, 1], xlabel: 'x / L', ylabel: 'R' });
      [[data.mu_rod, kit.blue, []], [data.mu_sphere, kit.blue, [6, 3]], [1, kit.blue, [2, 3]]].forEach(function (c) { var f = []; for (i = 0; i <= 50; i++) f.push([i * 0.005, Roff(i * 0.005, c[0])]); kit.curve(ctx, f, ax.x, ax.y, c[1], 1.8, c[2]); });
      var fh = []; for (i = 0; i <= 50; i++) fh.push([i * 0.005, Roff(i * 0.005, data.mu_rod) / 2]); kit.curve(ctx, fh, ax.x, ax.y, kit.red, 1.8);
      Object.keys(data.offnode).forEach(function (k) { var o = data.offnode[k]; ctx.fillStyle = kit.ink(); [[o.rod], [o.mu1]].forEach(function (q) { ctx.beginPath(); ctx.arc(ax.x(+k), ax.y(q[0]), 2.6, 0, TAU); ctx.fill(); }); ctx.fillStyle = kit.ink(); ctx.beginPath(); ctx.arc(ax.x(+k), ax.y(o.half_rod), 2.6, 0, TAU); ctx.fill(); });
      txt(ctx, S(P + 'curve.rod'), ax.x(0.13), ax.y(0.99), kit.blue, 'left', 10); txt(ctx, S(P + 'curve.sphere'), ax.x(0.2), ax.y(0.91), kit.blue, 'left', 10); txt(ctx, 'μ = 1', ax.x(0.2), ax.y(0.8), kit.blue, 'left', 10); txt(ctx, S(P + 'curve.halfrod'), ax.x(0.1), ax.y(0.52), kit.red, 'left', 10);
      var xx = ax.x(st.x); ctx.strokeStyle = kit.accent(); ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(xx, box.t); ctx.lineTo(xx, box.b); ctx.stroke();
    }
    function drawExtrap() {
      var ctx = c3.ctx, w = c3.w, h = c3.h, box = plotBox(c3); ctx.clearRect(0, 0, w, h);
      var ax = kit.axes(ctx, box, { xmin: 0, xmax: 0.025, ymin: 0, ymax: 1.05, xticks: [0, 0.005, 0.01, 0.015, 0.02, 0.025], yticks: [0, 0.5, 1], xlabel: 'δ / a', ylabel: 'R' });
      var cs = data.cs_estimate; kit.curve(ctx, [[0, 1], [0.025, 1 - cs * 0.025]], ax.x, ax.y, kit.blue, 2); kit.curve(ctx, [[0, 0.5], [0.025, 0.5 * (1 - cs * 0.025)]], ax.x, ax.y, kit.red, 2, [6, 4]);
      ['1000', '3000'].forEach(function (f) { Object.keys(data.probes[f]).forEach(function (k) {
        var q = data.probes[f][k], x = ax.x(q.delta_over_a), y = ax.y(1 - cs * q.delta_over_a), sel = f === st.freq && k === st.probe, rod = k[0] === 'A';
        ctx.lineWidth = sel ? 2.6 : 1.4; ctx.strokeStyle = sel ? kit.accent() : kit.ink(); ctx.fillStyle = rod ? kit.ink() : kit.panel(); ctx.beginPath();
        if (f === '1000') ctx.arc(x, y, 4.5, 0, TAU); else ctx.rect(x - 4, y - 4, 8, 8); ctx.fill(); ctx.stroke();
      }); });
      var xx = ax.x(st.da); ctx.strokeStyle = kit.accent(); ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(xx, box.t); ctx.lineTo(xx, box.b); ctx.stroke();
      txt(ctx, S(P + 'estimate'), box.r - 4, box.t + 14, kit.muted(), 'right', 10);
    }

    // ================================================================ hear: the two modes in quadrature, one on each channel
    var ph = kit.panel_(root, P + 'panel.hear', S), ctlH = kit.controls(ph), pair = null;
    var playB = kit.button(ctlH, 'exp.common.play', S, function () { st.on = !st.on; playB.textContent = S(st.on ? 'exp.common.mute' : 'exp.common.play'); playB.setAttribute('data-s', st.on ? 'exp.common.mute' : 'exp.common.play'); if (st.on) startPair(); else stopPair(); });
    kit.seg(ctlH, { S: S, ids: [P + 'sense.plus', P + 'sense.minus', P + 'sense.lin'], values: [90, 270, 0], value: 90, onchange: function (v) { st.phi = v; slPhi.set(v); st.dirty = true; upd(); } });
    var rdH = kit.readout(ph); kit.line(ph, P + 'hear.line', S);
    function startPair() {
      var a = kit.audio(); if (!a) { rdH.textContent = S('exp.common.noaudio'); return; }
      stopPair(); var c = a.ctx, m = c.createChannelMerger(2), oL = c.createOscillator(), oR = c.createOscillator(), gL = c.createGain(), gR = c.createGain(), d = c.createDelay(0.02);
      oL.frequency.value = F; oR.frequency.value = F; gL.gain.value = 0; gR.gain.value = 0;
      oL.connect(gL); gL.connect(m, 0, 0); oR.connect(d); d.connect(gR); gR.connect(m, 0, 1); m.connect(a.master);
      var t0 = c.currentTime + 0.02; oL.start(t0); oR.start(t0);
      pair = { set: function () { var t = c.currentTime; gL.gain.setTargetAtTime(0.2 * st.A1, t, 0.02); gR.gain.setTargetAtTime(0.2 * st.A2, t, 0.02); d.delayTime.setTargetAtTime((st.phi / 360) / F, t, 0.02); },
        stop: function () { var t = c.currentTime; gL.gain.setTargetAtTime(0, t, 0.02); gR.gain.setTargetAtTime(0, t, 0.02); oL.stop(t + 0.15); oR.stop(t + 0.15); } };
      pair.set(); updPair();
    }
    function stopPair() { if (pair) { pair.stop(); pair = null; } }
    function updPair() { if (pair) pair.set(); rdH.textContent = F + ' Hz  ·  Δt = ' + kit.num(st.phi / 360 * 1000 / F, 3) + ' ms  ·  ' + kit.num(st.phi, 0) + '°'; }

    // ================================================================ (e) the special places: the cube, the triangle, the tetrahedron
    // kinematics only: a velocity V = a + ib turns on its ellipse, spin ∝ Im(V* × V); the numbers printed come from the data (data.cube, data.triangle)
    var SP = { cube: 'three', phi3: 90, u: 0, wpt: [1, 1], wph: 90, snd: null }, OUT = S('exp.common.outside');
    function dv(o, k) { return o && o[k] != null ? o[k] : null; }   // a value of S's data, null while the entry is a placeholder
    var pe = kit.panel_(root, P + 'panel.special', S, 'span');
    var ctlE = kit.controls(pe);
    kit.seg(ctlE, { S: S, ids: [P + 'cube.two', P + 'cube.three', P + 'cube.free', P + 'cube.tetra'], values: ['two', 'three', 'free', 'tetra'], value: SP.cube, onchange: function (v) { SP.cube = v; readE(); if (SP.snd && SP.snd.kind === 'cube') startCube(); } });
    var slP3 = kit.slider(ctlE, { S: S, id: P + 'phi3', min: 0, max: 360, step: 1, value: SP.phi3, fmt: function (v) { return Math.round(v) + '°'; }, onchange: function (v) { SP.phi3 = v; readE(); if (SP.snd && SP.snd.kind === 'cube') SP.snd.set(); } });
    var slU = kit.slider(ctlE, { S: S, id: P + 'diag.t', min: -1, max: 1, step: 0.01, value: 0, fmt: function (v) { return kit.num(v, 2); }, onchange: function (v) { SP.u = v; readE(); } });
    var playE = kit.button(ctlE, 'exp.common.play', S, function () { if (SP.snd && SP.snd.kind === 'cube') stopSP(); else startCube(); });
    var ge = grid(); pe.appendChild(ge);
    var ge1 = el('div'), ge2 = el('div'), ge3 = el('div'); ge.appendChild(ge1); ge.appendChild(ge2); ge.appendChild(ge3);
    var cubeC = cv(ge1, 0.9, 320), diagC = cv(ge2, 0.9, 320), triC = cv(ge3, 0.9, 320);
    var rdE1 = kit.readout(pe), rdE2 = kit.readout(pe), rdE3 = kit.readout(pe), rdE5 = kit.readout(pe), rdE4 = kit.readout(pe);
    var lnCube = kit.line(pe, P + 'line.cube', S), lnDiag = kit.line(pe, P + 'line.diag', S), lnTet = kit.line(pe, P + 'line.tetra', S);
    kit.line(pe, P + 'line.tri', S); kit.line(pe, P + 'hear.three', S);
    var rdSlowE = kit.readout(pe); rdSlowE.textContent = S('exp.common.slowed').replace('{n}', String(SLOW));
    function modes() { // amplitudes and phases (degrees) of the three cavity modes at the centre
      if (SP.cube === 'two') return { A: [1, 1, 0], ph: [0, 90, 0] };
      if (SP.cube === 'free') return { A: [1, 1, 1], ph: [0, 90, SP.phi3] };
      return { A: [1, 1, 1], ph: [0, 120, 240] };
    }
    function spinOf(m) { var r = Math.PI / 180, A = m.A, f = m.ph; return [A[1] * A[2] * Math.sin((f[2] - f[1]) * r), A[2] * A[0] * Math.sin((f[0] - f[2]) * r), A[0] * A[1] * Math.sin((f[1] - f[0]) * r)]; }
    function vel(m, wt, sc) { var r = Math.PI / 180; return [0, 1, 2].map(function (j) { return (sc == null ? 1 : sc) * m.A[j] * Math.cos(wt - m.ph[j] * r); }); }
    var CY = Math.cos(-0.62), SY = Math.sin(-0.62), CP = Math.cos(0.42), SPp = Math.sin(0.42);
    function proj(v) { var x = v[0] * CY - v[1] * SY, y = v[0] * SY + v[1] * CY; return [x, -(y * SPp + v[2] * CP)]; }
    var E1 = [1 / Math.SQRT2, -1 / Math.SQRT2, 0], E2 = [-1 / Math.sqrt(6), -1 / Math.sqrt(6), 2 / Math.sqrt(6)];
    function projD(v) { return [v[0] * E1[0] + v[1] * E1[1], -(v[0] * E2[0] + v[1] * E2[1] + v[2] * E2[2])]; }
    var CORN = []; [-1, 1].forEach(function (a) { [-1, 1].forEach(function (b) { [-1, 1].forEach(function (c) { CORN.push([a, b, c]); }); }); });
    var EDGES = []; CORN.forEach(function (p, i) { CORN.forEach(function (q, j) { if (j > i && Math.abs(p[0] - q[0]) + Math.abs(p[1] - q[1]) + Math.abs(p[2] - q[2]) === 2) EDGES.push([p, q]); }); });
    var TET = [[1, 1, 1], [1, -1, -1], [-1, 1, -1], [-1, -1, 1]];
    function drawBody(c, pr, cx, cy, U) {
      function L3(p, q, col, w, dash) { var a = pr(p), b = pr(q); c.strokeStyle = col; c.lineWidth = w; c.setLineDash(dash || []); c.beginPath(); c.moveTo(cx + U * a[0], cy + U * a[1]); c.lineTo(cx + U * b[0], cy + U * b[1]); c.stroke(); c.setLineDash([]); }
      EDGES.forEach(function (e) { L3(e[0], e[1], kit.ink(), 1.2); });
      [[1, 1, 1], [1, -1, -1], [-1, 1, -1], [-1, -1, 1]].forEach(function (d, i) { var main = i === 0 && SP.cube !== 'two'; L3(d, d.map(function (x) { return -x; }), main ? kit.accent() : kit.muted(), main ? 2 : 1, main ? [] : [3, 3]); });
      if (SP.cube === 'tetra') TET.forEach(function (p, i) { TET.forEach(function (q, j) { if (j > i) L3(p, q, kit.violet, 1.8); }); });
    }
    function drawOrbit(c, pr, cx, cy, U, m, sc, centre) {
      var o = centre || [0, 0, 0], i; c.strokeStyle = kit.accent(); c.lineWidth = 1.6; c.beginPath();
      for (i = 0; i <= 90; i++) { var v = vel(m, TAU * i / 90, sc), p = pr([o[0] + v[0], o[1] + v[1], o[2] + v[2]]); if (i) c.lineTo(cx + U * p[0], cy + U * p[1]); else c.moveTo(cx + U * p[0], cy + U * p[1]); }
      c.stroke();
    }
    function drawCubeView(cvx, pr, label) {
      var c = cvx.ctx, w = cvx.w, h = cvx.h, cx = w / 2, cy = h / 2, U = 0.27 * Math.min(w, h), m = modes(), wt = TAU * PIC_HZ * st.t, S3 = spinOf(m);
      c.clearRect(0, 0, w, h); drawBody(c, pr, cx, cy, U);
      drawOrbit(c, pr, cx, cy, U, m, 0.55);
      if (SP.cube === 'three' || SP.cube === 'tetra') { var CB = data.cube, cs_ = 0.55 * Math.sqrt(1.5) / CB.radius; c.fillStyle = kit.ink(); CB.circle.forEach(function (q, i) { if (i % 4) return; var pp = pr(q.map(function (x) { return x * cs_; })); c.beginPath(); c.arc(cx + U * pp[0], cy + U * pp[1], 1.8, 0, TAU); c.fill(); }); }
      if (SP.cube === 'tetra') { var a4 = pr([0, 1.25, 0]), b4 = pr([0, -1.25, 0]); c.strokeStyle = kit.violet; c.setLineDash([5, 4]); c.lineWidth = 1.4; c.beginPath(); c.moveTo(cx + U * a4[0], cy + U * a4[1]); c.lineTo(cx + U * b4[0], cy + U * b4[1]); c.stroke(); c.setLineDash([]); txt(c, S(P + 'cv.s4'), cx + U * a4[0] + 4, cy + U * a4[1], kit.violet, 'left', 10); }
      var v = vel(m, wt, 0.55), p = pr(v); kit.arrow(c, cx, cy, cx + U * p[0], cy + U * p[1], kit.red, 2.2);
      var s = pr(S3.map(function (x) { return 0.6 * x; })); kit.arrow(c, cx, cy, cx + U * s[0], cy + U * s[1], kit.violet, 2.6);
      if (SP.cube !== 'two') { var q = [SP.u, SP.u, SP.u], pq = pr(q), rad = Math.cos(Math.PI * SP.u / 2);
        c.fillStyle = kit.warm(); c.beginPath(); c.arc(cx + U * pq[0], cy + U * pq[1], 4, 0, TAU); c.fill();
        var m3 = { A: [1, 1, 1], ph: [0, 120, 240] }; c.globalAlpha = 0.8; drawOrbit(c, pr, cx, cy, U, m3, 0.55 * rad, q); c.globalAlpha = 1; }
      txt(c, label, 8, 14, kit.muted(), 'left', 11);
      txt(c, S(P + 'cv.vel'), 8, h - 22, kit.red, 'left', 11); txt(c, S(P + 'cv.spin'), 8, h - 8, kit.violet, 'left', 11);
    }
    function readE() {
      var m = modes(), s3v = spinOf(m), f = function (x) { return (x >= 0 ? '+' : '−') + kit.num(Math.abs(x), 3); }, C = data.cube;
      rdE1.textContent = S(P + 'rd.spin').replace('{x}', f(s3v[0])).replace('{y}', f(s3v[1])).replace('{z}', f(s3v[2])).replace('{z2}', f(spinOf({ A: [1, 1, 0], ph: [0, 90, 0] })[2]));
      rdE2.textContent = SP.cube === 'free' ? S(P + 'rd.torque') : ''; rdE2.style.display = SP.cube === 'free' ? '' : 'none';
      var rc = C.radius / (C.A / C.rho_c), pd = C.p_diag, on = SP.cube !== 'two';
      rdE3.textContent = on ? S(P + 'rd.diag').replace('{t}', kit.num(SP.u, 2)).replace('{p}', kit.num(pd, 0)).replace('{r}', kit.num(rc * Math.cos(Math.PI * SP.u / 2), 4) + ' A/ρc') : ''; rdE3.style.display = on ? '' : 'none';
      var Tt = data.tetrahedron;
      rdE5.textContent = SP.cube === 'three' ? S(P + 'rd.fibre').replace('{e}', kit.num(C.fibre_edge, 4)) : SP.cube === 'tetra' ? S(P + 'rd.tetra').replace('{p}', Tt.phases.join(', ')).replace('{s}', Tt.S).replace('{u}', 'ρ = 6/5, ω = 5, A = 3/7, c = 1') : '';
      rdE5.style.display = (SP.cube === 'three' || SP.cube === 'tetra') ? '' : 'none';
      var T = data.triangle;
      rdE4.textContent = S(P + 'rd.tri').replace('{l}', kit.num(T.lambda_a2, 4)).replace('{k}', kit.num(T.K_a, 4)).replace('{w0}', T.weights[0]).replace('{w1}', T.weights[1]).replace('{w2}', T.weights[2] === '1' ? '' : T.weights[2]).replace('{g}', kit.num(T.grad2_over_K2, 2)).replace('{z}', kit.num(T.impurity, 2));
      slP3.el.style.display = SP.cube === 'free' ? '' : 'none'; slU.el.style.display = on ? '' : 'none';
      lnDiag.style.display = on ? '' : 'none'; lnTet.style.display = SP.cube === 'tetra' ? '' : 'none';
    }
    // the triangle (MUS-220): b = ω₃²e^{iK₀·x} + ω₃e^{iK₁·x} + e^{iK₂·x}, the K_j along the sides at 0, 2π/3, 4π/3, |K|a = 4π/3 (the data);
    // the pressure Re(b e^{−iωt}) turns about the centroid, where b = 0 and ∇b is circular (vertex up, side 1: the rigid walls hold for this order)
    var TRI = null, TD = 1.08, TY = 0.144;   // the drawn square: side TD around the middle of the triangle's height
    function triField(n) {
      var ka = data.triangle.K_a, e = [0, 1, 2].map(function (j) { var t = j * TAU / 3; return [Math.cos(t), Math.sin(t)]; }), W = [[-0.5, -0.8660254], [-0.5, 0.8660254], [1, 0]];
      var re = [], im = [], R = 1 / Math.sqrt(3), i, j;   // side 1, centroid at 0, circumradius 1/√3
      for (j = 0; j < n; j++) for (i = 0; i < n; i++) { var x = TD * ((i + 0.5) / n - 0.5), y = TD * ((j + 0.5) / n - 0.5) + TY, pr_ = 0, pi_ = 0;
        e.forEach(function (d, q) { var ph = ka * (d[0] * x + d[1] * y), cr = Math.cos(ph), ci = Math.sin(ph); pr_ += W[q][0] * cr - W[q][1] * ci; pi_ += W[q][0] * ci + W[q][1] * cr; }); re.push(pr_); im.push(pi_); }
      var g = [[0, 0], [0, 0]]; e.forEach(function (d, q) { [0, 1].forEach(function (m) { g[m][0] += -ka * d[m] * W[q][1]; g[m][1] += ka * d[m] * W[q][0]; }); });   // ∇b at 0 = Σ i K_j w_j
      return { re: re, im: im, e: e, R: R, n: n, g: g };
    }
    function inTri(x, y, R) { var a = [[0, R], [-R * 0.8660254, -R / 2], [R * 0.8660254, -R / 2]]; function sd(p, q) { return (q[0] - p[0]) * (y - p[1]) - (q[1] - p[1]) * (x - p[0]); } var d1 = sd(a[0], a[1]), d2 = sd(a[1], a[2]), d3 = sd(a[2], a[0]); return (d1 >= 0 && d2 >= 0 && d3 >= 0) || (d1 <= 0 && d2 <= 0 && d3 <= 0); }
    function drawTri() {
      if (!TRI) TRI = triField(56);
      var c = triC.ctx, w = triC.w, h = triC.h, side = Math.min(w, h) - 20, ox = (w - side) / 2, oy = (h - side) / 2, n = TRI.n, cs = side / n, wt = TAU * PIC_HZ * st.t, cw = Math.cos(wt), sw = Math.sin(wt), i, j, mx = 2.6;
      c.clearRect(0, 0, w, h);
      for (j = 0; j < n; j++) for (i = 0; i < n; i++) { var x = TD * ((i + 0.5) / n - 0.5), y = TD * ((j + 0.5) / n - 0.5) + TY; if (!inTri(x, y, TRI.R)) continue; var k = j * n + i, v = TRI.re[k] * cw + TRI.im[k] * sw; c.fillStyle = kit.cmap(v / 3); c.fillRect(ox + i * cs, oy + (n - 1 - j) * cs, cs + 0.6, cs + 0.6); }
      function P2(x, y) { return [ox + (x / TD + 0.5) * side, oy + side - ((y - TY) / TD + 0.5) * side]; }
      var R = TRI.R, V = [[0, R], [-R * 0.8660254, -R / 2], [R * 0.8660254, -R / 2]].map(function (p) { return P2(p[0], p[1]); });
      c.strokeStyle = kit.ink(); c.lineWidth = 1.5; c.beginPath(); c.moveTo(V[0][0], V[0][1]); c.lineTo(V[1][0], V[1][1]); c.lineTo(V[2][0], V[2][1]); c.closePath(); c.stroke();
      var O = P2(0, 0); TRI.e.forEach(function (d) { kit.arrow(c, O[0], O[1], O[0] + d[0] * side * 0.16, O[1] - d[1] * side * 0.16, kit.ink(), 1.3); });   // the three travelling waves' directions
      c.strokeStyle = kit.accent(); c.lineWidth = 1.6; c.beginPath(); c.arc(O[0], O[1], side * 0.06, 0, TAU); c.stroke();
      var G = TRI.g, gx = G[0][0] * cw + G[0][1] * sw, gy = G[1][0] * cw + G[1][1] * sw, gn = Math.hypot(gx, gy) || 1;   // the direction of −∇p, the velocity's
      c.fillStyle = kit.accent(); c.beginPath(); c.arc(O[0] - side * 0.06 * gx / gn, O[1] + side * 0.06 * gy / gn, 3.5, 0, TAU); c.fill();
      txt(c, S(P + 'cv.tri'), 8, 14, kit.muted(), 'left', 11); txt(c, S(P + 'cv.node'), O[0] + side * 0.07, O[1] + side * 0.1, kit.accent(), 'left', 11);
    }
    // the sound of the drive: three oscillators at F with delays for the phases, on the left, the centre and the right; or the two modes in quadrature
    function stopSP() { if (SP.snd) { SP.snd.stop(); var b = SP.snd.btn; SP.snd = null; b.textContent = S('exp.common.play'); b.setAttribute('data-s', 'exp.common.play'); } }
    function voices(list, kind, btn) { // list: () → [{pan, gain, deg}]
      var a = kit.audio(); if (!a) { rdE4.textContent = S('exp.common.noaudio'); return; }
      stopSP(); if (st.on) { st.on = false; stopPair(); playB.textContent = S('exp.common.play'); playB.setAttribute('data-s', 'exp.common.play'); }
      var c = a.ctx, m = c.createChannelMerger(2), V = [0, 1, 2].map(function () { var o = c.createOscillator(), d = c.createDelay(0.02), gL = c.createGain(), gR = c.createGain(); o.frequency.value = F; gL.gain.value = 0; gR.gain.value = 0; o.connect(d); d.connect(gL); d.connect(gR); gL.connect(m, 0, 0); gR.connect(m, 0, 1); return { o: o, d: d, gL: gL, gR: gR }; });
      m.connect(a.master); var t0 = c.currentTime + 0.02; V.forEach(function (v) { v.o.start(t0); });
      var snd = { kind: kind, btn: btn, set: function () { var t = c.currentTime; list().forEach(function (q, i) { var v = V[i]; v.gL.gain.setTargetAtTime(q.gain * (1 - q.pan) / 2, t, 0.03); v.gR.gain.setTargetAtTime(q.gain * (1 + q.pan) / 2, t, 0.03); v.d.delayTime.setTargetAtTime((((q.deg % 360) + 360) % 360 / 360) / F, t, 0.02); }); },
        stop: function () { var t = c.currentTime; V.forEach(function (v) { v.gL.gain.setTargetAtTime(0, t, 0.02); v.gR.gain.setTargetAtTime(0, t, 0.02); v.o.stop(t + 0.15); }); } };
      SP.snd = snd; snd.set(); btn.textContent = S('exp.common.mute'); btn.setAttribute('data-s', 'exp.common.mute');
    }
    function startCube() { voices(function () { var m = modes(); if (SP.cube === 'two') return [{ pan: -1, gain: 0.3, deg: 0 }, { pan: 1, gain: 0.3, deg: 90 }, { pan: 0, gain: 0, deg: 0 }]; return [{ pan: -1, gain: 0.2, deg: m.ph[0] }, { pan: 0, gain: 0.2, deg: m.ph[1] }, { pan: 1, gain: 0.2, deg: m.ph[2] }]; }, 'cube', playE); }

    // ================================================================ (f) the still point of the water tank: η = a[cos kx cos ωt + cos ky sin ωt]
    var pw = kit.panel_(root, P + 'panel.water', S, 'span');
    var ctlW = kit.controls(pw);
    kit.seg(ctlW, { S: S, ids: [P + 'water.plus', P + 'water.minus', P + 'water.lin'], values: [90, -90, 0], value: 90, onchange: function (v) { SP.wph = v; readW(); if (SP.snd && SP.snd.kind === 'water') SP.snd.set(); } });
    var playW = kit.button(ctlW, 'exp.common.play', S, function () { if (SP.snd && SP.snd.kind === 'water') stopSP(); else voices(function () { return [{ pan: -1, gain: 0.3, deg: 0 }, { pan: 1, gain: 0.3, deg: SP.wph }, { pan: 0, gain: 0, deg: 0 }]; }, 'water', playW); });
    var gw = grid(); pw.appendChild(gw);
    var gw1 = el('div'), gw2 = el('div'), gw3 = el('div'); gw.appendChild(gw1); gw.appendChild(gw2); gw.appendChild(gw3);
    var watC = cv(gw1, 0.9, 340), secC = cv(gw2, 0.9, 340), trvC = cv(gw3, 0.9, 340);
    kit.line(gw3, P + 'line.travel', S);
    kit.line(gw1, P + 'water.pick', S, 'exp-note');
    watC.el.addEventListener('click', function (ev) { var b = watC.el.getBoundingClientRect(); SP.wpt = [(ev.clientX - b.left) < b.width / 2 ? -1 : 1, (ev.clientY - b.top) < b.height / 2 ? 1 : -1]; readW(); });
    var rdW1 = kit.readout(pw), rdW2 = kit.readout(pw), rdW3 = kit.readout(pw);
    kit.line(pw, P + 'line.water', S); kit.line(pw, P + 'hear.water', S);
    function eta(kx, ky, wt) { var r = Math.PI / 180; return Math.cos(kx) * Math.cos(wt) + Math.cos(ky) * Math.cos(wt - SP.wph * r); }
    function drawWater() {
      var c = watC.ctx, w = watC.w, h = watC.h, side = Math.min(w, h) - 16, ox = (w - side) / 2, oy = (h - side) / 2, n = 48, cs = side / n, wt = TAU * PIC_HZ * st.t, i, j;
      c.clearRect(0, 0, w, h);
      for (j = 0; j < n; j++) for (i = 0; i < n; i++) { var kx = Math.PI * (2 * (i + 0.5) / n - 1), ky = Math.PI * (2 * (j + 0.5) / n - 1); c.fillStyle = kit.cmap(eta(kx, ky, wt) / 2); c.fillRect(ox + i * cs, oy + (n - 1 - j) * cs, cs + 0.6, cs + 0.6); }
      function X(k) { return ox + (k / Math.PI + 1) / 2 * side; } function Y(k) { return oy + side - (k / Math.PI + 1) / 2 * side; }
      // the zero contour of the height, by marching squares on the same grid
      var g = []; for (j = 0; j <= n; j++) { g[j] = []; for (i = 0; i <= n; i++) g[j][i] = eta(Math.PI * (2 * i / n - 1), Math.PI * (2 * j / n - 1), wt); }
      c.strokeStyle = kit.ink(); c.lineWidth = 0.9; c.globalAlpha = 0.6;
      for (j = 0; j < n; j++) for (i = 0; i < n; i++) { var q = [g[j][i], g[j][i + 1], g[j + 1][i + 1], g[j + 1][i]], C4 = [[0, 0], [1, 0], [1, 1], [0, 1]], pts = [];
        for (var e = 0; e < 4; e++) { var a0 = q[e], b0 = q[(e + 1) % 4]; if (a0 * b0 < 0) { var f = a0 / (a0 - b0), p0 = C4[e], p1 = C4[(e + 1) % 4]; pts.push([ox + (i + p0[0] + f * (p1[0] - p0[0])) * cs, oy + side - (j + p0[1] + f * (p1[1] - p0[1])) * cs]); } }
        for (e = 0; e + 1 < pts.length; e += 2) { c.beginPath(); c.moveTo(pts[e][0], pts[e][1]); c.lineTo(pts[e + 1][0], pts[e + 1][1]); c.stroke(); } }
      c.globalAlpha = 1; c.strokeStyle = kit.ink(); c.lineWidth = 1.5; c.strokeRect(ox, oy, side, side);
      c.setLineDash([2, 4]); c.strokeStyle = kit.muted(); c.lineWidth = 1.2; [-1, 1].forEach(function (s) { var k = s * Math.PI / 2; c.beginPath(); c.moveTo(X(k), oy); c.lineTo(X(k), oy + side); c.moveTo(ox, Y(k)); c.lineTo(ox + side, Y(k)); c.stroke(); }); c.setLineDash([]);
      [-1, 1].forEach(function (a) { [-1, 1].forEach(function (b) { var sel = a === SP.wpt[0] && b === SP.wpt[1]; c.strokeStyle = sel ? kit.accent() : kit.ink(); c.lineWidth = sel ? 2.4 : 1.4; c.beginPath(); c.arc(X(a * Math.PI / 2), Y(b * Math.PI / 2), sel ? 7 : 5, 0, TAU); c.stroke(); }); });
      if (SP.wph === 90) { var SG = data.still.grid, US = data.still.us, cell = side / 20; c.globalAlpha = 0.85;
        SG.forEach(function (ky, i) { SG.forEach(function (kx, j) { if (i % 2 || j % 2) return; var u = US[i][j], x0 = X(kx), y0 = Y(ky); kit.arrow(c, x0, y0, x0 + u[0] * cell * 1.6, y0 - u[1] * cell * 1.6, kit.violet, 1.1); }); });
        c.globalAlpha = 1; txt(c, S(P + 'cv.drift'), X(SG[SG.length - 1]) - 2, Y(SG[0]) - 4, kit.violet, 'right', 10); }
      txt(c, S(P + 'cv.surface'), ox + 4, oy + 13, kit.ink(), 'left', 11); txt(c, S(P + 'cv.still'), X(SP.wpt[0] * Math.PI / 2) + 9, Y(SP.wpt[1] * Math.PI / 2) - 8, kit.accent(), 'left', 11);
    }
    function drawSection() { // the parcels below the chosen still point: horizontal orbits of radius a e^{kz}, in perspective
      var c = secC.ctx, w = secC.w, h = secC.h, wt = TAU * PIC_HZ * st.t, r = Math.PI / 180, cx = w / 2, top = 40, R0 = Math.min(w * 0.3, 90), depths = [0, 0.4, 0.9, 1.6];
      c.clearRect(0, 0, w, h);
      c.fillStyle = 'rgba(43,95,158,0.08)'; c.fillRect(10, top, w - 20, h - top - 10);
      c.strokeStyle = kit.blue; c.lineWidth = 1.5; c.beginPath(); c.moveTo(10, top); c.lineTo(w - 10, top); c.stroke();
      c.strokeStyle = kit.muted(); c.setLineDash([3, 3]); c.beginPath(); c.moveTo(cx, top - 20); c.lineTo(cx, h - 10); c.stroke(); c.setLineDash([]);
      var sx = SP.wpt[0], sy = SP.wpt[1]; // sin kx, sin ky at the still point
      depths.forEach(function (kz, i) {
        var y0 = top + (h - top - 30) * kz / 1.8, A = R0 * Math.exp(-kz), j;
        // displacement (x, y) = -a e^{kz} (sin kx cos ωt, sin ky cos(ωt − φ)) for η = a[cos kx cos ωt + cos ky cos(ωt − φ)]
        function D(t) { return [-A * sx * Math.cos(t), -A * sy * Math.cos(t - SP.wph * r)]; }
        c.strokeStyle = kit.accent(); c.globalAlpha = 0.5; c.lineWidth = 1; c.beginPath(); for (j = 0; j <= 60; j++) { var d = D(TAU * j / 60); if (j) c.lineTo(cx + d[0], y0 - 0.3 * d[1]); else c.moveTo(cx + d[0], y0 - 0.3 * d[1]); } c.stroke(); c.globalAlpha = 1;
        var p = D(wt); c.fillStyle = i === 0 ? kit.warm() : kit.accent(); c.beginPath(); c.arc(cx + p[0], y0 - 0.3 * p[1], i === 0 ? 6 : 4, 0, TAU); c.fill();
        if (i > 0) txt(c, 'kz = −' + kit.num(kz, 1), w - 14, y0 + 4, kit.muted(), 'right', 10);
      });
      txt(c, S(P + 'cv.section'), 12, 16, kit.ink(), 'left', 11); txt(c, S(P + 'cv.floater'), 12, top - 6, kit.warm(), 'left', 11);
      var hand = Math.sin(SP.wph * r) * sx * sy; txt(c, hand > 0.01 ? '↺' : hand < -0.01 ? '↻' : '↔', cx + R0 + 14, top + 5, kit.warm(), 'left', 16);
    }
    function wAt(arr, kz) { var Wd = data.water; return kit.interp(Wd.kz.map(function (z, i) { return [-z, arr[i]]; }), -kz); }
    function readW() {
      var Wd = data.water, us0 = data.still.us[5][5];
      rdW1.textContent = S(P + 'rd.water').replace('{s}', kit.num(Wd.S[0], 3)).replace('{s1}', kit.num(wAt(Wd.S, -1), 4)).replace('{r}', kit.num(Wd.radius[0], 3)).replace('{u}', kit.num(Math.hypot(us0[0], us0[1]), 3)).replace('{c}', kit.num(Wd.column_ratio, 0));
      rdW2.textContent = S(P + 'rd.travel').replace('{t}', kit.num(Wd.ratio_total, 0)).replace('{k}', kit.num(Wd.ratio_kinetic, 0)).replace('{c}', kit.num(Wd.column_ratio, 0));
      rdW3.textContent = S('exp.common.slowed').replace('{n}', String(SLOW));
    }
    function drawTravel() { // η = a cos(kx − ωt); a parcel at rest position (x0, z0) is displaced by a e^{kz0}(−sin(kx0 − ωt), cos(kx0 − ωt)): forward at the crests
      var c = trvC.ctx, w = trvC.w, h = trvC.h, wt = TAU * PIC_HZ * st.t, top = h * 0.24, L = w - 30, sc = L / (2 * TAU), A0 = Math.min(26, h * 0.08), depths = [0, -0.5, -1, -1.6], i, j;
      c.clearRect(0, 0, w, h); c.fillStyle = 'rgba(43,95,158,0.08)';
      c.beginPath(); c.moveTo(15, h - 8); for (i = 0; i <= 120; i++) { var kx = 2 * TAU * i / 120; c.lineTo(15 + kx * sc, top - A0 * Math.cos(kx - wt)); } c.lineTo(w - 15, h - 8); c.closePath(); c.fill();
      c.strokeStyle = kit.blue; c.lineWidth = 1.6; c.beginPath(); for (i = 0; i <= 120; i++) { var kx2 = 2 * TAU * i / 120, y = top - A0 * Math.cos(kx2 - wt); if (i) c.lineTo(15 + kx2 * sc, y); else c.moveTo(15 + kx2 * sc, y); } c.stroke();
      depths.forEach(function (kz) { var r = A0 * wAt(data.water.radius, kz), z0 = top - kz * (h - top - 30) / 1.7;
        for (j = 0; j < 8; j++) { var kx0 = (j + 0.5) * 2 * TAU / 8, x0 = 15 + kx0 * sc, ph = kx0 - wt;
          c.strokeStyle = kit.accent(); c.globalAlpha = 0.35; c.lineWidth = 1; c.beginPath(); c.arc(x0, z0, r, 0, TAU); c.stroke(); c.globalAlpha = 1;
          c.fillStyle = kz === 0 ? kit.warm() : kit.accent(); c.beginPath(); c.arc(x0 - r * Math.sin(ph), z0 - r * Math.cos(ph), kz === 0 ? 3.5 : 2.8, 0, TAU); c.fill(); } });
      kit.arrow(c, w - 70, 16, w - 20, 16, kit.ink(), 1.5); txt(c, S(P + 'cv.wave'), w - 74, 20, kit.ink(), 'right', 11);
      txt(c, S(P + 'cv.travel'), 12, 16, kit.ink(), 'left', 11);
    }

    // ================================================================ (g) the smallest rotor (MUS-214, MUS-215): Ων/|v|² against a/δ, and the thermal floor
    var RO = data.rotor, FL = data.floor; SP.rf = 1e8; SP.rv = '0.1414';
    var pr5 = kit.panel_(root, P + 'panel.rotor', S, 'span');
    var ctlR = kit.controls(pr5);
    kit.seg(ctlR, { S: S, ids: [P + 'rotor.v1', P + 'rotor.v10'], values: ['0.1414', '1.4142'], value: SP.rv, onchange: function (v) { SP.rv = v; readR(); } });
    kit.slider(ctlR, { S: S, id: P + 'rotor.f', min: 1e6, max: 1e10, log: true, value: SP.rf, fmt: fHz, onchange: function (v) { SP.rf = v; readR(); } });
    var rotC = cv(pr5, window.innerWidth < 600 ? 0.85 : 0.45, 360), rdR1 = kit.readout(pr5), rdR2 = kit.readout(pr5);
    kit.line(pr5, P + 'cap.rotor', S);
    function fHz(v) { return v >= 1e9 ? kit.num(v / 1e9, 2) + ' GHz' : v >= 1e6 ? kit.num(v / 1e6, v < 1e7 ? 2 : 0) + ' MHz' : kit.num(v, 0) + ' Hz'; }
    function fM(v) { return v >= 1e-6 ? kit.num(v * 1e6, 2) + ' µm' : kit.num(v * 1e9, v < 1e-8 ? 2 : 1) + ' nm'; }
    function delta(f) { return Math.sqrt(2 * (FL.eta / FL.rho) / (TAU * f)); }   // the viscous layer of water, from the inputs of sn·FLOOR
    function aT(f) { var t = FL.crossing[SP.rv].map(function (q) { return [Math.log(q[0]), Math.log(q[1])]; }), v = kit.interp(t, Math.log(f)); return v == null ? null : Math.exp(v); }
    var RC = [['silica_water', kit.blue, 'rotor.l.silica'], ['gold_water', kit.warm(), 'rotor.l.gold'], ['aluminium_air', kit.violet, 'rotor.l.al']];
    function drawRotor() {
      var c = rotC.ctx, w = rotC.w, h = rotC.h, box = { l: 54, r: w - 12, t: 10, b: h - 34 }; c.clearRect(0, 0, w, h);
      var ax = kit.axes(c, box, { xmin: RO.x[0], xmax: RO.x[RO.x.length - 1], xlog: true, ymin: 1e-6, ymax: 1e5, ylog: true, xticks: [0.01, 0.1, 1, 10], yticks: [1e-5, 1e-3, 0.1, 10, 1000], xlabel: S(P + 'rotor.cv.x'), ylabel: S(P + 'rotor.cv.y') });
      c.save(); c.beginPath(); c.rect(box.l, box.t, box.r - box.l, box.b - box.t); c.clip();
      kit.curve(c, RO.x.map(function (x, i) { return [x, RO.heavy[i]]; }), ax.x, ax.y, kit.muted(), 1.4, [6, 4]);
      RC.forEach(function (q) { kit.curve(c, RO.x.map(function (x, i) { return [x, RO[q[0]][i]]; }), ax.x, ax.y, q[1], 2); var m = RO.max[q[0]]; c.fillStyle = q[1]; c.beginPath(); c.arc(ax.x(m[0]), ax.y(m[1]), 5, 0, TAU); c.fill(); });
      var hx = ax.x(1), hy = ax.y(RO.heavy_at_1); c.strokeStyle = kit.ink(); c.lineWidth = 1.6; c.beginPath(); c.moveTo(hx - 5, hy - 5); c.lineTo(hx + 5, hy + 5); c.moveTo(hx - 5, hy + 5); c.lineTo(hx + 5, hy - 5); c.stroke();
      var a = aT(SP.rf); if (a != null) { var xt = a / delta(SP.rf); c.strokeStyle = kit.warm(); c.setLineDash([2, 3]); c.lineWidth = 1.4; c.beginPath(); c.moveTo(ax.x(xt), box.t); c.lineTo(ax.x(xt), box.b); c.stroke(); c.setLineDash([]); }
      c.restore();
      var items = RC.map(function (q) { return [S(P + q[2]), q[1]]; }).concat([[S(P + 'rotor.l.heavy'), kit.muted()], [S(P + 'rotor.l.floor'), kit.warm()]]);
      c.font = '11px system-ui, sans-serif'; var lw = 0; items.forEach(function (q) { lw = Math.max(lw, c.measureText(q[0]).width); });
      var lx = box.r - lw - 10, ly = box.t + 16; c.globalAlpha = 0.88; c.fillStyle = kit.panel(); c.fillRect(lx - 4, ly - 11, lw + 8, 13 * items.length + 4); c.globalAlpha = 1;
      items.forEach(function (q, j) { txt(c, q[0], lx, ly + 13 * j, q[1], 'left', 11); });
    }
    function readR() {
      var a = aT(SP.rf), d = delta(SP.rf), M = RO.max, L = FL.least;
      rdR1.textContent = S(P + 'rotor.rd.f').replace('{f}', fHz(SP.rf)).replace('{d}', fM(d)).replace('{a}', a == null ? OUT : fM(a)).replace('{x}', a == null ? OUT : kit.num(a / d, 3));
      rdR2.textContent = S(P + 'rotor.rd.max').replace('{s1}', kit.num(M.silica_water[1], 6)).replace('{x1}', kit.num(M.silica_water[0], 4)).replace('{s2}', kit.num(M.gold_water[1], 5)).replace('{x2}', kit.num(M.gold_water[0], 5)).replace('{s3}', kit.num(M.aluminium_air[1], 3)).replace('{x3}', kit.num(M.aluminium_air[0], 6))
        .replace('{a1}', fM(L['0.1414'][1])).replace('{f1}', fHz(L['0.1414'][0])).replace('{a2}', fM(L['1.4142'][1])).replace('{f2}', fHz(L['1.4142'][0])).replace('{xl}', kit.num(FL.x_least, 3)).replace('{w1}', kit.sci(FL.rate_max['0.1414'], 2));
    }
    readE(); readW(); readR();

    upd(); readB(); readC();
    kit.loop(function (t, dt) { if (!st.paused) st.t += dt; drawEllipse(); if (st.dirty) { drawMap(); st.dirty = false; } drawBars(); drawApp(); drawPhase(); drawOffset(); drawExtrap(); drawCubeView(cubeC, proj, S(P + 'cv.cube')); drawCubeView(diagC, projD, S(P + 'cv.diagview')); drawTri(); drawWater(); drawSection(); drawTravel(); drawRotor(); });
    window.addEventListener('resize', function () { st.dirty = true; });
  } };
})();
