// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// field — the field made visible: the same plane wave as sound (p, v) and as light (E, B), travelling or standing.
(function () { 'use strict';
  window.SDV_EXP = window.SDV_EXP || {};
  window.SDV_EXP.field = { mount: function (root, data, S, kit) {
    var C = data.c, RHO = data.rho, Z = C * RHO, F = data.f, P = data.P, SLOW = data.slow;
    var LAM = C / F, K = 2 * Math.PI / LAM, OM = 2 * Math.PI * F, L2 = 2 * LAM, ML = 18;
    var XI_SCALE = 0.09 * LAM / (2 * P / (Z * OM));
    var st = { mode: 'tr', flux: true, vec: false, xm: 0.4 * LAM, play: false, hearE: false };
    var el = kit.el, ink = kit.ink, mut = kit.muted, acc = kit.accent;
    var reduced = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
    var paused = reduced;
    function T(id, o) { var s = S(id); if (o) for (var k in o) s = s.split('{' + k + '}').join(o[k]); return s; }

    function A(x, ph) { return st.mode === 'tr' ? Math.cos(K * x - ph) : 2 * Math.cos(K * x) * Math.cos(ph); }
    function Bn(x, ph) { return st.mode === 'tr' ? Math.cos(K * x - ph) : 2 * Math.sin(K * x) * Math.sin(ph); }
    function Xi(x, ph) { var a = P / (Z * OM); return st.mode === 'tr' ? -a * Math.sin(K * x - ph) : -2 * a * Math.sin(K * x) * Math.cos(ph); }
    function residuals() {
      var h = LAM / 2000, dt = 1 / F / 2000, Nrm = K * 2 * P / Z;
      var p = function (x, y, t) { return P * A(x, OM * t); }, vx = function (x, y, t) { return (P / Z) * Bn(x, OM * t); }, vy = function () { return 0; };
      var rs = 0, rv = 0, rb = 0;
      for (var i = 0; i <= 32; i++) for (var j = 0; j < 8; j++) {
        var x = L2 * i / 32, y = 0.05 * j, t = (j * 0.37 + 0.1) / F;
        var dpdt = (p(x, y, t + dt) - p(x, y, t - dt)) / (2 * dt);
        var dvxdt = (vx(x, y, t + dt) - vx(x, y, t - dt)) / (2 * dt), dvydt = (vy(x, y, t + dt) - vy(x, y, t - dt)) / (2 * dt);
        var divv = (vx(x + h, y, t) - vx(x - h, y, t)) / (2 * h) + (vy(x, y + h, t) - vy(x, y - h, t)) / (2 * h);
        var dpdx = (p(x + h, y, t) - p(x - h, y, t)) / (2 * h), dpdy = (p(x, y + h, t) - p(x, y - h, t)) / (2 * h);
        rs = Math.max(rs, Math.abs(dpdt / (RHO * C * C) + divv));
        rv = Math.max(rv, Math.hypot(dvxdt / C + dpdx / Z, dvydt / C + dpdy / Z));
        rb = Math.max(rb, Math.abs((vy(x + h, y, t) - vy(x - h, y, t)) / (2 * h) - (vx(x, y + h, t) - vx(x, y - h, t)) / (2 * h)));
      }
      return [rs, rv, rb].map(function (r) { return 100 * r / Nrm; });
    }
    function meanFlux() { var s = 0, n = 0; for (var i = 0; i < 128; i++) for (var j = 0; j < 128; j++) { var x = L2 * (i + 0.5) / 128, ph = 2 * Math.PI * j / 128; s += A(x, ph) * Bn(x, ph); n++; } return s / n; }
    var f0 = function (v, d) { return (Math.abs(v) < 0.5 * Math.pow(10, -d) ? 0 : v).toFixed(d); };

    // ---------------------------------------------------------------- layout
    root.classList.add('half');
    var pS = kit.panel_(root, 'exp.field.panel.sound', S), pL = kit.panel_(root, 'exp.field.panel.light', S);
    var ctl = kit.controls(pS); pS.insertBefore(ctl, pS.children[1]);
    var seg = kit.seg(ctl, { ids: ['exp.common.travelling', 'exp.common.standing'], values: ['tr', 'st'], value: 'tr', S: S, onchange: function (m) { st.mode = m; refresh(); } });
    kit.check(ctl, 'exp.field.flux', S, true, function (v) { st.flux = v; });
    var playB = kit.button(ctl, 'exp.common.play', S, function () {
      if (!kit.audio()) { return; } ensureVoices(); st.play = !st.play;
      playB.textContent = S(st.play ? 'exp.common.mute' : 'exp.common.play'); playB.setAttribute('data-s', st.play ? 'exp.common.mute' : 'exp.common.play'); playB.setAttribute('aria-pressed', String(st.play));
    }, 'acc');
    var hearB = kit.button(ctl, 'exp.field.hearE', S, function () { if (!kit.audio()) return; ensureVoices(); st.hearE = !st.hearE; hearB.setAttribute('aria-pressed', String(st.hearE)); });
    var fluxRead = kit.readout(pS), consts = kit.readout(pS);
    var cs = kit.canvas(pS, 10, 336); cs.el.setAttribute('tabindex', '0'); cs.el.setAttribute('aria-label', S('exp.field.aria.sound'));
    var soundEq = kit.line(pS, 'exp.field.eq.s.tr', S), slow = kit.readout(pS);
    var box = el('div', { class: 'exp-panel' }); pS.appendChild(box);
    box.appendChild(el('h3', { 'data-s': 'exp.field.res.head', text: S('exp.field.res.head') }));
    kit.line(box, 'exp.field.res.lead', S);
    var meters = [];
    ['exp.field.res.scalar', 'exp.field.res.vector', 'exp.field.res.bivector'].forEach(function (sid) {
      var row = el('div', { class: 'fld-meter' });
      row.style.cssText = 'display:grid;grid-template-columns:11em 1fr 5em;gap:8px;align-items:center;font-size:var(--fs-s);margin:3px 0';
      var bar = el('span'), fill = el('i'); bar.style.cssText = 'height:10px;border:1px solid ' + ink() + ';border-radius:2px;position:relative;display:block;overflow:hidden'; fill.style.cssText = 'position:absolute;left:0;top:0;bottom:0;background:' + acc() + ';width:0'; bar.appendChild(fill);
      var val = el('b'); val.style.fontVariantNumeric = 'tabular-nums';
      row.appendChild(el('span', { 'data-s': sid, text: S(sid) })); row.appendChild(bar); row.appendChild(val); box.appendChild(row); meters.push({ fill: fill, val: val });
    });
    var rmax = kit.readout(box);

    var cl = kit.canvas(pL, 10, 336); cl.el.setAttribute('tabindex', '0'); cl.el.setAttribute('aria-label', S('exp.field.aria.light'));
    var lightEq = kit.line(pL, 'exp.field.eq.l.tr', S);
    var dual = el('div', { class: 'exp-controls', role: 'group' }); pL.appendChild(dual);
    function bits(on, hint) {
      var w = el('span', { class: 'fld-bits', title: hint }); w.style.cssText = 'display:inline-flex;gap:3px';
      ['z', 'y', 'x'].forEach(function (a, i) { var s = el('span', { text: String(on[i]) }); s.style.cssText = 'display:inline-block;width:18px;height:18px;border-radius:3px;text-align:center;font:600 12px/16px ui-monospace,monospace;' + (on[i] ? 'border:2px solid currentColor' : 'border:1px dashed currentColor;opacity:.5'); var c = el('span', { text: a }); c.style.cssText = 'display:inline-flex;flex-direction:column;align-items:center;font-size:10px'; c.insertBefore(s, c.firstChild); w.appendChild(c); });
      return w;
    }
    var dVec = el('button', { type: 'button', class: 'btn exp-btn', 'aria-pressed': 'false' }), dPl = el('button', { type: 'button', class: 'btn exp-btn', 'aria-pressed': 'true' });
    [[dVec, 'exp.field.dual.vec', 'exp.field.dual.vec.hint', [1, 0, 0]], [dPl, 'exp.field.dual.pl', 'exp.field.dual.pl.hint', [0, 1, 1]]].forEach(function (d) {
      d[0].style.cssText = 'display:flex;flex-direction:column;align-items:flex-start;gap:4px;text-align:left;border-radius:10px';
      d[0].appendChild(el('span', { 'data-s': d[1], text: S(d[1]) })); d[0].appendChild(bits(d[3], S(d[2])));
      d[0].appendChild(el('span', { 'data-s': d[2], text: S(d[2]), style: 'font-size:12px;color:' + mut() }));
    });
    function setVec(v) { st.vec = v; dVec.setAttribute('aria-pressed', String(v)); dPl.setAttribute('aria-pressed', String(!v)); dVec.style.background = v ? ink() : ''; dVec.style.color = v ? kit.panel() : ''; dPl.style.background = v ? '' : ink(); dPl.style.color = v ? '' : kit.panel(); }
    dVec.addEventListener('click', function () { setVec(true); }); dPl.addEventListener('click', function () { setVec(false); });
    dual.appendChild(dVec); dual.appendChild(el('span', { text: '⇄', 'aria-hidden': 'true' })); dual.appendChild(dPl); setVec(false);
    kit.line(pL, 'exp.field.dual.line', S);

    // grades
    var gr = el('div', { class: 'exp-panel span' }); root.appendChild(gr);
    var gwrap = el('div'); gwrap.style.cssText = 'display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:12px'; gr.appendChild(gwrap);
    [['exact', 'exp.field.g.exact', 'MUS-029 MUS-047'], ['partial', 'exp.field.g.partial', 'MUS-029 MUS-047 MUS-046'], ['none', 'exp.field.g.none', 'MUS-029 MUS-045']].forEach(function (g) {
      var c = el('div'); kit.grade(c, g[0], 'exp.common.grade.' + g[0], S); c.firstChild.style.fontWeight = '600';
      kit.line(c, g[1], S);
      if (g[0] === 'none') {
        var b = kit.button(c, 'exp.field.boost', S, function () { msg.textContent = S('exp.field.boost.msg'); msg.setAttribute('data-s', 'exp.field.boost.msg'); }, 'exp-dead'); b.setAttribute('aria-disabled', 'true'); b.style.cursor = 'not-allowed';
        var msg = el('p', { class: 'exp-line', 'aria-live': 'polite' }); c.appendChild(msg);
      }
      c.appendChild(el('p', { class: 'exp-note', text: g[2] })); gwrap.appendChild(c);
    });
    kit.line(root, 'exp.field.note', S, 'exp-note');
    var sh = el('div', { class: 'exp-panel span' }); root.appendChild(sh);
    sh.appendChild(el('h3', { 'data-s': 'exp.common.see', text: S('exp.common.see') })); kit.line(sh, 'exp.field.see', S);
    sh.appendChild(el('h3', { 'data-s': 'exp.common.hear', text: S('exp.common.hear') })); kit.line(sh, 'exp.field.hear', S);

    // ---------------------------------------------------------------- numbers
    function refresh() {
      var r = residuals();
      meters.forEach(function (m, i) { m.val.textContent = f0(r[i], 2) + ' %'; m.fill.style.width = Math.min(100, r[i]) + '%'; });
      var mx = Math.max.apply(null, r);
      rmax.textContent = T('exp.field.res.max', { a: f0(mx, 2), b: mx.toExponential(1) });
      var mf = meanFlux();
      fluxRead.textContent = T('exp.field.flux.read', { i: f0(P * P / Z * mf * 1000, 4), s: f0(mf, 4) });
      var tr = st.mode === 'tr';
      soundEq.textContent = S(tr ? 'exp.field.eq.s.tr' : 'exp.field.eq.s.st'); soundEq.setAttribute('data-s', tr ? 'exp.field.eq.s.tr' : 'exp.field.eq.s.st');
      lightEq.textContent = S(tr ? 'exp.field.eq.l.tr' : 'exp.field.eq.l.st'); lightEq.setAttribute('data-s', tr ? 'exp.field.eq.l.tr' : 'exp.field.eq.l.st');
    }
    consts.textContent = T('exp.field.consts', { f: F, c: C, rho: RHO, lam: LAM.toFixed(4), z: Z.toFixed(4), k: K.toFixed(4), om: OM.toFixed(2), p: P });
    slow.textContent = T('exp.common.slowed', { n: SLOW }) + ' ' + T('exp.field.disp', { n: Math.round(XI_SCALE).toLocaleString('en-US'), u: (2 * P / (Z * OM) * 1e6).toFixed(2), per: (SLOW / F).toFixed(2), ms: (1000 / F).toFixed(2) });

    // ---------------------------------------------------------------- drawing
    function begin(cv) { var s = cv.size(); var c = cv.ctx; c.clearRect(0, 0, s.w, s.h); c.fillStyle = kit.panel(); c.fillRect(0, 0, s.w, s.h); c.font = '12px system-ui,sans-serif'; c.textBaseline = 'alphabetic'; return { c: c, W: s.w, H: s.h }; }
    function arrow(c, x0, y0, x1, y1, col) { kit.arrow(c, x0, y0, x1, y1, col, c.lineWidth); }
    function colorbar(c, W, label) { var w = Math.min(90, W * 0.24), x = W - ML - w, y = 8; for (var i = 0; i < w; i++) { c.fillStyle = kit.cmap((i / (w - 1)) * 2 - 1); c.fillRect(x + i, y, 1.5, 8); }
      c.strokeStyle = mut(); c.lineWidth = 1; c.strokeRect(x, y, w, 8); c.fillStyle = mut(); c.textAlign = 'center'; c.fillText('0', x + w / 2, y + 20); c.textAlign = 'left'; c.fillText('−2', x, y + 20); c.textAlign = 'right'; c.fillText('+2', x + w, y + 20); c.fillText(label, x - 6, y + 8); }
    function mic(c, y0, y1, x) { c.strokeStyle = ink(); c.lineWidth = 1.2; c.setLineDash([4, 3]); c.beginPath(); c.moveTo(x, y0); c.lineTo(x, y1); c.stroke(); c.setLineDash([]); c.fillStyle = ink(); c.beginPath(); c.moveTo(x, y0 + 9); c.lineTo(x - 6, y0 - 3); c.lineTo(x + 6, y0 - 3); c.closePath(); c.fill(); }
    function trace(c, W, y0, y1, fn, vmax, label, val, unit) {
      var x0 = ML, w = W - 2 * ML, h = y1 - y0, mid = y0 + h / 2;
      c.strokeStyle = mut(); c.lineWidth = 1; c.strokeRect(x0, y0, w, h); c.beginPath(); c.moveTo(x0, mid); c.lineTo(x0 + w, mid); c.stroke();
      c.fillStyle = mut(); c.textAlign = 'left'; c.fillText(label + ' = ' + val.toFixed(2) + ' ' + unit, x0 + 6, y0 + 14); c.fillText('+' + vmax, x0 + w - 22, y0 + 13); c.fillText('−' + vmax, x0 + w - 22, y1 - 5);
      c.strokeStyle = ink(); c.lineWidth = 1.6; c.beginPath(); var n = Math.floor(w);
      for (var i = 0; i <= n; i++) { var y = mid - fn(i / n) / vmax * (h / 2 - 4); if (i) c.lineTo(x0 + i, y); else c.moveTo(x0 + i, y); } c.stroke();
      var v = fn(1); c.fillStyle = kit.cmap(v / vmax); c.beginPath(); c.arc(x0 + n, mid - v / vmax * (h / 2 - 4), 4.5, 0, 7); c.fill(); c.stroke();
    }
    var cells = function (W) { return W < 520 ? 12 : 16; };
    var xmPx = function (W) { return ML + st.xm / L2 * (W - 2 * ML); };
    function drawSound(ph) {
      var g = begin(cs), c = g.c, W = g.W, H = g.H, w = W - 2 * ML, N = cells(W), cell = w / N;
      c.fillStyle = ink(); c.textAlign = 'left'; c.font = '600 12px system-ui,sans-serif'; c.fillText(S('exp.field.cv.s.head'), ML, 16); c.font = '12px system-ui,sans-serif';
      colorbar(c, W, 'p, Pa');
      var yA = 34, hA = 92, mid = yA + hA / 2, i;
      for (i = 0; i < w; i += 2) { c.fillStyle = kit.cmap(P * A((i + 1) / w * L2, ph) / 2); c.fillRect(ML + i, yA, 2.6, hA); }
      c.strokeStyle = mut(); c.lineWidth = 1; c.strokeRect(ML, yA, w, hA);
      c.lineWidth = 1.3;
      for (i = 0; i < N; i++) { var len = Bn((i + 0.5) * L2 / N, ph) / 2 * cell * 0.95, X = ML + (i + 0.5) * cell; arrow(c, X - len / 2, mid - 14, X + len / 2, mid - 14, ink()); }
      if (st.flux) { c.lineWidth = 2.2; var fa = acc();
        for (i = 0; i < N; i++) { var xc = (i + 0.5) * L2 / N, I = A(xc, ph) * Bn(xc, ph), l2 = I * cell * 0.95, X2 = ML + (i + 0.5) * cell;
          if (Math.abs(l2) < 1) { c.fillStyle = fa; c.beginPath(); c.arc(X2, mid + 22, 1.6, 0, 7); c.fill(); } else arrow(c, X2 - l2 / 2, mid + 22, X2 + l2 / 2, mid + 22, fa); }
        c.fillStyle = fa; c.textAlign = 'left'; c.fillText(S('exp.field.cv.s.flux'), ML + 5, yA + hA - 6); }
      var yP = 146; c.fillStyle = mut(); c.textAlign = 'left'; c.fillText(T('exp.field.cv.s.parcels', { n: Math.round(XI_SCALE).toLocaleString('en-US') }), ML, yP);
      var M = Math.floor(w / 9);
      for (i = 0; i < M; i++) { var x0 = (i + 0.5) * L2 / M, X0 = ML + x0 / L2 * w; c.strokeStyle = mut(); c.lineWidth = 1; c.beginPath(); c.moveTo(X0, yP + 8); c.lineTo(X0, yP + 16); c.stroke();
        var X = ML + (x0 + XI_SCALE * Xi(x0, ph)) / L2 * w; c.fillStyle = kit.cmap(P * A(x0, ph) / 1.3); c.strokeStyle = ink(); c.lineWidth = 0.8; c.beginPath(); c.arc(X, yP + 30, 3.6, 0, 7); c.fill(); c.stroke(); }
      c.fillStyle = mut(); c.textAlign = 'left'; c.fillText(S('exp.field.cv.s.red'), ML, yP + 54);
      var mx = xmPx(W); mic(c, yA, yP + 60, mx);
      c.fillStyle = ink(); c.textAlign = mx > W - 90 ? 'right' : 'left'; c.fillText(S('exp.field.cv.s.mic'), mx + (mx > W - 90 ? -9 : 9), yA + 5);
      trace(c, W, 236, H - 8, function (u) { return P * A(st.xm, ph - 4 * Math.PI * (1 - u)); }, 2, S('exp.field.cv.s.trace'), P * A(st.xm, ph), 'Pa');
    }
    function discB(c, X, Y, B, rmax) {
      var r = rmax * Math.sqrt(Math.min(1, Math.abs(B) / 2)); if (r < 1.5) { c.fillStyle = mut(); c.beginPath(); c.arc(X, Y, 1.2, 0, 7); c.fill(); return; }
      var col = B < 0 ? kit.blue : kit.red; c.globalAlpha = 0.2; c.fillStyle = col; c.beginPath(); c.arc(X, Y, r, 0, 7); c.fill(); c.globalAlpha = 1; c.strokeStyle = col; c.lineWidth = 1.2; c.stroke();
      if (r < 5) return; var ra = r * 0.62, ccw = B > 0, a0 = 0.6 * Math.PI, sw = 1.45 * Math.PI, a1 = ccw ? a0 - sw : a0 + sw;
      c.lineWidth = 1.5; c.beginPath(); c.arc(X, Y, ra, a0, a1, ccw); c.stroke();
      var ex = X + ra * Math.cos(a1), ey = Y + ra * Math.sin(a1), dx = ccw ? Math.sin(a1) : -Math.sin(a1), dy = ccw ? -Math.cos(a1) : Math.cos(a1), h = Math.max(3, r * 0.38);
      c.fillStyle = col; c.beginPath(); c.moveTo(ex + dx * h, ey + dy * h); c.lineTo(ex - dy * h * 0.6, ey + dx * h * 0.6); c.lineTo(ex + dy * h * 0.6, ey - dx * h * 0.6); c.closePath(); c.fill();
    }
    function markB(c, X, Y, B, rmax) {
      var r = rmax * Math.min(1, Math.abs(B) / 2); if (r < 1.5) { c.fillStyle = mut(); c.beginPath(); c.arc(X, Y, 1.2, 0, 7); c.fill(); return; }
      var col = B < 0 ? kit.blue : kit.red; c.strokeStyle = col; c.fillStyle = col; c.lineWidth = 1.4; c.beginPath(); c.arc(X, Y, r, 0, 7); c.stroke();
      if (B > 0) { c.beginPath(); c.arc(X, Y, Math.max(1.4, r * 0.28), 0, 7); c.fill(); } else { var d = r * 0.62; c.beginPath(); c.moveTo(X - d * 0.7, Y - d * 0.7); c.lineTo(X + d * 0.7, Y + d * 0.7); c.moveTo(X + d * 0.7, Y - d * 0.7); c.lineTo(X - d * 0.7, Y + d * 0.7); c.stroke(); }
    }
    function drawLight(ph) {
      var g = begin(cl), c = g.c, W = g.W, H = g.H, w = W - 2 * ML, N = cells(W), cell = w / N, i;
      c.fillStyle = ink(); c.textAlign = 'left'; c.font = '600 12px system-ui,sans-serif'; c.fillText(S('exp.field.cv.l.head'), ML, 16); c.font = '12px system-ui,sans-serif';
      colorbar(c, W, 'E/E₀');
      var yA = 34, hA = 92, mid = yA + hA / 2;
      for (i = 0; i < w; i += 2) { c.fillStyle = kit.cmap(A((i + 1) / w * L2, ph) / 2); c.fillRect(ML + i, yA, 2.6, hA); }
      c.strokeStyle = mut(); c.lineWidth = 1; c.strokeRect(ML, yA, w, hA); c.lineWidth = 1.3;
      for (i = 0; i < N; i++) { var e = A((i + 0.5) * L2 / N, ph), X = ML + (i + 0.5) * cell, len = e / 2 * (hA / 2 - 6); arrow(c, X, mid + len / 2, X, mid - len / 2, ink()); }
      if (st.flux) { c.lineWidth = 2.2; var fa = acc(), yS = yA + hA + 14; c.fillStyle = fa; c.textAlign = 'left'; c.fillText(S('exp.field.cv.l.flux'), ML + 5, yA + hA - 6);
        for (i = 0; i < N; i++) { var xc = (i + 0.5) * L2 / N, Sx = A(xc, ph) * Bn(xc, ph), l2 = Sx * cell * 0.95, X2 = ML + (i + 0.5) * cell;
          if (Math.abs(l2) < 1) { c.fillStyle = fa; c.beginPath(); c.arc(X2, yS, 1.6, 0, 7); c.fill(); } else arrow(c, X2 - l2 / 2, yS, X2 + l2 / 2, yS, fa); } }
      var yB = 164, hB = 64, mB = yB + hB / 2, nar = W < 520; c.fillStyle = mut(); c.textAlign = 'left';
      c.fillText(S(st.vec ? (nar ? 'exp.field.cv.l.bvec.n' : 'exp.field.cv.l.bvec') : (nar ? 'exp.field.cv.l.bpl.n' : 'exp.field.cv.l.bpl')), ML, yB - 6);
      c.strokeStyle = mut(); c.lineWidth = 1; c.strokeRect(ML, yB, w, hB);
      for (i = 0; i < N; i++) { var b = Bn((i + 0.5) * L2 / N, ph), Xb = ML + (i + 0.5) * cell, rm = Math.min(hB / 2 - 3, cell * 0.5); (st.vec ? markB : discB)(c, Xb, mB, b, rm); }
      var mx = xmPx(W); mic(c, yA, yB + hB + 4, mx); c.fillStyle = ink(); c.textAlign = mx > W - 90 ? 'right' : 'left'; c.fillText(S('exp.field.cv.l.marker'), mx + (mx > W - 90 ? -9 : 9), yA + 5);
      trace(c, W, 246, H - 8, function (u) { return A(st.xm, ph - 4 * Math.PI * (1 - u)); }, 2, S('exp.field.cv.l.trace'), A(st.xm, ph), 'E₀');
    }

    // ---------------------------------------------------------------- interaction
    function bindDrag(cv) { var d = false, e0 = cv.el;
      function set(e) { var r = e0.getBoundingClientRect(); st.xm = kit.clamp((e.clientX - r.left - ML) / (r.width - 2 * ML) * L2, 0, L2); }
      e0.style.touchAction = 'pan-y'; e0.style.cursor = 'ew-resize';
      e0.addEventListener('pointerdown', function (e) { d = true; try { e0.setPointerCapture(e.pointerId); } catch (x) { } set(e); });
      e0.addEventListener('pointermove', function (e) { if (d) set(e); });
      var up = function () { d = false; }; e0.addEventListener('pointerup', up); e0.addEventListener('pointercancel', up);
      e0.addEventListener('keydown', function (e) { var s = e.shiftKey ? LAM / 40 : LAM / 200; if (e.key === 'ArrowLeft') { st.xm = Math.max(0, st.xm - s); e.preventDefault(); } if (e.key === 'ArrowRight') { st.xm = Math.min(L2, st.xm + s); e.preventDefault(); } });
    }
    bindDrag(cs); bindDrag(cl);

    // ---------------------------------------------------------------- sound: p(t) at the marker as a sine, E(t) as a triangle
    var vS = null, vE = null;
    function ensureVoices() { if (!vS) { vS = kit.voice({ f: F, gain: 0, type: 'sine' }); vE = kit.voice({ f: F, gain: 0, type: 'triangle' }); } }
    function ampAt() { return st.mode === 'tr' ? 1 : Math.abs(Math.cos(K * st.xm)); }
    function updateAudio() { if (!vS) return; var a = 0.2 * ampAt(); vS.set(F, st.play ? a : 0); vE.set(F, st.hearE ? a : 0); }

    refresh();
    var pauseB = kit.button(ctl, 'exp.common.pause', S, function () { paused = !paused; pauseB.setAttribute('aria-pressed', String(paused)); });
    pauseB.setAttribute('aria-pressed', String(paused));
    var ph = 0;
    kit.loop(function (t, dt) {
      if (!paused) ph += OM * dt / SLOW; drawSound(ph); drawLight(ph); updateAudio();
    });
  } };
})();
