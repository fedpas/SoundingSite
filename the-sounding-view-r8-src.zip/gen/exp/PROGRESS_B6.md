# B6 progress
- [x] read contract, kit, layers, spin, B5 note, packs T, O and S (rows, figure data, logs, figures)
- [x] layers: the cavity's phase (T) and the O–X window (O) — js, strings, data, spec, harness, screenshots; console clean at 1280 and 390
- [x] spin: the special places, the water tank, the smallest rotor, wired to S (spin_probes.json and its log); S's nine rows in `rows`; placeholders dropped; source extended; harness, screenshots; console clean at 1280 and 390
- [x] spin.spec.md, layers.spec.md "Extended"; B6_NOTE.md
- [x] S's review applied: the medium's-share condition in cap.rotor, rotor.rd.f, rotor.rd.max; harness and screenshots redone, console clean at 1280 and 390
- [ ] if a later review changes a number: rerun scratchpad/b6tools/spin_data.py (and the strings scripts) and reshoot
Backup of the originals: scratchpad/b6bak/; tools: scratchpad/b6tools/ (layers_data.py, layers_strings.py, spin_data.py, spin_strings.py + spin_strings2.py)
