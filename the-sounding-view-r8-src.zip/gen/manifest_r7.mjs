// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// manifest_r7.mjs — release 7, the Italian side (manifest_r6.mjs with release 6 as the baseline). In one run:
//   1. keeps the three Italian tables of release 3 (all finished: no stub) and moves what the new structure no longer renders
//      or shows (narrations, titles and strings of targets that are gone) to content/it/retired_r6.json;
//   2. writes a marked stub ("stub": true, refused by the full build) for every target and string the new structure needs and
//      the tables lack, and for every string, the experiments' included, whose English text changed since release 6 (the old Italian kept as previousIt);
//   3. writes content/it/MANIFEST_R7.json: exactly the targets and strings that carry a stub, each with the English material it
//      stands on, the length asked and where it renders; the strings of the experiments as one group ("experiments"); the list
//      of targets whose narration should be re-read (the layers and spin chapters, the counts); and refreshes MANIFEST_TITOLI.json.
// It reads build/build_log.json of a build with SDV_IT=partial (what the pages lacked). Idempotent: a second run keeps the stubs
// and the narrators' finished entries.
// Usage: SDV_IT=partial node gen/build.mjs ATLAS; node gen/manifest_r7.mjs ATLAS   (SDV_R6: the release-6 site folder with gen/content/strings.json and gen/exp/*.strings.json)
import fs from 'node:fs';
import path from 'node:path';
import { load, textKey, firstSentence, GEN, SITE } from './lib/sources.mjs';
import { loadExperiments } from './lib/exp.mjs';

const REPO = path.resolve(process.argv[2] || process.env.SDV_ATLAS || path.join(path.dirname(SITE), 'repo'));
const D = load(REPO);
const P = D.pack, Q = P.q;
const J = (p) => JSON.parse(fs.readFileSync(p, 'utf8'));
const W = (p, o) => fs.writeFileSync(p, JSON.stringify(o, null, 1) + '\n');
const IT = path.join(GEN, 'content', 'it');
const ST = J(path.join(GEN, 'content', 'structure.json'));
const log = J(path.join(GEN, 'build', 'build_log.json')).it;
const cur = J(path.join(GEN, 'content', 'strings.json'));
const curById = new Map(cur.strings.map((s) => [s.id, s]));
const R4 = path.resolve(process.env.SDV_R6 || path.join(SITE, '..', '..', '..', 'stage_src', 'the-sounding-view')); // release 6 as deployed, read only
const r3 = J(path.join(R4, 'gen', 'content', 'strings.json'));
const r3ById = new Map(r3.strings.map((s) => [s.id, s]));
for (const f of fs.readdirSync(path.join(R4, 'gen', 'exp')).filter((x) => /\.strings\.json$/.test(x))) for (const e of J(path.join(R4, 'gen', 'exp', f)).strings) r3ById.set(e.id, e); // release 6's experiment strings too
const tabS = J(path.join(IT, 'strings_it.json')), tabR = J(path.join(IT, 'racconto.json')), tabT = J(path.join(IT, 'titoli.json'));
const retired = fs.existsSync(path.join(IT, 'retired_r6.json')) ? J(path.join(IT, 'retired_r6.json')) : { about: "What release 7 retired from the Italian tables of release 6: narrations, titles and strings of targets the new structure no longer renders or shows. The prose is the narrators' own, kept here to draw on.", narrations: [], titles: [], strings: [] };

// ---- the experiments' strings (exp.*, hinge, analysis page): the English the narrator renders
const expMods = loadExperiments(GEN, new Map());
const expStr = [];
for (const [id, s] of (() => { const m = new Map(); loadExperiments(GEN, m); return m; })()) expStr.push({ id, text: s.text, why: s.why });
const expOf = (id) => { const m = /^exp\.([a-z0-9]+)\./.exec(id); return m ? m[1] : null; };
const expIds = new Set(expStr.map((s) => s.id));

// ---- 1. what is gone
const RETIRE_R = new Set(log.unrendered), RETIRE_T = new Set(log.unrenderedTitoli);
const keepR = [], keepT = [];
for (const it of tabR.items) (RETIRE_R.has(it.target) ? retired.narrations : keepR).push(it);
for (const it of tabT.items) (RETIRE_T.has(it.target) ? retired.titles : keepT).push(it);
tabR.items = keepR; tabT.items = keepT;
tabS.strings = tabS.strings.filter((s) => { if (curById.has(s.id) || expIds.has(s.id)) return true; retired.strings.push(s); return false; });
retired.narrations = [...new Map(retired.narrations.map((x) => [x.target, x])).values()];
retired.titles = [...new Map(retired.titles.map((x) => [x.target, x])).values()];
retired.strings = [...new Map(retired.strings.map((x) => [x.id, x])).values()];

// ---- English material
const research = (id) => { const t = D.texts.get(textKey(id, 'research', 'full')); return t ? t.body : null; };
const evidenceOf = (r) => (r.evidence || []).map((e) => `${e.check}${e.script ? ` (${path.basename(e.script)})` : ""}`);
const rowInfo = (id) => { const r = D.rows.get(id); return { id, status: D.status[id].status, kind: r.kind, homePhys: r.homePhys, homeMath: r.homeMath, research: research(id), depends: (r.depends || []).map((d) => `${d.id} (${d.rel})`), evidence: evidenceOf(r), since: r.since }; };
const CHAPS = [];
for (const part of ST.parts) for (const slug of part.chapters) {
  const def = ST.chapters[slug];
  const chains = def.section ? [[...D.chains.values()].find((c) => c.section === def.section)] : def.chains.filter((id) => !D.absentChains.has(id)).map((id) => D.chains.get(id));
  if (!def.section && !chains.length) continue;
  const rows = chains.flatMap((c) => c.rows);
  for (const inp of def.inputs || []) { const at = rows.findIndex((x) => (D.rows.get(x).depends || []).some((d) => d.id === inp)); if (at < 0) rows.push(inp); else rows.splice(at, 0, inp); }
  CHAPS.push({ slug, part: part.id, def, rows, chains });
}
const chapOf = new Map(); for (const c of CHAPS) for (const r of c.rows) chapOf.set(r, c);
const short = (t, n = 700) => (t && t.length > n ? t.slice(0, n) + ' …' : t);
const en = (id) => (curById.get(id) || {}).text;
const rowMaterial = (id) => { const i = rowInfo(id); return { id, status: i.status, homePhys: i.homePhys, homeMath: i.homeMath, researchFirst: firstSentence(i.research || ''), research: short(i.research), depends: i.depends, evidence: i.evidence }; };
const chainTitle = (c) => c.title;

const NARR = {}, TIT = {};
for (const target of [...new Set([...log.missingNarrations, ...tabR.items.filter((i) => i.stub).map((i) => i.target)])]) {
  let m;
  if ((m = /^row:(.+)$/.exec(target))) { const c = chapOf.get(m[1]); NARR[target] = { kind: 'row', what: `the row ${m[1]} told: what it claims, what establishes it, the numbers that matter, where it sits in the chapter ${c.slug}`, tells: [m[1]], length: '40–90', where: `${c.slug}.html#${m[1]}, the Racconto register`, material: rowMaterial(m[1]) }; }
  else if ((m = /^section:(.+)$/.exec(target))) { const c = CHAPS.find((x) => x.slug === m[1]); NARR[target] = { kind: 'section', what: `the chapter ${m[1]} of its part: what it is about, what its rows establish together, what the experiment at its head shows and lets you hear`, tells: [...c.rows.filter((r) => /^MUS-/.test(r)).slice(0, 6), ...(c.def.clips || []).map((x) => 'clip:' + x.slice(0, 2))], length: '90–160', where: `${m[1]}.html, the lead`, material: { title: en(`ch.${m[1]}.title`), lead: en(`ch.${m[1]}.lead`), chains: c.chains.map((x) => ({ id: x.id, title: chainTitle(x) })), rows: c.rows.map((r) => ({ id: r, homePhys: D.rows.get(r).homePhys })), experiments: c.def.experiments } }; }
  else if (target === 'page:experiment') NARR[target] = { kind: 'page', what: 'the report of the acoustic Beth experiment (the page experiment.html): what it would measure, with what, and what each result would mean for the spin of sound — one paragraph above the English report', tells: ['MUS-066', 'MUS-063', 'MUS-087'], length: '90–140', where: 'experiment.html, under the title', material: { title: D.analyses.find((a) => a.id === 'acoustic-spin-torque').title, line: D.analyses.find((a) => a.id === 'acoustic-spin-torque').line, checks: D.analyses.find((a) => a.id === 'acoustic-spin-torque').checks } };
  else NARR[target] = { kind: 'other', what: target, tells: [], length: '60–120', where: '?', material: {} };
}
for (const target of [...new Set([...log.missingTitoli, ...tabT.items.filter((i) => i.stub).map((i) => i.target)])]) {
  let m;
  if ((m = /^row:(.+)$/.exec(target))) { const c = chapOf.get(m[1]); TIT[target] = { what: `the one-line claim of the row ${m[1]}${c ? ` (chapter ${c.slug})` : ' (not on a chapter: it is shown in the legend of an experiment)'}, the head of its block: ≤ 14 words, no final period`, material: rowMaterial(m[1]), length: '≤ 14 words', where: c ? `${c.slug}.html#${m[1]}, the head of the block, and the legends of the experiments` : 'the legends of the experiments' }; }
  else if ((m = /^movement:(m\d)(:lead)?$/.exec(target))) TIT[target] = { what: m[2] ? `the one-line lead of the movement ${m[1]} of Part III` : `the heading of the movement ${m[1]} of Part III`, material: { en: en(`part.light.${m[1]}${m[2] ? '.lead' : ''}`), chapters: ST.parts.find((p) => p.id === 'light').movements.find((x) => x.id === m[1]).chapters }, length: m[2] ? '≤ 25 words' : '≤ 6 words', where: 'light.html, above the cards of the movement' };
  else if ((m = /^section:([a-z]+)(:sub)?$/.exec(target))) TIT[target] = { what: m[2] ? `one line under the title of the chapter ${m[1]}` : `the title of the chapter ${m[1]}: the h1, the crumbs, the cards and the previous / next links`, material: { en: en(`ch.${m[1]}.title`), lead: en(`ch.${m[1]}.lead`), card: en(`ch.${m[1]}.card`) }, length: m[2] ? '≤ 14 words' : '≤ 8 words', where: `${m[1]}.html` };
  else if ((m = /^chain:(.+)$/.exec(target))) { const ch = D.chains.get('music.mu-light.' + (m[1] === 'plasma' ? 'fluids' : m[1])) || [...D.chains.values()].find((x) => x.id.endsWith('.' + m[1])); TIT[target] = { what: `the heading of the chain ${m[1]} on its chapter (a second chain stands under the first as a sub-heading)`, material: { chain: ch ? ch.title : null }, length: '≤ 10 words', where: `${(CHAPS.find((c) => c.chains.some((x) => x.id.endsWith('.' + (m[1] === 'plasma' ? 'fluids' : m[1])))) || { slug: m[1] }).slug}.html, the heading above the chain's rows` }; }
  else if ((m = /^card:section:(.+)$/.exec(target))) TIT[target] = { what: `the card text of the chapter ${m[1]} on its part's page: two or three sentences`, material: { en: en(`ch.${m[1]}.card`), lead: en(`ch.${m[1]}.lead`) }, length: '30–60 words', where: "the page of Part III, the chapter's card" };
  else if ((m = /^lens:(\d+)$/.exec(target))) { const e = D.lens.dictionary[+m[1] - 1]; TIT[target] = { what: `the Italian term of the lens entry ${m[1]} (the music side), the first cell of its row`, material: { n: +m[1], atlas: e.atlas, term: e.term, match: e.match, evidence: e.evidence, rows: e.rows }, length: 'a term, ≤ 8 words', where: `dictionary.html#lens-${m[1]}` }; }
  else if ((m = /^check:(music_\w+)$/.exec(target))) { const sc = P.scripts.get(m[1]); TIT[target] = { what: `one line: what ${m[1]}.py computes`, material: { script: `${m[1]}.py`, what: sc.head, groups: sc.order }, length: 'one line, ≤ 30 words', where: `checks.html#${m[1]}, above the counts` }; }
  else if (target === 'page:experiment:title') TIT[target] = { what: 'the title of the analysis page (the title of the report)', material: { en: D.analyses.find((a) => a.id === 'acoustic-spin-torque').title }, length: '≤ 10 words', where: 'experiment.html (h1), the tab title' };
  else TIT[target] = { what: target, material: {}, length: '?', where: '?' };
}

// ---- 2. stubs
const stubText = (what) => `[bozza] ${what}`;
for (const [target, n] of Object.entries(NARR)) if (!tabR.items.some((i) => i.target === target)) tabR.items.push({ id: 'r:' + target, target, tells: n.tells, text: stubText('r:' + target), why: 'stub: the narrator tells this target (MANIFEST_R7.json)', stub: true });
for (const [target] of Object.entries(TIT)) if (!tabT.items.some((i) => i.target === target)) tabT.items.push({ id: 't:' + target, target, text: stubText('t:' + target), why: 'stub: the narrator titles this target (MANIFEST_R7.json)', stub: true });
const have = new Map(tabS.strings.map((s) => [s.id, s]));
const ITneed = new Set(log.missingStrings);
const enOnlyMarked = [], strings_new = [], strings_changed = [], experiments = [];
for (const s of [...cur.strings, ...expStr]) {
  const it = have.get(s.id), old = r3ById.get(s.id);
  const isExp = expIds.has(s.id);
  if (!it && !ITneed.has(s.id)) { if (!isExp && !s.enOnly) { curById.get(s.id).enOnly = true; enOnlyMarked.push(s.id); } continue; }
  const entry = isExp ? { id: s.id, text: s.text, why: s.why, group: 'experiments', experiment: expOf(s.id) || (s.id.startsWith('exp.common.') ? 'common' : 'page') } : { id: s.id, text: s.text, why: s.why, optional: !!(curById.get(s.id) || {}).optional };
  if (!it) { tabS.strings.push({ id: s.id, text: stubText('s:' + s.id), why: 'stub: the narrator renders this string (MANIFEST_R7.json)', stub: true }); (isExp ? experiments : strings_new).push(entry); }
  else if (it.stub) (isExp ? experiments : old ? strings_changed : strings_new).push(old ? { ...entry, was: old.text, previousIt: it.previousIt } : entry);
  else if (old && old.text !== s.text) { tabS.strings[tabS.strings.indexOf(it)] = { id: s.id, text: stubText('s:' + s.id), previousIt: it.text, why: 'stub: the English text changed (MANIFEST_R7.json); the previous Italian is kept in previousIt', stub: true }; (isExp ? experiments : strings_changed).push({ ...entry, was: old.text, previousIt: it.text }); }
}
if (enOnlyMarked.length) { cur.strings.forEach((s) => { if (enOnlyMarked.includes(s.id)) s.enOnly = true; }); W(path.join(GEN, 'content', 'strings.json'), cur); }
W(path.join(IT, 'strings_it.json'), tabS); W(path.join(IT, 'racconto.json'), tabR); W(path.join(IT, 'titoli.json'), tabT); W(path.join(IT, 'retired_r6.json'), retired);

// ---- 3. the manifest
const stubN = tabR.items.filter((i) => i.stub).map((i) => i.target);
const stubT = tabT.items.filter((i) => i.stub).map((i) => i.target);
const narrations = stubN.map((t) => ({ target: t, id: 'r:' + t, ...(NARR[t] || {}) }));
const titles = stubT.map((t) => ({ target: t, id: 't:' + t, ...(TIT[t] || {}) }));
const byKind = (a) => a.reduce((o, x) => { o[x.kind || 'title'] = (o[x.kind || 'title'] || 0) + 1; return o; }, {});
// release 7: no row text changed in the Atlas; what should be re-read is Part I (three chapters now), the fourth group of the checks page, and the pages whose counts changed
const review = [
  { target: 'part:sound', priority: 'reword', why: 'Part I now holds three chapters: the violin stands after consonance (the English lead part.sound.lead and the card part.sound.card each gained a sentence naming the violin: a true object with pieces added, where every added piece has its computation); the Italian title card:part:sound may gain the same' },
  { target: 'page:checks, page:pictures, page:about, page:sources', priority: 'check', why: 'counts changed (31 scripts, 34 figures, 223 row blocks); the sources page gains the violin\'s references; Method says what the site reads of the five works read from their own files (about.bridges.rows and about.reads.pack are yours)' },
];
const manifest = {
  about: 'The manifest of the Italian side of The Sounding View, release 7, for the two narrators (it/VOICE_IT.md): exactly the targets and strings that need Italian, each carrying "stub": true in the three tables (racconto.json, titoli.json, strings_it.json) until it is filled. The tables of release 3 are finished and carry over for every target that is still rendered. New in release 4: the five chapters of Part III that follow the Atlas\'s chains, the 78 rows of those chains, the 15 lens entries, the nine scripts, the four movements, the analysis page, and the strings of the experiments (group "experiments": the experiments\' words, in their English; each has a why that says where it stands). The review list names the 29 rows whose text changed in the Atlas 4.4.14.',
  written: new Date().toISOString(),
  rules: J(path.join(IT, 'MANIFEST.json')).rules,
  counts: { narrations: narrations.length, narrationsByKind: byKind(narrations), titles: titles.length, strings_new: strings_new.length, strings_changed: strings_changed.length, experiments: experiments.length, experimentsByModule: experiments.reduce((o, x) => { o[x.experiment] = (o[x.experiment] || 0) + 1; return o; }, {}), review: review.length, retired: { narrations: retired.narrations.length, titles: retired.titles.length, strings: retired.strings.length } },
  narrations, titles, strings_new, strings_changed, experiments: { group: 'experiments', about: 'The strings of the 23 experiments (ids exp.<name>.*, exp.common.*) and of the pointers to them. Each stands in one experiment of a chapter; the strings with {placeholders} keep them, filled by the page with numbers.', strings: experiments }, review,
};
W(path.join(IT, 'MANIFEST_R7.json'), manifest);
const mt = J(path.join(IT, 'MANIFEST_TITOLI.json'));
const known = new Set(tabT.items.map((i) => i.target));
mt.targets = mt.targets.filter((t) => known.has(t.target));
for (const t of titles) if (!mt.targets.some((x) => x.target === t.target)) mt.targets.push({ target: t.target, id: t.id, what: t.what, material: t.material, length: t.length, where: t.where });
for (const t of tabT.items) if (!mt.targets.some((x) => x.target === t.target)) mt.targets.push({ target: t.target, id: t.id, what: t.target, material: {}, length: '', where: '' });
mt.counts = { ...mt.counts, targets: mt.targets.length, release: 7 };
W(path.join(IT, 'MANIFEST_TITOLI.json'), mt);
console.log(`${enOnlyMarked.length} strings marked enOnly`);
console.log(`MANIFEST_R7.json: ${narrations.length} narrations ${JSON.stringify(manifest.counts.narrationsByKind)}, ${titles.length} titles, ${strings_new.length} new strings, ${strings_changed.length} changed, ${experiments.length} experiment strings, ${review.length} review items; retired ${retired.narrations.length} narrations, ${retired.titles.length} titles, ${retired.strings.length} strings`);
