// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// manifest_r3.mjs — release 3, the Italian side. In one run:
//   1. migrates the three Italian tables of release 2 to the new structure: targets that moved are renamed (the text kept),
//      targets and strings that no longer exist go to content/it/retired_r2.json (the narrators may draw on their prose);
//   2. writes a marked stub ("stub": true, refused by the full build) for every target and string the new structure needs
//      and the tables lack, and for every string whose English text changed (the old Italian kept in the manifest);
//   3. writes content/it/MANIFEST_R3.json: exactly the targets and strings that carry a stub, each with the English
//      material it stands on, the length asked and where it renders; and refreshes MANIFEST_TITOLI.json's target list.
// It reads build/build_log.json of a build with SDV_IT=partial (what the pages lacked). Idempotent: a second run keeps the
// stubs and the narrators' finished entries.
// Usage: SDV_IT=partial node gen/build.mjs REPO; node gen/manifest_r3.mjs REPO
import fs from 'node:fs';
import path from 'node:path';
import { load, resolve, textKey, firstSentence, GEN, SITE } from './lib/sources.mjs';
import { mdPlain } from './lib/md.mjs';
import { ALL_SCRIPTS } from './lib/pack.mjs';

const REPO = path.resolve(process.argv[2] || process.env.SDV_ATLAS || path.join(path.dirname(SITE), 'repo'));
const D = load(REPO);
const P = D.pack, Q = P.q;
const J = (p) => JSON.parse(fs.readFileSync(p, 'utf8'));
const W = (p, o) => fs.writeFileSync(p, JSON.stringify(o, null, 1) + '\n');
const IT = path.join(GEN, 'content', 'it');
const ST = J(path.join(GEN, 'content', 'structure.json'));
const log = J(path.join(GEN, 'build', 'build_log.json')).it;
const cur = J(path.join(GEN, 'content', 'strings.json'));
const curById = new Map(cur.strings.map((s) => [s.id, s]));
const r2 = J(path.join(SITE, '..', 'site', 'gen', 'content', 'strings.json')); // release 2, read only
const r2ById = new Map(r2.strings.map((s) => [s.id, s]));
const tabS = J(path.join(IT, 'strings_it.json')), tabR = J(path.join(IT, 'racconto.json')), tabT = J(path.join(IT, 'titoli.json'));
const retired = fs.existsSync(path.join(IT, 'retired_r2.json')) ? J(path.join(IT, 'retired_r2.json')) : { about: 'What release 3 retired from the Italian tables of release 2: the narrations, titles and strings of targets the new structure no longer renders. The prose is the narrators\' own, kept here to draw on.', narrations: [], titles: [], strings: [] };

// ---- 1. migrate
const RENAME = { 'checks:round37': 'checks:bridges', 'pictures:round37': 'pictures:bridges' };
for (const it of tabR.items) if (RENAME[it.target]) { it.target = RENAME[it.target]; it.id = 'r:' + it.target; }
const RETIRE_R = new Set(log.unrendered.filter((t) => !RENAME[t]).concat(tabR.items.filter((i) => /^bridges:(item:|opinion|table)/.test(i.target)).map((i) => i.target)));
const RETIRE_T = new Set(log.unrenderedTitoli);
const keepR = [], keepT = [];
for (const it of tabR.items) (RETIRE_R.has(it.target) ? retired.narrations : keepR).push(it);
for (const it of tabT.items) (RETIRE_T.has(it.target) ? retired.titles : keepT).push(it);
tabR.items = keepR; tabT.items = keepT;
const dropped = new Set(J('/tmp/dropped_strings.json'));
tabS.strings = tabS.strings.filter((s) => { if (curById.has(s.id)) return true; retired.strings.push(s); return false; });
retired.narrations = [...new Map(retired.narrations.map((x) => [x.target, x])).values()];
retired.titles = [...new Map(retired.titles.map((x) => [x.target, x])).values()];
retired.strings = [...new Map(retired.strings.map((x) => [x.id, x])).values()];

// ---- English material
const research = (id) => { const t = D.texts.get(textKey(id, 'research', 'full')); return t ? t.body : null; };
const rowInfo = (id) => {
  if (Q.rows.has(id)) { const r = Q.rows.get(id); return { id, status: r.status, kind: r.kind, homePhys: r.fields.homePhys, homeMath: r.fields.homeMath, research: r.research, depends: r.fields.depends || null }; }
  const r = D.rows.get(id); return { id, status: D.status[id].status, homePhys: r.homePhys, homeMath: r.homeMath, research: research(id) };
};
const CH = (slug) => { const def = ST.chapters[slug]; return def; };
const CHAPS = []; // slug -> rows (same rule as build.mjs)
for (const part of ST.parts) for (const slug of part.chapters) {
  const def = ST.chapters[slug]; let rows;
  if (def.section) rows = [...D.chains.values()].find((c) => c.section === def.section).rows.filter((x) => !(def.drop || []).includes(x));
  else { rows = def.rows.slice(); for (const inp of def.inputs || []) { const at = rows.findIndex((x) => Q.rows.has(x) && new RegExp(`\\b${inp}\\b`).test(Q.rows.get(x).fields.depends || '')); if (at < 0) rows.push(inp); else rows.splice(at, 0, inp); } }
  CHAPS.push({ slug, part: part.id, def, rows });
}
const chapOf = new Map(); for (const c of CHAPS) for (const r of c.rows) chapOf.set(r, c);
const short = (t, n = 700) => (t && t.length > n ? t.slice(0, n) + ' …' : t);
const figOf = (name) => P.figByFile.get(name + '.svg');
const clipOf = (nn) => P.clips.concat(D.clips).find((c) => c.file.startsWith(nn + '_'));
const en = (id) => (curById.get(id) || {}).text;

const NARR = {}; // target -> { kind, what, tells, length, where, material }
const TIT = {};  // target -> { what, material, length, where }
const rowMaterial = (id) => { const i = rowInfo(id); return { id, status: i.status, homePhys: i.homePhys, homeMath: i.homeMath, researchFirst: firstSentence(i.research || ''), research: short(i.research), depends: i.depends }; };
for (const target of [...new Set([...log.missingNarrations, ...tabR.items.filter((i) => i.stub).map((i) => i.target)])]) {
  let m;
  if ((m = /^row:(.+)$/.exec(target))) { const c = chapOf.get(m[1]); NARR[target] = { kind: 'row', what: `the row ${m[1]} told: what it claims, what establishes it, the numbers that matter, where it sits in the chapter ${c.slug}${Q.rows.has(m[1]) ? ' (a row of the study Sound beside light, whose research text is its only prose)' : ''}`, tells: [m[1]], length: /^INP-/.test(m[1]) ? '40–90' : '60–140', where: `${c.slug}.html#${m[1]}, the Racconto register`, material: rowMaterial(m[1]) }; }
  else if ((m = /^section:(.+)$/.exec(target))) { const c = CHAPS.find((x) => x.slug === m[1]); NARR[target] = { kind: 'section', what: `the chapter ${m[1]} of Part III: what it is about, what its rows establish together, what to listen to or look at`, tells: [...c.rows.filter((r) => /^MUS-/.test(r)).slice(0, 6), ...(c.def.clips || []).map((x) => 'clip:' + x.split('_')[0]), ...(c.def.instruments || []).map((x) => 'instrument:' + x)], length: '120–180', where: `${m[1]}.html, under the title`, material: { lead: en(`ch.${m[1]}.lead`), card: en(`ch.${m[1]}.card`), rows: c.rows.map((r) => `${r}: ${rowInfo(r).homePhys}`) } }; }
  else if ((m = /^part:(.+)$/.exec(target))) { const tl = { sound: ['MUS-001', 'MUS-002', 'MUS-003'], twelve: ['MUS-004', 'MUS-005', 'MUS-011'], light: ['MUS-049', 'MUS-055', 'MUS-078', 'MUS-066'] }[m[1]]; NARR[target] = { kind: 'part', what: `Part ${ST.parts.find((p) => p.id === m[1]).roman}, ${en(`part.${m[1]}.title`)}: the part told as one arc, its chapters in order, in the narrator's words`, tells: tl, length: '100–160', where: `${m[1]}.html, under the title`, material: { title: en(`part.${m[1]}.title`), lead: en(`part.${m[1]}.lead`), card: en(`part.${m[1]}.card`), chapters: ST.parts.find((p) => p.id === m[1]).chapters } }; }
  else if ((m = /^bridgech:(.+)$/.exec(target))) { const g = ST.bridgeChapters.find((x) => x.id === m[1]); NARR[target] = { kind: 'bridges', what: `the chapter ${m[1]} of the map of the bridges: what its bridges join, how each grade moved, what decided it`, tells: { twelves: ['drill:§2', 'drill:§3'], bits: ['drill:§4'], dualities: ['drill:§5', 'drill:§7'], ring: ['drill:§13', 'clip:19'], light: ['drill:§6', 'MUS-053', 'MUS-078'] }[m[1]], length: '80–140', where: `bridges.html#bm-${m[1]}, under the chapter's title`, material: { title: en(`bm.${m[1]}.title`), lead: en(`bm.${m[1]}.lead`), bridges: g.bridges.map((n) => (n === 'P' ? { n, bridge: Q.itemOf.get('plasma').bridge.table.get('P').bridge, after: Q.itemOf.get('plasma').bridge.table.get('P').proposed } : { n, bridge: P.bridges.get(n).bridge, before: P.bridges.get(n)[P.bridgesHead[2]], after: P.bridges.get(n)[P.bridgesHead[3]] })) } }; }
  else if (target === 'instrument:stiff') NARR[target] = { kind: 'instrument', what: 'instrument 10 of the Sounds page, the ring with two stiffnesses: what it plays, what to try (the four media, the slider, the three buttons), where its numbers come from', tells: ['MUS-055', 'MUS-052', 'clip:22', 'two_stiffnesses.json'], length: '60–120', where: 'sounds.html#i-stiff, under the title', material: { title: en('i10.h'), lead: en('i10.p'), numbers: en('i10.from') } };
  else if (target === 'clip:22') NARR[target] = { kind: 'clip', what: 'what you hear in 22_two_stiffnesses.wav, after the index\'s "what is heard"', tells: ['clip:22', 'MUS-055'], length: '40–90', where: 'sounds.html#clip-22, under the audio', material: { heard: clipOf('22').heard, built: clipOf('22').built, seconds: clipOf('22').seconds } };
  else if (target === 'checks:light') NARR[target] = { kind: 'page', what: 'the six scripts of Sound beside light as a set: what they compute together, what a control is', tells: ALL_SCRIPTS.slice(9).map((s) => `check:${s}.py`), length: '60–120', where: 'checks.html#light-scripts, under the heading', material: { heading: en('checks.light'), note: en('checks.light.p') } };
  else if (target === 'pictures:light') NARR[target] = { kind: 'page', what: 'the four figures of Sound beside light as a set', tells: Q.figures.map((f) => 'fig:' + f.file.replace(/\.svg$/, '')), length: '60–120', where: 'pictures.html#pics-light, under the heading', material: { heading: en('pics.light'), figures: Q.figures.map((f) => ({ file: f.file, caption: f.caption })) } };
  else NARR[target] = { kind: 'other', what: target, tells: [], length: '60–120', where: '?', material: {} };
}
for (const target of [...new Set([...log.missingTitoli, ...tabT.items.filter((i) => i.stub).map((i) => i.target)])]) {
  let m;
  if ((m = /^row:(.+)$/.exec(target))) { const c = chapOf.get(m[1]); TIT[target] = { what: `the one-line claim of the row ${m[1]} (chapter ${c.slug}), the head of its block: ≤ 14 words, no final period`, material: rowMaterial(m[1]), length: '≤ 14 words', where: `${c.slug}.html#${m[1]}, the head of the block` }; }
  else if ((m = /^part:(.+)$/.exec(target))) TIT[target] = { what: `the title of Part ${ST.parts.find((p) => p.id === m[1]).roman}`, material: { en: en(`part.${m[1]}.title`), lead: en(`part.${m[1]}.lead`) }, length: '≤ 6 words', where: `${m[1]}.html (h1), the home card, the crumbs` };
  else if ((m = /^card:part:(.+)$/.exec(target))) TIT[target] = { what: `the home card's text for Part ${ST.parts.find((p) => p.id === m[1]).roman}: two sentences at most`, material: { en: en(`part.${m[1]}.card`), lead: en(`part.${m[1]}.lead`) }, length: '20–45 words', where: 'index.html, the part card' };
  else if ((m = /^section:([a-z]+)(:sub)?$/.exec(target))) { const sl = m[1]; TIT[target] = { what: m[2] ? `one line under the title of the chapter ${sl}` : `the title of the chapter ${sl}: the h1, the crumbs, the cards and the previous / next links`, material: { en: en(`ch.${sl}.title`), lead: en(`ch.${sl}.lead`), card: en(`ch.${sl}.card`) }, length: m[2] ? 'one line, ≤ 18 words' : '≤ 8 words', where: `${sl}.html` }; }
  else if ((m = /^chain:(.+)$/.exec(target))) TIT[target] = { what: `the heading of the rows' list on the chapter ${m[1]}`, material: { en: en('sec.pack.title'), chapter: en(`ch.${m[1]}.title`) }, length: '≤ 10 words', where: `${m[1]}.html, the heading above the rows` };
  else if ((m = /^card:section:(.+)$/.exec(target))) TIT[target] = { what: `the card text of the chapter ${m[1]} on its part's page: two or three sentences`, material: { en: en(`ch.${m[1]}.card`), lead: en(`ch.${m[1]}.lead`) }, length: '30–60 words', where: `the page of the part, the chapter's card` };
  else if ((m = /^bridgech:(.+)$/.exec(target))) TIT[target] = { what: `the title of the chapter ${m[1]} of the map of the bridges`, material: { en: en(`bm.${m[1]}.title`), lead: en(`bm.${m[1]}.lead`) }, length: '≤ 6 words', where: `bridges.html#bm-${m[1]}` };
  else if (target === 'bridge:P') TIT[target] = { what: 'the Italian name of the twelfth line of the map: the plasma coupling', material: Q.itemOf.get('plasma').bridge.table.get('P'), length: 'one line, as bridge 4 reads', where: 'bridges.html#bridge-P' };
  else if (target === 'bridge:P:why') TIT[target] = { what: 'what decided the grade of the twelfth line', material: { en: en('b.plasma.why'), after: Q.itemOf.get('plasma').bridge.table.get('P').proposed }, length: 'one sentence', where: 'bridges.html#bridge-P' };
  else if ((m = /^fig:(.+)$/.exec(target))) { const f = figOf(m[1]); TIT[target] = { what: `the Italian caption of the figure ${m[1]}.svg (Sound beside light)`, material: { file: f.file, caption: f.caption, data: f.data, row: f.row }, length: '1–3 sentences', where: 'the figure, on its chapters and on pictures.html' }; }
  else if ((m = /^clip:(.+)$/.exec(target))) { const c = clipOf(m[1]); TIT[target] = { what: `the short title of the clip ${c.file}`, material: { file: c.file, seconds: c.seconds, heard: c.heard }, length: '≤ 10 words', where: `sounds.html#clip-${m[1]}` }; }
  else if ((m = /^lens:(\d+)$/.exec(target))) { const e = D.lens.dictionary[+m[1] - 1]; TIT[target] = { what: `the Italian term of the lens entry ${m[1]} (the music side), the first cell of its row`, material: { n: +m[1], atlas: e.atlas, term: e.term, match: e.match, evidence: e.evidence, rows: e.rows }, length: 'a term, ≤ 8 words', where: `dictionary.html#lens-${m[1]}` }; }
  else if ((m = /^check:(music_\w+)$/.exec(target))) { const sc = P.scripts.get(m[1]); TIT[target] = { what: `one line: what ${m[1]}.py computes`, material: { script: `${m[1]}.py`, what: sc.head, groups: sc.order }, length: 'one line, ≤ 30 words', where: `checks.html#${m[1]}, above the counts` }; }
  else if (target === 'instrument:stiff') TIT[target] = { what: 'the title of instrument 10', material: { en: en('i10.h') }, length: '≤ 8 words', where: 'sounds.html#i-stiff' };
  else TIT[target] = { what: target, material: {}, length: '?', where: '?' };
}

// ---- 2. stubs
const stubText = (what) => `[bozza] ${what.replace(/pack/g, 'pk')}`; // the stub names its target; the English material is in MANIFEST_R3.json
const added = { narrations: [], titles: [], strings: [], changed: [] };
for (const [target, n] of Object.entries(NARR)) if (!tabR.items.some((i) => i.target === target)) { tabR.items.push({ id: 'r:' + target, target, tells: n.tells, text: stubText('r:' + target), why: 'stub: the narrator tells this target (MANIFEST_R3.json)', stub: true }); added.narrations.push(target); }
for (const [target, t] of Object.entries(TIT)) if (!tabT.items.some((i) => i.target === target)) { tabT.items.push({ id: 't:' + target, target, text: stubText('t:' + target), why: 'stub: the narrator titles this target (MANIFEST_R3.json)', stub: true }); added.titles.push(target); }
const have = new Map(tabS.strings.map((s) => [s.id, s]));
const ITneed = new Set(log.missingStrings);
const enOnlyMarked = [];
const strings_new = [], strings_changed = [];
for (const s of cur.strings) {
  const it = have.get(s.id);
  const old = r2ById.get(s.id);
  if (!it && !ITneed.has(s.id)) { if (!s.enOnly) { s.enOnly = true; enOnlyMarked.push(s.id); } continue; }
  if (!it) { tabS.strings.push({ id: s.id, text: stubText('s:' + s.id), why: 'stub: the narrator renders this string (MANIFEST_R3.json)', stub: true }); strings_new.push({ id: s.id, text: s.text, why: s.why, optional: !!s.optional }); added.strings.push(s.id); }
  else if (it.stub) { (old ? strings_changed : strings_new).push(old ? { id: s.id, text: s.text, was: old.text, previousIt: it.previousIt, why: s.why } : { id: s.id, text: s.text, why: s.why, optional: !!s.optional }); }
  else if (old && old.text !== s.text) { tabS.strings[tabS.strings.indexOf(it)] = { id: s.id, text: stubText('s:' + s.id), previousIt: it.text, why: 'stub: the English text changed (MANIFEST_R3.json); the previous Italian is kept in previousIt', stub: true }; strings_changed.push({ id: s.id, text: s.text, was: old.text, previousIt: it.text, why: s.why }); added.changed.push(s.id); }
}
// Italian strings the Italian pages never show: not needed (part, chapter and bridge-chapter titles and leads are told by the narrator's targets)
const ITONLY_EN = new Set(['part.sound.title', 'part.twelve.title', 'part.light.title', 'part.question.title']);
for (const id of ITONLY_EN) { /* these are the English page's own; the Italian page tells the part with t:part:* */ }
if (enOnlyMarked.length) W(path.join(GEN, 'content', 'strings.json'), cur);
W(path.join(IT, 'strings_it.json'), tabS); W(path.join(IT, 'racconto.json'), tabR); W(path.join(IT, 'titoli.json'), tabT); W(path.join(IT, 'retired_r2.json'), retired);

// ---- 3. the manifest
const stubN = tabR.items.filter((i) => i.stub).map((i) => i.target);
const stubT = tabT.items.filter((i) => i.stub).map((i) => i.target);
const narrations = stubN.map((t) => ({ target: t, id: 'r:' + t, ...(NARR[t] || {}) }));
const titles = stubT.map((t) => ({ target: t, id: 't:' + t, ...(TIT[t] || {}) }));
const byKind = (a) => a.reduce((o, x) => { o[x.kind || 'title'] = (o[x.kind || 'title'] || 0) + 1; return o; }, {});
// the review list: targets whose Atlas row changed text in 4.4.10, and Italian that now stands on other English
const review = [
  { target: 'row:MUS-049', priority: 'doubtful', why: 'MUS-049 is rewritten by the pack of round 38 (reading / ours becomes computation / computed, with new sources): the narration of release 2 told the old row. The site now shows the row from the study\'s file, status computed.' },
  { target: 'row:MUS-016', priority: 'low', why: 'homeMath changed in 4.4.10; the narration stands on the study\'s prose, which did not change' },
  { target: 'row:MUS-037', priority: 'low', why: 'homeMath changed in 4.4.10' },
  { target: 'row:MUS-046', priority: 'low', why: 'homeMath changed in 4.4.10' },
  { target: 'row:MUS-004', priority: 'low', why: 'text and depends changed in 4.4.10' },
  { target: 'row:LNS-137', priority: 'low', why: 'text changed in 4.4.10' },
  { target: 'row:SPR-M01', priority: 'low', why: 'depends changed in 4.4.10' },
  { target: 'section:tone', priority: 'check', why: 'the chapter lost MUS-045 … MUS-049 (they stand in the chapter Sound and light, side by side); its narration, if it tells them, should stop at MUS-044' },
  { target: 'page:bridges, page:bridges:sub, page:bridges:head', priority: 'reword', why: 'the page is a map of five chapters now (12 lines, no row blocks); b.sub and b.lead changed' },
  { target: 'page:home, page:sounds, page:checks, page:pictures, page:sources, page:dictionary, page:about', priority: 'check', why: 'counts changed (22 clips, 10 instruments, 17 scripts, 29 figures, 47 lens entries); about.* and method.* changed; the Italian tells these pages in numbers' },
  { target: '~25 rows of the former pack (MUS-014 … MUS-049, INP-131/132)', priority: 'low', why: 'their research texts were edited by D115 in 4.4.10 (small folds, e.g. "SPR-M16\'s pluck"); the narrations stand on the studies\' prose' },
];
const manifest = {
  about: 'The manifest of the Italian side of The Sounding View, release 3, for the two narrators (it/VOICE_IT.md): exactly the targets and strings that need Italian, each carrying "stub": true in the three tables (racconto.json, titoli.json, strings_it.json) until it is filled. The tables of release 2 carry over for every target that still exists; moved targets were renamed with their text; retired ones are in retired_r2.json. Fill an entry by replacing its text, deleting "stub" and writing a real "why". Each narration: target, what it is, tells (the ids it may tell, checked against the site), the English material, length in words, where it renders. Each title: the same, with the length asked. Each string: the English text and why.',
  written: new Date().toISOString(),
  rules: J(path.join(IT, 'MANIFEST.json')).rules,
  counts: { narrations: narrations.length, narrationsByKind: byKind(narrations), titles: titles.length, strings_new: strings_new.length, strings_changed: strings_changed.length, retired: { narrations: retired.narrations.length, titles: retired.titles.length, strings: retired.strings.length } },
  renamed: RENAME,
  narrations, titles, strings_new, strings_changed, review,
};
W(path.join(IT, 'MANIFEST_R3.json'), manifest);
const mt = J(path.join(IT, 'MANIFEST_TITOLI.json'));
const known = new Set(tabT.items.map((i) => i.target));
mt.targets = mt.targets.filter((t) => known.has(t.target));
for (const t of titles) if (!mt.targets.some((x) => x.target === t.target)) mt.targets.push({ target: t.target, id: t.id, what: t.what, material: t.material, length: t.length, where: t.where });
for (const t of tabT.items) if (!mt.targets.some((x) => x.target === t.target)) mt.targets.push({ target: t.target, id: t.id, what: t.target, material: {}, length: '', where: '' });
mt.counts = { ...mt.counts, targets: mt.targets.length, release: 3 };
W(path.join(IT, 'MANIFEST_TITOLI.json'), mt);
console.log(`${enOnlyMarked.length} strings marked enOnly (the Italian pages never show them)`);
console.log(`MANIFEST_R3.json: ${narrations.length} narrations ${JSON.stringify(manifest.counts.narrationsByKind)}, ${titles.length} titles, ${strings_new.length} new strings, ${strings_changed.length} changed; retired ${retired.narrations.length} narrations, ${retired.titles.length} titles, ${retired.strings.length} strings`);
